param([switch]$NoBackup, [string]$BackupTo = "", [switch]$FromApps)
$ErrorActionPreference = "Stop"
$Dest = Split-Path -Parent $MyInvocation.MyCommand.Path
$Dest = [IO.Path]::GetFullPath($Dest).TrimEnd('\')
$Name = (Get-Content (Join-Path $Dest "NAME.txt") -Raw).Trim()
function Tell($text, $icon = "Information") {
    if (-not $FromApps) { return }
    Add-Type -AssemblyName System.Windows.Forms
    [void][System.Windows.Forms.MessageBox]::Show($text, "$Name", "OK", $icon)
}
trap { Tell "$Name couldn't be fully removed." "Warning"; break }
function Folder($n) { [Environment]::GetFolderPath($n, 'Create') }

function Stop-Procs($procs) {
    $ids = @($procs | Where-Object { $_ } | ForEach-Object { $_.ProcessId })
    foreach ($id in $ids) { Stop-Process -Id $id -Force -ErrorAction SilentlyContinue }
    if ($ids) { try { Wait-Process -Id $ids -Timeout 20 -ErrorAction SilentlyContinue } catch { } }
}

$browser = $null
$mailFwd = $false
try {
    $st = Get-Content (Join-Path $Dest "app\settings.json") -Raw -Encoding UTF8 | ConvertFrom-Json
    $mailFwd = $st.mail_source -eq "forward" -and [bool][string]$st.mail_address
    $bh = $st.browser_home
    if ($bh) {
        $bh = [Environment]::ExpandEnvironmentVariables([string]$bh)
        if (-not [IO.Path]::IsPathRooted($bh)) { $bh = Join-Path (Join-Path $Dest "app") $bh }
        $browser = [IO.Path]::GetFullPath($bh).TrimEnd('\')
    }
} catch { }

$inDest = "*" + [Management.Automation.WildcardPattern]::Escape("$Dest\") + "*"
Stop-Procs (Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and (
                                                           ($_.Name -in @("python.exe", "pythonw.exe", "llama-server.exe", "msedge.exe", "chrome.exe",
                                                                          "soffice.exe", "soffice.bin") -and $_.CommandLine -and $_.CommandLine -like $inDest) -or
                                                           ($_.ExecutablePath -and $_.ExecutablePath -like $inDest)) })
if ($browser) {
    $rx = [Regex]::Escape($browser) + '(["\\\s]|$)'
    Stop-Procs (Get-CimInstance Win32_Process | Where-Object { $_.Name -in @("chrome.exe", "msedge.exe") -and $_.CommandLine -and $_.CommandLine -match $rx })
}
if (-not $NoBackup) {
    $root = if ($BackupTo) { $BackupTo } else { Folder "MyDocuments" }
    $bak = Join-Path $root ("$Name backup " + (Get-Date -Format "yyyy-MM-dd HHmm"))
    New-Item -ItemType Directory -Force $bak | Out-Null
    Get-ChildItem (Join-Path $Dest "app") -File | Where-Object { $_.Extension -in ".json", ".csv", ".xlsx" } |
        Copy-Item -Destination $bak
    foreach ($d in @("profile", "Categories")) {
        if (Test-Path (Join-Path $Dest $d)) { Copy-Item (Join-Path $Dest $d) $bak -Recurse }
    }
    $runs = Join-Path $Dest "app\runs"
    if (Test-Path $runs) {
        & robocopy $runs (Join-Path $bak "runs") /E /XD (Join-Path $runs "update") /NFL /NDL /NJH /NJS /NP /R:1 /W:1 | Out-Null
        if ($LASTEXITCODE -ge 8) { throw "could not back up $runs (robocopy $LASTEXITCODE) - nothing was removed" }
    }
    Write-Host "[$Name] your data was copied to $bak"
}
if ($browser -and (Test-Path -LiteralPath $browser) -and ((Test-Path -LiteralPath (Join-Path $browser "Local State")) -or
                                                          -not (Get-ChildItem -LiteralPath $browser -Force))) {
    try {
        Remove-Item -LiteralPath $browser -Recurse -Force
        $parent = Split-Path $browser
        if ((Split-Path $parent -Leaf) -eq $Name -and -not (Get-ChildItem -LiteralPath $parent -Force)) { Remove-Item -LiteralPath $parent -Force }
        Write-Host "[$Name] removed its browser profile $browser"
    } catch { Write-Host "[$Name] could not remove its browser profile $browser ($_)" }
}
foreach ($l in @((Join-Path (Folder "Programs") "$Name.lnk"),
                 (Join-Path (Folder "Startup") "$Name tray.lnk"),
                 (Join-Path (Folder "Startup") "$Name daily run.lnk"))) {
    if (Test-Path $l) { Remove-Item $l -Force }
}
$key = Join-Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall" (& { param($d) "$Name-" + ([BitConverter]::ToString(
    [Security.Cryptography.SHA1]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($d.ToLower()))) -replace "-", "").Substring(0, 8) } $Dest)
if (Test-Path $key) { Remove-Item $key -Recurse -Force }
Get-ChildItem "HKCU:\Software\Classes\AppUserModelId" -ErrorAction SilentlyContinue |
    Where-Object { [string](Get-ItemProperty $_.PSPath).IconUri -like "$($Dest.TrimEnd('\'))\*" } | Remove-Item -Recurse -Force
if ($FromApps -and (Test-Path (Join-Path $Dest "runtime\python.exe"))) {
    $py = @'
import vault, config
if config.setting('mail_source') == 'forward':
    try:
        import fwdmail
        print('job mail account removed:', bool(fwdmail.forget().get('forgotten')))
    except Exception as e:
        print('job mail account not removed:', e)
print('secrets removed:', vault.forget_all())
'@
    Push-Location (Join-Path $Dest "app")
    try { & (Join-Path $Dest "runtime\python.exe") -E -s -c $py | Write-Host } catch { }
    Pop-Location
}
Set-Location $env:TEMP
Remove-Item $Dest -Recurse -Force
Write-Host "[$Name] removed"
Tell ("$Name was removed." + $(if ($bak) { "`n`nYour data (profile, answers, applications, resumes) was saved to:`n$bak" } else { "" }) +
      $(if ($mailFwd) { "`n`nGmail still sends copies of your job mail to $Name. To stop that, remove the $Name forwarding " +
                        "address (Gmail settings > Forwarding and POP/IMAP) and the $Name filters (Filters and Blocked " +
                        "Addresses). Gmail's settings open when you press OK." } else { "" }))
if ($FromApps -and $mailFwd) { Start-Process "https://mail.google.com/mail/u/0/#settings/fwdandpop" }
