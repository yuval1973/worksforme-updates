param([switch]$Assemble, [string]$Pkg = "", [string]$Reuse = "", [string]$Dest = "")
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Name = (Get-Content (Join-Path $Here "NAME.txt") -Raw).Trim()
$C = Get-Content (Join-Path $Here "components.json") -Raw | ConvertFrom-Json
if (-not $Dest) { $Dest = Join-Path $env:LOCALAPPDATA "Programs\$Name" }
if (-not $Reuse -and (Test-Path (Join-Path $Dest "components.json"))) { $Reuse = $Dest }
$Work = Join-Path $env:LOCALAPPDATA "$Name-setup"
$Cache = Join-Path $Work "cache"
if (-not $Pkg) { $Pkg = Join-Path $Work "pkg" }
New-Item -ItemType Directory -Force $Cache | Out-Null
$Log = Join-Path $Work "setup.log"
$script:started = Get-Date
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Add-Type -AssemblyName System.IO.Compression, System.IO.Compression.FileSystem

function Log($m) { try { Add-Content -Path $Log -Value ("{0:yyyy-MM-dd HH:mm:ss} {1}" -f (Get-Date), $m) -ErrorAction Stop } catch { } }

$old = if ($Reuse -and (Test-Path (Join-Path $Reuse "components.json"))) { Get-Content (Join-Path $Reuse "components.json") -Raw | ConvertFrom-Json } else { $null }
function Same($a, $b) { $a -and $b -and $a.sha256 -eq $b.sha256 }
$runtimeKey = { param($x) ($x.python.sha256 + "|" + (($x.wheels | ForEach-Object sha256 | Sort-Object) -join ",")) }
$reuseRuntime = $old -and ((& $runtimeKey $old) -eq (& $runtimeKey $C)) -and (Test-Path (Join-Path $Reuse "runtime\python.exe"))
$reuseEngine = (Same $old.engine $C.engine) -and (Test-Path (Join-Path $Reuse "engine\llama-server.exe"))
$Bundle = Join-Path $Here "bundle"
$hasBundle = Test-Path (Join-Path $Bundle "bundle.json")
$wasSigned = $Reuse -and (Test-Path (Join-Path $Reuse "engine\signed-bundle.json"))
$sysLO = @((Join-Path $env:ProgramFiles "LibreOffice\program\soffice.exe"), (Join-Path ${env:ProgramFiles(x86)} "LibreOffice\program\soffice.exe")) |
    Where-Object { Test-Path $_ } | Select-Object -First 1
$hasWord = Test-Path "Registry::HKEY_CLASSES_ROOT\Word.Application\CLSID"
$wantLO = $C.libreoffice -and (($env:JOBBOT_OWN_LIBREOFFICE) -or -not ($sysLO -or $hasWord))
$keepLO = $wantLO -and (Same $old.libreoffice $C.libreoffice) -and (Test-Path (Join-Path $Reuse "libreoffice\program\soffice.exe"))
$needLO = $wantLO -and -not $keepLO
$get = @()
if (-not $reuseRuntime) { $get += $C.python; $get += $C.wheels }
if (-not $reuseEngine -and -not $hasBundle) { $get += $C.engine }
if ($needLO) { $get += $C.libreoffice }
$getBytes = [long](($get | Measure-Object size -Sum).Sum)

$UI = $null
if (-not $Assemble) {
    Add-Type -Namespace Native -Name Con -MemberDefinition @'
[DllImport("kernel32.dll")] public static extern IntPtr GetConsoleWindow();
[DllImport("kernel32.dll")] public static extern uint GetConsoleProcessList(uint[] list, uint count);
[DllImport("user32.dll")] public static extern bool ShowWindow(IntPtr h, int cmd);
'@
    $cw = [Native.Con]::GetConsoleWindow()
    if ($cw -ne [IntPtr]::Zero -and [Native.Con]::GetConsoleProcessList((New-Object uint32[] 8), 8) -le 1) { [void][Native.Con]::ShowWindow($cw, 0) }
    Add-Type -AssemblyName System.Windows.Forms, System.Drawing
    [System.Windows.Forms.Application]::EnableVisualStyles()
    $f = New-Object System.Windows.Forms.Form
    $f.Text = "$Name setup"; $f.ClientSize = New-Object System.Drawing.Size(340, 196)
    $f.FormBorderStyle = "FixedToolWindow"; $f.ControlBox = $false; $f.ShowInTaskbar = $false; $f.TopMost = $true
    $f.Font = New-Object System.Drawing.Font("Segoe UI", 9)
    $wa = [System.Windows.Forms.Screen]::PrimaryScreen.WorkingArea
    $f.StartPosition = "Manual"; $f.Location = New-Object System.Drawing.Point(($wa.Right - $f.Width - 12), ($wa.Bottom - $f.Height - 12))
    $head = New-Object System.Windows.Forms.Label; $head.Text = "Setting up $Name. This may take a few minutes."
    $head.SetBounds(14, 10, 316, 18); $f.Controls.Add($head)
    $steps = @("Check this PC", "Download the components", "Prepare", "Install")
    $rows = @{}
    for ($i = 0; $i -lt $steps.Count; $i++) {
        $l = New-Object System.Windows.Forms.Label; $l.Text = "    " + $steps[$i]; $l.SetBounds(20, 36 + $i * 20, 310, 18)
        $l.ForeColor = [System.Drawing.Color]::Gray; $f.Controls.Add($l); $rows[$i] = $l
    }
    $bar = New-Object System.Windows.Forms.ProgressBar; $bar.SetBounds(20, 122, 300, 12); $f.Controls.Add($bar)
    $now = New-Object System.Windows.Forms.Label; $now.SetBounds(20, 140, 300, 18); $f.Controls.Add($now)
    $btn = New-Object System.Windows.Forms.Button; $btn.Text = "Cancel"; $btn.SetBounds(236, 162, 84, 26); $f.Controls.Add($btn)
    $script:cancel = $false
    $btn.Add_Click({ if ($btn.Text -eq "Close") { $f.Close() } else { $script:cancel = $true; $now.Text = "Stopping..." } })
    $f.Add_FormClosing({ if ($btn.Text -ne "Close" -and $_.CloseReason -eq "UserClosing") { $_.Cancel = $true } })
    $f.Show(); [System.Windows.Forms.Application]::DoEvents()
    $UI = @{ form = $f; rows = $rows; bar = $bar; now = $now; btn = $btn; steps = $steps }
}
function Step($i, $state) {
    Log "step $i $state"
    if (-not $UI) { return }
    $mark = @{ run = [char]0x25B6; done = [char]0x2714; fail = [char]0x2716 }[$state]
    $UI.rows[$i].Text = " $mark  " + $UI.steps[$i]
    $UI.rows[$i].ForeColor = @{ run = [System.Drawing.Color]::Black; done = [System.Drawing.Color]::Green; fail = [System.Drawing.Color]::Red }[$state]
    if ($state -eq "run") { Span 0 100; $UI.bar.Value = 0 }
    [System.Windows.Forms.Application]::DoEvents()
}
$script:spanLo = 0; $script:spanHi = 100
function Span($lo, $hi) { $script:spanLo = $lo; $script:spanHi = $hi }
function Say($text, $pct = -1) {
    if (-not $UI) { return }
    if ($env:JOBBOT_TEST_CANCEL_AFTER -match '^\d+$' -and ((Get-Date) - $script:started).TotalSeconds -gt [int]$env:JOBBOT_TEST_CANCEL_AFTER) { $script:cancel = $true }
    if ($pct -ge 0) { $UI.bar.Value = [int][Math]::Min(100, $script:spanLo + ($script:spanHi - $script:spanLo) * [Math]::Min(100, $pct) / 100) }
    [System.Windows.Forms.Application]::DoEvents()
    if ($script:cancel) { throw "cancelled - run the setup again to continue where it stopped" }
}
function Size-Of($p) {
    if (-not (Test-Path $p)) { return [long]0 }
    [long](Get-ChildItem $p -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum
}
function Wait-Done($proc, [scriptblock]$done, $total) {
    $null = $proc.Handle
    $pct = 0; $next = Get-Date
    while (-not $proc.HasExited) {
        if ($UI -and (Get-Date) -ge $next) { $pct = 100 * [Math]::Min(0.99, [double](& $done) / [Math]::Max(1, $total)); $next = (Get-Date).AddSeconds(1.5) }
        Say "" $pct; Start-Sleep -Milliseconds 300
    }
    Say "" 100
}
function Msi-Bytes($msi) {
    $wi = $db = $v = $null
    try {
        $wi = New-Object -ComObject WindowsInstaller.Installer
        $db = $wi.GetType().InvokeMember("OpenDatabase", "InvokeMethod", $null, $wi, @($msi, 0))
        $v = $db.GetType().InvokeMember("OpenView", "InvokeMethod", $null, $db, @('SELECT `FileSize` FROM `File`'))
        [void]$v.GetType().InvokeMember("Execute", "InvokeMethod", $null, $v, $null)
        $sum = [long]0; $n = 0
        while ($r = $v.GetType().InvokeMember("Fetch", "InvokeMethod", $null, $v, $null)) {
            $sum += $r.GetType().InvokeMember("IntegerData", "GetProperty", $null, $r, 1)
            if (++$n % 500 -eq 0) { Say "" }
        }
        [void]$v.GetType().InvokeMember("Close", "InvokeMethod", $null, $v, $null)
        return $sum
    } catch {
        if ("$_" -like "*cancelled*") { throw }
        return [long]1600MB
    } finally {
        foreach ($o in $v, $db, $wi) { if ($o) { [void][Runtime.InteropServices.Marshal]::ReleaseComObject($o) } }
    }
}
function Remove-Work($all) {
    if ($Assemble) { return }
    $list = @($Pkg, (Join-Path $Work "py"), (Join-Path $Work "engine"), (Join-Path $Work "lo"),
              (Join-Path $env:TEMP "$Name-$($C.libreoffice.file)"))
    if ($all) { $list += $Cache }
    foreach ($x in $list) {
        for ($i = 0; $i -lt 30 -and (Test-Path $x); $i++) {
            Remove-Item $x -Recurse -Force -ErrorAction SilentlyContinue
            if (Test-Path $x) { if ($UI) { [System.Windows.Forms.Application]::DoEvents() }; Start-Sleep 1 }
        }
        if (Test-Path $x) { Log "could not remove $x" }
    }
}

function Get-Piece($c) {
    $dir = Join-Path $Cache $c.sha256.Substring(0, 16); New-Item -ItemType Directory -Force $dir | Out-Null
    $out = Join-Path $dir $c.file
    if ((Test-Path $out) -and ((Get-FileHash $out -Algorithm SHA256).Hash -eq $c.sha256.ToUpper())) { return $out }
    $part = "$out.part"
    Log "download $($c.file)"
    for ($try = 1; $try -le 8; $try++) {
        $have = if (Test-Path $part) { (Get-Item $part).Length } else { 0 }
        try {
            $u = if ($try -gt 3 -and $c.mirror) { $c.mirror } else { $c.url }
            $req = [System.Net.HttpWebRequest]::Create($u); $req.UserAgent = "$Name-setup"; $req.Timeout = 60000
            if ($have -gt 0) { $req.AddRange([long]$have) }
            $res = $req.GetResponse()
            $mode = if ($have -gt 0 -and [int]$res.StatusCode -eq 206) { "Append" } else { $have = 0; "Create" }
            $in = $res.GetResponseStream(); $fs = New-Object System.IO.FileStream($part, $mode)
            $buf = New-Object byte[] 1048576; $got = 0
            try {
                while (($n = $in.Read($buf, 0, $buf.Length)) -gt 0) {
                    $fs.Write($buf, 0, $n); $got += $n
                    Say $c.file (100 * ($have + $got) / $c.size)
                }
            } finally { $fs.Close(); $in.Close(); $res.Close() }
            if ((Get-Item $part).Length -ge $c.size) { break }
        } catch {
            if ("$_" -like "*cancelled*") { throw }
            Log "download $($c.file) try $try failed: $_"; Start-Sleep -Seconds ([Math]::Min(30, 3 * $try))
        }
    }
    if ((Get-FileHash $part -Algorithm SHA256).Hash -ne $c.sha256.ToUpper()) {
        if ((Get-Item $part).Length -ge $c.size) { Remove-Item $part -Force }
        throw "$($c.file) did not download completely or is not the published file - run the setup again"
    }
    Move-Item $part $out -Force
    return $out
}

try {
    Step 0 run
    if (-not [Environment]::Is64BitOperatingSystem) { throw "$Name needs 64-bit Windows" }
    $sac = (Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Control\CI\Policy" -ErrorAction SilentlyContinue).VerifiedAndReputablePolicyState
    $trusted = $hasBundle -and ((Get-Content (Join-Path $Bundle "bundle.json") -Raw | ConvertFrom-Json).method -in @("azure", "certum"))
    if ($sac -eq 1 -and -not $trusted) { throw "smart app control is on" }
    if ($sac -eq 2) { Log "Smart App Control: evaluation mode - nothing is blocked now; Windows may switch it on later" }
    if ($wasSigned -and -not $hasBundle -and -not ($reuseEngine -and $reuseRuntime)) {
        throw "this update changes signed parts but carries no signed bundle - it needs the full package"
    }
    $free = (Get-PSDrive ($env:LOCALAPPDATA.Substring(0, 1))).Free / 1GB
    $need = if ($needLO) { 5 } else { 3 }
    if ($free -lt $need) { throw ("only {0:N1} GB free on the disk - {1} needs about {2} GB, plus the AI model later" -f $free, $Name, $need) }
    if (Test-Path $Pkg) { Remove-Item $Pkg -Recurse -Force }
    New-Item -ItemType Directory -Force $Pkg | Out-Null
    Step 0 done

    Step 1 run
    $piece = @{}; $done = [long]0
    foreach ($one in $get) {
        Span (100 * $done / [Math]::Max(1, $getBytes)) (100 * ($done + $one.size) / [Math]::Max(1, $getBytes)); $done += $one.size
        $piece[$one.file] = Get-Piece $one
    }
    Step 1 done

    Step 2 run
    $loShare = if ($needLO) { 60 } else { 0 }
    $pipTo = 95 - $loShare
    Span 0 5
    if ($reuseRuntime) {
        Log "re-using Python + packages from $Reuse"
        & robocopy (Join-Path $Reuse "runtime") (Join-Path $Pkg "runtime") /E /NFL /NDL /NJH /NJS /NP | Out-Null
    } else {
        $tmp = Join-Path $Work "py"; if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
        [System.IO.Compression.ZipFile]::ExtractToDirectory($piece[$C.python.file], $tmp)
        New-Item -ItemType Directory -Force (Join-Path $tmp "Lib\site-packages") | Out-Null
        $pth = Get-ChildItem $tmp -Filter "python3*._pth" | Select-Object -First 1
        $lib = Get-ChildItem $tmp -Filter "python3*.zip" | Select-Object -First 1
        if (-not $pth -or -not $lib) { throw "the Python package is not python.org's embeddable one (no ._pth / library zip)" }
        Set-Content -Path $pth.FullName -Encoding ASCII -Value @($lib.Name, ".", "Lib\site-packages", "..\app", "..\app\product", "import site")
        Move-Item $tmp (Join-Path $Pkg "runtime")
    }
    Say "Python" 100

    Span 5 10
    if ($hasBundle) {
        Log "the engine from the signed bundle"
        & robocopy (Join-Path $Bundle "engine") (Join-Path $Pkg "engine") /E /NFL /NDL /NJH /NJS /NP | Out-Null
        Copy-Item (Join-Path $Bundle "bundle.json") (Join-Path $Pkg "engine\signed-bundle.json") -Force
    } elseif ($reuseEngine) {
        Log "re-using the engine from $Reuse"
        & robocopy (Join-Path $Reuse "engine") (Join-Path $Pkg "engine") /E /NFL /NDL /NJH /NJS /NP | Out-Null
    } else {
        $tmp = Join-Path $Work "engine"; if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
        [System.IO.Compression.ZipFile]::ExtractToDirectory($piece[$C.engine.file], $tmp)
        New-Item -ItemType Directory -Force (Join-Path $Pkg "engine") | Out-Null
        Get-ChildItem $tmp -Recurse -File | Where-Object {
            ($_.Name -eq "llama-server.exe" -or $_.Extension -eq ".dll" -or $_.Name -like "LICENSE*") -and
            -not ($_.Name -like "*-impl.dll" -and $_.Name -ne "llama-server-impl.dll") } |
            Copy-Item -Destination (Join-Path $Pkg "engine")
    }
    Say "the engine" 100

    Span 10 $pipTo
    if (-not $reuseRuntime) {
        $files = @($C.wheels | ForEach-Object { $piece[$_.file] })
        $site = Join-Path $Pkg "runtime\Lib\site-packages"
        $n = 0
        foreach ($f in $files) {
            $z = [System.IO.Compression.ZipFile]::OpenRead($f)
            try {
                foreach ($e in $z.Entries) {
                    if (-not $e.Name) { continue }
                    $rel = $e.FullName -replace '/', '\'
                    if ($rel -match '^[^\\]+\.data\\(purelib|platlib)\\(.+)$') { $rel = $Matches[2] }
                    elseif ($rel -match '^[^\\]+\.data\\') { continue }
                    $to = Join-Path $site $rel
                    New-Item -ItemType Directory -Force (Split-Path $to) | Out-Null
                    [System.IO.Compression.ZipFileExtensions]::ExtractToFile($e, $to, $true)
                }
            } finally { $z.Dispose() }
            $n++
            Say "the packages" ([int](100 * $n / $files.Count))
        }
        Log "unpacked $n packages into $site"
    }
    $site = Join-Path $Pkg "runtime\Lib\site-packages"
    if ($hasBundle) {
        & robocopy (Join-Path $Bundle "site-packages") $site /E /NFL /NDL /NJH /NJS /NP | Out-Null
        Log "the compiled package parts from the signed bundle"
    }
    Remove-Item (Join-Path $site "greenlet\tests") -Recurse -Force -ErrorAction SilentlyContinue

    Span $pipTo 95
    if (-not $wantLO) {
        Log $(if ($hasWord) { "Microsoft Word makes the PDFs - no LibreOffice download" } else { "LibreOffice on this PC: $sysLO" })
    } elseif ($keepLO) {
        Log "re-using LibreOffice in $Reuse"
    } else {
        $tmp = Join-Path $Work "lo"; if (Test-Path $tmp) { Remove-Item $tmp -Recurse -Force }
        $run = Join-Path $env:TEMP "$Name-$($C.libreoffice.file)"; Copy-Item $piece[$C.libreoffice.file] $run -Force
        try {
            $bytes = if ($UI) { Msi-Bytes $run } else { 1 }
            for ($try = 1; ; $try++) {
                $msiP = Start-Process msiexec.exe -ArgumentList "/a `"$run`" /qn TARGETDIR=`"$tmp`"" -PassThru -WindowStyle Hidden
                $t0 = Get-Date
                Wait-Done $msiP {
                    if ($env:JOBBOT_TEST_CANCEL_AFTER -eq "unpack" -and ((Get-Date) - $t0).TotalSeconds -gt 20) { $script:cancel = $true }
                    Size-Of $tmp } $bytes
                if ($msiP.ExitCode -ne 1618 -or $try -ge 6) { break }
                Log "msiexec busy (another installation) - try $try"; Start-Sleep -Seconds 20
            }
        } finally { Remove-Item $run -Force -ErrorAction SilentlyContinue }
        if ($msiP.ExitCode) { throw "could not unpack LibreOffice (msiexec $($msiP.ExitCode))" }
        $exe = Get-ChildItem $tmp -Recurse -Filter soffice.exe | Where-Object { $_.Directory.Name -eq "program" } | Select-Object -First 1
        if (-not $exe) { throw "LibreOffice unpacked without its program" }
        $root = $exe.Directory.Parent.FullName
        Copy-Item (Join-Path $root "System64\*.dll") (Join-Path $root "program") -Force -ErrorAction SilentlyContinue
        $ff = Join-Path $root "share\fonts\truetype"; New-Item -ItemType Directory -Force $ff | Out-Null
        Get-ChildItem (Join-Path $root "Fonts") -File -ErrorAction SilentlyContinue | Move-Item -Destination $ff -Force
        foreach ($x in "System", "System64", "Fonts", "help", "readmes") { Remove-Item (Join-Path $root $x) -Recurse -Force -ErrorAction SilentlyContinue }
        Remove-Item (Join-Path $root "program\intl\fbintl.dll") -Force -ErrorAction SilentlyContinue
        Get-ChildItem (Join-Path $root "program") -Directory -Filter "python-core-*" -ErrorAction SilentlyContinue | ForEach-Object {
            Get-ChildItem (Join-Path $_.FullName "lib\pip\_vendor\distlib"), (Join-Path $_.FullName "lib\setuptools") -Filter *.exe -File -ErrorAction SilentlyContinue | Remove-Item -Force
        }
        Get-ChildItem $root -Filter *.msi -File | Remove-Item -Force
        Move-Item $root (Join-Path $Pkg "libreoffice")
        Remove-Item $tmp -Recurse -Force -ErrorAction SilentlyContinue
        Log "LibreOffice unpacked"
    }

    Span 95 100
    & robocopy (Join-Path $Here "app") (Join-Path $Pkg "app") /E /NFL /NDL /NJH /NJS /NP | Out-Null
    foreach ($x in "install.ps1", "uninstall.ps1", "Install.cmd", "NAME.txt", "components.json", "setup.ps1") {
        if (Test-Path (Join-Path $Here $x)) { Copy-Item (Join-Path $Here $x) $Pkg -Force }
    }
    & (Join-Path $Pkg "runtime\python.exe") -E -s -m compileall -q (Join-Path $Pkg "app") | Out-Null
    Say "the app" 100
    Step 2 done

    if ($Assemble) { Log "assembled $Pkg"; exit 0 }

    Step 3 run
    if ($UI) { $UI.btn.Enabled = $false }
    $total = Size-Of $Pkg; $base = Size-Of $Dest
    $out = Join-Path $Work "install.log"
    $instP = Start-Process powershell -ArgumentList @("-NoProfile", "-ExecutionPolicy", "Bypass", "-File", "`"$(Join-Path $Pkg 'install.ps1')`"",
                                                      "-Dest", "`"$Dest`"") -PassThru -WindowStyle Hidden -RedirectStandardOutput $out -RedirectStandardError "$out.err"
    Wait-Done $instP { (Size-Of $Dest) - $base } $total
    Get-Content $out, "$out.err" -ErrorAction SilentlyContinue | ForEach-Object { Log "$_" }
    Remove-Item $out, "$out.err" -Force -ErrorAction SilentlyContinue
    if ($instP.ExitCode) { throw "the installer stopped ($($instP.ExitCode)) - see $Log" }
    Copy-Item (Join-Path $Pkg "components.json") $Dest -Force
    Step 3 done
    Remove-Work $true
    if ($UI) {
        $UI.now.Text = "$Name is installed - opening it..."
        $end = (Get-Date).AddSeconds(3)
        while ((Get-Date) -lt $end) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100 }
        $UI.btn.Text = "Close"; $UI.form.Close()
    }
} catch {
    $cancelled = "$_" -like "cancelled*"
    Log $(if ($cancelled) { "cancelled by the user - removing what the setup downloaded" } else { "FAILED: $_" })
    if ($Assemble) { Write-Error "$_"; exit 1 }
    if ($UI) { for ($i = 0; $i -lt $UI.steps.Count; $i++) { if ($UI.rows[$i].Text.StartsWith(" " + [char]0x25B6)) { Step $i fail } } }
    if ($cancelled) {
        if ($UI) { $UI.now.Text = "Stopping..."; $UI.btn.Enabled = $false; $UI.bar.Value = 0; [System.Windows.Forms.Application]::DoEvents() }
        foreach ($q in $msiP, $pipP) { if ($q -and -not $q.HasExited) { try { $q.Kill(); [void]$q.WaitForExit(15000) } catch { } } }
        $lo = Join-Path $Work "lo"; $was = -1; $same = 0; $until = (Get-Date).AddMinutes(5)
        while ((Test-Path $lo) -and $same -lt 4 -and (Get-Date) -lt $until) {
            $size = Size-Of $lo; if ($size -eq $was) { $same++ } else { $same = 0; $was = $size }
            if ($UI) { [System.Windows.Forms.Application]::DoEvents() }; Start-Sleep -Milliseconds 1500
        }
        Remove-Work $true
        if (-not (Test-Path (Join-Path $Dest "app\VERSION.txt"))) {
            for ($i = 0; $i -lt 10 -and (Test-Path $Work); $i++) {
                Remove-Item $Work -Recurse -Force -ErrorAction SilentlyContinue
                if (Test-Path $Work) { if ($UI) { [System.Windows.Forms.Application]::DoEvents() }; Start-Sleep -Milliseconds 500 }
            }
        }
        if ($UI) {
            $UI.now.Text = "Cancelled."
            $end = (Get-Date).AddSeconds(3)
            while ((Get-Date) -lt $end) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100 }
            $UI.btn.Text = "Close"; $UI.form.Close()
        }
        exit 1
    }
    if ($UI) {
        if ("$_" -like "*smart app control*") {
            $UI.bar.Visible = $false; $UI.now.SetBounds(20, 116, 300, 66)
            $UI.btn.Top += 24; $UI.form.Height += 24; $UI.form.Top -= 24
        }
        $UI.now.Text = if ("$_" -like "*free on the disk*") { "Not enough free disk space." }
            elseif ("$_" -like "*smart app control*") { "This version can't be installed while Smart App Control is on." }
            else { "Setup could not finish - please run it again." }
        $UI.btn.Text = "Close"
        while ($UI.form.Visible) { [System.Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 100 }
    }
    exit 1
}
