import json
import os
import threading
import time
from contextlib import contextmanager
from pathlib import Path

_LOCKS, _GUARD = {}, threading.Lock()


@contextmanager
def locked(path):
    key = str(Path(path).resolve()).lower()
    with _GUARD:
        lock = _LOCKS.setdefault(key, threading.RLock())
    with lock:
        yield


def write_text(path, text, encoding="utf-8"):
    p = Path(path)
    p.parent.mkdir(parents=True, exist_ok=True)
    tmp = p.with_name(f".{p.name}.{os.getpid()}.{threading.get_ident()}.tmp")
    with locked(p):
        tmp.write_text(text, encoding=encoding)
        for attempt in range(20):
            try:
                os.replace(tmp, p)
                return p
            except PermissionError:
                time.sleep(0.1 * (attempt + 1))
        tmp.unlink(missing_ok=True)
        raise PermissionError(f"could not save {p.name} - another program holds it; try again")


def write_json(path, data):
    return write_text(path, json.dumps(data, indent=1, ensure_ascii=False))


def read_json(path, default=None):
    try:
        return json.loads(Path(path).read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return {} if default is None else default


@contextmanager
def update_json(path, default=None):
    with locked(path):
        d = read_json(path, default)
        yield d
        write_json(path, d)
