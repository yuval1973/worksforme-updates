import datetime as dt
import json
import re
import shutil
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import safe_io
import formats

HERE = Path(__file__).resolve().parent
ENGINE = HERE.parent
sys.path.insert(0, str(ENGINE))

FILES = {"s": "settings.json", "t": "targets.json", "a": "applicant.json"}
YN = ["Yes", "No"]
RACES = ["White", "Black or African American", "Asian", "American Indian or Alaska Native",
         "Native Hawaiian or Other Pacific Islander", "Two or more races", "Decline"]
US_STATES = formats.US_STATES
KIND_CHOICES = [["full-time", "Full-time"], ["contract", "Contract"], ["contract-to-hire", "Contract-to-hire"],
                ["part-time", "Part-time"], ["temporary", "Temporary"]]
FIELDS = [
    ("a", "identity.first_name", "First name", "text", "", "Profile", "Contact", None),
    ("a", "identity.last_name", "Last name", "text", "", "Profile", "Contact", None),
    ("a", "identity.email", "Email on applications", "text", "Employers write to this address.", "Profile", "Contact", None),
    ("a", "identity.phone", "Phone", "text", "", "Profile", "Contact", None),
    ("a", "identity.linkedin", "LinkedIn profile", "text", "", "Profile", "Contact", None),
    ("a", "location.country_code", "Country", "country", "", "Profile", "Address", None),
    ("a", "location.street_address", "Street address", "text", "", "Profile", "Address", None),
    ("a", "location.city", "City", "text", "", "Profile", "Address", None),
    ("a", "location.state_code", "State", "region", "", "Profile", "Address", None),
    ("a", "location.zip", "ZIP", "text", "", "Profile", "Address", None),
    ("a", "location.county", "County", "text", "", "Profile", "Address", None),
    ("s", "fit_breadth", "How far from your core work", "choice",
     "Related work includes the fields under \"Work you could move into\".",
     "Job search", "What fits", [["core", "Only my field"], ["related", "My field and closely related work"]]),
    ("a", "compensation.floor.min_base_usd", "Lowest base salary (USD a year)", "number",
     "Jobs that pay less are skipped.", "Job search", "Pay", None),
    ("a", "compensation.floor.min_total_usd", "Lowest total pay (USD a year)", "number", "Including bonus and equity.",
     "Job search", "Pay", None),
    ("t", "employment_types", "Open to", "checks", "", "Job search", "Kind of work", KIND_CHOICES),
    ("t", "top_tier", "Companies you most want to work at", "companies",
     "These get priority, even while applying is on hold.", "Job search", "Top companies", None),
    ("s", "auto_submit", "Submit applications by itself", "bool",
     "When off, you review each application before it's submitted.", "Applying", "How it applies", None),
    ("s", "daily_cap", "Most applications a day", "number", "", "Applying", "How it applies", None),
    ("s", "daily_run.at", "Start the daily run at", "time", "", "Applying", "Schedule", None),
    ("s", "daily_run.idle_minutes", "Wait until the PC is idle (minutes)", "number", "0 = start on time.",
     "Applying", "Schedule", None),
    ("t", "great_min_mid_base", "Still apply when the posted base pay is at least (USD)", "number",
     "Applies even while on hold.", "Applying", "While applying is on hold", None),
    ("s", "recruiter_auto_reply", "Reply to recruiter messages for me", "bool",
     "A short reply with your resume and availability.", "Applying", "Recruiters", None),
    ("s", "recruiter_reply_availability", "My availability for calls", "text", "", "Applying", "Recruiters", None),
    ("s", "recruiter_decline", "Politely decline messages that don't fit", "bool", "", "Applying", "Recruiters", None),
    ("s", "recruiter_unclear", "A recruiter's job that only partly fits", "choice", "", "Applying", "Recruiters",
     [["apply", "Apply"], ["skip", "Skip it"], ["ask", "Ask me"]]),
    ("a", "eligibility.authorized_to_work_us", "Authorized to work in the US", "choice", "", "Form answers",
     "Work eligibility", ["Yes", "No"]),
    ("a", "eligibility.requires_sponsorship", "Needs visa sponsorship", "choice", "", "Form answers", "Work eligibility",
     [["No - now or in the future", "No - now or in the future"], ["Yes - now or in the future", "Yes - now or in the future"]]),
    ("a", "eligibility.over_18", "18 or older", "choice", "", "Form answers", "Work eligibility", ["Yes", "No"]),
    ("a", "eligibility.security_clearance", "Security clearance", "choice", "", "Form answers", "Work eligibility",
     [["No - none, never held one", "None, never held one"], ["Yes", "Yes, I hold one"]]),
    ("a", "eligibility.government_employee_or_relative", "You or a close relative work for a government?", "choice", "",
     "Form answers", "Work eligibility", ["No", "Yes"]),
    ("a", "eligibility.currently_employed", "Employed right now", "choice", "", "Form answers", "Availability", ["Yes", "No"]),
    ("a", "eligibility.earliest_start", "Earliest start", "choice", "",
     "Form answers", "Availability", [["Immediately", "Immediately"], ["Two weeks after an offer", "2 weeks after an offer"],
                                      ["Three weeks after an offer", "3 weeks after an offer"],
                                      ["One month after an offer", "1 month after an offer"],
                                      ["Two months after an offer", "2 months after an offer"],
                                      ["Three months after an offer", "3 months after an offer"]]),
    ("a", "eligibility.willing_to_relocate", "Willing to relocate", "choice", "", "Form answers", "Availability", ["Yes", "No"]),
    ("a", "eligibility.willing_to_travel", "Willing to travel", "choice", "",
     "Form answers", "Availability", [["No", "No"], ["Up to 10%", "Up to 10%"], ["Up to 25%", "Up to 25%"],
                                      ["Up to 50%", "Up to 50%"], ["Yes", "Yes, any"]]),
    ("a", "standing_answers.onsite_ok", "Willing to work from the office / on-site", "choice", "", "Form answers",
     "Availability", YN),
    ("a", "eligibility.may_contact_current_employer", "Employers may contact your current employer", "choice", "",
     "Form answers", "Availability", ["No", "Yes"]),
    ("a", "standing_answers.how_did_you_hear", "How did you hear about the job?", "choice", "", "Form answers", "Other questions",
     [["LinkedIn", "LinkedIn"], ["Job board", "A job board"], ["Company website", "The company's website"],
      ["Recruiter", "A recruiter"], ["Referral", "A referral"]]),
    ("a", "standing_answers.contact_method", "Preferred contact method", "choice", "", "Form answers", "Other questions",
     ["Email", "Phone"]),
    ("a", "standing_answers.ai_policy_ack", "Acknowledge an employer's AI-use policy", "choice", "", "Form answers",
     "Other questions", YN),
    ("a", "standing_answers.close_relationship_with_employee", "Close relationship with someone at the company", "choice",
     "", "Form answers", "Other questions", YN),
    ("a", "standing_answers.employed_by_affiliate", "Employed by one of the company's subsidiaries", "choice", "",
     "Form answers", "Other questions", YN),
    ("a", "standing_answers.contractor_here", "Worked at the company as a contractor", "choice", "", "Form answers",
     "Other questions", YN),
    ("a", "standing_answers.non_compete", "A non-compete or non-solicitation in place", "choice", "", "Form answers",
     "Other questions", YN),
    ("a", "standing_answers.referred_by_leader", "Referred by a senior leader (jobs you apply to on your own)", "choice",
     "Referral applications answer this from the referral itself.", None, "Other questions", YN),
    ("a", "standing_answers.referrer_name", "Referrer name (jobs you apply to on your own)", "text", "", None,
     "Other questions", None),
    ("a", "self_identification.gender", "Gender", "choice", "", "Form answers",
     "Voluntary questions", ["Male", "Female", "Decline"]),
    ("a", "self_identification.hispanic_latino", "Hispanic or Latino", "choice", "", "Form answers", "Voluntary questions",
     ["No", "Yes", "Decline"]),
    ("a", "self_identification.race", "Race", "choice", "", "Form answers", "Voluntary questions", RACES),
    ("a", "self_identification.veteran_status", "Veteran status", "choice", "", "Form answers", "Voluntary questions",
     [["I am not a veteran", "I am not a veteran"], ["I am a protected veteran", "I am a protected veteran"],
      ["I am a veteran, but not a protected veteran", "A veteran, not a protected one"], ["Decline", "Decline"]]),
    ("a", "self_identification.military_spouse", "Military spouse / partner", "choice", "", "Form answers",
     "Voluntary questions", ["No", "Yes", "Decline"]),
    ("a", "self_identification.disability_status", "Disability", "choice", "", "Form answers", "Voluntary questions",
     [["No, I do not have a disability", "No"], ["Yes, I have a disability", "Yes"], ["Decline", "Decline"]]),
    ("s", "daily_email", "When to send it", "choice", "", "Email & accounts", "Daily email",
     [["all", "Every day there is news"], ["needs", "Only when something needs me"], ["off", "Never"]]),
    ("s", "report_to", "Send it to", "text", "", "Email & accounts", "Daily email", None),
    ("s", "auto_update", "Install updates automatically", "bool", "", "Advanced", "Updates", None),
    ("s", "practice", "Help improve WorksForMe", "bool", "", None, None, None),
    ("s", "support_reports", "Help improve WorksForMe by sending problem reports", "bool", "", "Advanced", "Support", None),
    ("s", "excel_ledger", "Also keep an Excel copy of the history", "bool", "", "Advanced", "History", None),
    ("s", "ai_provider", "AI provider", "choice", "", None, None, [["openai", "Built-in / OpenAI-compatible"], ["anthropic", "Anthropic"]]),
    ("s", "ai_model", "Model", "text", "", None, None, None),
    ("s", "ai_base_url", "Model server address", "text", "", None, None, None),
    ("s", "engine.model", "Built-in model file", "text", "", None, None, None),
    ("s", "ai_reasoning", "Reasoning level", "choice", "", None, None,
     [["", "Default"], ["off", "Off"], ["low", "Low"], ["medium", "Medium"], ["high", "High"]]),
    ("s", "ai_key_name", "API key name", "text", "", None, None, None),
]


def _load(f):
    p = ENGINE / FILES[f]
    return json.loads(p.read_text(encoding="utf-8-sig")) if p.exists() else {}


def _get(d, key):
    for part in key.split("."):
        if not isinstance(d, dict) or part not in d:
            return None
        d = d[part]
    return d


def _set(d, key, value):
    *path, leaf = key.split(".")
    for part in path:
        d = d.setdefault(part, {})
    d[leaf] = value


def _defaults():
    import config
    return {"s:fit_breadth": config.FIT_BREADTH, "s:daily_cap": config.DAILY_CAP, "s:daily_email": config.DAILY_EMAIL_MODE,
            "s:auto_submit": config.AUTO_SUBMIT, "s:ai_provider": config.AI_PROVIDER,
            "s:ai_model": config.AI_MODEL, "s:ai_base_url": config.AI_BASE_URL,
            "s:daily_run.at": config.RUN_AT, "s:daily_run.idle_minutes": config.IDLE_MIN, "s:report_to": config.REPORT_TO,
            "s:recruiter_auto_reply": bool(config.setting("recruiter_auto_reply", False)),
            "t:great_min_mid_base": None, "t:top_tier": {}, "t:employment_types": ["full-time"],
            "s:recruiter_decline": False,
            "s:job_seek_folder": config.JOB_SEEK_FOLDER, "s:linkedin_folder": config.LINKEDIN_FOLDER,
            "s:recruiter_unclear": "apply", "a:eligibility.over_18": "Yes",
            "s:auto_update": True, "s:practice": True,
            "a:standing_answers.onsite_ok": "Yes", "a:standing_answers.ai_policy_ack": "Yes",
            "a:standing_answers.contact_method": "Email", "a:standing_answers.close_relationship_with_employee": "No",
            "a:standing_answers.employed_by_affiliate": "No", "a:standing_answers.contractor_here": "No",
            "a:standing_answers.how_did_you_hear": "LinkedIn", "a:standing_answers.referred_by_leader": "No",
            "a:standing_answers.referrer_name": "N/A", "a:standing_answers.non_compete": "No"}


def home_country(data_a=None):
    a = _load("a") if data_a is None else data_a
    return str((a.get("location") or {}).get("country_code") or "US").upper()


def read():
    data = {f: _load(f) for f in FILES}
    dflt = _defaults()
    cc = home_country(data["a"])
    ex = formats.examples(cc)
    out = []
    for f, key, label, typ, help_, tab, section, choices in FIELDS:
        if tab is None:
            continue
        v = _get(data[f], key)
        if v is None:
            v = dflt.get(f"{f}:{key}")
        folder = typ == "folder"
        if folder:
            typ, choices = "choice", [str(v)]
        if typ == "country":
            choices = formats.countries.COUNTRIES
        if typ == "region":
            choices = [[c, n if cc != "US" else f"{c} - {n}"] for c, n in formats.countries.address_rules(cc)["areas"]]
        row = {"id": f"{f}:{key}", "label": label, "type": typ, "help": help_, "tab": tab, "section": section,
               "folder": folder, "choices": choices, "placeholder": ex.get(key, ""), "value": v}
        if typ == "text" or key in formats.MONEY:
            tidied, problem = formats.fix(key, v if v is not None else "", cc)
            if problem or (tidied != v and not (tidied in ("", None) and v in ("", None))):
                row["fix"] = {"value": tidied, "error": problem}
        out.append(row)
    return out


class FieldError(ValueError):
    def __init__(self, msg, field):
        super().__init__(msg)
        self.field = field


def _value(key, typ, raw, cc="US"):
    v = _coerce(typ, raw)
    if typ in ("text", "region") or key in formats.MONEY:
        v, problem = formats.fix(key, v, cc)
        if problem:
            raise ValueError(problem)
    if typ == "country" and not formats.countries.code_of(v or ""):
        raise ValueError("pick a country from the list")
    if typ == "country":
        v = formats.countries.code_of(v)
    return _shape(key, v)


def check(fid, raw, country=None):
    spec = {f"{f}:{k}": (k, t) for f, k, _l, t, _h, tab, *_ in FIELDS if tab}
    if fid not in spec:
        return {"value": raw, "error": None}
    key, typ = spec[fid]
    try:
        v = _value(key, typ, raw, formats.countries.code_of(country or "") or home_country())
    except (ValueError, json.JSONDecodeError) as e:
        return {"value": raw, "error": str(e)}
    return {"value": v, "error": None}


def mail_folders():
    try:
        import gmail
        return gmail.folders()
    except Exception:
        return []


def _coerce(typ, v):
    if typ == "number":
        s = str(v).replace(",", "").replace("$", "").strip()
        if not s:
            raise ValueError("needs a number")
        try:
            n = int(float(s))
        except ValueError:
            raise ValueError("a whole number, e.g. 5") from None
        if n < 0:
            raise ValueError("cannot be negative")
        return n
    if typ == "time":
        if not re.fullmatch(r"([01]?\d|2[0-3]):[0-5]\d", str(v).strip()):
            raise ValueError("use HH:MM, e.g. 06:00")
        return str(v).strip()
    if typ == "bool":
        return bool(v) if not isinstance(v, str) else v.lower() in ("true", "1", "yes", "on")
    if typ == "companies":
        v = json.loads(v) if isinstance(v, str) else v
        return {str(k).strip(): v[k] for k in (v or {}) if str(k).strip()}
    if typ == "checks":
        v = json.loads(v) if isinstance(v, str) else v
        allowed = [k for k, _ in KIND_CHOICES]
        picked = [k for k in allowed if k in {str(x).strip().lower() for x in (v or [])}]
        if not picked:
            raise ValueError("pick at least one")
        return picked
    return v


EMAIL = formats.EMAIL


def _shape(key, v):
    if key == "top_tier" and v is not None:
        if not all(isinstance(n, int) and not isinstance(n, bool) and 1 <= n <= 20 for n in v.values()):
            raise ValueError("applications a month: a number from 1 to 20")
        tidy = {}
        for name, n in v.items():
            name, problem = formats.fix("company", name)
            if problem:
                raise ValueError(f'"{name}": {problem}')
            tidy[name] = n
        v = tidy
    if key == "ai_base_url" and v and not re.match(r"https?://[^\s'\"`]+$", str(v)):
        raise ValueError("must be an http(s) address")
    if key == "daily_run.idle_minutes" and v is not None and not 0 <= v <= 240:
        raise ValueError("from 0 to 240 minutes")
    if key == "job_seek_folder" and str(v or "").strip().upper() in ("", "INBOX"):
        raise ValueError("pick a folder of its own for employers' replies - the inbox holds all your mail")
    if key in ("daily_cap",) and v is not None and not 1 <= v <= 50:
        raise ValueError("between 1 and 50 (use Hold to stop applying)")
    return v


def save(changes, internal=False):
    with safe_io.locked(ENGINE / "settings.json"), safe_io.locked(ENGINE / "targets.json"), \
            safe_io.locked(ENGINE / "applicant.json"):
        return _save(changes, internal)


def derived(data, changes, touched):
    a = data["a"]
    cc = home_country(a)
    if "a:identity.phone" in changes or "a:location.country_code" in changes:
        import wizard
        a.setdefault("identity", {}).update(wizard.phone_parts(a["identity"].get("phone"), cc))
    if "a:location.state_code" in changes or "a:location.country_code" in changes:
        import wizard
        loc = a.setdefault("location", {})
        region = str(loc.get("state_code") or "")
        fields = wizard.home_fields(cc, region.upper() if cc == "US" else region)
        fields.pop("zip", None)
        loc.update(fields)
        if cc == "US" and not loc.get("county"):
            loc.pop("county", None)
    floor = (a.get("compensation") or {}).get("floor") or {}
    if "a:compensation.floor.min_base_usd" in changes and floor.get("min_base_usd"):
        a["compensation"]["required_range_usd"] = [floor["min_base_usd"], round(floor["min_base_usd"] * 1.3)]
        a["compensation"]["single_number_usd"] = round(floor["min_base_usd"] * 1.15)
    if ("a:eligibility.willing_to_relocate" in changes or "a:compensation.floor.min_base_usd" in changes) \
            and (ENGINE / FILES["t"]).exists():
        import wizard
        data["t"]["relocate_min_base"] = wizard.relocate_min_base(a)
        touched.add("t")


ADDRESS = ("a:location.country_code", "a:location.street_address", "a:location.city", "a:location.state_code",
           "a:location.zip")


def cross_check(a, changes):
    labels = {f"{f}:{k}": label for f, k, label, *_ in FIELDS}
    if any(k in changes for k in ADDRESS):
        loc = a.get("location") or {}
        errs = formats.countries.check_address(loc.get("country_code") or "US", loc.get("street_address"),
                                               loc.get("city"), loc.get("state_code"), loc.get("zip"))
        for key, why in errs.items():
            raise FieldError(f"{labels.get('a:' + key, key)}: {why}", f"a:{key}")
    floor = (a.get("compensation") or {}).get("floor") or {}
    base, total = floor.get("min_base_usd") or 0, floor.get("min_total_usd") or 0
    if base and total and base > total and \
            ("a:compensation.floor.min_base_usd" in changes or "a:compensation.floor.min_total_usd" in changes):
        raise FieldError("Lowest total pay (USD a year): it includes the base, so it cannot be below the lowest base "
                         f"salary ({base:,})", "a:compensation.floor.min_total_usd")


def _save(changes, internal=False):
    spec = {f"{f}:{k}": (f, k, t, label) for f, k, label, t, _h, tab, *_ in FIELDS if tab or internal}
    data = {f: _load(f) for f in FILES}
    touched = set()
    new_cc = formats.countries.code_of(str(changes.get("a:location.country_code") or "")) or home_country(data["a"])
    moved = "a:location.country_code" in changes and new_cc != home_country(data["a"])
    if moved and (ENGINE / FILES["a"]).exists():
        for k, label in (("location.street_address", "Street address"), ("location.city", "City")):
            if not str(changes.get(f"a:{k}") or "").strip() or changes.get(f"a:{k}") == _get(data["a"], k):
                raise FieldError(f"{label}: your address in {formats.countries.name(new_cc)}", f"a:{k}")
        for k in ("location.state_code", "location.zip"):
            changes.setdefault(f"a:{k}", _get(data["a"], k) or "")
    for fid, raw in changes.items():
        if fid not in spec:
            continue
        f, key, typ, label = spec[fid]
        if f in ("a", "t") and not (ENGINE / FILES[f]).exists():
            continue
        try:
            v = _value(key, typ, raw, new_cc)
        except (ValueError, json.JSONDecodeError) as e:
            raise FieldError(f"{label}: {e}", fid)
        if _get(data[f], key) != v:
            _set(data[f], key, v)
            touched.add(f)
        if fid == "s:support_reports" and _get(data["s"], "practice") != v:
            _set(data["s"], "practice", v)
            touched.add("s")
    if not touched:
        return []
    if "a" in touched:
        derived(data, changes, touched)
        cross_check(data["a"], changes)
    import selftest
    if "a" in touched:
        selftest.applicant(data["a"])
    if "t" in touched:
        fp, dp = data["t"].get("fit_prompt", ""), data["t"].get("draft_prompt", "")
        for ph in ("{title}", "{company}", "{jd}"):
            if ph not in fp:
                raise ValueError(f"the fit rules must keep {ph}")
        for ph in ("{company}", "{question}", "{max_chars}", "{jd}"):
            if ph not in dp:
                raise ValueError(f"the writing rules must keep {ph}")
    bak = ENGINE / "runs" / "settings-backup" / dt.datetime.now().strftime("%Y-%m-%d_%H%M%S_%f")
    bak.mkdir(parents=True, exist_ok=True)
    for f in touched:
        p = ENGINE / FILES[f]
        if p.exists():
            shutil.copy2(p, bak / p.name)
        safe_io.write_json(p, data[f])
    return [FILES[f] for f in touched]


GENERATED = ("persona", "excluded_companies", "title_skips", "local_regex", "fit_prompt", "draft_prompt", "_wizard")
FIT_LIST_LABELS = {"core_domains": "Work you have done for years", "adjacent_domains": "Work you could move into",
                   "hard_nos": "Rules a job out", "none_domains": "Fields that are not a fit",
                   "above_level_words": "Title words above your level", "below_level_words": "Title words below your level",
                   "other_discipline_words": "Title words of other professions", "nearby_towns": "Towns you would commute to"}


def tidy_lists(lists, before=None):
    known = {str(x).lower() for v in (before or {}).values() for x in (v or [])}
    out = {}
    for k, items in lists.items():
        label, seen, keep = FIT_LIST_LABELS.get(k, k), set(), []
        for x in items or []:
            x, problem = formats.fix(formats.LIST_ITEM, x)
            if not x or x.lower() in seen:
                continue
            if problem and x.lower() not in known:
                raise ValueError(f'{label}: "{x[:40]}" - {problem}')
            seen.add(x.lower())
            keep.append(x)
        if len(keep) > 60:
            raise ValueError(f"{label}: 60 lines at most")
        out[k] = keep
    return out


def fit_lists():
    w = _load("t").get("_wizard")
    if not w:
        return None
    return {**w["lists"], "core_domains": w["profile"].get("core_domains") or [],
            "adjacent_domains": w["profile"].get("adjacent_domains") or []}


def save_fit_lists(lists):
    with safe_io.locked(ENGINE / "targets.json"):
        return _save_fit_lists(lists)


def _save_fit_lists(lists):
    import wizard
    t = _load("t")
    w = t.get("_wizard")
    if not w:
        raise ValueError("these fit rules were written by hand, so they cannot be changed here")
    lists = tidy_lists(lists, fit_lists())
    prof = dict(w["profile"])
    for k in ("core_domains", "adjacent_domains"):
        if k in lists:
            prof[k] = [x for x in lists.pop(k) if x.strip()]
    new_lists = {**w["lists"], **lists}
    fresh = wizard.to_targets(prof, new_lists)
    merged = {**t, **{k: fresh[k] for k in GENERATED if k in fresh}}
    bak = ENGINE / "runs" / "settings-backup" / dt.datetime.now().strftime("%Y-%m-%d_%H%M%S")
    bak.mkdir(parents=True, exist_ok=True)
    shutil.copy2(ENGINE / "targets.json", bak / "targets.json")
    safe_io.write_json(ENGINE / "targets.json", merged)
    return "targets.json"


def factory_reset(clear_history=False):
    import socket
    import config
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", int(config.setting("ports.lock", 9446))))
    except OSError:
        raise ValueError("a run is using the browser right now - reset when it is done")
    finally:
        s.close()
    bak = ENGINE / "runs" / "factory-reset" / dt.datetime.now().strftime("%Y-%m-%d_%H%M%S_%f")
    bak.mkdir(parents=True, exist_ok=True)
    names = ["applicant.json", "targets.json", "fit_cases.json", "job_notes.json"] + (["applications.csv"] if clear_history else [])
    old = _load("s")
    for n in names + ["settings.json", "runs/wizard-state.json", "runs/setup-upload"]:
        p = ENGINE / n
        if p.exists():
            shutil.move(str(p), str(bak / p.name))
    for d in ("profile", "Categories"):
        p = ENGINE.parent / d
        if p.exists() and p.is_dir() and (ENGINE.parent / "runtime").exists():
            shutil.move(str(p), str(bak / d))
    tpl = next((p for p in (ENGINE / "templates" / "settings.template.json",
                            ENGINE / "kit" / "templates" / "settings.template.json") if p.exists()), None)
    fresh = json.loads(tpl.read_text(encoding="utf-8-sig")) if tpl else {}
    for k in ("chrome_exe", "browser_home", "ports", "vault_prefix", "legacy_secret_store", "engine", "ai_provider",
              "ai_model", "ai_base_url", "ai_reasoning", "ai_key_name", "app_name", "ledger_file", "categories_dir", "edition",
              "update_url", "auto_update", "update_check_at", "support_to", "excel_ledger", "daily_email",
              "mail_server", "mail_source", "mail_id", "mail_address", "email", "report_to"):
        if k in old:
            fresh[k] = old[k]
    safe_io.write_json(ENGINE / "settings.json", fresh)
    if clear_history:
        first = ENGINE / "templates" / "first-run" / "applications.csv"
        if first.exists():
            shutil.copy2(first, ENGINE / "applications.csv")
    try:
        import wizard
        lnk = wizard.startup_shortcut()
        if lnk.exists():
            shutil.move(str(lnk), str(bak / lnk.name))
    except Exception:
        pass
    _stop_agent()
    return bak


def _stop_agent():
    import subprocess
    agent = str(ENGINE / "agent.pyw").lower()
    ps = "Get-CimInstance Win32_Process | Where-Object { $_.CommandLine } | ForEach-Object { '{0}|{1}' -f $_.ProcessId, $_.CommandLine }"
    try:
        out = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=60,
                             creationflags=subprocess.CREATE_NO_WINDOW).stdout
    except (OSError, subprocess.SubprocessError):
        return
    for line in out.splitlines():
        pid, _, cmd = line.partition("|")
        if agent in cmd.lower() and pid.strip().isdigit():
            subprocess.run(["taskkill", "/F", "/PID", pid.strip()], capture_output=True,
                           creationflags=subprocess.CREATE_NO_WINDOW)
