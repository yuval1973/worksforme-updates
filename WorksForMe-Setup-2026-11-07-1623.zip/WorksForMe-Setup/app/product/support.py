import csv
import datetime as dt
import json
import re
import sys
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

HERE = Path(__file__).resolve().parent
ENGINE = HERE.parent
sys.path[:0] = [str(ENGINE), str(HERE)]
import config
import safe_io

SENT = ENGINE / "runs" / "support_sent.json"
from sites import TECHNICAL, USERS_OWN


GENERIC = {"yes", "no", "n/a", "na", "none", "decline", "i decline", "leave blank", "prefer not to say",
           "i don't wish to answer", "i do not wish to answer", "not specified", "other", "true", "false"}


COARSE = {"country", "country_code", "state", "state_code"}


def _strings(v):
    if isinstance(v, str):
        yield v
    elif isinstance(v, dict):
        for x in v.values():
            yield from _strings(x)
    elif isinstance(v, (list, tuple)):
        for x in v:
            yield from _strings(x)


def _secrets():
    p = ENGINE / "applicant.json"
    a = safe_io.read_json(p) if p.exists() else {}
    vals = []
    for sect in ("identity", "location", "self_identification"):
        for k, v in (a.get(sect) or {}).items():
            if sect == "location" and k in COARSE:
                continue
            for s in _strings(v):
                vals.append((s, f"<{sect}.{k}>"))
    sa = a.get("standing_answers") or {}
    for k in ("referrer_name", "relatives_at_companies", "relatives", "close_relationship_name"):
        for s in _strings(sa.get(k)):
            vals.append((s, f"<standing_answers.{k}>"))
    for role in a.get("experience") or a.get("work_history") or []:
        for k in ("company", "employer"):
            for s in _strings((role or {}).get(k)):
                vals.append((s, "<employer>"))
    for school in a.get("education") or []:
        for s in _strings((school or {}).get("school")):
            vals.append((s, "<school>"))
    for x in a.get("learned_answers") or []:
        for s in _strings((x or {}).get("answer")):
            vals.append((s, "<learned answer>"))
    ident = a.get("identity") or {}
    full = f"{ident.get('first_name', '')} {ident.get('last_name', '')}".strip()
    if full:
        vals.append((full, "<identity.full_name>"))
    vals.append((config.EMAIL, "<identity.email>"))
    import os
    for k in ("USERNAME", "COMPUTERNAME"):
        if os.environ.get(k):
            vals.append((os.environ[k], f"<{k.lower()}>"))
    keep = {(v.strip(), tag) for v, tag in vals if v and len(v.strip()) >= 2 and v.strip().lower() not in GENERIC}
    return sorted(keep, key=lambda x: -len(x[0]))


def scrub(text, secrets=None):
    secrets = _secrets() if secrets is None else secrets
    text = re.sub(r"(?i)[a-z]:\\users\\[^\\/\s\"']+", r"C:\\Users\\<user>", text)
    text = re.sub(r"(https?://[^\s?#\"'<>]+)[?#][^\s\"'<>]*", r"\1", text)
    text = re.sub(r"[\w.+-]+(?:@|%40)[\w-]+(?:\.[\w-]+)+", "<email>", text)
    for v, tag in secrets:
        text = re.sub(rf"(?<!\w){re.escape(v)}(?!\w)", tag, text, flags=re.I)
    return re.sub(r"(?<![\w/=])\(?\d{3}\)?[-. ]\d{3}[-. ]\d{4}\b", "<phone>", text)


def candidates(day=None):
    day = day or dt.date.today().isoformat()
    latest = {}
    with (ENGINE / "applications.csv").open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            latest[r.get("url") or id(r)] = r
    out = []
    for r in latest.values():
        st, notes = (r.get("status") or "").lower(), r.get("notes") or ""
        if r.get("date") != day or not st.startswith(("error", "needs you", "waiting: site not supported", "waiting: site broken")):
            continue
        if st.startswith("needs you") and USERS_OWN.search(notes):
            continue
        out.append(r)
    return out


def practice_candidates(day=None):
    import sites
    day, f = day or dt.date.today().isoformat(), ENGINE / "runs" / "practice.csv"
    if not f.exists():
        return []
    latest = {}
    with f.open(encoding="utf-8") as fh:
        for r in csv.DictReader(fh):
            latest[r.get("url") or id(r)] = r
    return [dict(r, practice=sites.practice_finding(r)) for r in latest.values()
            if r.get("date") == day and sites.practice_finding(r)]


def _log_excerpt(r, lines=120):
    logs = sorted((ENGINE / "runs").glob("daily-*.log"))
    if not logs:
        return ""
    text = logs[-1].read_text(encoding="utf-8", errors="replace").splitlines()
    key = (r.get("company") or "")[:20]
    nxt = re.compile(r"Chrome launched|^\[[\d:]+\] == ")
    starts = [i for i, l in enumerate(text) if key and f"LinkedIn: {key}" in l]
    best = [i for i in starts if (r.get("title") or "")[:30] in text[i]] or starts
    if best:
        a = max(0, best[-1] - 1)
        a -= 1 if a and key in text[a - 1] else 0
        b = next((j for j in range(best[-1] + 1, len(text)) if nxt.search(text[j])), len(text))
        return "\n".join(text[a:b][-lines:])
    hits = [i for i, l in enumerate(text) if key and key in l]
    if not hits:
        return "(no log lines for this job)"
    b = next((j for j in range(hits[-1] + 1, min(len(text), hits[-1] + 40)) if nxt.search(text[j])), min(len(text), hits[-1] + 40))
    return "\n".join(text[max(0, hits[0] - 3):b][-lines:])


def version():
    return (ENGINE / "VERSION.txt").read_text(encoding="utf-8").strip() if (ENGINE / "VERSION.txt").exists() else "dev"


def system_lines():
    import platform
    ver = version()
    return [*([f"Version: {ver.removeprefix(config.APP_NAME).strip()}"] if ver != "dev" else []),
            f"Windows: {platform.release()} {platform.version()}",
            f"Browser: {Path(str(config.CHROME_EXE)).stem}", f"AI: {config.AI_PROVIDER} / {config.AI_MODEL or config.setting('engine.model', '-')}",
            f"Submits by itself: {config.AUTO_SUBMIT}; daily cap {config.DAILY_CAP}; edition {config.setting('edition', 'dev')}"]


def shot_slug(company):
    return re.sub(r"[^A-Za-z0-9]+", "-", company or "job")[:30]


def evidence(r):
    if not r.get("company"):
        return None, None
    slug = shot_slug(r["company"])
    forms = sorted((ENGINE / "runs").glob(f"{r.get('date')}_*_{slug}_*-form.json"))
    shots = sorted((ENGINE / "runs").glob(f"{r.get('date')}_*_{slug}_*.png"))
    return (forms[-1] if forms else None), (shots[-1] if shots else None)


def report_id(key):
    import hashlib
    return "WFM-" + hashlib.sha1(key.encode()).hexdigest()[:6].upper()


def build(r, secrets, rid=""):
    import sites
    site = re.sub(r"^https?://(www\.)?", "", (r.get("action_url") or r.get("url") or "")).split("/")[0]
    practice, notes = r.get("practice"), r.get("notes") or ""
    held = "checked before submit" in notes.lower()
    subject = (f"[support] {rid} {site} - "
               + (f"practice: {practice}" if practice else "held before Submit: an answer to check" if held
                  else (r.get('status') or '')[:40]))
    form, _shot = evidence(r)
    body = "\n".join([f"Report: {rid}", *system_lines(), "",
        *([f"PRACTICE RUN ({practice}): the user was not applying - stand-in details, nothing uploaded or submitted. "
           "This site is skipped by practice runs until an update arrives, then tried once more.", ""] if practice else []),
        *(["HELD BEFORE SUBMIT: the second reader found an answer that disagrees with the user's profile, so nothing was "
           "sent. The answer, what the profile says, and why are in the notes below.", ""] if held and not practice else []),
        f"Date: {r.get('date')}", f"Company: {r.get('company')}", f"Role: {r.get('title')}", f"Site: {site} (adapter: {r.get('ats') or '-'})",
        f"Job: {r.get('url')}", f"Where it stopped: {r.get('action_url') or '-'}",
        f"Status: {r.get('status')}", "", "Notes:", notes or "-", "",
        "" if practice else "This site is skipped on this PC until an update arrives." if broken_here(site) else
        "If it fails again, this site is skipped on this PC until an update arrives." if sites.technical(notes) and not held else
        f"The job waits and is tried again on the next runs; after {sites.WAIT_DAYS} days it goes to the user.", "",
        "Attached: form.json - the page where it stopped: field labels, types, required, filled yes/no (never the values)."
        if form else "No form map (the page was not open when it stopped).", "",
        "Log excerpt:", _log_excerpt(r)])
    return scrub(subject, secrets), scrub(body, secrets)


def broken_here(site):
    try:
        import sites
        return sites.is_broken(site)
    except Exception:
        return False


def _mail(subject, body, attachments=()):
    msg = MIMEMultipart()
    msg["Subject"], msg["From"], msg["To"] = subject, config.EMAIL, config.setting("support_to")
    msg.attach(MIMEText(body, "plain", "utf-8"))
    for name, data in attachments:
        part = MIMEApplication(data, Name=name)
        part["Content-Disposition"] = f'attachment; filename="{name}"'
        msg.attach(part)
    if config.setting("mail_source") == "forward":
        import fwdmail
        fwdmail.send_message(msg, "support")
        return
    import smtplib
    import vault
    msg.replace_header("To", config.EMAIL)
    with smtplib.SMTP("smtp.gmail.com", 587, timeout=30, local_hostname="localhost") as s:
        s.starttls()
        s.login(config.EMAIL, vault.get("EMAIL_PASS"))
        s.sendmail(config.EMAIL, [config.EMAIL], msg.as_string())


def keep_copy(rid, subject, body):
    d = ENGINE / "runs" / "support"
    d.mkdir(parents=True, exist_ok=True)
    (d / f"{rid}.txt").write_text(subject + "\n\n" + body, encoding="utf-8")


def filled_form(url):
    if not url:
        return []
    key = f"URL: {url}\n"
    for p in sorted((ENGINE / "runs").glob("20*_*.txt"), key=lambda p: p.stat().st_mtime, reverse=True)[:400]:
        try:
            body = p.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if key in body:
            return [("filled-form.txt", scrub(body, _secrets()).encode("utf-8"))]
    return []


def send_note(text, include_log=True, url=""):
    if not config.setting("support_to"):
        raise RuntimeError("this version has no support address")
    secrets = _secrets()
    rid = report_id(f"note|{dt.datetime.now().isoformat()}")
    subject = scrub(f"[support] {rid} from the user - {' '.join(text.split())[:50]}", secrets)
    log = ""
    if include_log:
        logs = sorted((ENGINE / "runs").glob("daily-*.log"))
        log = scrub("\n".join(logs[-1].read_text(encoding="utf-8", errors="replace").splitlines()[-200:]), secrets) if logs else "(no run yet)"
    body = "\n".join([f"Report: {rid}", *[scrub(x, secrets) for x in system_lines()], "", "The user wrote:", text, "",
                      *(["Last run's log (personal details removed):", log] if include_log else [])])
    _mail(subject, body, filled_form(url) if include_log else [])
    keep_copy(rid, subject, body)
    sent = json.loads(SENT.read_text(encoding="utf-8")) if SENT.exists() else {}
    sent[rid] = {"date": dt.date.today().isoformat(), "subject": subject}
    safe_io.write_json(SENT, sent)
    return rid


def send_update_failure(version):
    if not config.setting("support_reports", False) or not config.setting("support_to"):
        return None
    sent = json.loads(SENT.read_text(encoding="utf-8")) if SENT.exists() else {}
    key = f"update|{version}"
    if key in sent:
        return report_id(key)
    secrets, rid = _secrets(), report_id(key)
    subject = scrub(f"[support] {rid} update failed - {version}", secrets)
    lp = ENGINE / "runs" / "update" / "update.log"
    log = "\n".join(lp.read_text(encoding="utf-8", errors="replace").splitlines()[-80:]) if lp.exists() else "(no update log)"
    body = "\n".join([f"Report: {rid}", *[scrub(x, secrets) for x in system_lines()], "",
                      f"The update to {version} did not install; WorksForMe went back to the version it had.", "",
                      "Update log (personal details removed):", scrub(log, secrets)])
    _mail(subject, body)
    keep_copy(rid, subject, body)
    sent[key] = {"date": dt.date.today().isoformat(), "subject": subject}
    safe_io.write_json(SENT, sent)
    return rid


def send_failure(where, error, detail=""):
    if not config.setting("support_reports", False) or not config.setting("support_to"):
        return None
    sent = json.loads(SENT.read_text(encoding="utf-8")) if SENT.exists() else {}
    sig = re.sub(r"\d+", "N", f"{type(error).__name__}: {error}")[:120]
    key = f"fail|{version()}|{where}|{sig}"
    rid = report_id(key)
    if key in sent:
        return rid
    import traceback
    secrets = _secrets()
    trace = "".join(traceback.format_exception(type(error), error, error.__traceback__))[-4000:] \
        if isinstance(error, BaseException) else str(error)
    logs = sorted((ENGINE / "runs").glob("daily-*.log"))
    log = "\n".join(logs[-1].read_text(encoding="utf-8", errors="replace").splitlines()[-60:]) if logs else "(no run yet)"
    subject = scrub(f"[support] {rid} {where} - {sig[:60]}", secrets)
    body = "\n".join([f"Report: {rid}", *[scrub(x, secrets) for x in system_lines()], "",
                      f"Where: {where}", f"What happened: {scrub(sig, secrets)}", *([scrub(detail, secrets)] if detail else []),
                      "", "Trace (personal details removed):", scrub(trace, secrets), "",
                      "Last run's log (personal details removed):", scrub(log, secrets)])
    _mail(subject, body)
    keep_copy(rid, subject, body)
    sent[key] = {"date": dt.date.today().isoformat(), "subject": subject, "kind": "failure", "where": where}
    safe_io.write_json(SENT, sent)
    return rid


def send_new(dry=False):
    if not config.setting("support_to"):
        return []
    rows = candidates() if config.setting("support_reports", False) else []
    rows += practice_candidates() if config.setting("practice", True) else []
    sent = json.loads(SENT.read_text(encoding="utf-8")) if SENT.exists() else {}
    secrets, out = _secrets(), []
    for r in rows:
        site = re.sub(r'^https?://(www\.)?', '', r.get('action_url') or r.get('url') or '').split('/')[0]
        key = f"{r.get('url')}|{(r.get('status') or '')[:30]}"
        if (r.get("status") or "").startswith("waiting: site"):
            key = f"{site}|{r['status'][:30]}|{version()}"
        if r.get("practice"):
            key = f"practice|{site}|{r['practice']}|{version()}"
        if key in sent:
            continue
        rid = report_id(key)
        subject, body = build(r, secrets, rid)
        out.append(subject)
        if dry:
            continue
        form, shot = evidence(r)
        files = []
        if form:
            files.append(("form.json", scrub(form.read_text(encoding="utf-8"), secrets).encode("utf-8")))
        if shot:
            files.append((shot.name, shot.read_bytes()))
        _mail(subject, body, files)
        keep_copy(rid, subject, body)
        sent[key] = {"date": dt.date.today().isoformat(), "subject": subject}
    if not dry and out:
        safe_io.write_json(SENT, sent)
    return out


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if "--update-failed" in sys.argv:
        rid = send_update_failure(sys.argv[sys.argv.index("--update-failed") + 1])
        print(f"filed {rid}" if rid else "not filed: problem reports are off")
        sys.exit(0)
    dry = "--dry-run" in sys.argv
    print("\n".join(send_new(dry=dry)) or "nothing to report")
