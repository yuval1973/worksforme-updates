import threading
import time
import urllib.request
from pathlib import Path

STATE = {"state": "idle", "file": None, "done": 0, "total": 0, "rate": 0, "error": None}
_lock = threading.Lock()


def status():
    return dict(STATE)


def _verified(part, sha256):
    if not sha256:
        return True
    import hashlib
    STATE.update(state="checking")
    h = hashlib.sha256()
    with part.open("rb") as f:
        while chunk := f.read(1 << 24):
            h.update(chunk)
    if h.hexdigest().lower() != sha256.lower():
        part.unlink(missing_ok=True)
        STATE.update(state="failed", error="the download is not the published file (checksum) - try again")
        return False
    return True


def _run(url, dest, on_done, sha256=None):
    part = dest.with_suffix(dest.suffix + ".part")
    try:
        for attempt in range(30):
            have = part.stat().st_size if part.exists() else 0
            req = urllib.request.Request(url, headers={"Range": f"bytes={have}-", "User-Agent": "model-download"})
            try:
                with urllib.request.urlopen(req, timeout=60) as r:
                    total = have + int(r.headers.get("Content-Length") or 0)
                    if r.status == 200 and have:
                        have, total = 0, int(r.headers.get("Content-Length") or 0)
                        part.unlink(missing_ok=True)
                    STATE.update(total=total, done=have)
                    t0, n0 = time.time(), have
                    with part.open("ab") as f:
                        while chunk := r.read(1 << 20):
                            f.write(chunk)
                            have += len(chunk)
                            dt = time.time() - t0
                            STATE.update(done=have, rate=int((have - n0) / dt) if dt > 1 else 0)
                if have >= total > 0:
                    if not _verified(part, sha256):
                        return
                    part.replace(dest)
                    STATE.update(state="done", done=total)
                    on_done(dest)
                    return
            except urllib.error.HTTPError as e:
                if e.code == 416 and part.exists():
                    if not _verified(part, sha256):
                        return
                    part.replace(dest)
                    STATE.update(state="done")
                    on_done(dest)
                    return
                STATE["error"] = f"HTTP {e.code}"
            except OSError as e:
                STATE["error"] = f"{type(e).__name__}: {e}"
            time.sleep(min(60, 5 * (attempt + 1)))
        STATE.update(state="failed")
    except Exception as e:
        STATE.update(state="failed", error=f"{type(e).__name__}: {e}")


def start(url, folder, filename, on_done, sha256=None):
    with _lock:
        dest = Path(folder) / filename
        if dest.exists():
            STATE.update(state="done", file=filename, done=dest.stat().st_size, total=dest.stat().st_size)
            on_done(dest)
            return status()
        if STATE["state"] == "downloading":
            return status()
        Path(folder).mkdir(parents=True, exist_ok=True)
        STATE.update(state="downloading", file=filename, error=None, done=0, total=0)
        threading.Thread(target=_run, args=(url, dest, on_done, sha256), daemon=True).start()
        return status()
