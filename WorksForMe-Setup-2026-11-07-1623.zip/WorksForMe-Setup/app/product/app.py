import csv
import datetime as dt
import hashlib
import html
import json
import re
import subprocess
import sys
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, unquote, urlparse

HERE = Path(__file__).resolve().parent
ENGINE = HERE.parent
sys.path.insert(0, str(ENGINE))
import config
import safe_io

_FILES = [ENGINE / n for n in ("settings.json", "targets.json", "applicant.json")]
_stamp = lambda: [f.stat().st_mtime_ns if f.exists() else 0 for f in _FILES + [config.MASTER_RESUME]]
WIZARD_STATE = ENGINE / "runs" / "wizard-state.json"


def wizard_state(**update):
    if not update:
        return safe_io.read_json(WIZARD_STATE)
    with safe_io.update_json(WIZARD_STATE) as s:
        s.update(update)
    return s
_SEEN = _stamp()
_RELOAD = threading.Lock()


def fresh():
    global _SEEN
    import importlib.util

    def rerun(mod):
        spec = importlib.util.spec_from_file_location(mod.__name__, mod.__file__)
        spec.loader.exec_module(mod)
    with _RELOAD:
        now = _stamp()
        if now == _SEEN:
            return False
        old_model = config.setting("engine.model")
        snapshot = dict(vars(config))
        try:
            rerun(config)
        except Exception:
            vars(config).update(snapshot)
            _SEEN = now
            return False
        llm = sys.modules.get("llm")
        if llm is not None:
            eng, restart = llm._engine, llm.ENGINE_RESTART
            if eng is not None and config.setting("engine.model") != old_model:
                import engine
                engine.stop(eng)
                eng = restart = None
            rerun(llm)
            llm._engine, llm.ENGINE_RESTART = eng, restart
        _SEEN = now
        return True


PORT = int(config.setting("ports.ui", 9450))
PY = str(Path(sys.executable).with_name("python.exe"))
PYW = str(Path(sys.executable).with_name("pythonw.exe"))
LEDGER = ENGINE / "applications.csv"
BUCKETS = {
    "applied": ("submitted", "applied"),
    "waiting": ("waiting", "queued"),
    "needs": ("needs you", "ready for review", "submit clicked", "error"),
}
STALE_DAYS = 14


def ledger_rows():
    try:
        with LEDGER.open(encoding="utf-8-sig", errors="replace", newline="") as f:
            return list(csv.DictReader(f))
    except FileNotFoundError:
        return []


def latest_rows():
    rows = ledger_rows()
    latest = {}
    for r in rows:
        latest[r.get("url") or f"nourl-{len(latest)}"] = r
    return list(latest.values())


def bucket(status):
    s = (status or "").lower()
    return next((b for b, pre in BUCKETS.items() if s.startswith(pre)), None)


def own_step(r):
    import sites
    s = (r.get("status") or "").lower()
    return s.startswith("ready for review") or (s.startswith("needs you") and bool(sites.USERS_OWN.search(r.get("notes") or "")))


def flag(name):
    p = ENGINE / name
    if not p.exists():
        return {"on": False}
    text = p.read_text(encoding="utf-8", errors="ignore")
    m = re.search(r"\d{4}-\d{2}-\d{2}", text)
    return {"on": True, "until": m.group(0) if m else None, "note": text.strip()[:400]}


def review_state(rows):
    import report
    import settings_api
    s = settings_api._load("s")
    auto = bool(s.get("auto_submit", False))
    stale = (dt.date.today() - dt.timedelta(days=STALE_DAYS)).isoformat()
    waiting = 0 if auto else sum(1 for r in rows if (r.get("status") or "").startswith("ready for review")
                                 and (r.get("date") or "") >= stale)
    return {"auto": auto, "reviews": waiting, "full": waiting >= report.REVIEW_FULL,
            "nudge": report.review_nudge(rows, s)[0]}


def filters_new():
    try:
        import gmail_setup
        return bool(gmail_setup.filters_due())
    except Exception:
        return False


def overview():
    rows = latest_rows()
    counts = {b: 0 for b in BUCKETS}
    counts["pending"] = 0
    stale = (dt.date.today() - dt.timedelta(days=STALE_DAYS)).isoformat()
    for r in rows:
        if (b := bucket(r.get("status"))) and not (b == "needs" and (r.get("date") or "") < stale):
            counts["pending" if b == "needs" and not own_step(r) else b] += 1
    month = (dt.date.today() - dt.timedelta(days=30)).isoformat()
    last = ENGINE / "runs" / "last_daily_run.txt"
    try:
        threads = len(responses())
    except Exception:
        threads = 0
    return {"app": config.APP_NAME, "owner": config.OWNER, "today": dt.date.today().isoformat(),
            "hold": flag("HOLD"), "paused": flag("PAUSED"),
            "last_run": last.read_text(encoding="utf-8").strip() if last.exists() else None, "running": browser_busy(),
            "run_at": config.RUN_AT, "counts": counts, "responses": threads,
            "applied_30d": sum(1 for r in rows if bucket(r.get("status")) == "applied" and (r.get("date") or "") >= month),
            "applied_today": sum(1 for r in rows if bucket(r.get("status")) == "applied"
                                 and (r.get("date") or "") == dt.date.today().isoformat()),
            "model": ai_label(), "email": config.EMAIL,
            "support": bool(config.setting("support_to")),
            "reports": bool(config.setting("support_to") and config.setting("support_reports", False)),
            "pending": pending_count(), "review": review_state(rows), "filters_new": filters_new(),
            "taste": not (ENGINE / "fit_cases.json").exists() and any(
                f.stat().st_size > 120 for f in (ENGINE / "runs").glob("triage-*.csv"))}


def co_key(name):
    import jobseek
    k = jobseek.norm(name)
    return re.sub(r"\b(io|com|ai|systems|labs|group|holdings)$", "", k).strip()


def clean_title(t):
    t = re.split(r"\s+\|\s+", t or "")[0]
    t = re.sub(r"\s+-\s+[\w&.' ]+\bCareers?\b.*$", "", t)
    t = re.sub(r"\s+in\s+[A-Z][\w .'-]+(,\s*[A-Z][\w .'-]+){1,3}$", "", t)
    return t.strip()


def _names(rows):
    best = {}
    for r in rows:
        n = (r.get("company") or "").strip()
        k = co_key(n)
        if n and (k not in best or (best[k].islower() and not n.islower())):
            best[k] = n
    return best


def split_pay(summary):
    pay, rest = [], []
    for line in (summary or "").splitlines():
        (pay if re.match(r"\s*PAY\s*:", line) else rest).append(re.sub(r"^\s*PAY\s*:\s*", "", line))
    return "; ".join(p for p in pay if p.strip()), "\n".join(rest).strip()


NOTES = ENGINE / "job_notes.json"


def notes():
    try:
        return json.loads(NOTES.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


_NOTES_NOW = {}


def save_note(url, text):
    if not (url or "").strip():
        raise ValueError("a note needs the job's link")
    with safe_io.update_json(NOTES) as n:
        if text.strip():
            n[url] = {"text": text.strip(), "updated": dt.date.today().isoformat()}
        else:
            n.pop(url, None)
    return bool(text.strip())


def open_mail(msgid):
    import hashlib
    import os
    import gmail
    out = ENGINE / "runs" / "mail" / (hashlib.sha1(msgid.encode()).hexdigest()[:16] + ".eml")
    if not out.exists():
        m = gmail.connect(tries=2)
        try:
            m.select(f'"{gmail.special(m, chr(92) + "All")}"', readonly=True)
            typ, data = m.uid("SEARCH", None, "HEADER", "Message-ID", f'"{msgid.strip("<>")}"')
            uids = data[0].split() if typ == "OK" and data and data[0] else []
            if not uids:
                raise FileNotFoundError("that email is no longer in the mailbox")
            typ, msg = m.uid("FETCH", uids[-1], "(BODY.PEEK[])")
            raw = next(p[1] for p in msg if isinstance(p, tuple))
        finally:
            m.logout()
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(raw)
    os.startfile(str(out))
    return out.name


def support_sent():
    p = ENGINE / "runs" / "support_sent.json"
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    return sorted(({"date": v.get("date"), "subject": v.get("subject")} for v in d.values()), key=lambda x: x["date"] or "", reverse=True)


def pin_pattern(r):
    return f"^{re.escape(r.get('company') or '')} - {re.escape(r.get('title') or '')}$"


def pins():
    try:
        return [x for x in safe_io.read_json(ENGINE / "targets.json").get("queue_pin") or [] if x]
    except (OSError, ValueError):
        return []


def pinned(r, have=None):
    s = f"{r.get('company') or ''} - {r.get('title') or ''}"
    return any(re.search(x, s, re.I) for x in (pins() if have is None else have))


def set_pin(url, on):
    r = next((x for x in latest_rows() if x.get("url") == url), None)
    if not r:
        raise ValueError("no such job")
    pat = pin_pattern(r)
    with safe_io.locked(ENGINE / "targets.json"):
        t = safe_io.read_json(ENGINE / "targets.json")
        pins = [p for p in t.get("queue_pin") or [] if p != pat]
        if on:
            pins.append(pat)
        t["queue_pin"] = pins
        safe_io.write_json(ENGINE / "targets.json", t)
    fresh()
    return {"pinned": pinned(r, pins), "own": pat in pins}


def job_view(r, side, names, have_pins=None):
    pays, where, fit = side
    p = pays.get(job_key(r.get("url")))
    comp, desc = split_pay(r.get("summary"))
    rng = f"${p[0] // 1000}K-${p[1] // 1000}K" if p else ""
    status = r.get("status") or ""
    return {"date": r.get("date") or "", "company": names.get(co_key(r.get("company")), r.get("company") or ""),
            "co": co_key(r.get("company")), "title": clean_title(r.get("title")), "status": status,
            "kind": "error" if status.lower().startswith("error") else bucket(status) or "",
            "own": own_step(r),
            "pinned": pinned(r, have_pins),
            "pin_own": pin_pattern(r) in (pins() if have_pins is None else have_pins),
            "location": where.get(r.get("url") or "", ""), "pay": rng, "pay_mid": (p[0] + p[1]) // 2 if p else 0,
            "comp": "; ".join(x for x in (f"base {rng}" if rng else "", comp) if x),
            "summary": desc, "fit": fit.get(r.get("url") or "", ""), "notes": r.get("notes") or "",
            "my_notes": (_NOTES_NOW.get(r.get("url") or "") or {}).get("text", "") if r.get("url") else "",
            "url": r.get("url") or "", "action_url": r.get("action_url") or ""}


def jobs(which):
    if which == "responses":
        return responses()
    rows = latest_rows()
    side, names = (_side("pay.json"), _side("locations.json"), _fit_reasons()), _names(rows)
    stale = (dt.date.today() - dt.timedelta(days=STALE_DAYS)).isoformat()
    out, have = [], pins()
    for r in rows:
        if bucket(r.get("status")) == which:
            x = job_view(r, side, names, have)
            x["old"] = which == "needs" and x["date"] < stale
            out.append(x)
    return sorted(out, key=lambda r: r["date"], reverse=True)


def responses():
    import jobseek
    rows = latest_rows()
    names, side = _names(rows), (_side("pay.json"), _side("locations.json"), _fit_reasons())
    by_co = {}
    for r in rows:
        if bucket(r.get("status")) in ("applied", "waiting", "needs"):
            by_co.setdefault(co_key(r.get("company")), []).append(r)
    subj = lambda s: " ".join(re.sub(r"^((re|fw|fwd)\s*:\s*|\[external\]\s*:?\s*)+", "", (s or "").strip(), flags=re.I).lower().split())
    threads = {}
    cache = jobseek._load()
    since = jobseek._since(jobseek.WINDOW_DAYS)
    ids = {id(c): k for k, c in cache.items()}
    mails = [c for c in cache.values() if c.get("kind") in jobseek.RESPONSE_KINDS and c.get("date")
             and dt.datetime.fromisoformat(c["date"]) >= since]
    for c in sorted(mails, key=lambda c: c.get("date", "")):
        k = (co_key(c.get("company")), subj(c.get("subject")))
        th = threads.setdefault(k, {"company": names.get(k[0], c.get("company") or ""), "co": k[0], "subject": c.get("subject"),
                                    "mails": [], "seen": set()})
        sig = ((c.get("date") or "")[:16], subj(c.get("subject")), c.get("sender"))
        if sig in th["seen"]:
            continue
        th["seen"].add(sig)
        th["mails"].append({"date": (c.get("date") or "")[:10], "kind": c.get("kind"), "sender": c.get("sender") or "",
                            "id": ids.get(id(c), "")})
        th["date"], th["kind"] = (c.get("date") or "")[:10], c.get("kind")
    out = []
    for th in threads.values():
        th.pop("seen")
        cands = sorted(by_co.get(th["co"], []), key=lambda r: (bucket(r.get("status")) == "applied", r.get("date") or ""),
                       reverse=True)
        s = (th["subject"] or "").lower()
        hits = [r for r in cands if clean_title(r.get("title")).strip() and clean_title(r.get("title")).lower()[:40] in s]
        best = max(hits, key=lambda r: len(clean_title(r.get("title")))) if hits else (cands[0] if cands else None)
        th["job"] = job_view(best, side, names) if best else None
        th["count"] = len(th["mails"])
        out.append(th)
    return sorted(out, key=lambda t: t["date"], reverse=True)


def companies():
    import jobseek
    rows = latest_rows()
    active = jobseek.active_by_company(None, ledger_rows())
    out = {}
    for name in _names(rows).values():
        k, top = co_key(name), jobseek.max_active(name)
        left = max(0, jobseek.company_slots_left(name, active))
        out[k] = {"used": max(0, top - left), "max": top}
    return out


def job_key(url):
    m = re.search(r"linkedin\.com/jobs/view/(\d+)", url or "")
    return f"li:{m.group(1)}" if m else (url or "").split("?")[0].rstrip("/")


def _fit_reasons():
    out = {}
    for f in sorted((ENGINE / "runs").glob("triage-*.csv")):
        try:
            with f.open(encoding="utf-8") as fh:
                for r in csv.DictReader(fh):
                    if r.get("verdict") == "strong":
                        out[r["url"]] = re.sub(r"\s*GAPS \(info only\):.*", "", r.get("reason") or "")
        except (OSError, KeyError):
            continue
    return out


def _side(name):
    try:
        return json.loads((ENGINE / name).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def setup_state():
    import vault
    try:
        mail = bool(vault.get("EMAIL_PASS"))
    except Exception:
        mail = False
    return {"profile": (ENGINE / "applicant.json").exists(), "targets": (ENGINE / "targets.json").exists(),
            "versions": bool(wizard_state().get("versions_done")) or len(config.CATEGORIES) > 1,
            "ai": ai_state(),
            "gmail_ok": bool(wizard_state().get("gmail_ok")), "alerts_ok": bool(wizard_state().get("alerts_ok")),
            "selftest": bool(wizard_state().get("selftest_ran")),
            "resume": config.MASTER_RESUME.exists(), "gmail": mail, "fit_cases": (ENGINE / "fit_cases.json").exists(),
            "set_up": (ENGINE / "applicant.json").exists() and (ENGINE / "targets.json").exists(),
            "live": is_live(), "stuck": wizard_state().get("stuck")}


def is_live():
    if config.setting("edition") != "product":
        return True
    if wizard_state().get("live"):
        return True
    try:
        import wizard
        return wizard.startup_shortcut().exists()
    except Exception:
        return False


def learn(question, answer, company=None):
    import shutil
    p = ENGINE / "applicant.json"
    with safe_io.locked(p):
        return _learn(p, question, answer, company, shutil)


def _learn(p, question, answer, company, shutil):
    a = json.loads(p.read_text(encoding="utf-8-sig"))
    q = re.sub(r"^\s*still empty:\s*", "", question, flags=re.I).strip().rstrip("*").strip()
    norm = lambda s: " ".join(re.sub(r"[^a-z0-9 ]", " ", (s or "").lower()).split())
    items = [x for x in a.get("learned_answers") or [] if not (norm(x.get("question")) == norm(q)
                                                               and norm(x.get("company")) == norm(company))]
    items.append({"question": q, "answer": answer, "company": company, "date": dt.date.today().isoformat()})
    a["learned_answers"] = items
    bak = ENGINE / "runs" / "settings-backup" / dt.datetime.now().strftime("%Y-%m-%d_%H%M%S_%f")
    bak.mkdir(parents=True, exist_ok=True)
    shutil.copy2(p, bak / p.name)
    safe_io.write_json(p, a)
    return f"{q} -> {answer}" + (f" (only {company})" if company else " (all forms)")


def use_model(path, reasoning=""):
    import settings_api
    settings_api.save({"s:engine.model": Path(path).name, "s:ai_provider": "openai", "s:ai_model": Path(path).stem,
                       "s:ai_base_url": f"http://127.0.0.1:{int(config.setting('ports.model', 9451))}/v1",
                       "s:ai_reasoning": reasoning}, internal=True)


def waiting():
    try:
        w = json.loads((ENGINE / "runs" / "waiting.json").read_text(encoding="utf-8"))
        if dt.datetime.fromisoformat(w["since"]) < dt.datetime.now() - dt.timedelta(minutes=16):
            return {}
    except (OSError, ValueError, KeyError, TypeError):
        return {}
    msg = re.sub(r"[,.]?\s*then (press )?Enter\.?\s*$", ".", str(w.get("msg") or ""), flags=re.I).strip()
    return {"msg": msg, "since": w["since"]}


def pending_count():
    try:
        import apply
        n = len(apply.pending_signins())
    except Exception:
        n = 0
    return n + (ENGINE / "runs" / "linkedin-signin-needed").exists()


def browser_busy():
    import socket
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", config.PORT_LOCK))
        return False
    except OSError:
        return True
    finally:
        s.close()


def action(name, until=None):
    import datetime as _dt
    if until and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", until):
        raise ValueError("date must be YYYY-MM-DD")
    note = {"pause": "Paused from the dashboard - nothing runs.", "hold": "Applying on hold from the dashboard - jobs are still found and queued."}
    if name in ("pause", "hold"):
        f = ENGINE / ("PAUSED" if name == "pause" else "HOLD")
        safe_io.write_text(f, (f"{until}\n" if until else "") + f"{note[name]} ({_dt.date.today()})\n")
        return ("The daily run is paused" if name == "pause" else "Applying is on hold") + (f" until {until}" if until else "") + "."
    if name in ("resume", "unhold"):
        f = ENGINE / ("PAUSED" if name == "resume" else "HOLD")
        if f.exists():
            f.unlink()
        return "The daily run is on again." if name == "resume" else "Applying is on again."
    if name in ("auto", "review"):
        import settings_api
        settings_api.save({"s:auto_submit": name == "auto"})
        return f"{config.APP_NAME} submits by itself." if name == "auto" else "You review each application before it's submitted."
    if name == "nudge-later":
        config.save(review_nudge_at=_dt.date.today().isoformat())
        return "OK"
    if name == "filters-done":
        import gmail_setup
        config.save(filters_saved=gmail_setup.rule_keys())
        return "OK"
    if name == "run":
        if browser_busy():
            raise RuntimeError("A run is already in progress.")
        subprocess.Popen([PY, str(ENGINE / "run_daily.py")], cwd=str(ENGINE), creationflags=subprocess.CREATE_NO_WINDOW,
                         stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return "Run started."
    if name == "pending":
        if not pending_count():
            raise ValueError("Nothing to finish in the browser.")
        subprocess.Popen([PY, str(ENGINE / "apply.py"), "--pending"], cwd=str(ENGINE), creationflags=subprocess.CREATE_NO_WINDOW,
                         stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        return "pending started"
    raise ValueError(f"unknown action {name}")


STAGE_NAMES = {"new alert jobs": "Read the job alerts", "LinkedIn sign-in check": "Checked the LinkedIn sign-in",
               "referral emails": "Referral emails", "recruiter InMails": "Recruiter messages", "score": "Judged the new jobs",
               "pool": "Built the list of fits", "apply": "Applied", "Job Seek sync": "Read employers' replies",
               "trash processed alerts": "Tidied the alert emails", "product refresh": "Product refresh (developer)",
               "report": "Daily report", "share new adapters": "Shared new site support",
               "support reports": "Problem reports"}
BAD = re.compile(r"\bERROR\b|Traceback|failed|exception|signed out", re.I)
NOISE = re.compile(r"^(browser: |== )")


def last_log():
    logs = sorted((ENGINE / "runs").glob("daily-*.log"))
    if not logs:
        return {"name": None, "text": "", "stages": []}
    lines = logs[-1].read_text(encoding="utf-8", errors="replace").splitlines()
    stages, cur = [], None
    for raw in lines:
        m = re.match(r"\[(\d\d:\d\d:\d\d)\] (.*)", raw)
        if not m:
            if cur:
                cur["lines"].append(raw)
            continue
        t, msg = m.groups()
        if msg.startswith("== "):
            name = msg[3:].strip()
            cur = {"time": t[:5], "stage": STAGE_NAMES.get(name, name), "lines": [], "problem": False}
            stages.append(cur)
            continue
        if cur is None:
            cur = {"time": t[:5], "stage": "Start", "lines": [], "problem": False}
            stages.append(cur)
        cur["lines"].append(f"{t[:5]}  {msg}")
        if BAD.search(msg):
            cur["problem"] = True
    summary = re.compile(r"^(applying on hold|already submitted|applied \d|pool:|report sent|daily email off|referrals:|"
                         r"recruiter InMails:|Job Seek:|moved \d|saved triage|\d+ alert emails|kit |support reports|"
                         r"nothing to report|nothing applied and nothing needs you|nothing needs you - no email|PAUSED|"
                         r"practice: \d)", re.I)
    for s in stages:
        useful = [l.split("  ", 1)[-1] for l in s["lines"] if not NOISE.match(l.split("  ", 1)[-1])]
        best = [l for l in useful if summary.match(l.strip())]
        s["outcome"] = ((best or useful)[0 if best and best[0].startswith("applying on hold") else -1] if useful else "done")[:160]
        s["lines"] = s["lines"][-60:]
    return {"name": logs[-1].name, "text": "\n".join(lines[-400:]), "stages": stages}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def send(self, code, body, ctype="application/json; charset=utf-8"):
        data = body if isinstance(body, bytes) else json.dumps(body).encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(data)

    def trusted(self, post):
        port = self.server.server_address[1]
        hosts = {f"127.0.0.1:{port}", f"localhost:{port}", f"{WINDOW_HOST}:{port}"}
        if (self.headers.get("Host") or "") not in hosts:
            return False
        if not post:
            return True
        origin = self.headers.get("Origin")
        if origin is None:
            return self.headers.get("X-Requested-By") == "app"
        return origin in {f"http://{h}" for h in hosts}

    def do_GET(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if not self.trusted(False):
            return self.send(403, {"error": "forbidden"})
        global _NOTES_NOW
        _NOTES_NOW = notes()
        try:
            fresh()
            done = is_live()
            if u.path == "/act":
                return self.send(*act_page(q.get("t", "")))
            if u.path == "/":
                return self.send(200, page_html("ui.html" if done else "setup.html"), "text/html; charset=utf-8")
            reopen = q.get("step") in ("versions", "cases", "linkedin") or \
                (q.get("step"), q.get("replace") or q.get("change")) in (("resume", "1"), ("gmail", "1"))
            if u.path == "/settings" or (u.path == "/setup" and done and (ENGINE / "fit_cases.json").exists() and not reopen):
                return self.send(200, page_html("settings.html"), "text/html; charset=utf-8")
            if u.path == "/api/settings":
                import settings_api
                return self.send(200, settings_api.read())
            if u.path == "/api/settings/fitlists":
                import settings_api
                return self.send(200, {"lists": settings_api.fit_lists(), "labels": settings_api.FIT_LIST_LABELS})
            if u.path == "/api/overview":
                return self.send(200, overview())
            if u.path == "/api/jobs":
                return self.send(200, jobs(q.get("tab", "applied")))
            if u.path == "/api/update/check":
                import updater
                return self.send(200, updater.check())
            if u.path == "/api/version":
                import updater
                return self.send(200, {"version": updater.current()})
            if u.path == "/api/memory":
                import machine
                import engine
                free = machine.free_gb()
                need = engine.min_need(config.setting("engine.model")) if config.setting("engine.model") else machine.floor_gb()
                return self.send(200, {"free_gb": round(free, 1), "need_gb": round(need, 1), "room": free >= need})
            if u.path == "/api/support/sent":
                return self.send(200, support_sent())
            if u.path == "/api/waiting":
                return self.send(200, waiting())
            if u.path == "/api/companies":
                return self.send(200, companies())
            if u.path == "/api/log":
                return self.send(200, last_log())
            if u.path == "/style.css":
                return self.send(200, (HERE / "style.css").read_bytes(), "text/css; charset=utf-8")
            if u.path == "/app.js":
                return self.send(200, (HERE / "app.js").read_bytes(), "text/javascript; charset=utf-8")
            if u.path in ("/icon.png", "/favicon.ico"):
                f = HERE / ("icon.png" if u.path == "/icon.png" else "icon.ico")
                return self.send(200, f.read_bytes(), "image/png" if f.suffix == ".png" else "image/x-icon")
            if u.path == "/setup":
                return self.send(200, page_html("setup.html"), "text/html; charset=utf-8")
            if u.path == "/api/machine":
                import machine
                return self.send(200, machine.check(ENGINE))
            if u.path == "/api/model/status":
                import model_download
                return self.send(200, {**model_download.status(), "installed": config.setting("engine.model")})
            if u.path == "/api/setup/state":
                return self.send(200, setup_state())
            if u.path == "/api/ai/providers":
                return self.send(200, ai_providers())
            if u.path == "/api/settings/extras":
                m = config.MASTER_RESUME
                return self.send(200, {"resume": {"name": m.name, "exists": m.exists(),
                                                  "date": dt.date.fromtimestamp(m.stat().st_mtime).isoformat() if m.exists() else ""},
                                       "mail_address": str(config.setting("mail_address", "") or "")})
            if u.path == "/api/setup/alerts/status":
                f = ENGINE / "runs" / "alerts-setup.json"
                s = json.loads(f.read_text(encoding="utf-8")) if f.exists() else {}
                if s.get("all_ok") and not wizard_state().get("alerts_ok"):
                    wizard_state(alerts_ok=True)
                return self.send(200, s)
            if u.path == "/api/setup/saved":
                return self.send(200, wizard_state())
            if u.path == "/api/setup/gmail":
                return self.send(200, {"email": config.EMAIL, "has_password": setup_state()["gmail"]})
            if u.path == "/api/setup/mail":
                return self.send(200, {"email": config.EMAIL, "address": config.setting("mail_address", "")})
            if u.path == "/api/setup/mail/code":
                try:
                    return self.send(200, {"code": forwarding_code()})
                except Exception:
                    return self.send(200, {"code": ""})
            if u.path == "/api/setup/gmail/folders":
                import settings_api
                return self.send(200, {"folders": settings_api.mail_folders(), "job_seek": config.JOB_SEEK_FOLDER,
                                       "linkedin": config.LINKEDIN_FOLDER, "suggest": {"job_seek": config.DEFAULT_JOB_SEEK_FOLDER,
                                                                                   "linkedin": config.DEFAULT_LINKEDIN_FOLDER}})
            if u.path == "/api/setup/jobs":
                import wizard
                return self.send(200, wizard.triage_jobs())
            if u.path == "/api/setup/questions":
                import wizard
                import formats
                cc = formats.countries.code_of(q.get("country", "")) or "US"
                ex = formats.examples(cc)
                return self.send(200, [{"key": k, "q": qq, "choices": c, "example": ex.get(k, "")}
                                       for k, qq, c in wizard.questions(cc)])
            if u.path == "/api/format/examples":
                import formats
                return self.send(200, formats.examples(formats.countries.code_of(q.get("country", "")) or "US"))
            if u.path == "/api/format/countries":
                import formats
                return self.send(200, formats.countries.COUNTRIES)
            if u.path == "/api/format/country":
                import formats
                cc = formats.countries.code_of(q.get("cc", "")) or "US"
                return self.send(200, {**formats.countries.address_rules(cc), "examples": formats.examples(cc)})
            self.send(404, {"error": "not found"})
        except json.JSONDecodeError as e:
            self.failed(e)
        except ValueError as e:
            self.send(400, {"error": said(e)})
        except Exception as e:
            self.failed(e)

    def failed(self, e):
        if isinstance(e, ConnectionError):
            return
        if type(e).__name__ == "MemoryShort":
            return self.send(503, {"error": str(e), "memory": True})
        self.send(500, {"error": hard_failure(urlparse(self.path).path, e)})

    def do_POST(self):
        u = urlparse(self.path)
        if not self.trusted(True):
            return self.send(403, {"error": "forbidden"})
        try:
            fresh()
            n = int(self.headers.get("Content-Length") or 0)
            if n > 20 * 2 ** 20:
                return self.send(413, {"error": "file too large"})
            body = self.rfile.read(n)
            if u.path == "/api/settings":
                import settings_api
                try:
                    return self.send(200, {"saved": settings_api.save(json.loads(body)["changes"])})
                except (ValueError, AssertionError) as e:
                    return self.send(400, {"error": str(e), "field": getattr(e, "field", None)})
            if u.path == "/api/settings/check":
                import settings_api
                req = json.loads(body or b"{}")
                return self.send(200, settings_api.check(req["id"], req.get("value"), req.get("country")))
            if u.path == "/api/format/check":
                import formats
                req = json.loads(body or b"{}")
                v, problem = formats.fix(req["key"], req.get("value"), formats.countries.code_of(req.get("country") or "") or "US")
                return self.send(200, {"value": v, "error": problem})
            if u.path == "/api/review":
                import review
                req = json.loads(body or b"{}")
                return self.send(200, {"findings": review.review(req.get("values") or {}, req.get("context") or {})})
            if u.path == "/api/review/profile":
                import review
                a = safe_io.read_json(ENGINE / "applicant.json") if (ENGINE / "applicant.json").exists() else {}
                t = safe_io.read_json(ENGINE / "targets.json") if (ENGINE / "targets.json").exists() else {}
                vals, ctx = review.profile_values(a, t)
                return self.send(200, {"findings": review.review(vals, ctx), "checked": sorted(vals)})
            if u.path == "/api/jobs/pin":
                req = json.loads(body or b"{}")
                try:
                    return self.send(200, set_pin(req["url"], bool(req.get("pin"))))
                except ValueError as e:
                    return self.send(404, {"error": str(e)})
            if u.path == "/api/settings/fitlists":
                import settings_api
                try:
                    return self.send(200, {"saved": settings_api.save_fit_lists(json.loads(body)["lists"])})
                except (ValueError, KeyError) as e:
                    return self.send(400, {"error": str(e)})
            if u.path == "/api/settings/reset":
                import settings_api
                req = json.loads(body or b"{}")
                if req.get("confirm") != "RESET":
                    return self.send(400, {"error": 'type RESET to confirm'})
                return self.send(200, {"backup": str(settings_api.factory_reset(bool(req.get("clear_history"))))})
            if u.path == "/api/update/apply":
                import updater
                updater.apply_detached()
                return self.send(200, {"started": True})
            if u.path == "/api/note":
                req = json.loads(body or b"{}")
                return self.send(200, {"saved": save_note(req.get("url") or "", req.get("text") or "")})
            if u.path == "/api/mail/open":
                try:
                    return self.send(200, {"opened": open_mail(json.loads(body)["id"])})
                except Exception:
                    return self.send(400, {"error": "That mail could not be opened on this PC."})
            if u.path == "/api/answer":
                req = json.loads(body or b"{}")
                q, a = (req.get("question") or "").strip(), (req.get("answer") or "").strip()
                if not q or not a:
                    return self.send(400, {"error": "question and answer are needed"})
                return self.send(200, {"saved": learn(q, a, req.get("company") or None)})
            if u.path.startswith("/api/action/"):
                req = json.loads(body or b"{}")
                try:
                    return self.send(200, {"done": action(u.path.rsplit("/", 1)[1], req.get("until"))})
                except (ValueError, RuntimeError) as e:
                    return self.send(409, {"error": str(e)})
            if u.path.startswith("/api/setup/versions"):
                import make_pdf
                import variants
                req = json.loads(body or b"{}")
                if u.path == "/api/setup/versions/skip":
                    wizard_state(versions_done=True)
                    return self.send(200, {"ok": True})
                if not setup_state()["profile"] or not setup_state()["targets"]:
                    return self.send(409, {"error": "Finish the \"Standing answers\" and \"Jobs that fit you\" steps first."})
                if not config.MASTER_RESUME.exists():
                    return self.send(409, {"error": "Your resume file is missing. Add it again in \"Your resume\"."})
                try:
                    word = variants.word_master()
                except ValueError as e:
                    word, why = None, e
                st = variants.structure(word) if word else None
                if st is None:
                    rid = None
                    try:
                        import support
                        rid = support.send_failure("resume versions", why if word is None else
                                                   ValueError("no editable summary in the Word master"),
                                                   f"master: {config.MASTER_RESUME.suffix}")
                    except Exception:
                        pass
                    told = f" Our support has the details ({rid}) and will fix it." if rid else ""
                    return self.send(200, {"unsupported": f"Versions aren't available for this resume yet - it will be used as is.{told}"})
                if u.path == "/api/setup/versions/check":
                    notes = []
                    return self.send(200, {"problems": variants.check(req["version"], st, notes), "notes": notes})
                if u.path == "/api/setup/versions/save":
                    try:
                        names = variants.save(req["versions"])
                    except (ValueError, KeyError, OSError, RuntimeError) as e:
                        return self.send(400, {"error": str(e)})
                    wizard_state(versions_done=True)
                    return self.send(200, {"saved": names})
                kept = wizard_state().get("versions")
                if kept and not req.get("again"):
                    return self.send(200, {**kept, "pdf": bool(make_pdf.available()), "directions": wizard_state().get("directions")})
                prof = req.get("draft") or wizard_state().get("draft") or \
                    json.loads((ENGINE / "targets.json").read_text(encoding="utf-8")).get("_wizard", {}).get("profile", {})
                if "directions" in req:
                    wizard_state(directions=req["directions"])
                own = wizard_state().get("directions")
                directions = [l.strip() for l in own.splitlines() if l.strip()] if own else []
                v = variants.propose(word, prof, directions)
                wizard_state(versions=v)
                return self.send(200, {**v, "pdf": bool(make_pdf.available()), "directions": wizard_state().get("directions")})
            if u.path == "/api/setup/upload":
                import wizard
                if setup_state()["profile"]:
                    return self.send(409, {"error": "already set up here"})
                name = upload_name(self.headers.get("X-File-Name"), "resume.pdf")
                if not name.lower().endswith(".pdf"):
                    return self.send(400, {"error": "only a PDF copy is added this way"})
                return self.send(200, {"kept": wizard.keep_upload(name, body).name})
            if u.path in ("/api/resume/replace/draft", "/api/resume/replace/upload"):
                import wizard
                name = upload_name(self.headers.get("X-File-Name"), "resume.docx")
                f = wizard.keep_upload(name, body, wizard.REPLACE)
                if u.path.endswith("/upload"):
                    return self.send(200, {"kept": f.name})
                return self.send(200, wizard.draft(f))
            if u.path == "/api/resume/replace/save":
                import wizard
                try:
                    out = wizard.replace_resume(json.loads(body)["draft"])
                except (ValueError, AssertionError, FileNotFoundError) as e:
                    return self.send(400, {"error": str(e).replace("applicant.json ", "")})
                fresh()
                return self.send(200, out)
            if u.path == "/api/setup/draft":
                import tempfile
                import wizard
                name = upload_name(self.headers.get("X-File-Name"), "resume.docx")
                if not setup_state()["set_up"]:
                    d = wizard.draft(wizard.keep_upload(name, body))
                    wizard_state(draft=d, lists=None)
                    return self.send(200, d)
                with tempfile.TemporaryDirectory() as tmp:
                    f = Path(tmp) / name
                    f.write_bytes(body)
                    return self.send(200, wizard.draft(f))
            if u.path == "/api/setup/targets":
                import wizard
                req = json.loads(body or b"{}")
                if "lists" not in req:
                    lists = wizard.draft_targets(req["draft"], wizard.llm.RESUME)
                    if not setup_state()["targets"]:
                        wizard_state(lists=lists)
                    return self.send(200, lists)
                import settings_api
                import formats
                drafted = (wizard_state() or {}).get("lists") or {}
                lists = dict(req["lists"])
                try:
                    lists.update(settings_api.tidy_lists({k: v for k, v in lists.items() if k in settings_api.FIT_LIST_LABELS},
                                                         {k: v for k, v in drafted.items() if isinstance(v, list)}))
                except ValueError as e:
                    return self.send(400, {"error": str(e)})
                for k, label in (("profession", "Your profession"), ("target_level", "Lowest level worth applying to")):
                    lists[k], problem = formats.fix(formats.LIST_ITEM, lists.get(k) or "")
                    if problem and lists[k] != drafted.get(k):
                        return self.send(400, {"error": f"{label}: {problem}"})
                req["lists"] = lists
                targets = wizard.to_targets(req["draft"], req["lists"])
                if not setup_state()["targets"]:
                    wizard_state(lists=req["lists"])
                try:
                    return self.send(200, {"saved": str(wizard.save(targets, name="targets.json"))})
                except FileExistsError as e:
                    return self.send(409, {"error": str(e), "preview": targets})
            if u.path == "/api/setup/mail/email":
                return self.send(*mail_email(json.loads(body or b"{}")))
            if u.path == "/api/setup/mail/test":
                return self.send(*mail_test())
            if u.path == "/api/setup/stuck/clear":
                wizard_state(stuck=None)
                return self.send(200, {"cleared": True})
            if u.path == "/api/setup/mail/check":
                st, msg = mail_check()
                if st == "PASS":
                    wizard_state(gmail_ok=True)
                return self.send(200, {"status": st, "message": msg})
            if u.path == "/api/setup/mail/filters":
                import gmail_setup
                if not config.setting("mail_address"):
                    return self.send(409, {"error": "Enter your email address in part 1 first."})
                try:
                    p = gmail_setup.save_filters(config.setting("mail_address"))
                except OSError:
                    return self.send(500, {"error": "The filter file could not be saved in your Downloads folder."})
                config.save(filters_saved=gmail_setup.rule_keys())
                return self.send(200, {"saved": p.name, "folder": p.parent.name})
            if u.path == "/api/filters/new":
                import gmail_setup
                due = gmail_setup.filters_due()
                if not due:
                    return self.send(409, {"error": "Your Gmail filters are up to date."})
                try:
                    p = gmail_setup.save_filters(config.setting("mail_address"), only=due)
                except OSError:
                    return self.send(500, {"error": "The filter file could not be saved in your Downloads folder."})
                return self.send(200, {"saved": p.stem, "folder": p.parent.name})
            if u.path == "/api/setup/gmail/email":
                import wizard
                req = json.loads(body)
                addr = req["email"].strip()
                if req.get("change"):
                    import settings_api
                    old = str(config.EMAIL or "")
                    with safe_io.locked(ENGINE / "settings.json"):
                        s = safe_io.read_json(ENGINE / "settings.json")
                        if str(s.get("report_to") or "").lower() in ("", old.lower()) or str(s.get("report_to", "")).startswith("<"):
                            s["report_to"] = addr
                        s["email"] = addr
                        safe_io.write_json(ENGINE / "settings.json", s)
                    fresh()
                    written = True
                else:
                    written = wizard.fill_setting("email", addr)
                wizard.fill_setting("report_to", addr)
                a = safe_io.read_json(ENGINE / "applicant.json") if (ENGINE / "applicant.json").exists() else {}
                on_forms = str((a.get("identity") or {}).get("email") or "").strip()
                differs = bool(on_forms) and on_forms.lower() != addr.lower()
                return self.send(200, {"written": written, "differs": differs, "on_forms": on_forms})
            if u.path == "/api/waiting/continue":
                (ENGINE / "CONTINUE").touch()
                return self.send(200, {"continued": True})
            if u.path in ("/api/setup/ai", "/api/setup/ai/key", "/api/setup/ai/check"):
                return self.send(*choose_ai(u.path, json.loads(body or b"{}")))
            if u.path == "/api/setup/gmail/password":
                req = json.loads(body or b"{}")
                if setup_state()["gmail"] and not req.get("change"):
                    return self.send(409, {"error": "a Gmail app password is already stored here"})
                v = "".join(str(req.get("value") or "").split())
                ok = gmail_login(str(config.EMAIL or ""), v) if re.fullmatch(r"[A-Za-z]{16}", v) else True
                if ok is False:
                    return self.send(400, {"error": GMAIL_REFUSED})
                code, out = store_secret("EMAIL_PASS", v)
                if code == 200:
                    out["checked"] = ok is True
                return self.send(code, out)
            if u.path == "/api/setup/gmail/check":
                st, msg = gmail_status()
                if st != "FAIL":
                    wizard_state(gmail_ok=True)
                return self.send(200, {"status": st, "message": msg})
            if u.path == "/api/setup/gmail/prepare":
                req = json.loads(body or b"{}")
                if is_live() and not req.get("change"):
                    return self.send(409, {"error": "already set up here - labels and filters exist"})
                pick = {f"s:{k}": str(req[k]).strip() for k in ("job_seek_folder", "linkedin_folder")
                        if str(req.get(k) or "").strip()}
                if "skip_inbox" in req:
                    pick["s:job_mail_skip_inbox"] = bool(req["skip_inbox"])
                if pick:
                    import settings_api
                    settings_api.save(pick)
                    fresh()
                import gmail_setup
                gmail_setup.labels()
                gmail_setup.filters()
                return self.send(200, {"filters_file": str(ENGINE / "gmail_filters.xml"),
                                       "folders": [config.JOB_SEEK_FOLDER, config.LINKEDIN_FOLDER]})
            if u.path == "/api/setup/alerts":
                import wizard
                req = json.loads(body or b"{}")
                if "lists" not in req:
                    return self.send(200, alert_lists(req["draft"]))
                try:
                    query = wizard.alert_query(req["lists"])
                except ValueError as e:
                    return self.send(400, {"error": str(e)})
                keep_alert_lists(req["lists"])
                return self.send(200, {"query": query})
            if u.path == "/api/setup/alerts/run":
                req = json.loads(body or b"{}")
                loc = (safe_io.read_json(ENGINE / "applicant.json") if (ENGINE / "applicant.json").exists() else {}).get("location") or {}
                place = ", ".join(x for x in (loc.get("city"), loc.get("state") or loc.get("state_code")) if x) or req.get("place") or ""
                if not req.get("query") or not place:
                    return self.send(400, {"error": "Build the search first (and finish your profile: the city is needed)."})
                cmd = "create" if req.get("cmd") == "create" else "check"
                safe_io.write_json(ENGINE / "runs" / "alerts-request.json",
                                   {"query": req["query"], "place": place, "levels": req.get("levels") or []})
                (ENGINE / "runs" / "alerts-setup.json").write_text(json.dumps({"state": "starting", "cmd": cmd, "steps": []}),
                                                                   encoding="utf-8")
                subprocess.Popen([PY, str(HERE / "linkedin_alerts.py"), cmd], creationflags=subprocess.CREATE_NO_WINDOW,
                                 cwd=str(ENGINE))
                return self.send(200, {"started": cmd, "place": place})
            if u.path == "/api/open-external":
                import os
                url = str(json.loads(body or b"{}").get("url") or "")
                if not re.match(r"https?://[^\s\"'<>]+$", url):
                    return self.send(400, {"error": "not a web address"})
                os.startfile(url)
                return self.send(200, {"opened": True})
            if u.path == "/api/setup/gmail/show-filters":
                p = ENGINE / "gmail_filters.xml"
                if not p.exists():
                    return self.send(404, {"error": "press \"Create them\" first"})
                subprocess.Popen(["explorer", "/select,", str(p)])
                return self.send(200, {"shown": str(p)})
            if u.path == "/api/open/linkedin-alerts":
                subprocess.Popen([PY, str(ENGINE / "jobapply.py"), "open", "https://www.linkedin.com/jobs/jam/?alerts=true"],
                                 creationflags=subprocess.CREATE_NO_WINDOW, cwd=str(ENGINE))
                return self.send(200, {"opened": True})
            if u.path == "/api/support/note":
                import support
                req = json.loads(body or b"{}")
                if not (req.get("text") or "").strip():
                    return self.send(400, {"error": "Write what went wrong first."})
                try:
                    return self.send(200, {"id": support.send_note(req["text"].strip()[:5000], bool(req.get("log", True)),
                                                                   str(req.get("url") or "")[:500])})
                except Exception as e:
                    return self.send(400, {"error": f"Could not send it: {e}"})
            if u.path == "/api/setup/linkedin":
                subprocess.Popen([PY, str(ENGINE / "jobapply.py"), "open", "https://www.linkedin.com/login"], creationflags=subprocess.CREATE_NO_WINDOW,
                                 cwd=str(ENGINE))
                return self.send(200, {"opened": True})
            if u.path == "/api/setup/cases":
                import wizard
                marks = json.loads(body)["marks"]
                f = ENGINE / "fit_cases.json"
                safe_io.write_json(f, wizard.fit_cases(marks, safe_io.read_json(f) if f.exists() else None))
                rows = {r["url"]: r for r in wizard.triage_jobs(500, include_marked=True)}
                return self.send(200, {"saved": str(f), "suggestions": wizard.taste_suggestions(marks, rows)})
            if u.path == "/api/taste/apply":
                import wizard
                return self.send(200, {"applied": wizard.apply_taste(json.loads(body).get("changes") or [])})
            if u.path == "/api/taste/recheck":
                return self.send(200, {"results": recheck(json.loads(body).get("marks") or [])})
            if u.path == "/api/setup/selftest":
                r = subprocess.run([PY, str(ENGINE / "selftest.py")], cwd=str(ENGINE), capture_output=True, creationflags=subprocess.CREATE_NO_WINDOW,
                                   text=True, encoding="utf-8", errors="replace", timeout=600)
                wizard_state(selftest_ran=True)
                return self.send(200, {"checks": selftest_view(r.stdout), "ok": r.returncode == 0})
            if u.path == "/api/window/ready":
                threading.Thread(target=reveal_window, daemon=True).start()
                return self.send(200, {"started": True})
            if u.path == "/api/setup/alerts/byhand":
                wizard_state(alerts_ok=True, alerts_by_hand=True)
                return self.send(200, {"ok": True})
            if u.path == "/api/model/download":
                if setup_state()["set_up"]:
                    return self.send(409, {"error": "this install is already set up - its AI model is chosen in Settings"})
                import machine
                import model_download
                import model_update
                mc = machine.check(ENGINE)
                pick = mc.get("model")
                if not pick:
                    return self.send(400, {"error": "this computer is too small for the built-in model"})
                folder = config.path(config.setting("engine.models", str(ENGINE.parent / "models")))

                def done(p, r=pick.get("reasoning", ""), fb=mc.get("fallback")):
                    use_model(p, r)
                    model_update.fetch_fallback(fb, folder)
                return self.send(200, model_download.start(pick["url"], folder, pick["file"], done, sha256=pick.get("sha256")))
            if u.path == "/api/setup/golive":
                import wizard
                if not wizard_state().get("gmail_ok"):
                    return self.send(409, {"error": "Set up your job mail first (the \"Job mail\" step)."})
                try:
                    lnk = wizard.go_live()
                except FileExistsError as e:
                    return self.send(409, {"error": str(e)})
                wizard_state(live=True)
                return self.send(200, {"shortcut": str(lnk)})
            if u.path == "/api/setup/save":
                import wizard
                req = json.loads(body or b"{}")
                if not setup_state()["profile"]:
                    wizard_state(draft=req["draft"])
                problem = wizard.format_problem(req["draft"], req.get("answers") or {})
                if problem:
                    return self.send(400, {"error": problem})
                applicant = wizard.apply_answers(wizard.to_applicant(req["draft"]), req.get("answers") or {})
                new = not setup_state()["profile"]
                if new:
                    ups = sorted(wizard.UPLOAD.glob("*")) if wizard.UPLOAD.exists() else []
                    applicant["resumes"] = {"General": str(ups[0])} if ups else applicant.get("resumes") or {}
                gaps, problem = wizard.missing(applicant)
                if gaps or problem:
                    return self.send(400, {"error": problem or wizard.fill_in(gaps), "missing": gaps})
                import settings_api
                try:
                    settings_api.cross_check(applicant, set(settings_api.ADDRESS) | {"a:compensation.floor.min_base_usd"})
                except settings_api.FieldError as e:
                    return self.send(400, {"error": str(e).replace("(USD a year)", "").replace("  ", " ")})
                if new:
                    try:
                        applicant["resumes"] = {"General": str(wizard.set_up_resume(applicant["identity"]["first_name"],
                                                                                    applicant["identity"]["last_name"]))}
                    except Exception as e:
                        return self.send(400, {"error": f"Could not prepare your resume file: {e}"})
                try:
                    saved = str(wizard.save(applicant))
                    ident = applicant.get("identity") or {}
                    wizard.fill_setting("owner", f"{ident.get('first_name', '')} {ident.get('last_name', '')}".strip())
                    return self.send(200, {"saved": saved})
                except FileExistsError as e:
                    return self.send(409, {"error": str(e), "preview": applicant})
            self.send(404, {"error": "not found"})
        except json.JSONDecodeError as e:
            self.failed(e)
        except ValueError as e:
            self.send(400, {"error": said(e)})
        except Exception as e:
            self.failed(e)


ONLINE = {
    "anthropic": {"label": "Anthropic (Claude)", "key": "ANTHROPIC_API_KEY", "model": "claude-haiku-4-5",
                  "model_name": "Claude Haiku 4.5", "key_page": "https://console.anthropic.com/settings/keys"},
    "openai": {"label": "OpenAI (GPT)", "key": "OPENAI_API_KEY", "model": "gpt-4.1-mini", "model_name": "GPT-4.1 mini",
               "base_url": "https://api.openai.com/v1", "key_page": "https://platform.openai.com/api-keys"},
    "gemini": {"label": "Google (Gemini)", "key": "GEMINI_API_KEY", "model": "gemini-2.5-flash", "model_name": "Gemini 2.5 Flash",
               "base_url": "https://generativelanguage.googleapis.com/v1beta/openai", "key_page": "https://aistudio.google.com/apikey"},
    "other": {"label": "Another online service", "key": "OTHER_AI_API_KEY", "model": None, "base_url": None,
              "key_page": "the service's own API-keys page"},
}


def ai_providers():
    cur = ai_state()
    out = [{"id": "builtin", "label": "Built-in AI", "model": "runs privately on this PC"}]
    out += [{"id": k, "label": o["label"], "model": o["model_name"]} for k, o in ONLINE.items() if k != "other"]
    if cur["provider"] == "other":
        out.append({"id": "other", "label": ONLINE["other"]["label"], "model": config.AI_MODEL})
    return {**cur, "providers": out}


def ai_state():
    import vault
    p = config.AI_PROVIDER
    local = p != "anthropic" and bool(re.match(r"https?://(127\.0\.0\.1|localhost)(:|/|$)", config.AI_BASE_URL or ""))
    if local:
        return {"provider": "builtin", "ready": bool(config.setting("engine.model")), "model": config.setting("engine.model")}
    key = config.setting("ai_key_name") or "OPENAI_API_KEY"
    name = "anthropic" if p == "anthropic" else next((k for k, o in ONLINE.items() if o["key"] == key), "other")
    try:
        have = bool(vault.get(ONLINE[name]["key"]))
    except Exception:
        have = False
    return {"provider": name, "ready": have, "model": config.AI_MODEL}


def choose_ai(path, req):
    import settings_api
    if path == "/api/setup/ai/check":
        r = subprocess.run([PY, "-E", "-s", "-c", "import llm; print(llm._parse(llm.Draft, 'Reply with the single word OK.', 20).text)"],
                           cwd=str(ENGINE), capture_output=True, text=True, encoding="utf-8", errors="replace", timeout=900,
                           creationflags=subprocess.CREATE_NO_WINDOW)
        tail = (r.stderr or "").strip().splitlines()[-1:] or ["no answer"]
        return 200, {"ok": r.returncode == 0, "message": "The AI answered." if r.returncode == 0 else tail[0][:300]}
    name = req.get("provider")
    if name == "builtin":
        model = config.setting("engine.model") or ""
        if not model or not (config.path(config.setting("engine.models", str(ENGINE.parent / "models"))) / Path(model).name).exists():
            return 400, {"error": "The built-in AI isn't downloaded yet."}
        port = int(config.setting("ports.model", 9451))
        settings_api.save({"s:ai_provider": "openai", "s:ai_base_url": f"http://127.0.0.1:{port}/v1",
                           "s:ai_model": Path(model).stem}, internal=True)
        return 200, {"provider": "builtin"}
    if name not in ONLINE:
        return 400, {"error": "Choose an AI from the list."}
    o = ONLINE[name]

    def switch():
        base = o.get("base_url") or req.get("base_url") or config.AI_BASE_URL
        model = o.get("model") or req.get("model") or config.AI_MODEL
        if name == "other" and (not re.match(r"https://", base or "") or not model):
            return "this online service needs its address and model - ask our support (Report a problem)"
        settings_api.save({"s:ai_provider": "anthropic" if name == "anthropic" else "openai", "s:ai_model": model,
                           "s:ai_base_url": base, "s:ai_reasoning": "", "s:ai_key_name": o["key"]}, internal=True)
        return None
    if path == "/api/setup/ai/key" and "value" in req:
        code, out = store_secret(o["key"], req.get("value"))
        if code == 200:
            err = switch()
            if err:
                return 400, {"error": err}
        return code, {**out, "provider": name, "label": o["label"]}
    import vault
    try:
        have = bool(vault.get(o["key"]))
    except Exception:
        have = False
    if have and path == "/api/setup/ai":
        err = switch()
        if err:
            return 400, {"error": err}
        return 200, {"provider": name, "have_key": True, "label": o["label"]}
    return 200, {"provider": name, "need_key": True, "key_page": o["key_page"], "label": o["label"]}


KEY_START = {"ANTHROPIC_API_KEY": ("sk-ant-", "Anthropic"), "OPENAI_API_KEY": ("sk-", "OpenAI"),
             "GEMINI_API_KEY": ("AIza", "Google")}


def store_secret(name, value):
    import vault
    v = "".join(str(value or "").split())
    if name == "EMAIL_PASS":
        if not re.fullmatch(r"[A-Za-z]{16}", v):
            return 400, {"error": "A Gmail app password is 16 letters (Google shows it as 4 groups of 4) - copy it again."}
    else:
        start, who = KEY_START.get(name, ("", "that company"))
        if len(v) < 20 or not v.startswith(start):
            return 400, {"error": f"This does not look like an API key from {who}"
                                  + (f" (theirs start with {start})" if start else "") + " - copy it again."}
    try:
        vault._cm_write(name, v)
    except Exception as e:
        return 500, {"error": "Couldn't save the key. Try again."}
    return 200, {"stored": True}


GMAIL_REFUSED = "Gmail did not accept this app password - copy it again, or create a new one (Google shows each only once)."


def gmail_login(addr, pw):
    import imaplib
    try:
        m = imaplib.IMAP4_SSL("imap.gmail.com", timeout=30)
    except OSError:
        return None
    try:
        m.login(addr, pw)
        return True
    except imaplib.IMAP4.abort:
        return None
    except imaplib.IMAP4.error:
        return False
    except OSError:
        return None
    finally:
        try:
            m.logout()
        except Exception:
            pass


def gmail_status():
    import imaplib
    import selftest
    try:
        st, _msg = selftest.gmail_check()
    except imaplib.IMAP4.abort:
        return "FAIL", "Gmail could not be reached - check the internet connection, then try again."
    except imaplib.IMAP4.error:
        return "FAIL", "Gmail did not accept the stored app password - enter a new one (Google cancels app passwords " \
                       "when your Google password changes)."
    except OSError:
        return "FAIL", "Gmail could not be reached - check the internet connection, then try again."
    except Exception as e:
        return "FAIL", "No app password is stored yet." if "not set" in str(e) else f"Gmail could not be checked ({type(e).__name__})."
    if st == "FAIL":
        return "FAIL", f'Gmail works, but the folder "{config.JOB_SEEK_FOLDER}" is missing - press "Use these folders" ' \
                       "(Setup > Gmail)."
    try:
        import gmail_setup
        _out, loose = gmail_setup.check()
    except Exception:
        loose = 0
    if loose:
        return "WARN", f"Connected. {loose} LinkedIn job alert{'s are' if loose > 1 else ' is'} still in your inbox - " \
                       "the filters are not imported yet (the last part of the Gmail step)."
    return "PASS", "Connected - Gmail works and the folders are ready."


def said(e):
    t = str(e).strip()
    return t[:1].upper() + t[1:] if t else "That did not work - please try again."


def ai_label():
    url = str(config.setting("ai_base_url") or "")
    if config.AI_PROVIDER != "anthropic" and re.match(r"https?://(127\.0\.0\.1|localhost)[:/]", url):
        return "built-in (runs on this PC)"
    if config.AI_PROVIDER == "anthropic":
        return "Anthropic (online)"
    return "Google Gemini (online)" if "googleapis" in url else "OpenAI (online)"


STUCK_STEP = (("/api/setup/mail", "gmail"), ("/api/setup/draft", "resume"), ("/api/setup/upload", "resume"),
              ("/api/setup/save", "answers"), ("/api/setup/questions", "answers"), ("/api/setup/targets", "targets"),
              ("/api/setup/versions", "versions"), ("/api/setup/alerts", "linkedin"), ("/api/setup/linkedin", "linkedin"),
              ("/api/setup/selftest", "test"), ("/api/setup/golive", "live"), ("/api/setup/cases", "cases"),
              ("/api/setup/ai", "machine"), ("/api/model", "machine"))
STEP_NAMES = {"machine": "Welcome", "gmail": "Job mail", "resume": "Your resume", "answers": "Standing answers",
              "targets": "Jobs that fit you", "versions": "Resume versions", "linkedin": "Job alerts", "test": "Self-test",
              "live": "Go live", "cases": "Teach it your taste"}


CHECK_LABELS = {"applicant.json": "Your profile", "targets.json": "Jobs that fit you", "resumes": "Your resume",
                "Gmail (IMAP)": "Job mail", "AI model": "AI", "Chrome + sign-ins": "LinkedIn sign-in",
                "daily scheduler": "Daily run", "fit_cases.json": "Your taste"}
CHECK_STEP = {"applicant.json": "Your resume", "targets.json": "Jobs that fit you", "resumes": "Resume versions",
              "AI model": "Welcome"}
CHECK_LATER = {"fit_cases.json": "after the first run", "daily scheduler": "turned on in \"Go live\""}
CHECK_YOU = {"Chrome + sign-ins": "sign in on the \"Job alerts\" step",
             "Gmail (IMAP)": "send a test mail on the \"Job mail\" step"}


def selftest_view(output):
    rows, ours = [], []
    for m in re.finditer(r"^(PASS|WARN|FAIL)\s{2}(\S.{0,40}?)\s{2,}(.*)$", output or "", re.M):
        st, name, text = m.group(1), m.group(2).strip(), m.group(3).strip()
        label = CHECK_LABELS.get(name)
        if label is None:
            if st != "PASS":
                ours.append((name, text))
        elif st == "PASS":
            rows.append({"label": label, "state": "ok", "text": ""})
        elif name in CHECK_LATER:
            rows.append({"label": label, "state": "later", "text": CHECK_LATER[name]})
        elif name in CHECK_YOU:
            rows.append({"label": label, "state": "you", "text": CHECK_YOU[name]})
        elif st == "WARN" and name in CHECK_STEP:
            rows.append({"label": label, "state": "you", "text": f"check the \"{CHECK_STEP[name]}\" step"})
        else:
            ours.append((name, text))
    if ours:
        rid = None
        try:
            import support
            rid = support.send_failure("self-test: " + ", ".join(n for n, _ in ours), RuntimeError("; ".join(t for _, t in ours)))
        except Exception:
            pass
        rows.append({"label": "WorksForMe", "state": "ours", "text": f"Our support is on it ({rid})" if rid
                     else "something didn't pass - try again later"})
    return rows


def fixed_reports():
    try:
        return set(json.loads((HERE / "fixed.json").read_text(encoding="utf-8")).get("fixed") or [])
    except (OSError, ValueError):
        return set()


def after_update():
    st = wizard_state().get("stuck") or {}
    if not st.get("rid") or st.get("fixed") or st["rid"] not in fixed_reports():
        return None
    wizard_state(stuck={**st, "fixed": True})
    name = STEP_NAMES.get(st.get("step"), "setup")
    app_name = config.APP_NAME
    text = (f"The problem that stopped the \"{name}\" step of your {app_name} setup ({st['rid']}) is fixed in today's "
            f"update. Open {app_name} and continue where you left off - everything you entered is still there.\n\n"
            f"- {app_name}'s support")
    try:
        import report
        report.send(f"Fixed - continue your {app_name} setup", text,
                    "<p>" + html.escape(text.split("\n\n")[0]) + "</p><p>" + html.escape(text.split("\n\n")[1]) + "</p>")
    except Exception:
        pass
    return f"Fixed: the \"{name}\" step works again - click to continue your setup.", f"/setup?step={st.get('step') or ''}"


def hard_failure(where, e, detail=""):
    try:
        import support
        rid = support.send_failure(where, e, detail)
    except Exception:
        rid = None
    step = next((s for p, s in STUCK_STEP if where.startswith(p)), None)
    if rid and step:
        try:
            wizard_state(stuck={"step": step, "rid": rid})
        except Exception:
            pass
    if rid:
        return f"Something went wrong. Our support is on it ({rid})."
    return "Something went wrong. Try again."


ALERT_KEYS = ("experience", "target_titles", "core_domains", "adjacent_domains", "summary")


def alert_lists(draft):
    import wizard
    key = hashlib.sha256(json.dumps({k: draft.get(k) for k in ALERT_KEYS}, sort_keys=True).encode()).hexdigest()[:16]
    saved = wizard_state().get("alert_lists") or {}
    if saved.get("key") == key and saved.get("lists"):
        return saved["lists"]
    lists = wizard.draft_alerts(draft)
    wizard_state(alert_lists={"key": key, "lists": lists})
    return lists


def keep_alert_lists(lists):
    saved = wizard_state().get("alert_lists") or {}
    if saved.get("lists"):
        wizard_state(alert_lists={**saved, "lists": {**saved["lists"], **lists}})


NOT_GOOGLE = re.compile(r"(?:outlook|hotmail|live|msn|windowslive|yahoo|ymail|rocketmail|icloud|me|mac|aol|proton|"
                        r"protonmail|pm|gmx|yandex|zoho|mail|tutanota|tuta|fastmail|walla|bezeqint|netvision|zahav|"
                        r"012|013|014)\.(?:com|net|org|me|io|[a-z]{2}|co\.[a-z]{2}|com\.[a-z]{2}|net\.[a-z]{2})")


def mail_email(req):
    import fwdmail
    addr = str(req.get("email") or "").strip()
    if not re.fullmatch(r"[^@\s]+@[^@\s]+\.[^@\s]+", addr):
        return 400, {"error": "That does not look like an email address - check it and try again."}
    dom = addr.rsplit("@", 1)[1].lower()
    if NOT_GOOGLE.fullmatch(dom):
        return 400, {"error": f"{dom} isn't supported yet. Use a Gmail or Google Workspace address."}
    with safe_io.locked(ENGINE / "settings.json"):
        s = safe_io.read_json(ENGINE / "settings.json")
        changed = str(s.get("email") or "").strip().lower() != addr.lower()
        s["email"], s["report_to"] = addr, addr
        safe_io.write_json(ENGINE / "settings.json", s)
    fresh()
    if changed:
        wizard_state(gmail_ok=False)
    try:
        address = fwdmail.register(addr.split("@")[0])
        fwdmail.call("POST", "/v1/owner", {"address": addr, "check": False}, acct=fwdmail.account())
    except fwdmail.ServerError:
        return 503, {"error": "Couldn't connect. Check your internet connection and try again."}
    a = safe_io.read_json(ENGINE / "applicant.json") if (ENGINE / "applicant.json").exists() else {}
    on_forms = str((a.get("identity") or {}).get("email") or "").strip()
    return 200, {"address": address, "on_forms": on_forms, "differs": bool(on_forms) and on_forms.lower() != addr.lower(),
                 "changed": changed}


def mail_test():
    import fwdmail
    addr = str(config.EMAIL or "").strip()
    if not fwdmail.account() or "@" not in addr:
        return 400, {"error": "Enter your email address in part 1 first."}
    try:
        r = fwdmail.call("POST", "/v1/owner", {"address": addr}, acct=fwdmail.account())
    except fwdmail.ServerError:
        return 503, {"error": "Couldn't connect. Check your internet connection and try again."}
    if r.get("verified"):
        return 200, {"verified": True}
    if not r.get("check_sent"):
        return 429, {"error": "You've reached today's test mail limit. Try again tomorrow."}
    return 200, {"sent": True}


def forwarding_code():
    import localmail
    box = localmail.connect()
    try:
        box.select(localmail.ALL)
        for u in reversed(box.uid("SEARCH", "X-GM-RAW", '"from:forwarding-noreply@google.com newer_than:3d"')[1][0].split()):
            raw = box.uid("FETCH", u, "(BODY.PEEK[])")[1][0][1].decode("utf-8", "replace")
            m = re.search(r"Confirmation code:\s*(\d{6,12})|\(#(\d{6,12})\)", raw)
            if m:
                return m.group(1) or m.group(2)
        return ""
    finally:
        box.logout()


def mail_check():
    import fwdmail
    import localmail
    if not fwdmail.account():
        return "WARN", "Enter your email address in part 1 first."
    try:
        s = localmail.Store()
        try:
            localmail.sync(s)
        finally:
            s.close()
        st = fwdmail.status()
        if not st.get("verified") and localmail.confirm_codes():
            st = fwdmail.status()
    except fwdmail.ServerError:
        return "WARN", "Couldn't connect. Retrying..."
    owner, seen, asked = str(config.EMAIL or "").strip(), localmail.forwarded_from(), localmail.asked_from()
    if st.get("verified") or localmail.same_mailbox(seen, owner):
        return "PASS", f"Connected ({config.EMAIL})"
    if seen:
        return "WARN", f"Mail arrives from {seen}, not from {config.EMAIL}. Forward from {config.EMAIL}."
    if asked and not localmail.same_mailbox(asked, owner):
        return "WARN", f"Forwarding was set up from {asked}, not from {config.EMAIL}. Set it up from {config.EMAIL}."
    if asked:
        return "WARN", "Gmail is ready to forward - now import the filter file, then send a test mail."
    return "WARN", "Not connected yet - set up the forwarding in Gmail, then send a test mail."


def recheck(marks):
    jobs = []
    for m in marks[:12]:
        jid = re.search(r"jobs/view/(\d+)", m.get("url") or "")
        p = ENGINE / "runs" / "jd" / f"{jid.group(1)}.txt" if jid else None
        if p and p.exists():
            jobs.append([m["title"], m["company"], p.read_text(encoding="utf-8"), bool(m["apply"])])
    if not jobs:
        return []
    code = ("import json, sys, llm\nout = []\nfor t, c, jd, want in json.loads(sys.stdin.read()):\n"
            "    v, why = llm.fit(t, c, jd); out.append({'title': t, 'company': c, 'it': 'apply' if v == 'strong' else 'skip',"
            " 'you': 'apply' if want else 'skip', 'why': why[:160]})\nprint(json.dumps(out))")
    r = subprocess.run([PY, "-E", "-s", "-c", code], cwd=str(ENGINE), input=json.dumps(jobs), capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=3600, creationflags=subprocess.CREATE_NO_WINDOW)
    try:
        return json.loads(r.stdout.strip().splitlines()[-1])
    except (ValueError, IndexError):
        raise RuntimeError((r.stderr or "no answer").strip().splitlines()[-1][:200])


def upload_name(header, default):
    name = Path(unquote(header or "")).name.strip()
    return default if name in ("", ".", "..") else name


ACT_PAGE = """<!doctype html><html><head><meta charset="utf-8"><title>{app}</title>
<style>body{{margin:0;font:15px/1.5 "Segoe UI",system-ui,sans-serif;background:#f4f6fa;color:#171c24;display:grid;place-items:center;height:100vh}}
div{{max-width:460px;background:#fff;border:1px solid #e2e7ee;border-top:4px solid #12808c;border-radius:12px;padding:22px 28px;text-align:center}}
img{{width:40px;height:40px}} p{{margin:6px 0;color:#5c6878;font-size:14px}}
button{{margin-top:10px;padding:8px 18px;border:0;border-radius:7px;background:#12808c;color:#fff;font:inherit;cursor:pointer}}</style></head>
<body><div><img src="/icon.png" alt=""><h3 style="margin:8px 0 4px">{head}</h3><p>{text}</p><div id="w"></div></div>
<script>
let last = null;
async function poll() {{
  try {{
    const j = await (await fetch("/api/waiting")).json(), w = document.getElementById("w"), m = j.msg || "";
    if (m !== last) {{
      last = m; w.innerHTML = "";
      if (m) {{
        const p = document.createElement("p"); p.style.color = "#171c24"; p.textContent = m + " When it is done there, press Continue.";
        const b = document.createElement("button"); b.textContent = "Continue";
        b.onclick = async () => {{ await fetch("/api/waiting/continue", {{method: "POST"}}); w.innerHTML = "<p>Continuing...</p>"; last = null; }};
        w.append(p, b);
      }}
    }}
  }} catch (e) {{}}
  setTimeout(poll, 3000);
}}
poll();
</script></body></html>"""


def page_html(name):
    import hashlib
    v = hashlib.sha1((HERE / "icon.png").read_bytes()).hexdigest()[:8]
    return (HERE / name).read_bytes().replace(b'"/icon.png"', f'"/icon.png?v={v}"'.encode())


def act_page(tok):
    import html as _h
    import email_actions
    page = lambda head, text: (200, ACT_PAGE.format(app=_h.escape(config.APP_NAME), head=_h.escape(head),
                                                    text=_h.escape(text)).encode("utf-8"), "text/html; charset=utf-8")
    e = email_actions.take(tok)
    if not e:
        return page("This link has expired", f"Open {config.APP_NAME} from the tray icon or the Start menu.")
    job = f"{e.get('company')} - {e.get('title')}".strip(" -")
    if e["kind"] == "finish":
        if e.get("previous") and e["previous"] >= (dt.datetime.now() - dt.timedelta(seconds=90)).isoformat(timespec="seconds"):
            return page("Already started", f"WorksForMe's browser is already open on {job}.")
        if browser_busy():
            return page("Not right now", "WorksForMe is busy. Try again in a few minutes.")
        subprocess.Popen([PY, str(ENGINE / "apply.py"), "--pending", "--only", e["url"]], cwd=str(ENGINE),
                         creationflags=subprocess.CREATE_NO_WINDOW, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                         stderr=subprocess.DEVNULL)
        return page("Started", f"Opening {job}. Sign in or enter the code to finish.")
    return page("Unknown action", f"Open {config.APP_NAME} from the tray icon or the Start menu.")


QUIET = [
    (("credentials_enable_service",), False), (("profile", "password_manager_enabled"), False),
    (("autofill", "enabled"), False), (("autofill", "profile_enabled"), False),
    (("autofill", "credit_card_enabled"), False),
    (("translate", "enabled"), False),
    (("profile", "exit_type"), "Normal"), (("profile", "exited_cleanly"), True),
    (("edge_quick_search", "show_mini_menu"), False),
]


def quiet_profile(prof):
    p = Path(prof) / "Default" / "Preferences"
    try:
        s = json.loads(p.read_text(encoding="utf-8"))
        s = s if isinstance(s, dict) else {}
    except (OSError, ValueError):
        s = {}
    for path, value in QUIET:
        node = s
        for k in path[:-1]:
            if not isinstance(node.get(k), dict):
                node[k] = {}
            node = node[k]
        node[path[-1]] = value
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(s), encoding="utf-8")
    except OSError:
        pass


WINDOW_HOST = (re.sub(r"[^a-z0-9-]", "", config.APP_NAME.lower()) or "app") + ".localhost"
OFF_SCREEN = -12000


_OPENED = [0.0]


def parked(left, top, iconic, exe):
    return not iconic and exe.lower() in ("msedge.exe", "chrome.exe") \
        and -30000 < left <= OFF_SCREEN // 2 and -30000 < top <= OFF_SCREEN // 2


def reveal_window():
    if time.time() - _OPENED[0] > 60:
        return 0
    try:
        import ctypes
        import ctypes.wintypes as wt
    except ImportError:
        return 0
    u, k = ctypes.windll.user32, ctypes.windll.kernel32
    found = []

    def exe_of(h):
        pid = wt.DWORD()
        u.GetWindowThreadProcessId(h, ctypes.byref(pid))
        p = k.OpenProcess(0x1000, False, pid.value)
        if not p:
            return ""
        try:
            buf, n = ctypes.create_unicode_buffer(520), wt.DWORD(520)
            return buf.value.rsplit("\\", 1)[-1] if k.QueryFullProcessImageNameW(p, 0, buf, ctypes.byref(n)) else ""
        finally:
            k.CloseHandle(p)

    def each(h, _):
        r = wt.RECT()
        if u.IsWindowVisible(h) and u.GetWindowRect(h, ctypes.byref(r)) and r.left < OFF_SCREEN // 2:
            if parked(r.left, r.top, bool(u.IsIconic(h)), exe_of(h)):
                found.append((h, r.right - r.left, r.bottom - r.top))
        return True
    u.EnumWindows(ctypes.WINFUNCTYPE(ctypes.c_bool, wt.HWND, wt.LPARAM)(each), 0)
    work = wt.RECT()
    u.SystemParametersInfoW(0x0030, 0, ctypes.byref(work), 0)
    for h, w, ht in found:
        w, ht = min(w, work.right - work.left), min(ht, work.bottom - work.top)
        x, y = work.left + (work.right - work.left - w) // 2, work.top + (work.bottom - work.top - ht) // 2
        u.SetWindowPos(h, 0, x, y, w, ht, 0x0004 | 0x0040)
        u.SetForegroundWindow(h)
    return len(found)


def open_window(url):
    import shutil
    for exe in (r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                r"C:\Program Files\Microsoft\Edge\Application\msedge.exe", config.CHROME_EXE, shutil.which("msedge")):
        if exe and Path(exe).exists():
            root = ENGINE.parent
            prof = root / "ui-profile" if (root / "runtime" / "python.exe").exists() else Path.home() / ".daybook-ui"
            quiet_profile(prof)
            url = re.sub(r"^http://(127\.0\.0\.1|localhost):", f"http://{WINDOW_HOST}:", url)
            _OPENED[0] = time.time()
            subprocess.Popen([exe, f"--app={url}", f"--user-data-dir={prof}", "--window-size=1280,860",
                              f"--window-position={OFF_SCREEN},{OFF_SCREEN}",
                              "--disable-extensions", "--disable-component-extensions-with-background-pages",
                              "--no-first-run", "--no-default-browser-check", "--disable-sync",
                              "--disable-features=Translate", "--disable-session-crashed-bubble",
                              "--overscroll-history-navigation=0", "--disable-pinch"])
            threading.Timer(10, reveal_window).start()
            return True
    import webbrowser
    return webbrowser.open(url)


def main():
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    url = f"http://127.0.0.1:{PORT}/"
    print(f"{config.APP_NAME} dashboard: {url}")
    if "--no-window" not in sys.argv:
        threading.Timer(0.5, open_window, args=(url,)).start()
    srv.serve_forever()


if __name__ == "__main__":
    main()
