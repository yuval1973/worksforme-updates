import json
import socket
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent
ENGINE = HERE.parent
sys.path[:0] = [str(ENGINE), str(HERE)]
STATE = ENGINE / "runs" / "update" / "model.json"
_PICK = {}


def _state():
    try:
        return json.loads(STATE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save(**kv):
    import safe_io
    s = _state()
    s.update(kv)
    safe_io.write_json(STATE, s)


def _free(port):
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", port))
        return True
    except OSError:
        return False
    finally:
        s.close()


def wanted():
    import machine
    if time.time() - _PICK.get("at", 0) > 6 * 3600:
        c = machine.check(ENGINE)
        _PICK.update(at=time.time(), model=c.get("model"), fallback=c.get("fallback"))
    return _PICK["model"]


def fetch_fallback(fb, folder):
    import shutil
    import model_download
    folder = Path(folder)
    if not fb or (folder / fb["file"]).exists() or model_download.status().get("state") in ("downloading", "checking"):
        return None
    folder.mkdir(parents=True, exist_ok=True)
    if shutil.disk_usage(folder).free / 2 ** 30 < fb["download_gb"] + 5:
        return None
    model_download.start(fb["url"], folder, fb["file"], lambda p: None, sha256=fb.get("sha256"))
    return "the smaller AI model is downloading"


def test(path, reasoning=""):
    py = str(Path(sys.executable).with_name("python.exe"))
    code = ("import sys; sys.path[:0] = ['.', 'product']; import config; "
            "config.SETTINGS.setdefault('engine', {})['model'] = sys.argv[1]; import llm; llm.REASONING = sys.argv[2]; "
            "print(llm._parse(llm.Draft, 'Reply with the single word OK.', 20).text)")
    r = subprocess.run([py, "-E", "-s", "-c", code, str(path), reasoning], cwd=str(ENGINE), capture_output=True, text=True,
                       encoding="utf-8", errors="replace", timeout=1800, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    return r.returncode == 0 and bool(r.stdout.strip()), (r.stderr or r.stdout).strip()[-300:]


def tick(notify=lambda title, text: None, setting=None):
    import config
    import model_download
    setting = setting or config.setting
    if not setting("auto_update", True):
        return None
    base = str(setting("ai_base_url", "") or "")
    if setting("ai_provider", "anthropic") == "anthropic" or not base.startswith(("http://127.0.0.1", "http://localhost")):
        return None
    cur, pick = setting("engine.model"), wanted()
    folder = config.path(setting("engine.models", str(ENGINE.parent / "models")))
    if not pick or not cur or pick["file"] == cur or pick["file"] in _state().get("failed", []):
        return fetch_fallback(_PICK.get("fallback"), folder) if cur else None
    dest = folder / pick["file"]
    if not dest.exists():
        if model_download.status().get("state") == "downloading":
            return "downloading"
        model_download.start(pick["url"], folder, pick["file"], lambda p: None, sha256=pick.get("sha256"))
        _save(file=pick["file"], state="downloading")
        notify("AI model", "Downloading an improved AI model.")
        return "download started"
    if not (_free(int(setting("ports.lock", 9446))) and _free(int(setting("ports.model", 9451)))):
        return "waiting: a run or the engine is busy"
    ok, why = test(dest, pick.get("reasoning", ""))
    if not ok:
        _save(failed=_state().get("failed", []) + [pick["file"]], state="failed", why=why)
        dest.unlink(missing_ok=True)
        return f"the new model failed its test - kept {cur}"
    import settings_api
    settings_api.save({"s:engine.model": dest.name, "s:ai_model": dest.stem, "s:ai_reasoning": pick.get("reasoning", "")}, internal=True)
    old = folder / Path(cur).name
    spare = (_PICK.get("fallback") or {}).get("file")
    if old.exists() and old != dest and old.name != spare:
        old.unlink(missing_ok=True)
    _save(file=pick["file"], state="done")
    notify("AI model", "The AI model was updated.")
    return f"switched to {dest.name}"


if __name__ == "__main__":
    print(tick(lambda t, x: print(t, x)))
