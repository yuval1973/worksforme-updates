
function appDialog(text, ok, cancel) {
  return new Promise(done => {
    const d = document.createElement("div");
    d.className = "appdlg";
    d.innerHTML = `<div class="appdlg-box" role="dialog" aria-modal="true"><p></p><div class="appdlg-row">`
      + (cancel ? '<button class="ghost" data-a="0"></button>' : "") + '<button data-a="1"></button></div></div>';
    d.querySelector("p").textContent = text;
    d.querySelector('[data-a="1"]').textContent = ok;
    if (cancel) d.querySelector('[data-a="0"]').textContent = cancel;
    const close = yes => { d.remove(); done(yes); };
    d.addEventListener("click", e => { const b = e.target.closest("[data-a]"); if (b) close(b.dataset.a === "1"); });
    d.addEventListener("keydown", e => { if (e.key === "Escape") close(!cancel); });
    document.body.appendChild(d);
    d.querySelector('[data-a="1"]').focus();
  });
}
const ask = (text, ok = "Yes", cancel = "Cancel") => appDialog(text, ok, cancel);
const tell = (text, ok = "OK") => appDialog(text, ok, null);

function unlink() {
  document.querySelectorAll("a[href]").forEach(a => {
    a.dataset.go = a.getAttribute("href");
    a.removeAttribute("href");
    a.removeAttribute("target");
    if (!a.hasAttribute("tabindex")) a.tabIndex = 0;
    a.setAttribute("role", "link");
  });
}
new MutationObserver(unlink).observe(document.documentElement, {childList: true, subtree: true});
addEventListener("DOMContentLoaded", unlink);
document.addEventListener("click", e => {
  const a = e.target.closest && e.target.closest("a[data-go]");
  if (!a || e.defaultPrevented) return;
  const go = a.dataset.go || "";
  e.preventDefault();
  if (!go || go.startsWith("#") || go.startsWith("javascript:")) return;
  const u = new URL(go, location.href);
  if (u.origin === location.origin) location.href = u.href;
  else if (/^https?:$/.test(u.protocol))
    fetch("/api/open-external", {method: "POST", body: JSON.stringify({url: u.href})}).then(r => r.text()).catch(() => {});
});
document.addEventListener("keydown", e => {
  if (e.key === "Enter" && e.target.matches && e.target.matches("a[data-go]")) { e.preventDefault(); e.target.click(); }
});

["dragover", "drop"].forEach(t => document.addEventListener(t, e => {
  if (e.target.closest && e.target.closest(".drop")) return;
  e.preventDefault();
  if (e.dataTransfer) e.dataTransfer.dropEffect = "none";
}));

const CTRL_KEYS = new Set(["d", "e", "g", "h", "j", "k", "l", "o", "p", "r", "s", "u", "+", "=", "-", "_", "0"]);
const CTRL_SHIFT_KEYS = new Set(["i", "j", "c", "k", "o", "b", "m", "y", "a", "r", "delete", "."]);
const F_KEYS = new Set(["f1", "f3", "f5", "f6", "f7", "f10", "f11", "f12", "browserback", "browserforward",
                        "browserrefresh", "browserhome", "browsersearch", "browserfavorites"]);
document.addEventListener("keydown", e => {
  const k = (e.key || "").toLowerCase();
  const typing = e.target.closest && e.target.closest("input, textarea, select, [contenteditable]");
  if (e.ctrlKey && !e.shiftKey && !e.altKey && k === "f") {
    e.preventDefault();
    const s = document.querySelector('input[type="search"], #q, #search');
    if (s) s.focus();
    return;
  }
  if (e.ctrlKey && !e.shiftKey && k === "a" && !typing) { e.preventDefault(); return; }
  if (F_KEYS.has(k) || (e.altKey && ["arrowleft", "arrowright", "home", "f", "e"].includes(k))
      || (e.ctrlKey && !e.shiftKey && CTRL_KEYS.has(k)) || (e.ctrlKey && e.shiftKey && CTRL_SHIFT_KEYS.has(k)))
    e.preventDefault();
}, true);
addEventListener("wheel", e => { if (e.ctrlKey) e.preventDefault(); }, {passive: false});
["mouseup", "auxclick"].forEach(t => addEventListener(t, e => { if (e.button === 3 || e.button === 4) e.preventDefault(); }));

document.addEventListener("contextmenu", e => {
  if (!e.target.closest("input, textarea, select")) e.preventDefault();
});
document.addEventListener("dragstart", e => {
  if (e.target.closest && e.target.closest("a, img")) e.preventDefault();
});

document.addEventListener("focusin", e => {
  if (e.target.matches && e.target.matches("input")) { e.target.autocomplete = "off"; e.target.spellcheck = false; }
});

const BUILT = {v: null, typed: false};
["input", "change"].forEach(t => document.addEventListener(t, e => { if (e.isTrusted) BUILT.typed = true; }, true));
const edited = () => BUILT.typed;
const newVersion = async () => {
  try {
    const v = (await (await fetch("/api/version", {cache: "no-store"})).json()).version || "";
    if (BUILT.v === null) { BUILT.v = v; return; }
    if (!v || v === BUILT.v || document.getElementById("updbar")) return;
    if (!edited() && !document.querySelector(".appdlg")) { location.reload(); return; }
    const bar = document.createElement("div");
    bar.id = "updbar";
    bar.className = "updbar";
    bar.innerHTML = "<span></span><button class=\"btn primary\"></button>";
    bar.querySelector("span").textContent = "WorksForMe was just updated.";
    bar.querySelector("button").textContent = "Reload";
    bar.querySelector("button").onclick = () => location.reload();
    document.body.appendChild(bar);
  } catch (e) { }
};
addEventListener("DOMContentLoaded", () => { newVersion(); setInterval(newVersion, 60000); });
addEventListener("focus", newVersion);

const CONTENT = "main h2, .card, section h2";
addEventListener("load", () => {
  const t0 = Date.now();
  const ready = () => fetch("/api/window/ready", {method: "POST"}).then(r => r.text()).catch(() => {});
  const wait = () => document.querySelector(CONTENT) || Date.now() - t0 > 4000 ? ready() : setTimeout(wait, 100);
  wait();
});
