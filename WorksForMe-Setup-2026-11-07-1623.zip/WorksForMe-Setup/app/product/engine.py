import json
import shutil
import subprocess
import sys
import time
import urllib.request
from pathlib import Path

ENGINE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ENGINE))
import config

BIN = config.path(config.setting("engine.bin", r"%USERPROFILE%\llm\bin"))
MODELS = config.path(config.setting("engine.models", r"%USERPROFILE%\llm\models"))
PORT = int(config.setting("ports.model", 9451))
CONTEXT = int(config.setting("engine.context", 16384))
URL = f"http://127.0.0.1:{PORT}"
VCRT = Path(__file__).resolve().parent / "vcrt"
DLL_NOT_FOUND = 0xC0000135


def ensure_runtime():
    if not VCRT.is_dir():
        return
    for src in VCRT.glob("*.dll"):
        dst = BIN / src.name
        try:
            if not dst.exists() or dst.stat().st_size != src.stat().st_size:
                shutil.copy2(src, dst)
        except OSError:
            pass


def quiet_errors():
    try:
        import ctypes
        ctypes.windll.kernel32.SetErrorMode(0x0001 | 0x0002 | 0x8000)
    except Exception:
        pass


def up():
    try:
        with urllib.request.urlopen(f"{URL}/health", timeout=3) as f:
            return json.loads(f.read()).get("status") == "ok"
    except Exception:
        return False


class MemoryShort(RuntimeError):
    def __init__(self, text="", short=None):
        super().__init__(text)
        self.short = short


def locate(model):
    p = Path(model)
    return p if p.is_absolute() or p.exists() else MODELS / p


def size_gb(p):
    return Path(p).stat().st_size / 2 ** 30 if Path(p).exists() else 0.0


def options(model):
    import machine
    main, small = locate(model), machine.RECOMMEND[-1]
    out = [(main, None)]
    if (MODELS / small[1]).exists() and small[1] != main.name:
        out.append((MODELS / small[1], small[4]))
    return out


def min_need(model):
    import machine
    return min(size_gb(p) for p, _ in options(model)) + machine.SPARE_GB


def choose(model):
    import machine
    found = options(model)
    free = machine.free_gb()
    for p, reasoning in found:
        if free >= size_gb(p) + machine.SPARE_GB:
            return p, reasoning, None
    return None, None, machine.shortage(min(size_gb(p) for p, _ in found) + machine.SPARE_GB, free)


def room_for(model):
    import machine
    need, free = size_gb(locate(model)) + machine.SPARE_GB, machine.free_gb()
    return None if free >= need else machine.shortage(need, free)


PLACEMENTS = [("auto-fit", []), ("experts in RAM", ["-ngl", "99", "--cpu-moe"]), ("CPU only", ["-ngl", "0", "--device", "none"])]
LAST_PLACEMENT = None
MEMO = ENGINE / "runs" / "engine-placement.json"


def order(model_name, cpu=False, after=None):
    names = [n for n, _ in PLACEMENTS]
    if cpu:
        return PLACEMENTS[-1:]
    if after is None:
        try:
            m = json.loads(MEMO.read_text(encoding="utf-8"))
            if m.get("model") == model_name and time.time() - m.get("at", 0) < 7 * 86400:
                after = m.get("failed")
        except (OSError, ValueError):
            pass
    if after in names:
        return PLACEMENTS[min(names.index(after) + 1, len(names) - 1):]
    return PLACEMENTS


def demote(model_name, failed):
    if failed != PLACEMENTS[-1][0]:
        MEMO.parent.mkdir(parents=True, exist_ok=True)
        MEMO.write_text(json.dumps({"model": model_name, "failed": failed, "at": time.time()}), encoding="utf-8")


_JOB = None


def tie(p):
    global _JOB
    import ctypes
    from ctypes import wintypes
    k = ctypes.WinDLL("kernel32", use_last_error=True)
    k.CreateJobObjectW.restype = wintypes.HANDLE
    k.SetInformationJobObject.argtypes = [wintypes.HANDLE, ctypes.c_int, ctypes.c_void_p, wintypes.DWORD]
    k.AssignProcessToJobObject.argtypes = [wintypes.HANDLE, wintypes.HANDLE]
    if _JOB is None:
        class Basic(ctypes.Structure):
            _fields_ = [("PerProcessUserTimeLimit", ctypes.c_int64), ("PerJobUserTimeLimit", ctypes.c_int64),
                        ("LimitFlags", wintypes.DWORD), ("MinimumWorkingSetSize", ctypes.c_size_t),
                        ("MaximumWorkingSetSize", ctypes.c_size_t), ("ActiveProcessLimit", wintypes.DWORD),
                        ("Affinity", ctypes.c_size_t), ("PriorityClass", wintypes.DWORD), ("SchedulingClass", wintypes.DWORD)]

        class Extended(ctypes.Structure):
            _fields_ = [("Basic", Basic), ("Io", ctypes.c_uint64 * 6), ("ProcessMemoryLimit", ctypes.c_size_t),
                        ("JobMemoryLimit", ctypes.c_size_t), ("PeakProcessMemoryUsed", ctypes.c_size_t),
                        ("PeakJobMemoryUsed", ctypes.c_size_t)]
        job = k.CreateJobObjectW(None, None)
        info = Extended()
        info.Basic.LimitFlags = 0x2000
        if not job or not k.SetInformationJobObject(job, 9, ctypes.byref(info), ctypes.sizeof(info)):
            return False
        _JOB = job
    return bool(k.AssignProcessToJobObject(_JOB, int(p._handle)))


def start(model, cpu=False, log=None, wait=600, after=None):
    global LAST_PLACEMENT
    model = Path(model)
    if not model.is_absolute() and not model.exists():
        model = MODELS / model
    ensure_runtime()
    quiet_errors()
    base = [str(BIN / "llama-server.exe"), "-m", str(model), "--host", "127.0.0.1", "--port", str(PORT),
            "-c", str(CONTEXT), "--jinja", "--no-webui",
            "-np", "1"]
    tried = []
    for name, extra in order(model.name, cpu, after):
        short = room_for(model) if tried or after else None
        if short:
            raise MemoryShort("not enough free memory to start the AI again", short)
        out = open(log, "a", encoding="utf-8") if log else subprocess.DEVNULL
        if log:
            out.write(f"\n==== engine: {model.name}, placement: {name}\n"); out.flush()
        p = subprocess.Popen(base + extra, stdout=out, stderr=subprocess.STDOUT, creationflags=subprocess.CREATE_NO_WINDOW)
        tie(p)
        t = time.time()
        while time.time() - t < wait:
            if p.poll() is not None:
                break
            if up():
                LAST_PLACEMENT = name
                if tried:
                    demote(model.name, tried[-1])
                return p
            time.sleep(2)
        else:
            p.kill()
        if p.returncode == DLL_NOT_FOUND:
            raise RuntimeError("the built-in AI could not start: a Windows file it needs is missing (Microsoft's C++ "
                               "runtime)")
        tried.append(name)
    raise RuntimeError(f"llama-server did not start ({', '.join(tried)}) - see {log or 'its output'}")


def stop(p):
    if p and p.poll() is None:
        p.terminate()
        try:
            p.wait(20)
        except subprocess.TimeoutExpired:
            p.kill()


if __name__ == "__main__":
    proc = start(sys.argv[1], cpu="--cpu" in sys.argv)
    print(f"model engine up at {URL}/v1 ({sys.argv[1]})")
    try:
        proc.wait()
    except KeyboardInterrupt:
        stop(proc)
