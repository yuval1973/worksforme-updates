import hashlib
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
PRIVATE = Path.home() / "JobBotKit" / "release_signing.key"
PUBLIC = HERE / "release_key.txt"
SIG_NAME = "RELEASE.sig"

p = 2 ** 255 - 19
q = 2 ** 252 + 27742317777372353535851937790883648493
d = -121665 * pow(121666, p - 2, p) % p
SQRT_M1 = pow(2, (p - 1) // 4, p)


def _sha512(b):
    return hashlib.sha512(b).digest()


def _recover_x(y, sign):
    if y >= p:
        return None
    x2 = (y * y - 1) * pow(d * y * y + 1, p - 2, p)
    if x2 == 0:
        return None if sign else 0
    x = pow(x2, (p + 3) // 8, p)
    if (x * x - x2) % p:
        x = x * SQRT_M1 % p
    if (x * x - x2) % p:
        return None
    return p - x if (x & 1) != sign else x


def _add(P, Q):
    A = (P[1] - P[0]) * (Q[1] - Q[0]) % p
    B = (P[1] + P[0]) * (Q[1] + Q[0]) % p
    C = 2 * P[3] * Q[3] * d % p
    D = 2 * P[2] * Q[2] % p
    E, F, G, H = B - A, D - C, D + C, B + A
    return (E * F, G * H, F * G, E * H)


def _mul(s, P):
    Q = (0, 1, 1, 0)
    while s > 0:
        if s & 1:
            Q = _add(Q, P)
        P = _add(P, P)
        s >>= 1
    return Q


def _equal(P, Q):
    return (P[0] * Q[2] - Q[0] * P[2]) % p == 0 and (P[1] * Q[2] - Q[1] * P[2]) % p == 0


_gy = 4 * pow(5, p - 2, p) % p
_gx = _recover_x(_gy, 0)
G = (_gx, _gy, 1, _gx * _gy % p)


def _compress(P):
    zi = pow(P[2], p - 2, p)
    x, y = P[0] * zi % p, P[1] * zi % p
    return int.to_bytes(y | ((x & 1) << 255), 32, "little")


def _decompress(s):
    if len(s) != 32:
        return None
    y = int.from_bytes(s, "little")
    sign = y >> 255
    y &= (1 << 255) - 1
    x = _recover_x(y, sign)
    return None if x is None else (x, y, 1, x * y % p)


def _expand(secret):
    h = _sha512(secret)
    a = int.from_bytes(h[:32], "little")
    a &= (1 << 254) - 8
    a |= 1 << 254
    return a, h[32:]


def public_key(secret):
    return _compress(_mul(_expand(secret)[0], G))


def sign(secret, msg):
    a, prefix = _expand(secret)
    A = _compress(_mul(a, G))
    r = int.from_bytes(_sha512(prefix + msg), "little") % q
    Rs = _compress(_mul(r, G))
    h = int.from_bytes(_sha512(Rs + A + msg), "little") % q
    return Rs + int.to_bytes((r + h * a) % q, 32, "little")


def verify(public, msg, sig):
    if len(public) != 32 or len(sig) != 64:
        return False
    A, R = _decompress(public), _decompress(sig[:32])
    s = int.from_bytes(sig[32:], "little")
    if A is None or R is None or s >= q:
        return False
    h = int.from_bytes(_sha512(sig[:32] + public + msg), "little") % q
    return _equal(_mul(s, G), _add(R, _mul(h, A)))


def package_digest(folder):
    folder = Path(folder)
    h = hashlib.sha256()
    for f in sorted(x for x in folder.rglob("*") if x.is_file() and x.name != SIG_NAME):
        fh = hashlib.sha256()
        with f.open("rb") as fp:
            while chunk := fp.read(1 << 20):
                fh.update(chunk)
        h.update(f.relative_to(folder).as_posix().encode() + b"\0" + fh.digest())
    return h.digest()


def sign_package(folder, secret=None):
    if secret is None:
        if not PRIVATE.exists():
            return None
        secret = bytes.fromhex(PRIVATE.read_text(encoding="utf-8").strip())
    sig = sign(secret, package_digest(folder))
    (Path(folder) / SIG_NAME).write_text(sig.hex(), encoding="utf-8")
    return sig.hex()


def verify_package(folder, public=None):
    try:
        public = public or bytes.fromhex(PUBLIC.read_text(encoding="utf-8").strip())
        sig = bytes.fromhex((Path(folder) / SIG_NAME).read_text(encoding="utf-8").strip())
    except (OSError, ValueError):
        return False
    return verify(public, package_digest(folder), sig)


if __name__ == "__main__":
    if "--new-key" in sys.argv:
        import secrets
        if PRIVATE.exists():
            sys.exit(f"a key already exists: {PRIVATE} - keep it (installs trust its public half)")
        k = secrets.token_bytes(32)
        PRIVATE.parent.mkdir(parents=True, exist_ok=True)
        PRIVATE.write_text(k.hex(), encoding="utf-8")
        PUBLIC.write_text(public_key(k).hex(), encoding="utf-8")
        print(f"private key: {PRIVATE} (never share it)\npublic key:  {PUBLIC} (ships in every package)")
