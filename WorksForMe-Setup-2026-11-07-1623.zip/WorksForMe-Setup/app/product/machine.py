import json
import re
import shutil
import subprocess
from pathlib import Path

HF = "https://huggingface.co"
RECOMMEND = [
    (32, "Qwen3.6-35B-A3B-UD-IQ4_XS.gguf",
     f"{HF}/unsloth/Qwen3.6-35B-A3B-GGUF/resolve/main/Qwen3.6-35B-A3B-UD-IQ4_XS.gguf", 17.7, "off",
     "the most accurate model that runs on a PC in our tests - as accurate as the online Haiku",
     "649d7508507b84638732c4f52c24c8b15843c6dca2f3ff793ae07c14a67ebbb3"),
    (24, "google_gemma-4-26B-A4B-it-IQ4_XS.gguf",
     f"{HF}/bartowski/google_gemma-4-26B-A4B-it-GGUF/resolve/main/google_gemma-4-26B-A4B-it-IQ4_XS.gguf", 14.2, "off",
     "a smaller model for PCs with 24-31 GB of memory - nearly as accurate",
     "86f0f6ca5f622bca4506f7849eee3459d0cac867b919630132145efd452ee8b9"),
    (20, "gpt-oss-20b-MXFP4.gguf", f"{HF}/ggml-org/gpt-oss-20b-GGUF/resolve/main/gpt-oss-20b-MXFP4.gguf", 12.1, "low",
     "a smaller model for PCs with 20-23 GB of memory - it is stricter and passes over more good jobs "
     "(an online AI key judges better)", "27cd6c432c7672cb812a92f611cf3ba7bbc35928262bb1e1253ff4ee6ae35901"),
]
SPARE_GB = 1.5
QUIET = {"memory compression", "system", "secure system", "registry", "idle", "svchost", "msmpeng", "llama-server",
         "python", "pythonw", "vmmem", "vmmemcmzygote", "dwm", "csrss", "lsass", "searchindexer", "explorer"}
BROWSERS = [r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
            r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"]


def _cim():
    ps = ("$c=Get-CimInstance Win32_ComputerSystem; $p=Get-CimInstance Win32_Processor | Select-Object -First 1; "
          "$g=@(Get-CimInstance Win32_VideoController | ForEach-Object Name); "
          "$m=(Get-CimInstance Win32_PhysicalMemory | Measure-Object Capacity -Sum).Sum; "
          "[pscustomobject]@{ram=$c.TotalPhysicalMemory; installed=$m; cpu=$p.Name; cores=$p.NumberOfCores; "
          "threads=$p.NumberOfLogicalProcessors; gpus=$g} | ConvertTo-Json -Compress")
    out = subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True, timeout=60,
                         creationflags=subprocess.CREATE_NO_WINDOW)
    return json.loads(out.stdout)


def memory_gb():
    import ctypes

    class Status(ctypes.Structure):
        _fields_ = [("length", ctypes.c_ulong), ("load", ctypes.c_ulong)] + [(n, ctypes.c_ulonglong) for n in (
            "total", "avail", "page_total", "page_avail", "virtual_total", "virtual_avail", "extended")]
    s = Status()
    s.length = ctypes.sizeof(Status)
    ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(s))
    return s.total / 2 ** 30, s.avail / 2 ** 30


def engine_gb():
    try:
        import config
        port = str((config.setting("ports") or {}).get("model") or "")
    except Exception:
        port = ""
    if not port:
        return 0.0
    ps = ("@(Get-CimInstance Win32_Process -Filter \"Name='llama-server.exe'\" | ForEach-Object { [pscustomobject]@{"
          "c = $_.CommandLine; m = (Get-Process -Id $_.ProcessId -ErrorAction SilentlyContinue).WorkingSet64} }) "
          "| ConvertTo-Json -Compress")
    try:
        rows = json.loads(subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True,
                                         timeout=30, creationflags=subprocess.CREATE_NO_WINDOW).stdout or "[]")
    except (OSError, subprocess.SubprocessError, ValueError):
        return 0.0
    rows = rows if isinstance(rows, list) else [rows]
    return sum((r.get("m") or 0) for r in rows if re.search(rf"--port\s+{port}\b", str(r.get("c") or ""))) / 2 ** 30


def free_gb():
    return memory_gb()[1] + engine_gb()


def _own():
    marks = [str(Path(__file__).resolve().parents[2]).lower(), "ui-profile", ".daybook-ui"]
    try:
        import config
        if config.setting("browser_home"):
            marks.append(str(config.path(config.setting("browser_home"))).lower())
    except Exception:
        pass
    return marks


def biggest_apps(n=3):
    ps = ("$c = @{}; Get-CimInstance Win32_Process | ForEach-Object { $c[[int]$_.ProcessId] = $_.CommandLine }; "
          "@(Get-Process | ForEach-Object { [pscustomobject]@{n = $_.ProcessName; d = $_.Description; m = $_.WorkingSet64; "
          "w = [int]($_.MainWindowHandle -ne 0); c = $c[$_.Id]} }) | ConvertTo-Json -Compress")
    try:
        rows = json.loads(subprocess.run(["powershell", "-NoProfile", "-Command", ps], capture_output=True, text=True,
                                         timeout=60, creationflags=subprocess.CREATE_NO_WINDOW).stdout or "[]")
    except (OSError, subprocess.SubprocessError, ValueError):
        return []
    own, groups = _own(), {}
    for r in rows if isinstance(rows, list) else [rows]:
        name = str(r.get("n") or "")
        if not name or name.lower() in QUIET or any(m in str(r.get("c") or "").lower() for m in own):
            continue
        g = groups.setdefault(name.lower(), {"label": "", "gb": 0.0, "window": False})
        g["gb"] += (r.get("m") or 0) / 2 ** 30
        g["window"] = g["window"] or bool(r.get("w"))
        g["label"] = g["label"] or str(r.get("d") or "").strip()
        g.setdefault("name", name)
    seen = [g for g in groups.values() if g["window"]] or list(groups.values())
    big = sorted((g for g in seen if g["gb"] >= 0.3), key=lambda g: -g["gb"])[:n]
    return [f"{g['label'] or g['name']} ({g['gb']:.1f} GB)" for g in big]


def shortage(need, free):
    return {"need": max(1, round(need)), "free": int(free), "apps": biggest_apps()}


def apps_text(apps):
    return apps[0] if len(apps) == 1 else ", ".join(apps[:-1]) + " and " + apps[-1] if apps else ""


def floor_gb():
    return RECOMMEND[-1][3] + SPARE_GB


def check(data_dir=Path.home()):
    c = _cim()
    ram = round(max(int(c.get("installed") or 0), int(c["ram"])) / 2 ** 30)
    free = shutil.disk_usage(data_dir).free // 2 ** 30
    gpus = c["gpus"] if isinstance(c["gpus"], list) else [c["gpus"]]
    pick = next((r for r in RECOMMEND if ram >= r[0]), None)
    small = RECOMMEND[-1]
    free_ram = free_gb()
    room = free_ram >= floor_gb()
    problems = []
    if not pick:
        problems.append(f"{ram} GB of memory - the built-in AI model needs {RECOMMEND[-1][0]} GB or more "
                        f"(an online AI key can be used instead)")
    if pick and free < pick[3] + 5:
        problems.append(f"Free up about {pick[3] + 5 - free:.0f} GB of disk space for the built-in AI.")
    short = shortage(floor_gb(), free_ram) if pick and not room else None
    note = ""
    if short:
        apps = apps_text(short["apps"])
        note = (f"The AI needs about {short['need']} GB and {short['free']} GB is free. Close some programs"
                + (f", such as {apps}" if apps else "") + ".")
    import sys
    sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
    import make_pdf
    pdf = bool(make_pdf.available())
    browser = next((b for b in BROWSERS if Path(b).exists()), None)
    if not browser:
        problems.append("no Chrome or Edge found")
    def model(r):
        return {"name": r[1].rsplit(".", 1)[0], "file": r[1], "url": r[2], "download_gb": r[3], "reasoning": r[4],
                "why": r[5], "sha256": r[6] if len(r) > 6 else None}
    return {"ram_gb": ram, "cpu": c["cpu"].strip(), "cores": c["cores"], "threads": c["threads"], "gpus": gpus,
            "free_disk_gb": free, "browser": browser, "pdf_converter": pdf, "free_ram_gb": round(free_ram, 1),
            "need_ram_gb": round(floor_gb(), 1), "room": room, "short": short, "memory_note": note,
            "model": model(pick) if pick else None, "fallback": model(small) if pick and pick[1] != small[1] else None,
            "ok": not problems, "problems": problems}


if __name__ == "__main__":
    print(json.dumps(check(), indent=1))
