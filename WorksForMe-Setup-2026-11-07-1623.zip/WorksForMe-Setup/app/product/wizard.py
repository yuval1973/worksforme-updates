import copy
import json
import re
import sys
from pathlib import Path
from typing import List

from pydantic import BaseModel

ENGINE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ENGINE))
sys.path.insert(1, str(Path(__file__).resolve().parent))
import config
import llm
import formats


class Role(BaseModel):
    title: str
    company: str
    location: str
    start_month: int
    start_year: int
    end_month: int
    end_year: int


class School(BaseModel):
    degree: str
    field: str
    school: str


class ProfileDraft(BaseModel):
    first_name: str
    last_name: str
    email: str
    phone: str
    linkedin: str
    city: str
    state_code: str
    country_code: str
    years_experience: int
    experience: List[Role]
    education: List[School]
    target_titles: List[str]
    core_domains: List[str]
    adjacent_domains: List[str]
    summary: str


PROMPT = """Read this resume and fill the fields. Facts (name, contact, roles, dates, schools) must come from the
resume exactly as written; use "" or 0 when a fact is not there - never guess. Experience: every role, newest first.
country_code: the 2-letter code of the country the person lives in (US, IL, GB, IN ...); "US" when the address is a US
city or state. state_code: the US state's 2-letter code, or another country's state / province as written ("" if none).
target_titles, core_domains, adjacent_domains and summary are suggestions the person will review: base them only on
what the resume shows, at the person's real level (no promotions, no demotions).

RESUME:
{resume}"""


def resume_text(path):
    keep = config.MASTER_RESUME
    try:
        config.MASTER_RESUME = Path(path)
        return llm._resume_facts()
    finally:
        config.MASTER_RESUME = keep


def draft(path):
    text = resume_text(path)
    d = llm._parse(ProfileDraft, PROMPT.format(resume=text[:20000]), 3000)
    return tidy(d.model_dump(), text)


def tidy(d, text):
    import datetime as dt
    low, digits = text.lower(), re.sub(r"\D", "", text)
    d["country_code"] = formats.countries.code_of(d.get("country_code") or "") or "US"
    if d.get("email") and d["email"].lower() not in low:
        d["email"] = ""
    ph = re.sub(r"\D", "", d.get("phone") or "")
    if d.get("phone") and (len(ph) < 7 or ph[-7:] not in digits):
        d["phone"] = ""
    h = re.search(r"linkedin\.com/in/([\w-]+)", d.get("linkedin") or "", re.I)
    if d.get("linkedin") and not (h and h.group(1).lower() in low):
        d["linkedin"] = ""
    if not d.get("email") and (m := re.search(r"[\w.+-]+@[\w-]+(?:\.[\w-]+)+", text)):
        d["email"] = m.group(0)
    if not d.get("phone") and (m := re.search(r"(?:\+?1[\s.-]?)?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]\d{4}\b", text)):
        d["phone"] = m.group(0).strip()
    if not d.get("linkedin") and (m := re.search(r"(?:https?://)?(?:[a-z]{2,3}\.)?linkedin\.com/in/[\w-]+", text, re.I)):
        d["linkedin"] = "https://www.linkedin.com/in/" + m.group(0).rsplit("/", 1)[1]
    for k in ("first_name", "last_name"):
        if (d.get(k) or "").isupper() and len(d[k]) > 1:
            d[k] = d[k].title()
    years = [r["start_year"] for r in d.get("experience") or [] if r.get("start_year")]
    if not d.get("years_experience") and years:
        d["years_experience"] = dt.date.today().year - min(years)
    for s in d.get("education") or []:
        if not (s.get("field") or "").strip() and (m := DEGREE_FIELD.match((s.get("degree") or "").strip())):
            s["degree"], s["field"] = m.group(1).strip(" ,-"), m.group(2).strip(" ,-")
    return d


DEGREE_FIELD = re.compile(r"^((?:[ABMD]\.?\s?[A-Za-z]{0,4}\.(?:\s?[A-Z][a-z]?\.)?|[ABM][AS]c?|MBA|Ph\.?\s?D\.?|M\.?B\.?A\.?"
                          r"|(?:Bachelor|Master|Doctor|Associate)(?:'s)?(?: of (?:[A-Z][a-z]+)(?: (?:and|in) [A-Z][a-z]+)?)?))"
                          r"(?:\s*,\s*|\s+-\s+|\s+in\s+|\s+)([A-Z].{2,})$")


STATES = dict(AL="Alabama", AK="Alaska", AZ="Arizona", AR="Arkansas", CA="California", CO="Colorado", CT="Connecticut",
              DE="Delaware", DC="District of Columbia", FL="Florida", GA="Georgia", HI="Hawaii", ID="Idaho", IL="Illinois",
              IN="Indiana", IA="Iowa", KS="Kansas", KY="Kentucky", LA="Louisiana", ME="Maine", MD="Maryland",
              MA="Massachusetts", MI="Michigan", MN="Minnesota", MS="Mississippi", MO="Missouri", MT="Montana",
              NE="Nebraska", NV="Nevada", NH="New Hampshire", NJ="New Jersey", NM="New Mexico", NY="New York",
              NC="North Carolina", ND="North Dakota", OH="Ohio", OK="Oklahoma", OR="Oregon", PA="Pennsylvania",
              RI="Rhode Island", SC="South Carolina", SD="South Dakota", TN="Tennessee", TX="Texas", UT="Utah",
              VT="Vermont", VA="Virginia", WA="Washington", WV="West Virginia", WI="Wisconsin", WY="Wyoming")
LEVELS = [
    (r"ph\.?d|doctor", 3, r"doctor|ph\.?d|^doctorate"),
    (r"\bm\.?b\.?a\b", 2, r"m\.?b\.?a|business administration|^masters?\b|master"),
    (r"\bm\.?(?:sc|s)\b|master.*science", 2, r"master.*science|\bM\.?Sc?\b|^masters?\b|master"),
    (r"\bm\.?a\b|master.*arts", 2, r"master.*arts|\bM\.?A\b|^masters?\b|master"),
    (r"master", 2, r"^masters?\b|master"),
    (r"\bb\.?(?:sc|s)\b|bachelor.*science", 1, r"bachelor.*science|\bB\.?Sc?\b|^bachelor|bachelor"),
    (r"\bb\.?a\b|bachelor.*arts", 1, r"bachelor.*arts|\bB\.?A\b|^bachelor|bachelor"),
    (r"bachelor", 1, r"^bachelor|bachelor"),
    (r"associate", 0, r"associate"),
]


def education_on_forms(schools):
    import re
    out = []
    for s in schools:
        rank, match = next(((r, m) for rx, r, m in LEVELS if re.search(rx, s["degree"], re.I)), (1, re.escape(s["degree"])))
        out.append((rank, {"school": s["school"], "school_fallback": None,
                           "degree": f"{s['degree']} {s['field']}".strip(), "degree_match": match,
                           "field_queries": [s["field"]] if s["field"] else []}))
    return [e for _, e in sorted(out, key=lambda x: x[0])]


DRAFT_FIELDS = {"first_name": ("identity.first_name", "First name"), "last_name": ("identity.last_name", "Last name"),
                "email": ("identity.email", "Email"), "phone": ("identity.phone", "Phone"),
                "linkedin": ("identity.linkedin", "LinkedIn"), "city": ("location.city", "City"),
                "state_code": ("location.state_code", "State")}


def country_of(d):
    return formats.countries.code_of(d.get("country_code") or "") or "US"


def questions(cc="US"):
    r = formats.countries.address_rules(cc)
    out = []
    for k, q, c in QUESTIONS:
        if k == "location.county" and cc != "US":
            continue
        if k == "location.zip":
            if not r["has_postal"]:
                continue
            q = r["postal_label"] if cc != "US" else q
        out.append((k, q, c))
    return out


def format_problem(d, answers):
    cc = country_of(d)
    q = {k: label for k, label, _c in questions(cc)}
    for name, (key, label) in DRAFT_FIELDS.items():
        if str(d.get(name) or "").strip() and (p := formats.fix(key, d[name], cc)[1]):
            return f"{label}: {p}"
    for key, value in answers.items():
        if key in q and str(value or "").strip() and (p := formats.fix(key, value, cc)[1]):
            return f"{q[key]}: {p}"
    import datetime as dt
    today = dt.date.today()
    for r in d.get("experience") or []:
        try:
            ey, em = int(r.get("end_year") or 0), int(r.get("end_month") or 0)
        except (TypeError, ValueError):
            continue
        title = r.get("title") or "A role"
        if ey == today.year and not em:
            return f"{title}: which month in {ey}? In \"Your resume\", enter the month you left, or \"now\" if you still work there."
        if ey and (ey, em or 12) > (today.year, today.month):
            return f"{title}: the end date is in the future. In \"Your resume\", enter \"now\" or the month you left."
    return None


def phone_parts(phone, cc="US"):
    try:
        p = formats.countries.phone(phone, cc)
        return {"phone_digits": p["national"], "phone_country_code": p["calling_code"], "phone_region": p["region"]}
    except ValueError:
        return {"phone_digits": "".join(c for c in str(phone or "") if c.isdigit())[-10:]}


def home_fields(cc, region):
    if cc == "US":
        return {"state_code": region, "state": STATES.get((region or "").upper(), region),
                "country": "United States", "country_code": "US"}
    hit = formats.countries.area(cc, region or "")
    r = formats.countries.address_rules(cc)
    out = {"state_code": hit[0] if hit else (region or ""), "state": hit[1] if hit else (region or ""),
           "country": formats.countries.name(cc), "country_code": cc, "county": ""}
    if not r["postal_required"]:
        out["zip"] = ""
    return out


def to_applicant(d, template=ENGINE / "kit" / "templates" / "applicant.template.json"):
    cc = country_of(d)
    d = {**d, **{n: formats.fix(key, d[n], cc)[0] for n, (key, _l) in DRAFT_FIELDS.items() if d.get(n)}}
    a = json.loads(Path(template).read_text(encoding="utf-8-sig"))
    a = copy.deepcopy(a)
    a["identity"].update(first_name=d["first_name"], last_name=d["last_name"], preferred_name=d["first_name"],
                         email=d["email"], phone=d["phone"], linkedin=d["linkedin"] or None, **phone_parts(d["phone"], cc))
    a["location"].update(city=d["city"], **home_fields(cc, d["state_code"]))
    a["eligibility"]["previously_worked_here"] = "No"
    for k in ("pronouns", "sexual_orientation", "transgender"):
        a["self_identification"][k] = "Leave blank when optional; when required: Decline to answer"
    home = (f"{d['city']}, {d['state_code']}" if cc == "US" else f"{d['city']}, {formats.countries.name(cc)}") \
        if d["city"] and (d["state_code"] or cc != "US") else ""
    roles = [{"title": r["title"], "company": r["company"], "location": r["location"] or home,
              "start_month": r.get("start_month") or 1, "start_year": r["start_year"],
              "end_month": (r.get("end_month") or 12) if r["end_year"] else None, "end_year": r["end_year"] or None}
             for r in d["experience"]]
    if roles:
        cur = roles[0]
        a["most_recent_job"].update(title=cur["title"], company=cur["company"], location=cur["location"],
                                    start_year=cur["start_year"], end_year=cur["end_year"])
        a["experience"] = roles
    a["education"] = [{"degree": s["degree"], "field": s["field"], "school": s["school"]} for s in d["education"]]
    if d["education"]:
        a["education_on_forms"] = education_on_forms(d["education"])
    return a


class TargetsDraft(BaseModel):
    profession: str
    target_level: str
    hard_nos: List[str]
    none_domains: List[str]
    above_level_words: List[str]
    below_level_words: List[str]
    other_discipline_words: List[str]
    nearby_towns: List[str]


TARGETS_PROMPT = """This person is setting up job alerts. From the resume and the profile below, suggest the fields.
Base everything on the resume; the person will edit every list. Title words are single words or short phrases as they
appear in job titles (lower case). nearby_towns: up to 12 towns within ~40 minutes of {city}, {state}.
- hard_nos: only what the profile or resume itself says rules a job out - never a moral, political or industry
  preference of your own (the person adds those). An empty list is fine.
- none_domains: kinds of WORK clearly outside their field (for a policy graduate e.g. software engineering, nursing) -
  never industries or employers they might prefer to avoid.
- target_level: their real level (a recent graduate is entry level); above_level_words / below_level_words: SENIORITY
  words only (junior, intern, entry level, associate, senior, lead, manager, director, vp...) - never words of the job
  itself (analyst, researcher, engineer, coordinator), and never a word from their own job titles.

PROFILE:
{profile}

RESUME:
{resume}"""


def draft_targets(profile, resume=""):
    p = {k: profile[k] for k in ("first_name", "experience", "target_titles", "core_domains", "adjacent_domains", "summary")}
    d = llm._parse(TargetsDraft, TARGETS_PROMPT.format(city=profile["city"], state=profile["state_code"],
                                                       profile=json.dumps(p, indent=1), resume=resume[:12000]), 2000)
    return own_words_out(d.model_dump(), profile)


def own_words_out(lists, profile):
    titles = (profile.get("target_titles") or []) + [r.get("title", "") for r in profile.get("experience") or []]
    own = {w for t in titles for w in re.findall(r"[a-z]+", (t or "").lower())}
    for k in ("above_level_words", "below_level_words", "other_discipline_words"):
        lists[k] = [w for w in lists.get(k) or [] if not set(re.findall(r"[a-z]+", w.lower())) & own]
    mine = set().union(*(_stems(x) for x in titles + (profile.get("core_domains") or []) + (profile.get("adjacent_domains") or [])))
    lists["other_discipline_words"] = [w for w in lists["other_discipline_words"] if not _stems(w) & mine]
    return lists


_STOP = {"and", "the", "for", "with", "from", "into", "other", "work"}


def _stems(text):
    out = set()
    for w in re.findall(r"[a-z]+", (text or "").lower()):
        if len(w) < 4 or w in _STOP:
            continue
        for suf in ("ers", "er", "ing", "ists", "ist", "ies", "s"):
            if w.endswith(suf) and len(w) - len(suf) >= 4:
                w = w[:-len(suf)]
                break
        out.add(w)
    return out


def _alt(words):
    import re
    ws = sorted({w.strip().lower() for w in words if w.strip()}, key=len, reverse=True)
    return "|".join(rf"\b{re.escape(w)}\b".replace(r"\ ", " ") for w in ws)


def to_targets(profile, t, template=ENGINE / "kit" / "templates" / "targets.template.json"):
    import re
    out = json.loads(Path(template).read_text(encoding="utf-8-sig"))
    first = profile["first_name"]
    cur = (profile.get("experience") or [{}])[0]
    employer = cur.get("company", "")
    core_name = re.sub(r"\b(inc|corp|corporation|llc|ltd|co)\b\.?", "", employer, flags=re.I).strip(" ,.")
    out["persona"] = f"{first} {profile['last_name']}, a {cur.get('title', t['profession'])} looking for a new role"
    out["excluded_companies"] = ([{"regex": re.escape(core_name.lower()), "reason": "current employer - never applied to by WorksForMe"}]
                                 if core_name else [])
    out["title_skips"] = [r for r in (
        {"regex": _alt(t["above_level_words"]), "reason": "title above target level"},
        {"regex": _alt(t["other_discipline_words"]), "reason": "not a target discipline"},
        {"regex": _alt(t["below_level_words"]), "reason": "below target level"}) if r["regex"]]
    towns = [profile["city"]] + t["nearby_towns"]
    out["local_regex"] = "|".join(re.escape(x).replace(r"\ ", " ") for x in towns if x) + "|remote"
    years = profile.get("years_experience") or 0
    above = ", ".join((t.get("above_level_words") or [])[:6])
    hard = "; ".join(["the hiring company is " + (employer or "the current employer") + " or one of its companies"]
                     + t["hard_nos"] + [f"level below {t['target_level']}",
                                        f"a level far above theirs ({above + ' titles, or ' if above else ''}"
                                        f"far more years of experience required than their {years})"])
    out["fit_prompt"] = (out["fit_prompt"].replace("<First>", first).replace("<their>", "their")
                         .replace("<current employer> or one of its companies; <hard no's, e.g. an active security clearance required; not hands-on>; level below <target level>", "")
                         .replace('else "": the hiring company is .', f'else "": {hard}.'))
    out["fit_prompt"] = re.sub(r"- core: <[^>]*>\.", "- core: " + "; ".join(profile["core_domains"]) + ".", out["fit_prompt"])
    out["fit_prompt"] = re.sub(r"- adjacent: <[^>]*>\.", "- adjacent: " + "; ".join(profile["adjacent_domains"]) + ".", out["fit_prompt"])
    out["fit_prompt"] = re.sub(r"- none: <[^>]*>\.", "- none: " + "; ".join(t["none_domains"]) + ".", out["fit_prompt"])
    out["draft_prompt"] = (out["draft_prompt"].replace("<First>", first).replace("<they>", "they")
                           .replace("<profession>", t["profession"]))
    prof = ENGINE / "applicant.json"
    out["relocate_min_base"] = relocate_min_base(json.loads(prof.read_text(encoding="utf-8-sig")) if prof.exists() else {})
    kinds = {str(x).lower() for x in t.get("employment_types") or []}
    out["employment_types"] = [k for k in ("full-time", "contract", "contract-to-hire", "part-time", "temporary")
                               if k in kinds] or ["full-time"]
    out["categories"] = ["General"]
    out["default_category"] = "General"
    out["_wizard"] = {"lists": t, "profile": {k: profile.get(k) for k in (
        "first_name", "last_name", "city", "state_code", "experience", "core_domains", "adjacent_domains")}}
    left = re.findall(r"<[^<>{}]{3,}>", json.dumps({k: out[k] for k in ("persona", "fit_prompt", "draft_prompt", "title_skips")}))
    if left:
        raise ValueError(f"placeholders left in targets: {left[:3]}")
    return out


QUESTIONS = [
    ("location.street_address", "Street address", None),
    ("location.zip", "ZIP code", None),
    ("location.county", "County", None),
    ("eligibility.authorized_to_work_us", "Are you authorized to work in the US?", ["Yes", "No"]),
    ("eligibility.requires_sponsorship", "Will you need visa sponsorship, now or later?", ["No - now or in the future", "Yes"]),
    ("eligibility.citizenship", "Citizenship", None),
    ("eligibility.willing_to_relocate", "Willing to relocate?", ["Yes", "No"]),
    ("eligibility.willing_to_travel", "Willing to travel?", ["No", "Up to 10%", "Up to 25%", "Up to 50%", "Yes"]),
    ("eligibility.currently_employed", "Are you employed right now?", ["Yes", "No"]),
    ("eligibility.earliest_start", "Earliest start", ["Immediately", "Two weeks after an offer", "Three weeks after an offer",
                                                      "One month after an offer", "Two months after an offer",
                                                      "Three months after an offer"]),
    ("eligibility.notice_period", "Notice period at your current job (None if not employed)", None),
    ("eligibility.may_contact_current_employer", "May employers contact your current employer?", ["No", "Yes"]),
    ("eligibility.government_employee_or_relative", "Are you, or a close relative, a government employee or official?", ["No", "Yes"]),
    ("standing_answers.non_compete", "Any non-compete or non-solicitation agreement in place?", ["No", "Yes"]),
    ("eligibility.security_clearance", "Security clearance", ["No - none, never held one", "Yes (I will type it)"]),
    ("compensation.floor.min_base_usd", "Lowest base salary you would take (USD per year)", None),
    ("compensation.floor.min_total_usd", "Lowest total pay you would take (USD per year)", None),
    ("self_identification.gender", "Gender (voluntary)", ["Male", "Female", "Decline"]),
    ("self_identification.hispanic_latino", "Hispanic or Latino? (voluntary)", ["No", "Yes", "Decline"]),
    ("self_identification.race", "Race (voluntary)", ["White", "Black or African American", "Asian",
                                                      "American Indian or Alaska Native",
                                                      "Native Hawaiian or Other Pacific Islander", "Two or more races",
                                                      "Decline"]),
    ("self_identification.veteran_status", "Veteran status (voluntary)", ["I am not a veteran", "I am a protected veteran",
                                                                          "I am a veteran, but not a protected veteran", "Decline"]),
    ("self_identification.disability_status", "Disability (voluntary)", ["No, I do not have a disability",
                                                                         "Yes, I have a disability", "Decline"]),
]


FIELD_LABELS = {"identity.first_name": "First name", "identity.last_name": "Last name", "identity.email": "Email",
                "identity.phone": "Phone", "identity.phone_digits": "Phone", "identity.linkedin": "LinkedIn",
                "location.country": "Country you live in", "location.city": "City", "location.state": "State",
                "location.state_code": "State", "experience": "Roles", "most_recent_job.title": "Roles",
                "most_recent_job.company": "Roles", "education_on_forms": "Education",
                "compensation.required_range_usd": "Lowest base salary you would take",
                "compensation.single_number_usd": "Lowest base salary you would take"}


def fill_in(gaps):
    asks = {k: re.sub(r"\s*\((voluntary|USD per year|None if not employed)\)$", "", q) for k, q, _c in QUESTIONS}
    order = list(FIELD_LABELS) + [k for k, _q, _c in QUESTIONS]
    keys = sorted({re.sub(r"^key ", "", g).split("[")[0] for g in gaps},
                  key=lambda k: order.index(k) if k in order else len(order))
    names = []
    for k in keys:
        name = FIELD_LABELS.get(k) or asks.get(k) or k.split(".")[-1].replace("_", " ").capitalize()
        if name not in names:
            names.append(name)
    return "Please fill in: " + ", ".join(names) + "."


def apply_answers(applicant, answers):
    free = {k for k, _q, c in QUESTIONS if c is None}
    cc = str((applicant.get("location") or {}).get("country_code") or "US").upper()
    for key, value in answers.items():
        if not any(key == q[0] for q in QUESTIONS):
            continue
        node = applicant
        *path, leaf = key.split(".")
        for part in path:
            node = node.setdefault(part, {})
        if key in formats.MONEY:
            value = formats.money(value) or 0
        elif key in free:
            value = formats.fix(key, value, cc)[0]
        node[leaf] = value
    floor = applicant.get("compensation", {}).get("floor", {})
    if floor.get("min_base_usd"):
        applicant["compensation"]["required_range_usd"] = [floor["min_base_usd"], round(floor["min_base_usd"] * 1.3)]
        applicant["compensation"]["single_number_usd"] = round(floor["min_base_usd"] * 1.15)
    return applicant


class AlertDraft(BaseModel):
    discipline_titles: List[str]
    level_words: List[str]
    domain_words: List[str]


ALERT_PROMPT = """Design a LinkedIn job-alert keyword search for this person. Give three lists:
- discipline_titles: 2-5 job-title phrases of their discipline WITHOUT level words, exactly as employers name the job in
  postings (e.g. "software engineer", "security engineer", "product manager") - never a skill area, a team name or a
  title you made up.
- level_words: their level and one or two adjacent levels (single words).
- domain_words: 5-10 specific words or short phrases of their field. AVOID words that appear in nearly every posting of
  the field (e.g. "distributed systems" for software) and ambiguous words that pull other fields (e.g. bare "agent", which
  pulls insurance and travel agents).
Base it on the resume and profile only.

PROFILE:
{profile}"""


def draft_alerts(profile):
    p = {k: profile[k] for k in ("experience", "target_titles", "core_domains", "adjacent_domains", "summary")}
    return tidy_alerts(llm._parse(AlertDraft, ALERT_PROMPT.format(profile=json.dumps(p, indent=1)), 1200).model_dump(),
                       profile.get("years_experience"))


LEVEL_RX = r"(?:senior|sr\.?|staff|principal|lead|junior|jr\.?|distinguished|chief|associate)"


DASHES = re.compile("[‐-―−﹘﹣－]")


def plain_word(w):
    return re.sub(r"\s+", " ", DASHES.sub("-", str(w or "")).replace("­", "").replace(" ", " ")).strip()


def tidy_alerts(a, years=None):
    for k in ("discipline_titles", "level_words", "domain_words"):
        a[k] = [plain_word(w) for w in a.get(k) or []]
    titles = []
    for t in a.get("discipline_titles") or []:
        t = re.sub(r"\s*\([^)]*\)", "", t)
        t = re.sub(rf"^(?:{LEVEL_RX}\s+)+", "", t.strip(), flags=re.I).strip(" ,-")
        if t and t.lower() not in (x.lower() for x in titles):
            titles.append(t)
    a["discipline_titles"] = titles[:6]
    a["level_words"] = list(dict.fromkeys(w.strip() for w in a.get("level_words") or [] if w.strip()))[:4]
    a["level_words"] = [w for w in a["level_words"] if re.fullmatch(
        r"(junior|jr\.?|entry[- ]level|entry|associate|mid[- ]level|intermediate|senior|sr\.?|staff|principal|lead|"
        r"distinguished|chief|head|manager|director|vp|vice president|intern|graduate|new grad|i{1,3}|iv)", w.strip(), re.I)]
    if years is not None and years < 5:
        a["level_words"] = [w for w in a["level_words"] if not re.fullmatch(
            r"(senior|sr\.?|staff|principal|lead|manager|director|head|chief|vp|vice president)", w, re.I)]
    a["domain_words"] = list(dict.fromkeys(w.strip() for w in a.get("domain_words") or [] if w.strip()))[:10]
    return a


def alert_query(a):
    a = {k: [plain_word(w) for w in v] if isinstance(v, list) else v for k, v in a.items()}
    q = lambda w: f'"{w.strip()}"' if " " in w.strip() else w.strip()
    if not [w for w in (a.get("discipline_titles") or []) if w.strip()]:
        raise ValueError("Add at least one job title.")
    parts = [a.get(k) or [] for k in ("discipline_titles", "level_words", "domain_words")]
    return " AND ".join("(" + " OR ".join(q(w) for w in ws if w.strip()) + ")" for ws in parts if any(w.strip() for w in ws))


def triage_jobs(n=12, include_marked=False):
    import csv
    import hashlib
    marked = {e.get("url") for e in (json.loads((ENGINE / "fit_cases.json").read_text(encoding="utf-8")).get("examples") or [])} \
        if (ENGINE / "fit_cases.json").exists() and not include_marked else set()
    seen, strong, other = set(marked), [], []
    for f in sorted((ENGINE / "runs").glob("triage-*.csv"), reverse=True):
        for r in csv.DictReader(f.open(encoding="utf-8")):
            if r.get("url") and r["url"] not in seen:
                seen.add(r["url"])
                (strong if r.get("verdict") == "strong" else other).append(r)
    k = min(len(strong), max(n // 2, n - len(other)))
    rows = sorted(strong[:k] + other[:n - k], key=lambda r: hashlib.sha1(r["url"].encode()).hexdigest())
    return [{"company": r["company"], "title": r["title"], "verdict": r["verdict"], "reason": r["reason"][:160],
             "url": r["url"]} for r in rows]


def fit_cases(marks, old=None):
    import datetime as dt
    old = old or {}
    cases = dict(old.get("cases") or {})
    ex = [e for e in old.get("examples") or [] if (e.get("company"), e.get("title")) not in
          {(m["company"], m["title"]) for m in marks}]
    for m in marks:
        cases[f"{m['company']} {m['title']}"[:80]] = bool(m["apply"])
        ex.append({"company": m["company"], "title": m["title"], "apply": bool(m["apply"]), "url": m.get("url", ""),
                   "date": dt.date.today().isoformat()})
    return {"cases": cases, "examples": ex[-40:]}


ROLE_WORDS = r"(engineer|developer|analyst|researcher|scientist|manager|coordinator|specialist|associate|assistant|consultant|" \
             r"director|lead|officer|representative|administrator|aide|intern|architect|designer|organizer|writer|editor|" \
             r"advisor|adviser|technician|strategist|planner|partner|head|staff|senior|sr|junior|jr|principal|ii|iii|iv|i)"


def field_of(title):
    t = re.sub(r"\(.*?\)|[,/|].*$", "", title or "").lower()
    words = [w for w in re.findall(r"[a-z][a-z&+-]*", t) if not re.fullmatch(ROLE_WORDS, w)]
    return " ".join(words).strip() or (title or "").strip().lower()


def taste_suggestions(marks, rows):
    t = json.loads((ENGINE / "targets.json").read_text(encoding="utf-8-sig"))
    w = t.get("_wizard") or {}
    lists, prof = w.get("lists") or {}, w.get("profile") or {}
    out = []
    for m in marks:
        r = rows.get(m.get("url")) or {}
        said_apply = r.get("verdict") == "strong"
        if not r or said_apply == bool(m["apply"]):
            continue
        why, title, opts = r.get("reason") or "", m["title"], []
        field = field_of(title)
        if m["apply"]:
            for key, rx_reason in (("above_level_words", "above target level"), ("below_level_words", "below target level"),
                                   ("other_discipline_words", "not a target discipline")):
                if rx_reason in why or why.startswith("RULE"):
                    for word in lists.get(key) or []:
                        if re.search(rf"\b{re.escape(word.lower())}\b", title.lower()):
                            opts.append({"kind": "drop", "list": key, "value": word,
                                         "label": f'Stop skipping job titles with "{word}"'})
            for hard in lists.get("hard_nos") or []:
                if hard.lower()[:25] in why.lower():
                    opts.append({"kind": "drop", "list": "hard_nos", "value": hard, "label": f'Remove the rule "{hard}"'})
            if why.startswith("DOMAIN adjacent"):
                opts.append({"kind": "setting", "key": "fit_breadth", "value": "related",
                             "label": "Also apply to work next to your field (not only your own field)"})
            if why.startswith("DOMAIN") and field not in [x.lower() for x in (prof.get("core_domains") or []) + (prof.get("adjacent_domains") or [])]:
                opts.append({"kind": "add", "list": "adjacent_domains", "value": field,
                             "label": f'Count "{field}" as work you would do'})
            if re.match(r"crowded|pay|low pay|below", why, re.I) and not opts:
                opts.append({"kind": "info", "label": "Skipped because of your pay settings (Settings > Job search)"})
        else:
            opts.append({"kind": "add", "list": "none_domains", "value": field, "label": f'"{field}" is not my kind of work'})
            own = {x for tt in (prof.get("target_titles") or []) + [e.get("title", "") for e in prof.get("experience") or []]
                   for x in re.findall(r"[a-z]+", (tt or "").lower())}
            for word in [x for x in re.findall(r"[a-z]+", title.lower()) if len(x) > 3 and x not in own][:3]:
                opts.append({"kind": "add", "list": "other_discipline_words", "value": word,
                             "label": f'Skip job titles with "{word}"'})
        out.append({"company": m["company"], "title": title, "you": "apply" if m["apply"] else "skip",
                    "it": "apply" if said_apply else "skip", "why": why[:200], "options": opts})
    return out


def apply_taste(changes):
    import settings_api
    lists = settings_api.fit_lists()
    if lists is None:
        raise ValueError("these fit rules were written by hand, so they cannot be changed here")
    done, setting = [], {}
    for c in changes:
        if c.get("kind") == "setting":
            setting[f"s:{c['key']}"] = c["value"]
        elif c.get("kind") in ("add", "drop") and c.get("list") in lists and str(c.get("value") or "").strip():
            cur = list(lists[c["list"]] or [])
            v = str(c["value"]).strip()
            if c["kind"] == "add" and v.lower() not in [x.lower() for x in cur]:
                cur.append(v)
            if c["kind"] == "drop":
                cur = [x for x in cur if x.lower() != v.lower()]
            lists[c["list"]] = cur
        else:
            continue
        done.append(c.get("label") or f"{c['kind']} {c.get('value')}")
    if any(c.get("kind") in ("add", "drop") for c in changes):
        settings_api.save_fit_lists(lists)
    if setting:
        settings_api.save(setting)
    return done


def startup_shortcut():
    import os
    return Path(os.environ["APPDATA"]) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / f"{config.APP_NAME} daily run.lnk"


def go_live():
    import subprocess
    lnk = startup_shortcut()
    if lnk.exists():
        raise FileExistsError(f"{lnk} exists - the daily run is already on")
    pyw = Path(sys.executable).with_name("pythonw.exe")
    agent = next(a for a in (ENGINE / "agent.pyw", ENGINE / "jobbot_agent.pyw") if a.exists())
    lnk.parent.mkdir(parents=True, exist_ok=True)
    ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut($env:SC_LNK); $s.TargetPath=$env:SC_EXE; "
          "$s.Arguments='-E -s \"' + $env:SC_AGENT + '\"'; $s.WorkingDirectory=$env:SC_DIR; $s.Description=$env:SC_DESC; $s.Save()")
    env = dict(__import__("os").environ, SC_LNK=str(lnk), SC_EXE=str(pyw), SC_AGENT=str(agent), SC_DIR=str(ENGINE),
               SC_DESC=f"{config.APP_NAME} daily run")
    subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=True, timeout=60, env=env,
                   creationflags=subprocess.CREATE_NO_WINDOW)
    if not lnk.exists():
        raise RuntimeError("the Startup shortcut was not created")
    start_agent(pyw, agent)
    return lnk


def start_agent(pyw, agent):
    import subprocess
    subprocess.Popen([str(pyw), "-E", "-s", str(agent)], cwd=str(ENGINE))


UPLOAD = ENGINE / "runs" / "setup-upload"

ROUTING_V1 = """# Resume categories

One PDF per category, built from the master resume. Version 1 of the setup uses ONE category: the master itself.

## Routing

| If the title or first responsibilities say... | Use |
|---|---|
| anything | **General** (default) |

## Provenance

Built {date} by the setup wizard from `{master}`. Rebuild the PDF after any change to the master.
"""


def keep_upload(name, data, folder=None):
    folder = folder or UPLOAD
    folder.mkdir(parents=True, exist_ok=True)
    pdf = Path(name).suffix.lower() == ".pdf"
    for old in folder.iterdir():
        if (old.suffix.lower() == ".pdf") == pdf:
            old.unlink()
    p = folder / Path(name).name
    p.write_bytes(data)
    return p


REPLACE = ENGINE / "runs" / "resume-replace"


def _general_pdf(up, own_pdf, name):
    import shutil
    import make_pdf
    cat = config.CATEGORIES_DIR / "General"
    cat.mkdir(parents=True, exist_ok=True)
    if up.suffix.lower() == ".pdf":
        pdf = cat / f"{name}.pdf"
        shutil.copy2(up, pdf)
        return pdf
    doc = cat / f"{name}{up.suffix}"
    shutil.copy2(up, doc)
    pdf = doc.with_suffix(".pdf")
    if own_pdf:
        shutil.copy2(own_pdf, pdf)
    elif make_pdf.available():
        make_pdf.convert(doc)
    else:
        raise ValueError("Add a PDF copy of your resume too (in Word: File > Save As > PDF).")
    return pdf


def replace_resume(d):
    import datetime as dt
    import shutil
    import safe_io
    import selftest
    ups = sorted(REPLACE.glob("*")) if REPLACE.exists() else []
    if not ups:
        raise ValueError("drop the new resume first")
    up = next((u for u in ups if u.suffix.lower() != ".pdf"), ups[0])
    own_pdf = next((u for u in ups if u.suffix.lower() == ".pdf"), None)
    a = json.loads((ENGINE / "applicant.json").read_text(encoding="utf-8-sig"))
    new = to_applicant({**d, "country_code": (a.get("location") or {}).get("country_code") or "US"})
    if not new.get("experience"):
        raise ValueError("no roles were read from this resume - check the work history above")
    for k in ("experience", "most_recent_job", "education", "education_on_forms"):
        if new.get(k):
            a[k] = new[k]
    a.setdefault("eligibility", {})["currently_employed"] = "No" if a["experience"][0].get("end_year") else "Yes"
    selftest.applicant(a)
    ident = a.get("identity") or {}
    name = f"{ident.get('first_name', '')} {ident.get('last_name', '')} - Resume".strip()
    bak = ENGINE / "runs" / "settings-backup" / dt.datetime.now().strftime("%Y-%m-%d_%H%M%S_resume")
    bak.mkdir(parents=True, exist_ok=True)
    old = config.MASTER_RESUME
    if old.exists():
        shutil.copy2(old, bak / old.name)
    shutil.copy2(ENGINE / "applicant.json", bak / "applicant.json")
    master = (old.parent if "<" not in str(old.parent) else ENGINE.parent / "profile") / f"{name}{up.suffix}"
    master.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(up, master)
    if master != old:
        with safe_io.locked(ENGINE / "settings.json"):
            s = json.loads((ENGINE / "settings.json").read_text(encoding="utf-8-sig"))
            s["master_resume"] = str(master)
            safe_io.write_json(ENGINE / "settings.json", s)
        config.MASTER_RESUME = master
    pdf = _general_pdf(up, own_pdf, name)
    retired = []
    if config.CATEGORIES_DIR.exists():
        for p in config.CATEGORIES_DIR.iterdir():
            if p.is_dir() and p.name != "General":
                (bak / "Categories").mkdir(exist_ok=True)
                shutil.move(str(p), str(bak / "Categories" / p.name))
                retired.append(p.name)
    a["resumes"] = {"General": str(pdf)}
    with safe_io.locked(ENGINE / "targets.json"):
        t = json.loads((ENGINE / "targets.json").read_text(encoding="utf-8-sig"))
        t["categories"], t["default_category"] = ["General"], "General"
        safe_io.write_json(ENGINE / "targets.json", t)
    safe_io.write_text(config.CATEGORIES_DIR / "README.md", ROUTING_V1.format(date=dt.date.today(), master=master.name))
    safe_io.write_json(ENGINE / "applicant.json", a)
    shutil.rmtree(REPLACE, ignore_errors=True)
    return {"master": master.name, "roles": len(a["experience"]), "employed": a["eligibility"]["currently_employed"],
            "retired": retired, "backup": str(bak)}


def set_up_resume(first, last):
    import datetime as dt
    import shutil
    ups = sorted(UPLOAD.glob("*")) if UPLOAD.exists() else []
    if not ups:
        raise FileNotFoundError("no resume was uploaded in this setup")
    up = next((u for u in ups if u.suffix.lower() != ".pdf"), ups[0])
    own_pdf = next((u for u in ups if u.suffix.lower() == ".pdf"), None)
    name = f"{first} {last} - Resume"
    master = config.MASTER_RESUME
    if "<" in str(master) or not master.exists():
        master = (config.MASTER_RESUME.parent if "<" not in str(config.MASTER_RESUME.parent) else ENGINE.parent / "profile") / f"{name}{up.suffix}"
        master.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(up, master)
        fill_setting("master_resume", str(master))
        config.MASTER_RESUME = master
    pdf = _general_pdf(up, own_pdf, name)
    readme = config.CATEGORIES_DIR / "README.md"
    if not readme.exists():
        readme.write_text(ROUTING_V1.format(date=dt.date.today(), master=master.name), encoding="utf-8")
    return pdf


def fill_setting(key, value, folder=None):
    import safe_io
    p = Path(folder or ENGINE) / "settings.json"
    with safe_io.locked(p):
        return _fill_setting(p, key, value)


def _fill_setting(p, key, value):
    s = json.loads(p.read_text(encoding="utf-8-sig")) if p.exists() else {}
    cur = str(s.get(key) or "")
    if cur and not re.search(r"<[^<>]+>", cur):
        return False
    s[key] = value
    import safe_io
    safe_io.write_json(p, s)
    return True


def relocate_min_base(applicant):
    if str(applicant.get("eligibility", {}).get("willing_to_relocate", "")).lower().startswith("n"):
        return 999_999_999
    return int(applicant.get("compensation", {}).get("floor", {}).get("min_base_usd") or 1)


def missing(applicant):
    import selftest
    out = [p.split(":")[0] for p in selftest.placeholders(applicant)]
    for k in selftest.required(applicant):
        try:
            selftest.need(applicant, k, "applicant.json")
        except Exception:
            out.append(k)
    if out:
        return sorted(set(out)), None
    try:
        selftest.applicant(applicant)
    except (ValueError, AssertionError) as e:
        return [], str(e).replace("applicant.json ", "")
    return [], None


def save(applicant, folder=None, name="applicant.json"):
    p = Path(folder or ENGINE) / name
    if p.exists():
        raise FileExistsError(f"{p} exists - the wizard never overwrites a set-up profile")
    import safe_io
    safe_io.write_json(p, applicant)
    return p


if __name__ == "__main__":
    print(json.dumps(draft(sys.argv[1]), indent=1, ensure_ascii=False))
