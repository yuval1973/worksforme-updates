import html
import json
import re
import sys
import zipfile
from pathlib import Path
from typing import List, Literal
from xml.etree import ElementTree

from pydantic import BaseModel

ENGINE = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ENGINE))
import config
import llm

P_RX = re.compile(r"<w:p[ >].*?</w:p>|<w:p(?: [^>]*)?/>", re.S)
R_RX = re.compile(r"<w:r[ >].*?</w:r>", re.S)
SUMMARY = re.compile(r"^(professional |career |executive |personal )?(summary|profile|about( me)?|overview|objective)$", re.I)
SKILLS = re.compile(r"^((technical|core|key|relevant) )?(skills|competencies|expertise|strengths)( (and|&) [\w ]+)?$", re.I)
SECTIONS = re.compile(r"^((work|professional|relevant|research|teaching|volunteer|leadership) )?(experience|history|employment"
                      r"|education|projects|publications|certifications?|licen[cs]es|awards|honou?rs|volunteering|languages"
                      r"|interests|references|research|activities|leadership|training|courses|achievements|affiliations"
                      r"|memberships|presentations|grants|patents|military service)( (and|&) [\w ]+)?$", re.I)
LEAD = re.compile(r"^(core strengths|core competencies|key strengths|strengths|highlights|areas of expertise)\s*:", re.I)
LABEL = re.compile(r"^[^:]{1,40}:\s*\S")
COMPLEX = re.compile(r"<w:(hyperlink|ins|del|moveFrom|moveTo|sdt|fldSimple|fldChar|instrText|txbxContent|rPrChange|drawing"
                     r"|pict|object|smartTag|customXml|bookmarkStart|bookmarkEnd|commentRangeStart|commentRangeEnd"
                     r"|commentReference|footnoteReference|endnoteReference)\b|<mc:AlternateContent")
STOP = set("a an and or the of in on at to for from by with as over into within across about between through via per "
           "who which that this these those is are was were be been being has have had its it their his her my our we "
           "i he she they them using including such also both more most than while plus".split())
NUMBER_WORDS = re.compile(r"\b(one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|"
                          r"sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|"
                          r"hundreds?|thousands?|millions?|billions?|dozens?)\b", re.I)
NUMBER = re.compile(r"\$?\d+(?:[.,]\d+)*(?:\s?(?:[KkMB]\b|%|\+|million|billion|thousand))?")


def _text(x):
    x = re.sub(r"<w:(delText|instrText)\b[^>]*>.*?</w:\1>", "", x, flags=re.S)
    return html.unescape(re.sub(r"<[^>]+>", "", re.sub(r"<w:tab/>", "\t", x))).strip()


def _heading(px, t):
    if not (0 < len(t) <= 40) or t.endswith("."):
        return False
    return bool(t.isupper() or SUMMARY.match(t) or SKILLS.match(t) or SECTIONS.match(t) or "<w:caps/>" in px
                or re.search(r'<w:pStyle w:val="(Heading|Title|Subtitle)', px))


def structure(docx):
    xml = zipfile.ZipFile(docx).read("word/document.xml").decode("utf-8")
    spans = [(m.start(), m.end()) for m in P_RX.finditer(xml)]
    raw = [xml[s:e] for s, e in spans]
    texts = [_text(p) for p in raw]
    heads = [_heading(p, t) for p, t in zip(raw, texts)]

    def section(rx, stop_at_label=False):
        start = next((i for i, t in enumerate(texts) if heads[i] and rx.match(t)), None)
        if start is None:
            return []
        out = []
        for i in range(start + 1, len(texts)):
            gap = xml[spans[i - 1][1]:spans[i][0]]
            if heads[i] or re.search(r"</?w:(tc|tbl)\b", gap) or (stop_at_label and (LEAD.match(texts[i]) or LABEL.match(texts[i]))):
                break
            if texts[i]:
                out.append(i)
        return out
    summary = section(SUMMARY, stop_at_label=True)
    if not summary or len(summary) > 3 or sum(len(texts[i].split()) for i in summary) > 200:
        return None
    skills = section(SKILLS)
    after = next((i for i in range(summary[-1] + 1, len(texts)) if texts[i]), None)
    lead = next((i for i in skills if LEAD.match(texts[i])), None)
    if lead is None and after is not None and LEAD.match(texts[after]):
        lead = after
    lines = [i for i in skills if i != lead and LABEL.match(texts[i])]
    editable = summary + lines + ([lead] if lead is not None else [])
    if any(COMPLEX.search(raw[i]) or len(re.findall(r"<w:p[ >/]", raw[i])) != 1 for i in editable):
        return None
    return {"xml": xml, "spans": spans, "texts": texts, "summary": summary, "lead": lead, "lines": lines,
            "added": 'w:val="AddedSummary"' in raw[summary[0]]}


def word_master(master=None):
    master = Path(master or config.MASTER_RESUME)
    if master.suffix.lower() == ".docx" and structure(master) is not None:
        return master
    out = master.with_name(master.stem + " (for versions).docx")
    if out.exists() and out.stat().st_mtime >= master.stat().st_mtime and structure(out) is not None:
        return out
    import resume_word
    try:
        a = json.loads((ENGINE / "applicant.json").read_text(encoding="utf-8-sig"))
        letter = ((a.get("location") or {}).get("country_code") or "US") in ("US", "CA")
    except (OSError, ValueError):
        letter = True
    return resume_word.rebuild(master, out, letter=letter)


class Version(BaseModel):
    kind: Literal["experience", "stretch"]
    name: str
    evidence: List[str]
    signals: List[str]
    summary: str
    lead: str
    lines: List[str]


class Versions(BaseModel):
    versions: List[Version]


PROMPT = """This person's resume has a summary and a skills section. Make versions of ONLY those parts, so each version
leads with what one kind of job looks for. Everything else in the resume stays exactly as it is.

Two kinds of version:
- "experience": a kind of work this resume clearly SHOWS - several roles, projects or bullets, not one passing word
  (one mention of a tool does not make someone a professional in it). Give 2-4 short phrases copied EXACTLY from the
  resume that show it. Make 1-3 of these, one per really different kind of work.
- "stretch": ONLY for the directions listed under DIRECTIONS THEY WANT TO TRY (none listed = no stretch versions) - one
  for EACH listed direction that no experience version already covers, named after that direction. The summary is
  honest: it says what they want to move into and which of their real skills carry over - it never claims
  experience they do not have. Evidence = 2-4 exact phrases of those transferable skills.

Rules:
- Use only facts that are in the resume: no new numbers, employers, products, technologies or claims. Reword, reorder
  and emphasize - never invent. Strengths and skill lines use only words that are already in the resume.
- Keep their voice and tense; keep the summary about as long as the original ({words} words, within 20%).
- Skill lines: exactly {n} lines, most relevant first, each in the original "Label: items" format. You may reorder the
  items in a line, rename a label, or move items between lines - but every item must already be in the resume.
- Each version: a short name for the kind of job (2-4 words); the title and responsibility words that mean a job is of
  this kind; the new summary; the new lead line in the same format WITHOUT its label ("" if there is none); the lines.
- The kinds must differ, and must be jobs they would apply to (their target titles and domains below) - none for a
  field they have not worked in. Do not name one "General" (the original resume keeps that name).

TARGET TITLES: {titles}
WORK THEY HAVE DONE FOR YEARS: {core}
DIRECTIONS THEY WANT TO TRY (stretch versions only for these): {directions}

SUMMARY (original):
{summary}

LEAD LINE (original{label}):
{lead}

SKILL LINES (original):
{lines}

THE WHOLE RESUME (facts only):
{resume}"""


def _label(t):
    m = LEAD.match(t)
    return t[:m.end()] if m else ""


def original(st):
    T = st["texts"]
    lead = T[st["lead"]] if st["lead"] is not None else ""
    return {"summary": "" if st.get("added") else " ".join(T[i] for i in st["summary"]),
            "lead": lead[len(_label(lead)):].strip(),
            "lines": [T[i] for i in st["lines"]]}


def propose(docx, profile, directions=None):
    st = structure(docx)
    if st is None:
        return None
    o = original(st)
    lead = st["texts"][st["lead"]] if st["lead"] is not None else ""
    prompt = PROMPT.format(words=len(o["summary"].split()) or 45, n=len(o["lines"]),
                           titles=", ".join(profile.get("target_titles") or []),
                           core=", ".join(profile.get("core_domains") or []),
                           directions="; ".join(directions or []) or "(none)",
                           summary=o["summary"] or "(none yet - write one, 2-3 sentences, from the resume's facts)",
                           label=f', label "{_label(lead)}"' if _label(lead) else "", lead=o["lead"] or "(none)",
                           lines="\n".join(o["lines"]) or "(none)", resume="\n".join(t for t in st["texts"] if t)[:16000])
    out = []
    asked = list(directions or [])
    words = lambda s: {w for w in re.findall(r"[a-z]{4,}", s.lower())}
    want = [words(d) for d in asked]
    text = "\n".join(st["texts"])
    for v in llm._parse(Versions, prompt, 3000).versions:
        v = v.model_dump()
        v.update(name=plain(v["name"], text), summary=plain(v["summary"], text), lead=plain(v["lead"], text),
                 lines=[plain(x, text) for x in v["lines"]], evidence=[plain(x, text) for x in v["evidence"]],
                 signals=[plain(x, text) for x in v["signals"]])
        if v["name"] == v["name"].lower():
            v["name"] = title_case(v["name"])
        if v["kind"] == "stretch" and not any(w & words(v["name"] + " " + " ".join(v["signals"])) for w in want):
            continue
        if sum(x["kind"] == v["kind"] for x in out) >= 3 or len(out) >= 5:
            continue
        v["lines"] = fit_lines(v["lines"], o["lines"])
        if name_problem(v["name"], [x["name"] for x in out]):
            continue
        notes = []
        v["evidence"] = proven(v["evidence"], st)
        if v["kind"] == "experience" and len(v["evidence"]) < 2:
            v["kind"] = "stretch"
            notes.append("your resume shows little of this kind of work - kept as a stretch version")
        problems = check(v, st, notes)
        out.append({**v, "problems": problems, "notes": notes})
    return {"original": o, "versions": out}


def plain(s, master):
    s = re.sub("[‐‑‒]", "-", s or "").replace(" ", " ")
    if "’" not in master and "‘" not in master:
        s = s.replace("’", "'").replace("‘", "'")
    if "“" not in master and "”" not in master:
        s = s.replace("“", '"').replace("”", '"')
    return s


def title_case(s):
    small = {"and", "of", "for", "the", "in", "on", "to", "a", "an", "or"}
    ws = s.split()
    return " ".join(w.upper() if len(w) <= 2 and w not in small else w if w in small and i else w[:1].upper() + w[1:]
                    for i, w in enumerate(ws))


def proven(quotes, st):
    norm = lambda t: re.sub(r"[^a-z0-9+#]+", " ", t.lower()).strip()
    master = norm("\n".join(st["texts"]))
    return [q for q in quotes or [] if len(norm(q)) >= 4 and norm(q) in master]


def name_problem(name, others):
    n = safe(name).lower()
    if not n:
        return "a version needs a name"
    if n == "general":
        return '"General" is the name of your resume as it is'
    if n in (safe(o).lower() for o in others):
        return f'two versions are named "{safe(name)}"'
    return None


def fit_lines(new, orig):
    new = [l.strip() for l in new if l and l.strip()][:len(orig)]
    labels = {l.split(":", 1)[0].strip().lower() for l in new}
    return new + [l for l in orig if l.split(":", 1)[0].strip().lower() not in labels][:len(orig) - len(new)]


WORD = re.compile(r"(?<![\w$.])[A-Za-z][\w+#]*(?:[.-][\w+#]+)*")


def _vocab(master):
    words = {w.lower() for w in WORD.findall(master)}
    return words | {p for w in words for p in re.split(r"[/.-]", w) if p}


def _known(w, words):
    w = w.lower()
    stems = {w, w[:-1] if w.endswith("s") else w, w[:-2] if w.endswith("es") else w, w[:-2] if w.endswith("ed") else w,
             w[:-1] if w.endswith("d") else w, w[:-3] if w.endswith("ing") else w}
    return bool(stems & words) or all(p in words or p in STOP for p in re.split(r"[/.-]", w) if p)


def check(v, st, notes=None):
    master = "\n".join(st["texts"])
    words, exact = _vocab(master), set(WORD.findall(master))
    exact |= {w[:-1] for w in exact if w.endswith("s")} | {w + "s" for w in exact}
    nums = {re.sub(r"\s", "", n) for n in NUMBER.findall(master)}
    problems, soft = [], []
    idiom = lambda t: re.sub(r"\b0-to-1\b", "", t)

    def numbers(part):
        problems.extend(f"the number {n} is not in your resume" for n in NUMBER.findall(part) if re.sub(r"\s", "", n) not in nums)
        problems.extend(f'"{w}" is not in your resume' for w in NUMBER_WORDS.findall(part) if w.lower() not in words)

    def name_like(w, at_start, single):
        return any(c.isupper() for c in w[1:]) or any(c.isdigit() for c in w) or (w[0].isupper() and (not at_start or single))
    for part in [v.get("lead") or ""] + list(v.get("lines") or []):
        part = idiom(part)
        numbers(part)
        body = part.split(":", 1)[1] if LABEL.match(part) else part
        label = part.split(":", 1)[0] if LABEL.match(part) else ""
        for item in [label] + re.split(r"[,;|()\u2022]", body):
            toks = WORD.findall(item)
            for k, w in enumerate(toks):
                if w.lower() in STOP or _known(w, words) or w in exact:
                    continue
                (problems if name_like(w, k == 0, len(toks) == 1) else soft).append(f'"{w}" is not in your resume')
    s = idiom(v.get("summary") or "")
    numbers(s)
    toks = list(WORD.finditer(s))
    for k, m in enumerate(toks):
        w = m.group(0)
        start = not s[:m.start()].strip() or re.search(r"[.!?:;|(\u2022\u2013\u2014-]\s*$", s[:m.start()])
        inner = any(c.isupper() for c in w[1:]) or any(c.isdigit() for c in w)
        if inner and not _known(w, words):
            problems.append(f'"{w}" is not in your resume')
        elif w[0].isupper() and not start and w not in exact and not (w.lower() in STOP):
            problems.append(f'"{w}" is not in your resume')
        elif w[0].isupper() and start and not _known(w, words) and w.lower() not in STOP:
            nxt = toks[k + 1].group(0) if k + 1 < len(toks) else ""
            if nxt[:1].isupper() and s[m.end():toks[k + 1].start()].strip() == "":
                problems.append(f'"{w}" is not in your resume')
            else:
                soft.append(f'"{w}" is not in your resume')
        elif not w[0].isupper() and w.lower() not in STOP and not _known(w, words) and len(w) > 3:
            soft.append(f'"{w}" is not in your resume')
    orig = 0 if st.get("added") else sum(len(st["texts"][i].split()) for i in st["summary"])
    if orig and not 0.6 <= len(s.split()) / orig <= 1.5:
        soft.append(f"the summary is {len(s.split())} words; the original has {orig}")
    if notes is not None:
        notes.extend(dict.fromkeys(x for x in soft if x not in problems))
    return list(dict.fromkeys(problems))


def _rpr(run):
    m = re.search(r"<w:rPr>.*?</w:rPr>(?=\s*<w:(t|tab|br|sym)\b)", run, re.S) or re.search(r"<w:rPr>.*?</w:rPr>", run, re.S)
    return m.group(0) if m else ""


def _run(rpr, text):
    return f'<w:r>{rpr}<w:t xml:space="preserve">{html.escape(text, quote=False)}</w:t></w:r>'


def set_text(px, text):
    runs = list(R_RX.finditer(px))
    if not runs:
        return px
    acc, k_label = "", None
    for k, m in enumerate(runs):
        acc += html.unescape(re.sub(r"<[^>]+>", "", m.group(0)))
        if ":" in acc:
            if not acc.split(":", 1)[1].strip() and len(acc) <= 60:
                k_label = k
            break
    if k_label is None:
        return px[:runs[0].start()] + _run(_rpr(runs[0].group(0)), text) + px[runs[-1].end():]
    label_rpr = _rpr(runs[0].group(0))
    body_rpr = _rpr(runs[k_label + 1].group(0)) if k_label + 1 < len(runs) else label_rpr
    old_label = acc.split(":", 1)[0]
    m = re.match(r"^([^:]{1,60}):\s*(.*)$", text, re.S)
    label, rest = (m.group(1), m.group(2)) if m else (old_label, text)
    return px[:runs[0].start()] + _run(label_rpr, label.strip() + ":") + _run(body_rpr, " " + rest.strip()) + px[runs[-1].end():]


def _no_runs(px):
    runs = list(R_RX.finditer(px))
    return px[:runs[0].start()] + px[runs[-1].end():] if runs else px


def build(master, v, out):
    st = structure(master)
    if st is None:
        raise ValueError("this resume's layout cannot be varied safely - it is used as it is")
    xml, spans = st["xml"], st["spans"]
    piece = lambda i: xml[spans[i][0]:spans[i][1]]
    new = {st["summary"][0]: set_text(piece(st["summary"][0]), v["summary"])}
    new.update({i: _no_runs(piece(i)) for i in st["summary"][1:]})
    if st["lead"] is not None and v.get("lead"):
        label = _label(st["texts"][st["lead"]])
        new[st["lead"]] = set_text(piece(st["lead"]), (label + " " if label else "") + v["lead"].strip())
    for pos, line in zip(st["lines"], fit_lines(v.get("lines") or [], original(st)["lines"])):
        new[pos] = set_text(piece(pos), line)
    parts, last = [], 0
    for i, (s, e) in enumerate(spans):
        parts += [xml[last:s], new.get(i, xml[s:e])]
        last = e
    doc = "".join(parts) + xml[last:]
    try:
        ElementTree.fromstring(doc.encode("utf-8"))
    except ElementTree.ParseError as e:
        raise ValueError(f"internal check failed: the version would not be a valid Word file ({e})")
    out.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(master) as zin, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zout:
        for item in zin.infolist():
            zout.writestr(item, doc.encode("utf-8") if item.filename == "word/document.xml" else zin.read(item.filename))
    return out


def safe(name):
    return re.sub(r'[\\/:*?"<>|]+', " ", name or "").strip()[:60]


def save(versions, applicant_path=None, targets_path=None):
    import make_pdf
    applicant_path, targets_path = applicant_path or ENGINE / "applicant.json", targets_path or ENGINE / "targets.json"
    master = word_master()
    st = structure(master)
    if st is None:
        raise ValueError("this resume's layout cannot be varied safely - it is used as it is")
    seen = []
    for v in versions:
        if p := name_problem(v.get("name"), seen):
            raise ValueError(p)
        seen.append(v["name"])
    bad = {v["name"]: p for v in versions if (p := check(v, st))}
    if bad:
        raise ValueError("; ".join(f"{n}: {', '.join(p)}" for n, p in bad.items()))
    if not make_pdf.available():
        raise ValueError("resume versions need Microsoft Word or LibreOffice (free, libreoffice.org) to make their PDFs")
    a = json.loads(Path(applicant_path).read_text(encoding="utf-8-sig"))
    t = json.loads(Path(targets_path).read_text(encoding="utf-8-sig"))
    first, last = a["identity"]["first_name"], a["identity"]["last_name"]
    names = []
    for v in versions:
        name = safe(v["name"])
        doc = build(master, v, config.CATEGORIES_DIR / name / f"{first} {last} - Resume ({name}).docx")
        a.setdefault("resumes", {})[name] = str(make_pdf.convert(doc))
        names.append(name)
    t["categories"] = ["General"] + names
    t["default_category"] = "General"
    rows = "\n".join(f"| {', '.join(v['signals'])} | **{safe(v['name'])}**{' (stretch)' if v.get('kind') == 'stretch' else ''} |"
                     for v in versions)
    import safe_io
    safe_io.write_text(config.CATEGORIES_DIR / "README.md", ROUTING.format(rows=rows, master=master.name))
    safe_io.write_json(applicant_path, a)
    safe_io.write_json(targets_path, t)
    return names


ROUTING = """# Resume categories

One PDF per kind of job, built by the setup from the master resume (`{master}`). Only the summary, the core-strengths
line and the skill lines differ; experience, education and contact are the master's, word for word.

## Routing

| If the title or first responsibilities say... | Use |
|---|---|
{rows}
| anything else, or nothing above clearly fits | **General** (default) |

Tiebreakers: the title beats the body; required qualifications beat nice-to-haves.

## Provenance

Built by the setup wizard. After any change to the master, run the setup's "Resume versions" step again.
"""
