import html
import re
import zipfile
from pathlib import Path
from typing import List, Literal

from pydantic import BaseModel

KINDS = ("name", "contact", "heading", "summary", "skill", "role", "bullet", "more", "text", "skip")
BULLET = re.compile(r"^\s*[•▪●◦‣⁃∙·■►➢*>\-–—]\s*")
PAGE = re.compile(r"^(page\s*)?\d{1,2}(\s*(of|/)\s*\d{1,2})?$", re.I)
CONTACT = re.compile(r"@|\+?\d[\d ().-]{7,}\d|linkedin\.com|github\.com|https?://|www\.|\|", re.I)
DATES = re.compile(r"\b(19|20)\d{2}\b|\bpresent\b|\bcurrent\b", re.I)
LABEL = re.compile(r"^[^:]{1,40}:\s*\S")
INK, ACCENT, MUTED = "1A1A1A", "1F4E79", "555555"


class Layout(BaseModel):
    kinds: List[Literal["name", "contact", "heading", "summary", "skill", "role", "bullet", "more", "text", "skip"]]


PROMPT = """Below are the {n} lines of a resume, numbered, as they were read from its file. Label every line - do not
copy or change any text, only say what each line is:
- name: the person's name (usually the first line)
- contact: email, phone, city, links, or a line of them
- heading: a section title (Summary, Experience, Education, Skills, Projects ...)
- summary: a line of the opening summary / profile paragraph
- skill: a line of a skills section
- role: the header of a job, school or project (title, employer, place, dates)
- bullet: a line that starts a bullet point
- more: a line that continues the line above it (the same sentence or bullet, wrapped onto a new line)
- text: any other line of content
- skip: page numbers ("Page 2 of 2", "2"), or the name / contact repeated at the top of a later page
Return exactly {n} labels, in the order of the lines.

{lines}"""

SYSTEM = "You label the lines of a resume for a document builder. You never write or change resume text."


def lines_of(src):
    src = Path(src)
    if src.suffix.lower() == ".pdf":
        from pypdf import PdfReader
        text = "\n".join(pg.extract_text() or "" for pg in PdfReader(str(src)).pages)
    elif src.suffix.lower() == ".docx":
        with zipfile.ZipFile(src) as z:
            names = z.namelist()
            parts = [n for n in names if re.fullmatch(r"word/header\d*\.xml", n)] + ["word/document.xml"]
            text = "\n".join(
                html.unescape(re.sub(r"<[^>]+>", "", re.sub(r"<w:tab/>", " ", p)))
                for n in parts for p in re.findall(r"<w:p[ >].*?</w:p>", z.read(n).decode("utf-8"), re.S))
    else:
        text = src.read_text(encoding="utf-8", errors="replace")
    out = [re.sub(r"[ \t ]+", " ", t).strip() for t in text.splitlines()]
    return [t for t in out if t]


def _head_like(t):
    import variants
    return 0 < len(t) <= 40 and not t.endswith(".") and not CONTACT.search(t) and (
        (t.isupper() and len(t.split()) <= 5) or bool(variants.SUMMARY.match(t) or variants.SKILLS.match(t)
                                                     or variants.SECTIONS.match(t)))


def guess(lines):
    import variants
    kinds, section, seen_head = [], "", False
    for i, t in enumerate(lines):
        if i == 0:
            k = "name"
        elif PAGE.match(t):
            k = "skip"
        elif _head_like(t):
            k, seen_head = "heading", True
            section = "summary" if variants.SUMMARY.match(t) else "skills" if variants.SKILLS.match(t) else "other"
        elif BULLET.match(t) and len(t) > 2:
            k = "bullet"
        elif not seen_head:
            k = "contact" if CONTACT.search(t) or len(t.split()) <= 4 else ("more" if kinds and kinds[-1] == "summary"
                                                                              else "summary")
        elif section == "summary":
            k = "summary" if not kinds or kinds[-1] == "heading" else "more"
        elif section == "skills":
            k = "skill" if LABEL.match(t) or not kinds or kinds[-1] == "heading" else "more"
        elif DATES.search(t) and len(t.split()) <= 20 and not t.endswith("."):
            k = "role"
        elif kinds and kinds[-1] in ("bullet", "more", "summary", "text") and (
                t[:1].islower() or not re.search(r"[.!?:;]$", lines[i - 1])):
            k = "more"
        elif len(t.split()) <= 5 and not re.search(r"[.,;:]$", t) and t[:1].isupper() and kinds and \
                kinds[-1] in ("heading", "bullet", "more", "text"):
            k = "role"
        else:
            k = "text"
        kinds.append(k)
    return kinds


def label(lines, ai=True):
    if ai:
        try:
            import llm
            numbered = "\n".join(f"{i + 1}. {t}" for i, t in enumerate(lines))
            got = llm._parse(Layout, PROMPT.format(n=len(lines), lines=numbered), 40 + 6 * len(lines), SYSTEM).kinds
            if len(got) == len(lines) and got[0] in ("name", "contact") and "heading" in got:
                return _sane(lines, list(got))
        except Exception as e:
            if type(e).__name__ == "MemoryShort":
                raise
    return guess(lines)


def _sane(lines, kinds):
    names = {lines[0].lower()}
    for i, (t, k) in enumerate(zip(lines, kinds)):
        if k == "skip" and not (PAGE.match(t) or t.lower() in names or (CONTACT.search(t) and i > 0)):
            kinds[i] = "text"
        if k == "more" and i == 0:
            kinds[i] = "name"
    return kinds


def blocks(lines, kinds):
    out = []
    for t, k in zip(lines, kinds):
        if k == "skip":
            continue
        if k == "more" and out and out[-1][0] not in ("heading", "name"):
            prev = out[-1][1]
            out[-1][1] = prev + t if prev.endswith("-") and t[:1].islower() else prev + " " + t
            continue
        if k == "bullet":
            t = BULLET.sub("", t, count=1)
        out.append(["text" if k == "more" else k, t])
    return out


def shape(bl):
    import variants
    first_head = next((i for i, (k, _) in enumerate(bl) if k == "heading"), len(bl))
    head_sum = next((i for i, (k, t) in enumerate(bl) if k == "heading" and variants.SUMMARY.match(t)), None)
    if head_sum is None:
        loose = [i for i, (k, _) in enumerate(bl) if k == "summary"]
        if loose:
            at = loose[0]
            bl.insert(at, ["heading", "Summary"])
            head_sum = at
        else:
            line = next((t for k, t in bl if k == "role"), None) or next((t for k, t in bl if k == "text"), "")
            bl[first_head:first_head] = [["heading", "Summary"], ["added", line]]
            return bl, True
    i = head_sum + 1
    while i < len(bl) and bl[i][0] != "heading":
        if bl[i][0] in ("text", "summary"):
            bl[i][0] = "summary"
        i += 1
    part = [j for j in range(head_sum + 1, i) if bl[j][0] == "summary"]
    if len(part) > 3:
        bl[part[0]][1] = " ".join(bl[j][1] for j in part)
        for j in reversed(part[1:]):
            del bl[j]
    return bl, False


def _r(text, b=False, sz=None, color=None, caps=False):
    props = "".join([f'<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/>', "<w:b/>" if b else "",
                     "<w:caps/>" if caps else "", f'<w:color w:val="{color}"/>' if color else "",
                     f'<w:sz w:val="{sz}"/><w:szCs w:val="{sz}"/>' if sz else ""])
    return f'<w:r><w:rPr>{props}</w:rPr><w:t xml:space="preserve">{html.escape(text, quote=False)}</w:t></w:r>'


def _p(runs, before=0, after=60, extra="", style=""):
    st = f'<w:pStyle w:val="{style}"/>' if style else ""
    return f'<w:p><w:pPr>{st}<w:spacing w:before="{before}" w:after="{after}"/>{extra}</w:pPr>{runs}</w:p>'


def paragraph(k, t):
    if k == "name":
        return _p(_r(t, b=True, sz=36, color=INK), after=40)
    if k == "contact":
        return _p(_r(t, sz=19, color=MUTED), after=0)
    if k == "heading":
        line = f'<w:pBdr><w:bottom w:val="single" w:sz="6" w:space="1" w:color="{ACCENT}"/></w:pBdr>'
        return _p(_r(t, b=True, sz=22, color=ACCENT, caps=True), before=200, after=80, extra=line)
    if k in ("summary", "added"):
        return _p(_r(t, sz=20), after=80, style="AddedSummary" if k == "added" else "")
    if k == "skill":
        m = LABEL.match(t)
        if m:
            lab, rest = t.split(":", 1)
            return _p(_r(lab.strip() + ":", b=True, sz=20) + _r(" " + rest.strip(), sz=20), after=40)
        return _p(_r(t, sz=20), after=40)
    if k == "role":
        return _p(_r(t, b=True, sz=20), before=120, after=40)
    if k == "bullet":
        ind = '<w:tabs><w:tab w:val="left" w:pos="360"/></w:tabs><w:ind w:left="360" w:hanging="220"/>'
        return _p(_r("•", sz=20) + "<w:r><w:tab/></w:r>" + _r(t, sz=20), after=30, extra=ind)
    return _p(_r(t, sz=20), after=60)


STYLES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:docDefaults><w:rPrDefault><w:rPr>
<w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri" w:eastAsia="Calibri"/><w:sz w:val="20"/><w:szCs w:val="20"/>
<w:lang w:val="en-US"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="60" w:line="252" w:lineRule="auto"/>
</w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/>
</w:style><w:style w:type="paragraph" w:styleId="AddedSummary"><w:name w:val="Summary"/><w:basedOn w:val="Normal"/>
</w:style></w:styles>"""

TYPES = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels"
ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/word/document.xml"
ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override
PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>"""

RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1"
Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>"""

DOC_RELS = """<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1"
Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>"""


def write(bl, out, letter=True):
    w, h = (12240, 15840) if letter else (11906, 16838)
    body = "".join(paragraph(k, t) for k, t in bl)
    doc = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
           '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' + body +
           f'<w:sectPr><w:pgSz w:w="{w}" w:h="{h}"/><w:pgMar w:top="900" w:right="1000" w:bottom="900" w:left="1000"'
           ' w:header="500" w:footer="500" w:gutter="0"/></w:sectPr></w:body></w:document>')
    out = Path(out)
    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = out.with_suffix(".tmp")
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", TYPES)
        z.writestr("_rels/.rels", RELS)
        z.writestr("word/_rels/document.xml.rels", DOC_RELS)
        z.writestr("word/styles.xml", STYLES)
        z.writestr("word/document.xml", doc)
    tmp.replace(out)
    return out


def rebuild(src, out, ai=True, letter=True):
    import variants
    lines = lines_of(src)
    if len(lines) < 5:
        raise ValueError("almost no text could be read from this resume")
    bl, added = shape(blocks(lines, label(lines, ai)))
    write(bl, out, letter)
    if variants.structure(out) is None:
        bl, added = shape(blocks(lines, guess(lines)))
        write(bl, out, letter)
        if variants.structure(out) is None:
            raise ValueError("the resume's summary could not be found for its versions")
    return Path(out)
