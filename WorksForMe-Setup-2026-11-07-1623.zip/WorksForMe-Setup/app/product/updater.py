import hashlib
import http.client
import json
import os
import re
import shutil
import socket
import subprocess
import sys
import time
import urllib.error
import urllib.request
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
APP = HERE.parent
ROOT = APP.parent
sys.path.insert(0, str(APP))

WORK = APP / "runs" / "update"
LOG = WORK / "update.log"
NW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
STALE = 3 * 3600
FEED = "https://updates.worksformehq.com/manifest.json"


def log(msg):
    WORK.mkdir(parents=True, exist_ok=True)
    import datetime as dt
    with LOG.open("a", encoding="utf-8") as f:
        f.write(f"{dt.datetime.now():%Y-%m-%d %H:%M:%S} {msg}\n")


def _settings(app=None):
    try:
        text = (Path(app or APP) / "settings.json").read_text(encoding="utf-8-sig")
    except OSError:
        return {}, None
    try:
        s = json.loads(text)
        return (s if isinstance(s, dict) else {}), None
    except ValueError:
        flat = {}
        for k, v in re.findall(r'"([\w.-]+)"\s*:\s*("(?:[^"\\]|\\.)*"|true|false|-?\d+)', text):
            try:
                flat.setdefault(k, json.loads(v))
            except ValueError:
                pass
        return None, flat


def setting(key, default=None, app=None):
    s, flat = _settings(app)
    if flat is not None:
        return flat.get(key.rsplit(".", 1)[-1], default)
    for part in key.split("."):
        if not isinstance(s, dict) or part not in s:
            return default
        s = s[part]
    return s


def current():
    p = APP / "VERSION.txt"
    try:
        return p.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return ""


def feed():
    return setting("update_url") or (FEED if installed() else "")


def manifest():
    url = feed()
    if not url:
        return None
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "updater"}), timeout=30) as f:
        m = json.loads(f.read().decode("utf-8"))
    if not isinstance(m, dict):
        raise ValueError("the update feed is not a manifest")
    return m


def state():
    try:
        s = json.loads((WORK / "state.json").read_text(encoding="utf-8"))
        return s if isinstance(s, dict) else {}
    except (OSError, ValueError):
        return {}


def set_state(**kw):
    s = state()
    s.update(kw)
    try:
        WORK.mkdir(parents=True, exist_ok=True)
        tmp = WORK / "state.json.tmp"
        tmp.write_text(json.dumps(s, indent=1), encoding="utf-8")
        tmp.replace(WORK / "state.json")
    except OSError as e:
        log(f"could not save the update state: {e}")


_STAMP = re.compile(r"(\d{4}-\d{2}-\d{2}) (\d{4})\b")


def newer(latest, cur=None):
    cur = current() if cur is None else cur
    latest = str(latest) if latest else ""
    if not latest or latest == cur or latest in (state().get("failed") or []):
        return False
    a, b = _STAMP.search(latest), _STAMP.search(cur or "")
    return a.groups() > b.groups() if a and b else True


def check():
    cur = current()
    if not feed():
        return {"configured": False, "current": cur}
    try:
        m = manifest()
    except Exception as e:
        if not setting("update_url"):
            return {"current": cur, "quiet": True}
        return {"error": f"{type(e).__name__}: {e}", "current": cur}
    latest = m.get("version")
    return {"current": cur, "latest": latest, "newer": newer(latest, cur),
            "failed": latest in (state().get("failed") or []), "notes": m.get("notes", "")}


def _run_lock(app=None):
    try:
        port = int(setting("ports.lock", 9446, app))
    except (TypeError, ValueError):
        port = 9446
    s = socket.socket()
    try:
        s.bind(("127.0.0.1", port))
        return s
    except OSError:
        s.close()
        return None


def run_in_progress(app=None):
    s = _run_lock(app)
    if s:
        s.close()
    return s is None


def _defer():
    set_state(last_check=None)
    return "deferred: a run is in progress"


def _sha(p):
    h = hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest().lower()


def _retry(e):
    if isinstance(e, urllib.error.HTTPError):
        return e.code in (408, 429) or e.code >= 500
    r = e.reason if isinstance(e, urllib.error.URLError) else e
    return isinstance(r, (OSError, http.client.HTTPException)) and not isinstance(r, (FileNotFoundError, PermissionError))


def _touch_lock():
    try:
        os.utime(WORK / "updating.lock")
    except OSError:
        pass


def _download(url, dest, sha256, size=None):
    want = (sha256 or "").lower()
    if dest.exists():
        if _sha(dest) == want:
            return
        dest.unlink()
    part = dest.with_suffix(".part")
    try:
        total = int(size) if size else None
    except (TypeError, ValueError):
        total = None
    done, last, touched = False, "", 0.0
    for attempt in range(10):
        have = part.stat().st_size if part.exists() else 0
        if total is not None and have >= total:
            done = True
            break
        req = urllib.request.Request(url, headers={"Range": f"bytes={have}-", "User-Agent": "updater"})
        got = 0
        try:
            with urllib.request.urlopen(req, timeout=60) as r:
                cr = re.match(r"bytes (\d+)-\d+/(\d+)", r.headers.get("Content-Range") or "")
                resume = r.status == 206 and (int(cr.group(1)) if cr else have) == have
                n = r.headers.get("Content-Length") or ""
                if total is None and cr:
                    total = int(cr.group(2))
                elif total is None and n.isdigit():
                    total = int(n) + (have if resume else 0)
                with part.open("ab" if resume else "wb") as f:
                    while chunk := r.read(1 << 20):
                        f.write(chunk)
                        got += len(chunk)
                        if time.time() - touched > 30:
                            touched = time.time()
                            _touch_lock()
        except (OSError, http.client.HTTPException) as e:
            if isinstance(e, urllib.error.HTTPError) and e.code == 416:
                done = True
                break
            last = f"{type(e).__name__}: {e}"
            log(f"download try {attempt + 1}: {last}")
            if not _retry(e):
                break
            time.sleep(min(30, 2 * (attempt + 1)))
            continue
        have = part.stat().st_size if part.exists() else 0
        if total is None or have >= total:
            done = True
            break
        if not got:
            break
        log(f"download cut short at {have} of {total} bytes - resuming")
    have = part.stat().st_size if part.exists() else 0
    if total is not None:
        done = have >= total
    if not done:
        raise ValueError(f"download incomplete ({have} of {total or '?'} bytes{'; ' + last if last else ''}) - kept, "
                         "it resumes at the next check; nothing installed")
    if _sha(part) != want:
        part.unlink(missing_ok=True)
        raise ValueError("checksum mismatch - the download is not the published file; nothing installed")
    part.replace(dest)


def _tidy(keep=()):
    for f in list(WORK.glob("new*.zip")) + list(WORK.glob("new*.part")):
        if f.name not in keep:
            f.unlink(missing_ok=True)


def _extract(zip_path, out):
    if out.exists():
        shutil.rmtree(out)
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(out)
    return min(out.rglob("install.ps1"), key=lambda p: len(p.parts)).parent


def _install(pkg, root):
    try:
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(pkg / "install.ps1"),
                            "-Dest", str(root), "-Quiet"], capture_output=True, text=True, errors="replace",
                           timeout=1800, creationflags=NW)
    except (subprocess.TimeoutExpired, OSError) as e:
        log(f"installer did not finish: {type(e).__name__}: {e}")
        return -1
    log(f"installer exit {r.returncode}: {(r.stdout + r.stderr)[-600:]}")
    return r.returncode


def _smoke(root):
    try:
        r = subprocess.run([str(root / "runtime" / "python.exe"), "-E", "-s", "-c",
                            "import sys; sys.path[:0] = ['.', 'product']; import config, llm, jobapply, gmail, app, settings_api, wizard"],
                           cwd=str(root / "app"), capture_output=True, text=True, errors="replace", timeout=300,
                           creationflags=NW)
    except (subprocess.TimeoutExpired, OSError) as e:
        return False, f"{type(e).__name__}: {e}"
    return r.returncode == 0, (r.stderr or "")[-500:]


def installed():
    return all((ROOT / p).exists() for p in ("runtime/python.exe", "NAME.txt", "install.ps1")) and (APP / "VERSION.txt").exists()


def apply():
    if not installed():
        return "not an install - nothing to update"
    m = manifest()
    if not m or not newer(m.get("version")):
        if m and m.get("version") in (state().get("failed") or []):
            return f"{m['version']} failed here before (rolled back) - waiting for the next release"
        return "up to date"
    if run_in_progress():
        log(f"update to {m['version']} deferred: a run is in progress")
        return _defer()
    WORK.mkdir(parents=True, exist_ok=True)
    lock = WORK / "updating.lock"
    if lock.exists() and time.time() - lock.stat().st_mtime < STALE:
        return "an update is already running"
    lock.write_text(m["version"], encoding="utf-8")
    sha = (m.get("sha256") or "").lower()
    new = WORK / f"new-{re.sub(r'[^0-9a-f]', '', sha)[:12] or 'nosum'}.zip"
    _tidy(keep={new.name, new.with_suffix(".part").name})
    log(f"updating {current()} -> {m['version']}")
    set_state(pending={"version": m["version"], "notes": str(m.get("notes") or "")[:200]})
    _download(m["url"], new, sha, m.get("size"))
    if run_in_progress():
        lock.unlink(missing_ok=True)
        log(f"update to {m['version']} deferred: a run is in progress")
        return _defer()
    pkg = _extract(new, WORK / "pkg")
    if _signed(pkg) is False:
        _mark_failed(m["version"])
        lock.unlink(missing_ok=True)
        log(f"refused {m['version']} from the feed: not signed by us")
        return f"refused {m['version']}: not signed by us"
    pkg = _assemble(pkg)
    _spawn([str(pkg / "runtime" / "python.exe"), "-E", "-s", str(pkg / "app" / "product" / "updater.py"), "--finish",
            str(ROOT), m["version"], str(new)], pkg / "app")
    return f"installing {m['version']}"


def _spawn(cmd, cwd):
    flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
    kw = dict(cwd=str(cwd), stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True)
    try:
        subprocess.Popen(cmd, creationflags=flags | 0x01000000, **kw)
    except OSError:
        subprocess.Popen(cmd, creationflags=flags, **kw)


def _snapshot(root, pkg):
    snap = WORK / "snap"
    shutil.rmtree(snap, ignore_errors=True)
    (snap / "app").mkdir(parents=True, exist_ok=True)
    for part in ("runtime", "engine"):
        if (root / part).is_dir():
            shutil.copytree(root / part, snap / part, dirs_exist_ok=True)
    for p in (root / "app").iterdir():
        if p.name != "runs":
            if p.is_dir():
                shutil.copytree(p, snap / "app" / p.name, dirs_exist_ok=True)
            else:
                shutil.copy2(p, snap / "app" / p.name)
    for f in ("install.ps1", "uninstall.ps1", "NAME.txt"):
        src = root / f if (root / f).exists() else pkg / f
        if src.exists():
            shutil.copy2(src, snap / f)
    return snap


def _rollback(root, src):
    try:
        if src.suffix == ".zip":
            src = _extract(src, WORK / "prev")
        code = _install(src, root)
        return _smoke(root) if code == 0 else (False, f"installer exit {code}")
    except Exception as e:
        return False, f"{type(e).__name__}: {e}"


def _mark_failed(version):
    set_state(failed=[v for v in (state().get("failed") or []) if v != version][-19:] + [version])


def _replace(pkg, root, version, zp):
    prev = WORK / "previous.zip"
    if prev.exists() and not zipfile.is_zipfile(prev):
        prev.unlink()
    snap = None
    if not prev.exists():
        try:
            snap = _snapshot(root, pkg)
        except Exception as e:
            shutil.rmtree(WORK / "snap", ignore_errors=True)
            return (f"update to {version} not installed: no copy of the installed program to roll back to could be "
                    f"made ({type(e).__name__}: {e})")
    try:
        code = _install(pkg, root)
        ok, err = _smoke(root) if code == 0 else (False, f"installer exit {code}")
    except Exception as e:
        ok, err = False, f"{type(e).__name__}: {e}"
    if ok:
        try:
            if zp.exists():
                zp.replace(prev)
        except OSError as e:
            log(f"could not keep the package for the next rollback: {e}")
        _tidy()
        for d in (WORK / "snap", WORK / "prev"):
            shutil.rmtree(d, ignore_errors=True)
        return f"updated to {version}"
    log(f"new version failed ({err}) - rolling back to {'the previous package' if snap is None else 'the copy of the installed program'}")
    _mark_failed(version)
    back, why = _rollback(root, snap or prev)
    _tidy()
    if back:
        if snap:
            shutil.rmtree(snap, ignore_errors=True)
        return f"update to {version} failed - rolled back to the previous version"
    return (f"update to {version} failed and the rollback failed too ({why}) - not rolled back: reinstall with "
            f"Install.cmd" + (f" (the old program is kept in {snap})" if snap else ""))


def _start_tray(root):
    pyw, tray = root / "runtime" / "pythonw.exe", root / "app" / "product" / "tray.pyw"
    try:
        if pyw.exists() and tray.exists():
            _spawn([str(pyw), "-E", "-s", str(tray)], root / "app")
    except Exception as e:
        log(f"could not start the tray: {type(e).__name__}: {e}")


def finish(root, version, zp=None):
    global WORK, LOG
    root = Path(root)
    WORK = root / "app" / "runs" / "update"
    LOG = WORK / "update.log"
    lock = _run_lock(root / "app")
    msg = f"update to {version} failed while installing"
    try:
        if lock is None:
            msg = f"update to {version} {_defer()} - nothing installed"
        else:
            msg = _replace(Path(__file__).resolve().parents[2], root, version, Path(zp) if zp else WORK / "new.zip")
    except Exception as e:
        msg = f"update failed while installing: {type(e).__name__}: {e}"
    finally:
        if lock:
            lock.close()
        (WORK / "updating.lock").unlink(missing_ok=True)
        _record(version, msg)
        _start_tray(root)
    log(msg)
    return msg


def _record(version, msg):
    if "deferred" in msg:
        return
    pending = state().get("pending") or {}
    set_state(result={"kind": "updated" if msg.startswith("updated to") else "failed", "version": version,
                      "notes": pending.get("notes", "") if pending.get("version") == version else "",
                      "shown": False}, pending=None)


def take_result():
    r = state().get("result")
    if not isinstance(r, dict) or r.get("shown"):
        return None
    set_state(result=dict(r, shown=True))
    return r


def report_failure(version):
    try:
        r = subprocess.run([str(ROOT / "runtime" / "python.exe"), "-E", "-s", str(HERE / "support.py"), "--update-failed",
                            version], cwd=str(APP), capture_output=True, text=True, errors="replace", timeout=180,
                           creationflags=NW)
        return r.stdout.strip().startswith("filed")
    except (subprocess.TimeoutExpired, OSError) as e:
        log(f"could not file the failed update: {type(e).__name__}: {e}")
        return False


def _signed(pkg):
    key = HERE / "release_key.txt"
    if not key.exists():
        return None
    sys.path.insert(0, str(HERE))
    import sign
    return sign.verify_package(pkg, bytes.fromhex(key.read_text(encoding="utf-8").strip()))


def _assemble(pkg):
    if (pkg / "runtime" / "python.exe").exists() or not (pkg / "setup.ps1").exists():
        return pkg
    out = WORK / "assembled"
    r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", str(pkg / "setup.ps1"), "-Assemble",
                        "-Pkg", str(out), "-Reuse", str(ROOT)], capture_output=True, text=True, errors="replace",
                       timeout=3600, creationflags=subprocess.CREATE_NO_WINDOW)
    log(f"assemble exit {r.returncode}: {(r.stdout + r.stderr)[-400:]}")
    if r.returncode or not (out / "runtime" / "python.exe").exists():
        raise RuntimeError("could not put the update together (downloads?) - it is tried again next time")
    return out


def apply_detached():
    py = ROOT / "runtime" / "python.exe"
    _spawn([str(py if py.exists() else sys.executable), "-E", "-s", str(Path(__file__)), "--apply"], APP)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if "--finish" in sys.argv:
        a = sys.argv[sys.argv.index("--finish") + 1:]
        try:
            print(finish(a[0], a[1], a[2] if len(a) > 2 else None))
        except Exception as e:
            WORK = Path(a[0]) / "app" / "runs" / "update"
            LOG = WORK / "update.log"
            log(f"update failed while installing: {type(e).__name__}: {e}")
    elif "--apply" in sys.argv:
        try:
            print(apply())
        except Exception as e:
            log(f"update failed: {type(e).__name__}: {e}")
            (WORK / "updating.lock").unlink(missing_ok=True)
            print(f"update failed: {e}")
    else:
        print(json.dumps(check(), indent=1))
