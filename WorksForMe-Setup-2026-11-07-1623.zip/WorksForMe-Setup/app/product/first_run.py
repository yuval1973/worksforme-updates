import json
import os
import shutil
import sys
from pathlib import Path

PORTS = {"ui": 9460, "model": 9461, "chrome": 9464, "agent": 9465, "lock": 9466}
CHROME = [r"C:\Program Files\Google\Chrome\Application\chrome.exe",
          r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
          str(Path.home() / r"AppData\Local\Google\Chrome\Application\chrome.exe"),
          r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
          r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"]


def main(dest, name):
    dest = Path(dest)
    app = dest / "app"
    made = []
    for f in (app / "templates" / "first-run").iterdir():
        if not (app / f.name).exists():
            shutil.copy2(f, app / f.name)
            made.append(f.name)
    s_path = app / "settings.json"
    if not s_path.exists():
        s = json.loads((app / "templates" / "settings.template.json").read_text(encoding="utf-8-sig"))
        s.update({
            "app_name": name, "ledger_file": f"{name}.xlsx", "vault_prefix": f"{name}.app/",
            "browser_home": f"%LOCALAPPDATA%\\{name}\\browser", "ports": PORTS,
            "chrome_exe": next((c for c in CHROME if Path(c).exists()), CHROME[0]),
            "engine": {"bin": str(dest / "engine"), "models": os.environ.get("JOBBOT_MODELS_DIR") or str(dest / "models"),
                       "context": 16384},
            "ai_provider": "openai", "ai_base_url": f"http://127.0.0.1:{PORTS['model']}/v1", "ai_model": "",
            "daily_email": "all", "support_reports": False,
            "edition": "product",
            "fit_examples": True,
            "excel_ledger": False,
        })
        s_path.write_text(json.dumps(s, indent=1, ensure_ascii=False), encoding="utf-8")
        made.append("settings.json")
    for d in ("models", "profile"):
        (dest / d).mkdir(exist_ok=True)
    (app / "runs").mkdir(exist_ok=True)
    print("first run:", ", ".join(made) if made else "nothing to create (an update - the user's data kept)")


if __name__ == "__main__":
    main(sys.argv[1], sys.argv[2] if len(sys.argv) > 2 else "WorksForMe")
