import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import urllib.request
import zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ENGINE = HERE.parent
sys.path[:0] = [str(ENGINE), str(HERE)]
NW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
PE = (".exe", ".dll", ".pyd")
TIMESTAMP = {"certum": "http://time.certum.pl", "azure": "http://timestamp.acs.microsoft.com"}
TEST_SUBJECT = "CN=WorksForMe test signing (not trusted)"
AZ_CLI = Path(os.environ.get("ProgramFiles", r"C:\Program Files")) / "Microsoft SDKs" / "Azure" / "CLI2" / "wbin"


def _az_env(how):
    env = dict(os.environ)
    where = Path(how.get("azure_cli") or AZ_CLI)
    if not shutil.which("az", path=env.get("PATH", "")) and (where / "az.cmd").exists():
        env["PATH"] = str(where) + os.pathsep + env.get("PATH", "")
    return env


def method():
    m = os.environ.get("WFM_SIGNING")
    if m:
        return {"method": m}
    try:
        import config
        s = config.setting("signing")
    except Exception:
        s = None
    return s if isinstance(s, dict) and s.get("method") else None


def _ps(script, timeout=600):
    r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", script],
                       capture_output=True, text=True, timeout=timeout, creationflags=NW)
    return r.returncode, (r.stdout + r.stderr).strip()


def _listfile(files):
    fd, name = tempfile.mkstemp(suffix=".txt")
    os.close(fd)
    Path(name).write_text("\n".join(files), encoding="utf-8")
    return Path(name)


def signatures(files):
    files = [str(f) for f in files]
    if not files:
        return {}
    lst = _listfile(files)
    try:
        code, out = _ps(f"Get-Content -LiteralPath '{lst}' -Encoding UTF8 | ForEach-Object {{ "
                        "(Get-AuthenticodeSignature -LiteralPath $_).Status.ToString() + '|' + $_ }")
    finally:
        lst.unlink(missing_ok=True)
    return {p: s for s, _, p in (line.partition("|") for line in out.splitlines() if "|" in line)}


def sign(files, how=None):
    how = how or method()
    files = [str(f) for f in files]
    if not how or not files:
        return 0
    m = how["method"]
    lst = _listfile(files)
    try:
        if m in ("test", "certum"):
            if m == "test":
                pick = (f"$c = Get-ChildItem Cert:\\CurrentUser\\My -CodeSigningCert | Where-Object Subject -eq '{TEST_SUBJECT}' "
                        "| Select-Object -First 1; if (-not $c) { $c = New-SelfSignedCertificate -Type CodeSigningCert "
                        f"-Subject '{TEST_SUBJECT}' -CertStoreLocation Cert:\\CurrentUser\\My -KeyAlgorithm RSA "
                        "-KeyLength 3072 -NotAfter (Get-Date).AddYears(3) }; $ts = @{}")
            else:
                tp = how.get("thumbprint", "")
                pick = ("$c = Get-ChildItem Cert:\\CurrentUser\\My -CodeSigningCert | Where-Object { "
                        f"'{tp}' -eq '' -or $_.Thumbprint -eq '{tp}' }} | Select-Object -First 1; "
                        "if (-not $c) { throw 'no code-signing certificate in the store - is SimplySign Desktop signed in?' }; "
                        f"$ts = @{{ TimestampServer = '{TIMESTAMP['certum']}' }}")
            code, out = _ps(pick + f"; $bad = 0; Get-Content -LiteralPath '{lst}' -Encoding UTF8 | ForEach-Object {{ "
                            "$r = Set-AuthenticodeSignature -LiteralPath $_ -Certificate $c -HashAlgorithm SHA256 @ts; "
                            "if ($r.Status -ne 'Valid' -and $r.Status -ne 'UnknownError') { $bad++; 'FAILED ' + $r.Status + ' ' + $_ } }; "
                            "'signed with ' + $c.Subject; exit $bad", timeout=3600)
        elif m == "azure":
            tool, dlib, meta = (os.path.expandvars(how.get(k) or "") for k in ("signtool", "dlib", "metadata"))
            if not (tool and dlib and meta):
                raise RuntimeError("signing 'azure' needs signtool, dlib and metadata paths in settings")
            r = subprocess.run([tool, "sign", "/v", "/fd", "SHA256", "/tr", TIMESTAMP["azure"], "/td", "SHA256",
                                "/dlib", dlib, "/dmdf", meta] + files, capture_output=True, text=True, timeout=3600,
                               creationflags=NW, env=_az_env(how))
            code, out = r.returncode, (r.stdout + r.stderr).strip()
        else:
            raise RuntimeError(f"unknown signing method {m!r}")
    finally:
        lst.unlink(missing_ok=True)
    if code:
        raise RuntimeError(f"signing failed ({m}): {out[-400:]}")
    return len(files)


def _fetch(c, cache):
    cache.mkdir(parents=True, exist_ok=True)
    f = cache / c["file"]
    if not f.exists() or hashlib.sha256(f.read_bytes()).hexdigest() != c["sha256"]:
        req = urllib.request.Request(c["url"], headers={"User-Agent": "worksforme-build"})
        with urllib.request.urlopen(req, timeout=300) as r:
            data = r.read()
        if hashlib.sha256(data).hexdigest() != c["sha256"]:
            raise RuntimeError(f"{c['file']} is not the pinned file (SHA-256 differs)")
        f.write_bytes(data)
    return f


def engine_file(name):
    return (name == "llama-server.exe" or name.endswith(".dll") or name.startswith("LICENSE")) and \
        not (name.endswith("-impl.dll") and name != "llama-server-impl.dll")


def _intact(folder):
    try:
        index = json.loads((folder / "bundle.json").read_text(encoding="utf-8"))["files"]
    except (OSError, ValueError, KeyError, TypeError):
        return False
    have = {str(f.relative_to(folder)).replace("\\", "/") for f in folder.rglob("*") if f.is_file()} - {"bundle.json"}
    return bool(index) and have == set(index) and all(
        hashlib.sha256((folder / rel).read_bytes()).hexdigest() == h for rel, h in index.items())


def make_bundle(dest, components, cache, how=None):
    how = how or method()
    dest, cache = Path(dest), Path(cache)
    if dest.exists():
        shutil.rmtree(dest)
    key = hashlib.sha256(json.dumps([components, how], sort_keys=True).encode()).hexdigest()[:16]
    kept = cache / f"signed-{key}"
    if _intact(kept):
        shutil.copytree(kept, dest)
        return 0
    n = _build_bundle(dest, components, cache, how)
    for old in cache.glob("signed-*"):
        shutil.rmtree(old, ignore_errors=True)
    shutil.copytree(dest, kept)
    return n


def _build_bundle(dest, components, cache, how):
    (dest / "engine").mkdir(parents=True)
    with zipfile.ZipFile(_fetch(components["engine"], cache)) as z:
        for e in z.infolist():
            name = e.filename.replace("\\", "/").rsplit("/", 1)[-1]
            if name and not e.is_dir() and engine_file(name):
                (dest / "engine" / name).write_bytes(z.read(e))
    for w in components["wheels"]:
        if w["file"].endswith("-none-any.whl"):
            continue
        with zipfile.ZipFile(_fetch(w, cache)) as z:
            for e in z.infolist():
                rel = e.filename
                if rel.lower().endswith(PE) and "/tests/" not in f"/{rel}" and ".data/" not in rel:
                    out = dest / "site-packages" / rel
                    out.parent.mkdir(parents=True, exist_ok=True)
                    out.write_bytes(z.read(e))
    files = [f for f in dest.rglob("*") if f.is_file() and f.suffix.lower() in PE]
    status = signatures(files)
    for f in files:
        if dest / "site-packages" in f.parents and status.get(str(f)) == "Valid":
            f.unlink()
    unsigned = [f for f in files if f.exists() and status.get(str(f)) != "Valid"]
    n = sign(unsigned, how)
    for d in sorted((p for p in (dest / "site-packages").rglob("*") if p.is_dir()), reverse=True):
        if not any(d.iterdir()):
            d.rmdir()
    index = {str(f.relative_to(dest)).replace("\\", "/"): hashlib.sha256(f.read_bytes()).hexdigest()
             for f in sorted(dest.rglob("*")) if f.is_file()}
    (dest / "bundle.json").write_text(json.dumps({"method": how["method"], "engine": components["engine"]["sha256"],
                                                  "files": index}, indent=1), encoding="utf-8")
    return n


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8")
    if sys.argv[1:2] == ["--sign"]:
        if not method():
            sys.exit("no signing method is set up")
        print(f"signed {sign(sys.argv[2:])} file(s)")
    elif sys.argv[1:2] == ["--inventory"]:
        root = Path(sys.argv[2])
        st = signatures([f for f in root.rglob("*") if f.is_file() and f.suffix.lower() in PE])
        for p, s in sorted(st.items(), key=lambda x: (x[1] == "Valid", x[0])):
            print(f"{s:10} {Path(p).relative_to(root)}")
        bare = sum(s == "NotSigned" for s in st.values())
        valid = sum(s == "Valid" for s in st.values())
        print(f"{len(st)} program files: {valid} valid, {bare} NOT signed, "
              f"{len(st) - valid - bare} signed by a certificate Windows does not trust (the test one)")
