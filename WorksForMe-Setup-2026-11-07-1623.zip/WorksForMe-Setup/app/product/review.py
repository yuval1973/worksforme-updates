import difflib
import sys
from pathlib import Path
from typing import List

from pydantic import BaseModel

HERE = Path(__file__).resolve().parent
sys.path[:0] = [str(HERE), str(HERE.parent)]
import formats

OPEN = {"identity.first_name": "first name", "identity.last_name": "last name", "identity.email": "email address",
        "report_to": "email address", "location.street_address": "street address", "location.city": "city",
        "location.county": "US county", "recruiter_reply_availability": "when the person can take calls",
        "standing_answers.referrer_name": "a person's name or N/A", "eligibility.citizenship": "citizenship",
        "eligibility.notice_period": "notice period", "company": "company name"}
CONTEXT = {"location.state_code": "state / province", "location.country_code": "country"}


class Finding(BaseModel):
    field: str
    problem: str
    suggestion: str


class Review(BaseModel):
    findings: List[Finding]


SYSTEM = """You check what a job seeker typed into their profile before it goes out on job applications. Report ONLY
clear mistakes: a misspelled word or name, a misspelled email domain (gmial.com, hotmial.com, gmail.con), a city that is
not in the given state or country, a value that is plainly the wrong kind of thing for its box, the same name typed two
different ways. Never report style preferences, abbreviations (St, Ave, Apt are fine), word order, or missing optional
details. Never translate, never add information, never guess a value you cannot see. A suggestion is the whole corrected
value for that box. No mistakes: an empty list."""


def review(values, context=None, ai=None):
    vals = {k: str(v).strip() for k, v in (values or {}).items() if (k in OPEN or k.startswith("company")) and str(v or "").strip()}
    if not vals:
        return []
    ctx = {k: v for k, v in (context or {}).items() if v}
    lines = "\n".join(f"- {k} ({OPEN.get(k, 'company name')}): {v!r}" for k, v in vals.items())
    prompt = (f"The profile: {ctx}\n\nCheck these boxes:\n{lines}\n\nThe field of each finding must be one of the keys "
              f"above, or one of {list(CONTEXT)} when that context value is the mistake.")
    try:
        if ai is None:
            import llm
            ai = lambda p: llm._parse(Review, p, 700, system=SYSTEM)
        found = ai(prompt).findings
    except Exception:
        return []
    cc = formats.countries.code_of(str(ctx.get("country") or "")) or "US"
    out = []
    for f in found:
        key, s = f.field.strip(), f.suggestion.strip()
        if key not in vals and key not in CONTEXT:
            continue
        if s and key in vals:
            tidied, problem = formats.fix("company" if key.startswith("company") else key, s, cc)
            tidied = str(tidied)
            if tidied.lower() == vals[key].lower():
                continue
            if problem or difflib.SequenceMatcher(None, tidied.lower(), vals[key].lower()).ratio() < 0.5:
                s = ""
            else:
                s = tidied
        elif s and key == "location.state_code":
            hit = formats.countries.area(cc, s)
            s = hit[0] if hit else ""
        elif s and key == "location.country_code":
            s = formats.countries.code_of(s) or ""
        out.append({"field": key, "problem": f.problem.strip()[:160], "suggestion": s})
    return out


def profile_values(a, t=None):
    ident, loc = a.get("identity") or {}, a.get("location") or {}
    el, sa = a.get("eligibility") or {}, a.get("standing_answers") or {}
    vals = {"identity.first_name": ident.get("first_name"), "identity.last_name": ident.get("last_name"),
            "identity.email": ident.get("email"), "location.street_address": loc.get("street_address"),
            "location.city": loc.get("city"), "location.county": loc.get("county"),
            "standing_answers.referrer_name": sa.get("referrer_name") if sa.get("referrer_name") != "N/A" else "",
            "eligibility.citizenship": el.get("citizenship")}
    for i, c in enumerate(((t or {}).get("top_tier") or {}).keys()):
        vals[f"company.{i}"] = c
    ctx = {"country": loc.get("country") or formats.countries.name(loc.get("country_code") or "US"),
           "state": loc.get("state"), "city": loc.get("city"), "zip": loc.get("zip"),
           "name on the resume": f"{ident.get('first_name', '')} {ident.get('last_name', '')}".strip()}
    return {k: v for k, v in vals.items() if v}, ctx
