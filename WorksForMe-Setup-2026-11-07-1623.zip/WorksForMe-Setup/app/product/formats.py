import re
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import countries

US_STATES = countries.US_STATES
EMAIL = re.compile(r"[^@\s]+@[^@\s]+\.[a-z]{2,}", re.I)
NAME = re.compile(r"[^\W\d_][\w .'-]{0,59}")
COMPANY = re.compile(r"(?=.*[^\W\d_])[\w&.,'()+/ -]{1,60}")

EXAMPLES = {
    "identity.email": "jane.smith@gmail.com",
    "identity.phone": "201-555-0123",
    "identity.linkedin": "linkedin.com/in/jane-smith",
    "location.street_address": "123 Main St, Apt 4",
    "location.city": "",
    "location.state_code": "",
    "location.zip": "",
    "location.county": "",
    "eligibility.citizenship": "US citizen",
    "eligibility.notice_period": "Two weeks",
    "compensation.floor.min_base_usd": "",
    "compensation.floor.min_total_usd": "",
    "recruiter_reply_availability": "weekdays after 2 pm",
    "standing_answers.referrer_name": "N/A",
    "report_to": "you@gmail.com",
    "great_min_mid_base": "",
    "company": "",
}
MONEY = ("compensation.floor.min_base_usd", "compensation.floor.min_total_usd", "great_min_mid_base")
LIST_ITEM = "fit_list"


def _us_plain(v):
    d = re.sub(r"\D", "", v)
    if len(d) == 11 and d[0] == "1":
        d = d[1:]
    return f"+1-{d[:3]}-{d[3:6]}-{d[6:]}" if len(d) == 10 and d[0] in "23456789" else None


def _phone(v, cc):
    try:
        return countries.phone(v, cc)["display"], None
    except ValueError as e:
        t = v.strip()
        us = cc == "US" and not t.startswith(("+", "00")) or t.startswith(("+1", "001"))
        if us and (plain := _us_plain(t)):
            return plain, None
        return v, ("a phone number with area code" if us else str(e))


def money(v):
    s = str(v).replace(",", "").replace("$", "").replace(" ", "").lower()
    if not s:
        return None
    k = s.endswith("k")
    n = float(s[:-1] if k else s)
    return int(round(n * 1000 if k else n))


def _tidy(key, v, cc="US"):
    if key in MONEY:
        return money(v)
    v = " ".join(str(v or "").split())
    if key in ("identity.email", "report_to", "support_to"):
        return v.lower()
    if key == "identity.phone":
        return _phone(v, cc)[0]
    if cc != "US" and key == "location.zip":
        return countries.check_postal(cc, v)[0]
    if cc != "US" and key == "location.state_code":
        hit = countries.area(cc, v)
        return hit[0] if hit else v
    if cc != "US" and key == "location.county":
        return ""
    if key == "identity.linkedin":
        m = re.search(r"linkedin\.com/in/([\w%.-]+)", v, re.I)
        return f"https://www.linkedin.com/in/{m.group(1)}" if m else v
    if key == "location.zip":
        d = re.sub(r"\D", "", v)
        return d if len(d) == 5 else f"{d[:5]}-{d[5:]}" if len(d) == 9 else v
    if key == "location.state_code":
        names = {n.lower(): c for c, n in US_STATES}
        return names.get(v.lower(), v.upper() if len(v) == 2 else v)
    if key == "location.county":
        return re.sub(r"\s+county$", "", v, flags=re.I)
    if key == "recruiter_reply_availability":
        v = re.sub(r"^(i'?m|i am)?\s*available\s*", "", v, flags=re.I)
        return v.rstrip(".").strip()
    if key == "standing_answers.referrer_name" and v.lower().strip(".") in ("", "na", "n/a", "none", "no", "nobody", "-"):
        return "N/A"
    if key in ("company", LIST_ITEM):
        return v.strip(" ,;")
    return v


def _problem(key, v, cc="US"):
    s = str(v or "")
    if key in ("identity.email", "report_to", "support_to"):
        return None if not s and key != "identity.email" or EMAIL.fullmatch(s) else "an email address, e.g. jane.smith@gmail.com"
    if key == "identity.phone":
        return _phone(s, cc)[1]
    if cc != "US" and key in ("location.zip", "location.state_code", "location.county"):
        r = countries.address_rules(cc)
        if key == "location.zip":
            return countries.check_postal(cc, s)[1] or (
                f"a postal code like {r['postal_example']}" if not s and r["postal_required"] and r["postal_example"] else None)
        if key == "location.state_code":
            if r["areas"] and s not in {k for k, _n in r["areas"]} and (s or r["area_required"]):
                return f"a {r['area_label'].lower()} of {r['name']}"
            return None
        return None
    if key == "identity.linkedin":
        return None if not s or re.fullmatch(r"https://www\.linkedin\.com/in/[\w%.-]+", s) \
            else "your profile address, e.g. linkedin.com/in/jane-smith"
    if key == "location.zip":
        return None if re.fullmatch(r"\d{5}(-\d{4})?", s) else "5 digits"
    if key == "location.state_code":
        return None if s in {c for c, _n in US_STATES} else "a US state"
    if key in ("identity.first_name", "identity.last_name", "location.city"):
        return None if NAME.fullmatch(s) else "letters, spaces, dots, apostrophes and dashes"
    if key == "location.county":
        return None if not s or NAME.fullmatch(s) else "the county's name"
    if key == "location.street_address":
        return None if re.search(r"[^\W\d_]{2}", s) and (re.search(r"\d", s) or len(s.split()) >= 3) \
            else "the number and street, e.g. 123 Main St, Apt 4"
    if key in MONEY:
        return None if not v or 1000 <= v <= 10_000_000 else "a yearly amount in dollars"
    if key == "recruiter_reply_availability":
        return None if not s or (re.search(r"[^\W\d_]{2}", s) and len(s) <= 120) \
            else "when you can take calls"
    if key == "standing_answers.referrer_name":
        return None if s == "N/A" or NAME.fullmatch(s) else "a name, or N/A"
    if key == "company":
        return None if COMPANY.fullmatch(s) else "a company name"
    if key == LIST_ITEM:
        return None if re.search(r"[^\W\d_]", s) and len(s) <= 80 else "a few words (80 characters at most)"
    return None


def fix(key, value, country="US"):
    cc = (country or "US").upper()
    try:
        v = _tidy(key, value, cc)
    except ValueError:
        return value, "a yearly amount in dollars"
    return v, _problem(key, v, cc)


def examples(country="US"):
    cc = (country or "US").upper()
    if cc == "US":
        return EXAMPLES
    import phonenumbers
    ex = phonenumbers.example_number_for_type(cc, phonenumbers.PhoneNumberType.MOBILE)
    r = countries.address_rules(cc)
    return {**EXAMPLES, "identity.phone": phonenumbers.format_number(ex, phonenumbers.PhoneNumberFormat.NATIONAL) if ex else "",
            "location.zip": r["postal_example"], "location.city": "", "location.street_address": "",
            "location.state_code": r["areas"][0][1] if r["areas"] else "", "location.county": ""}
