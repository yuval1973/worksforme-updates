import ctypes
import json
import sys
import threading
import time
import urllib.request
from ctypes import wintypes as wt
from http.server import ThreadingHTTPServer
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE)); sys.path.insert(0, str(HERE.parent))
import io
import os
for _name in ("stdout", "stderr"):
    if getattr(sys, _name) is None:
        setattr(sys, _name, io.TextIOWrapper(open(os.devnull, "wb"), encoding="utf-8"))
import updater

user32 = ctypes.WinDLL("user32", use_last_error=True)
shell32 = ctypes.WinDLL("shell32", use_last_error=True)
kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
LRESULT = ctypes.c_ssize_t
WNDPROC = ctypes.WINFUNCTYPE(LRESULT, wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM)
user32.DefWindowProcW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
user32.DefWindowProcW.restype = LRESULT
user32.CreateWindowExW.restype = wt.HWND
user32.LoadImageW.restype = wt.HANDLE
user32.CreatePopupMenu.restype = wt.HMENU
user32.TrackPopupMenu.argtypes = [wt.HMENU, wt.UINT, ctypes.c_int, ctypes.c_int, ctypes.c_int, wt.HWND, ctypes.c_void_p]
user32.AppendMenuW.argtypes = [wt.HMENU, wt.UINT, ctypes.c_size_t, wt.LPCWSTR]
user32.SetMenuDefaultItem.argtypes = [wt.HMENU, wt.UINT, wt.UINT]
user32.MessageBoxW.argtypes = [wt.HWND, wt.LPCWSTR, wt.LPCWSTR, wt.UINT]

WM_DESTROY, WM_COMMAND, WM_NULL, WM_APP = 0x0002, 0x0111, 0x0000, 0x8000
WM_LBUTTONDBLCLK, WM_RBUTTONUP = 0x0203, 0x0205
NIN_BALLOONUSERCLICK = 0x0405
NIM_ADD, NIM_MODIFY, NIM_DELETE = 0, 1, 2
NIF_MESSAGE, NIF_ICON, NIF_TIP, NIF_INFO = 0x1, 0x2, 0x4, 0x10
MF_STRING, MF_GRAYED, MF_CHECKED, MF_SEPARATOR = 0x0, 0x1, 0x8, 0x800
TPM_RIGHTBUTTON, TPM_RETURNCMD = 0x2, 0x100
CALLBACK = WM_APP + 1
try:
    PORT = int(updater.setting("ports.ui", 9450))
except (TypeError, ValueError):
    PORT = 9450
BASE = f"http://127.0.0.1:{PORT}"
NAME = str(updater.setting("app_name", "WorksForMe"))


class GUID(ctypes.Structure):
    _fields_ = [("a", wt.DWORD), ("b", wt.WORD), ("c", wt.WORD), ("d", ctypes.c_ubyte * 8)]


class NOTIFYICONDATAW(ctypes.Structure):
    _fields_ = [("cbSize", wt.DWORD), ("hWnd", wt.HWND), ("uID", wt.UINT), ("uFlags", wt.UINT),
                ("uCallbackMessage", wt.UINT), ("hIcon", wt.HICON), ("szTip", wt.WCHAR * 128), ("dwState", wt.DWORD),
                ("dwStateMask", wt.DWORD), ("szInfo", wt.WCHAR * 256), ("uVersion", wt.UINT),
                ("szInfoTitle", wt.WCHAR * 64), ("dwInfoFlags", wt.DWORD), ("guidItem", GUID), ("hBalloonIcon", wt.HICON)]


class WNDCLASSW(ctypes.Structure):
    _fields_ = [("style", wt.UINT), ("lpfnWndProc", WNDPROC), ("cbClsExtra", ctypes.c_int), ("cbWndExtra", ctypes.c_int),
                ("hInstance", wt.HINSTANCE), ("hIcon", wt.HICON), ("hCursor", wt.HANDLE), ("hbrBackground", wt.HBRUSH),
                ("lpszMenuName", wt.LPCWSTR), ("lpszClassName", wt.LPCWSTR)]


def api(path, post=False):
    req = urllib.request.Request(BASE + path, data=b"{}" if post else None, method="POST" if post else "GET",
                                 headers={"X-Requested-By": "app"})
    with urllib.request.urlopen(req, timeout=10) as f:
        return json.loads(f.read())


class Server(ThreadingHTTPServer):
    allow_reuse_address = False


def ensure_server():
    for _attempt in range(3):
        try:
            if api("/api/overview").get("app") == NAME:
                return True
        except Exception:
            pass
        try:
            import app
        except Exception:
            return True
        try:
            srv = Server(("127.0.0.1", PORT), app.Handler)
        except OSError:
            time.sleep(2)
            continue
        threading.Thread(target=srv.serve_forever, daemon=True).start()
        return True
    return False


QUIT_NOTE = "quit"


def until(flag):
    import datetime as dt
    try:
        d = dt.date.fromisoformat(flag.get("until") or "")
    except ValueError:
        return ""
    return f" until {d:%b} {d.day}"


def stop_runs():
    p = HERE.parent / "PAUSED"
    if not p.exists():
        import datetime as dt
        p.write_text(f"{QUIT_NOTE} - {NAME} was closed from its tray icon on {dt.datetime.now():%Y-%m-%d %H:%M}; nothing "
                     "runs until it is opened again (Start menu, or the next Windows sign-in).\n", encoding="utf-8")


def start_runs():
    p = HERE.parent / "PAUSED"
    try:
        if p.exists() and p.read_text(encoding="utf-8", errors="ignore").startswith(QUIT_NOTE + " "):
            p.unlink()
    except OSError:
        pass


def open_page(path="/"):
    import app
    app.open_window(BASE + path)


class Tray:
    ITEMS = {1: "open", 2: "run", 3: "hold", 4: "unhold", 5: "pause", 6: "resume", 7: "settings", 8: "report", 9: "quit"}

    def __init__(self):
        self.nid = NOTIFYICONDATAW()
        self.needs = None
        self.taskbar_created = None
        self._proc = WNDPROC(self.wndproc)
        hinst = kernel32.GetModuleHandleW(None)
        wc = WNDCLASSW(lpfnWndProc=self._proc, hInstance=hinst, lpszClassName=f"{NAME}Tray")
        user32.RegisterClassW(ctypes.byref(wc))
        self.hwnd = user32.CreateWindowExW(0, wc.lpszClassName, NAME, 0, 0, 0, 0, 0, None, None, hinst, None)
        self.taskbar_created = user32.RegisterWindowMessageW("TaskbarCreated")
        icon = user32.LoadImageW(None, str(HERE / "icon.ico"), 1, user32.GetSystemMetrics(49), user32.GetSystemMetrics(50), 0x10)
        self.nid.cbSize = ctypes.sizeof(NOTIFYICONDATAW)
        self.nid.hWnd, self.nid.uID, self.nid.hIcon = self.hwnd, 1, icon
        self.nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP
        self.nid.uCallbackMessage = CALLBACK
        self.nid.szTip = NAME
        shell32.Shell_NotifyIconW(NIM_ADD, ctypes.byref(self.nid))
        threading.Thread(target=self.poll, daemon=True).start()
        threading.Thread(target=self.updates, daemon=True).start()

    def notify(self, title, text, path="/"):
        self.click_path = path
        self.nid.uFlags = NIF_INFO
        self.nid.szInfoTitle, self.nid.szInfo, self.nid.dwInfoFlags = title[:63], text[:255], 0x1
        shell32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(self.nid))
        self.nid.uFlags = NIF_MESSAGE | NIF_ICON | NIF_TIP

    def update_note(self, r):
        if r.get("kind") == "updated":
            try:
                import app
                fixed = app.after_update()
            except Exception:
                fixed = None
            if fixed:
                self.notify(NAME, fixed[0], fixed[1])
                return
            notes = " ".join(str(r.get("notes") or "").split())
            self.notify(NAME, f"{NAME} was updated." + (f" What's new: {notes}" if notes else ""))
        else:
            filed = updater.report_failure(r.get("version") or "")
            self.notify(NAME, "The update couldn't be installed. " + ("Our support is on it." if filed
                                                                        else f"{NAME} will try again later."))

    def remind_due(self):
        import datetime as dt
        now = dt.datetime.now()
        mode = str(updater.setting("daily_email", True)).lower()
        if mode in ("true", "all") or now.hour < 9 or getattr(self, "reminded", None) == now.date():
            return False
        self.reminded = now.date()
        return True

    def poll(self):
        last_run = None
        while True:
            try:
                o = api("/api/overview")
                n = o["counts"].get("needs", 0)
                state = (f"paused{until(o['paused'])}" if o["paused"]["on"] else
                         f"applying on hold{until(o['hold'])}" if o["hold"]["on"] else "on")
                tip = f"{NAME} - {state}\nLast run {o.get('last_run') or 'never'}\n{n} need{'s' if n == 1 else ''} you"
                self.nid.szTip = tip[:127]
                shell32.Shell_NotifyIconW(NIM_MODIFY, ctypes.byref(self.nid))
                done = last_run is not None and o.get("last_run") and o.get("last_run") != last_run and not o.get("running")
                if done and (o.get("applied_today") or n):
                    a = o.get("applied_today") or 0
                    self.notify(f"{NAME} - today's run", f"{a} applied, {n} need{'s' if n == 1 else ''} you."
                                + (" Click to see what needs you." if n else " Click to open."), "/?tab=needs" if n else "/?tab=applied")
                elif self.needs is not None and n > self.needs:
                    self.notify(NAME, f"{n - self.needs} new item{'s' if n - self.needs > 1 else ''} need you. Click to open.",
                                "/?tab=needs")
                elif n and self.remind_due():
                    self.notify(NAME, f"{n} job{'s' if n > 1 else ''} still need{'s' if n == 1 else ''} you. Click to open.",
                                "/?tab=needs")
                if not o.get("running"):
                    last_run = o.get("last_run") or ""
                self.needs = n
            except Exception:
                pass
            time.sleep(120)

    def updates(self):
        import datetime as dt
        while True:
            try:
                r = updater.take_result()
                if r:
                    self.update_note(r)
            except Exception:
                pass
            try:
                at = dt.time(*map(int, str(updater.setting("update_check_at", "05:30")).split(":")))
                now = dt.datetime.now()
                today = now.date().isoformat()
                if updater.feed() and updater.setting("auto_update", True) and now.time() >= at \
                        and updater.state().get("last_check") != today and not updater.run_in_progress():
                    updater.set_state(last_check=today)
                    st = updater.check()
                    if st.get("newer"):
                        self.notify(NAME, "Installing an update - back in a minute.")
                        updater.apply_detached()
            except Exception:
                pass
            try:
                if now.time() >= at and not updater.run_in_progress():
                    import model_update
                    model_update.tick(self.notify, updater.setting)
            except Exception:
                pass
            time.sleep(300)

    def menu(self):
        try:
            o = api("/api/overview")
        except Exception:
            o = {"hold": {"on": False}, "paused": {"on": False}, "running": False}
        m = user32.CreatePopupMenu()
        add = lambda i, text, grey=False, tick=False: user32.AppendMenuW(
            m, MF_STRING | (MF_GRAYED if grey else 0) | (MF_CHECKED if tick else 0), i, text)
        sep = lambda: user32.AppendMenuW(m, MF_SEPARATOR, 0, None)
        add(1, "Open dashboard")
        user32.SetMenuDefaultItem(m, 1, False)
        add(2, "Running now..." if o.get("running") else "Run now", grey=bool(o.get("running")))
        sep()
        add(4, "Take applying off hold") if o["hold"]["on"] else add(3, "Put applying on hold")
        add(6, "Switch the daily run back on") if o["paused"]["on"] else add(5, "Pause the daily run")
        sep()
        add(7, "Settings")
        if o.get("support"):
            add(8, "Report a problem")
        sep()
        add(9, "Exit")
        pt = wt.POINT()
        user32.GetCursorPos(ctypes.byref(pt))
        user32.SetForegroundWindow(self.hwnd)
        cmd = user32.TrackPopupMenu(m, TPM_RIGHTBUTTON | TPM_RETURNCMD, pt.x, pt.y, 0, self.hwnd, None)
        user32.PostMessageW(self.hwnd, WM_NULL, 0, 0)
        user32.DestroyMenu(m)
        self.do(self.ITEMS.get(cmd))

    def do(self, what):
        try:
            if what == "open":
                open_page("/")
            elif what == "settings":
                open_page("/settings")
            elif what == "report":
                open_page("/?report=1")
            elif what == "quit":
                ok = user32.MessageBoxW(self.hwnd, f"Exit {NAME}? The daily run won't run until you open it again.", NAME,
                                        0x1 | 0x20 | 0x10000)
                if ok != 1:
                    return
                stop_runs()
                shell32.Shell_NotifyIconW(NIM_DELETE, ctypes.byref(self.nid))
                user32.PostQuitMessage(0)
            elif what:
                r = api(f"/api/action/{what}", post=True)
                self.notify(NAME, r.get("done", ""))
        except Exception as e:
            self.notify(NAME, "Couldn't complete that. Try again.")

    def wndproc(self, hwnd, msg, wp, lp):
        if msg == CALLBACK:
            if lp == NIN_BALLOONUSERCLICK:
                open_page(getattr(self, "click_path", "/"))
            elif lp == WM_LBUTTONDBLCLK:
                self.do("open")
            elif lp == WM_RBUTTONUP:
                self.menu()
            return 0
        if msg == self.taskbar_created:
            shell32.Shell_NotifyIconW(NIM_ADD, ctypes.byref(self.nid))
            return 0
        if msg == WM_DESTROY:
            user32.PostQuitMessage(0)
            return 0
        return user32.DefWindowProcW(hwnd, msg, wp, lp)


def app_identity():
    import re
    import winreg
    import zlib
    aid = re.sub(r"[^A-Za-z0-9]", "", NAME) + f".{zlib.crc32(str(HERE).lower().encode()):08x}"
    try:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, rf"Software\Classes\AppUserModelId\{aid}") as k:
            winreg.SetValueEx(k, "DisplayName", 0, winreg.REG_SZ, NAME)
            winreg.SetValueEx(k, "IconUri", 0, winreg.REG_SZ, str(HERE / "icon.ico"))
        shell32.SetCurrentProcessExplicitAppUserModelID(ctypes.c_wchar_p(aid))
    except OSError:
        pass
    return aid


def main():
    import zlib
    kernel32.CreateMutexW(None, False, f"Local\\{NAME}Tray-{zlib.crc32(str(HERE).lower().encode()):08x}")
    if ctypes.get_last_error() == 183:
        if "--open" in sys.argv:
            open_page("/")
        return
    app_identity()
    start_runs()
    if not ensure_server():
        user32.MessageBoxW(None, f"{NAME} could not start - another program on this PC is in its way. Restarting the PC "
                                 "usually fixes it.", NAME, 0x10 | 0x10000)
        return
    if "--open" in sys.argv:
        threading.Thread(target=open_page, args=("/",), daemon=True).start()
    Tray()
    msg = wt.MSG()
    while user32.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
        user32.TranslateMessage(ctypes.byref(msg))
        user32.DispatchMessageW(ctypes.byref(msg))


if __name__ == "__main__":
    main()
