import datetime as dt
import json
import re
import socket
import sys
from pathlib import Path
from urllib.parse import urlencode

HERE = Path(__file__).resolve().parent
ENGINE = HERE.parent
sys.path.insert(0, str(ENGINE))
import config

REQUEST = ENGINE / "runs" / "alerts-request.json"
STATUS = ENGINE / "runs" / "alerts-setup.json"
US = ("103644278", "United States")
SEARCH = "https://www.linkedin.com/jobs/search-results/?"
MANAGE = "https://www.linkedin.com/jobs/jam/?alerts=true"
LEVELS = [(r"intern|graduate|new grad", r"intern"), (r"junior|jr|entry|associate|i{1,2}$", r"entry|associate"),
          (r"senior|sr|staff|principal|lead|mid|intermediate|iii|iv", r"senior|mid-senior"), (r"manager|head", r"manager"),
          (r"director", r"director"), (r"vp|vice president|chief|executive", r"executive")]
GEO_JS = """async (kw) => {
  const csrf = (document.cookie.match(/JSESSIONID="?([^";]+)/) || [])[1];
  const u = '/voyager/api/graphql?variables=(keywords:' + encodeURIComponent(kw) + ',query:(typeaheadFilterQuery:(geoSearchTypes:'
    + 'List(MARKET_AREA,COUNTRY_REGION,ADMIN_DIVISION_1,CITY))),type:GEO)&queryId=voyagerSearchDashReusableTypeahead.57a4fa1dd92d3266ed968fdbab2d7bf5';
  const r = await fetch(u, {headers: {'csrf-token': csrf, 'accept': 'application/json', 'x-restli-protocol-version': '2.0.0'}, credentials: 'include'});
  if (!r.ok) return [];
  const els = (((await r.json()).data || {}).searchDashReusableTypeaheadByType || {}).elements || [];
  return els.map(e => [((e.target || {}).geo || {}).entityUrn || e.trackingUrn || '', (e.title || {}).text || '']);
}"""
PANEL_JS = """() => {
  const h = [...document.querySelectorAll('h2')].find(e => e.innerText.trim() === 'Jobs filters');
  if (!h) return null;
  let root = h; for (let i = 0; i < 8 && root.parentElement; i++) { root = root.parentElement; if (root.querySelectorAll('h2').length > 4) break; }
  return [...root.querySelectorAll('label[for]')].map(l => {
    const inp = document.getElementById(l.htmlFor);
    let box = l; for (let i = 0; i < 4 && box && !box.innerText.trim(); i++) box = box.parentElement;
    let sec = l; while (sec && sec !== root && !sec.querySelector('h2')) sec = sec.parentElement;
    return {for: l.htmlFor, checked: !!(inp && inp.checked), text: (box ? box.innerText : '').trim().replace(/\\s+/g, ' ').slice(0, 60),
            section: sec && sec.querySelector('h2') ? sec.querySelector('h2').innerText.trim() : ''};
  });
}"""


def status(**kw):
    s = json.loads(STATUS.read_text(encoding="utf-8")) if STATUS.exists() else {}
    if kw.get("reset"):
        s = {"started": dt.datetime.now().isoformat(timespec="seconds"), "steps": []}
        kw.pop("reset")
    if "step" in kw:
        s.setdefault("steps", []).append(kw.pop("step"))
    s.update(kw)
    STATUS.parent.mkdir(parents=True, exist_ok=True)
    STATUS.write_text(json.dumps(s, indent=1), encoding="utf-8")
    return s


def norm(q):
    return " ".join(re.sub(r"[“”]", '"', q or "").lower().split())


def wanted(req):
    return [dict(key="local", label=f"Your area ({req['place']})", place=req["place"], remote=False),
            dict(key="remote", label="Remote, anywhere in the US", place=US[1], geo=US[0], remote=True)]


def level_boxes(level_words):
    out = []
    for w in level_words or []:
        for rx, box in LEVELS:
            if re.fullmatch(rf"(?:{rx})\.?", w.strip().lower()) and box not in out:
                out.append(box)
    return out


def parse_manage(text):
    i = text.find("Manage job alerts")
    if i < 0:
        return None
    lines = [l.strip() for l in text[i + len("Manage job alerts"):].splitlines() if l.strip()]
    alerts, cur = [], []
    for l in lines:
        cur.append(l)
        if l.lower().startswith("frequency:"):
            q = cur[0] if cur else ""
            place = next((x for x in cur[1:] if not re.match(r"(filters|frequency):", x, re.I)), "")
            filt = next((x.split(":", 1)[1] for x in cur if x.lower().startswith("filters:")), "")
            alerts.append(dict(query=q, place=place, filters=[f.strip() for f in re.split(r"[·,]", filt) if f.strip()],
                               frequency=l.split(":", 1)[1].strip()))
            cur = []
        elif len(cur) > 6:
            break
    return alerts


def same_place(a, w):
    shown = a["place"].lower()
    if w["remote"]:
        return shown.startswith("united states")
    return w["place"].split(",")[0].strip().lower() in shown and not shown.startswith("united states")


def judge(alerts, want, query):
    out = []
    for w in want:
        same = [a for a in alerts if norm(a["query"]) == norm(query) and same_place(a, w)]
        if w["remote"]:
            same.sort(key=lambda a: not any(f.lower() == "remote" for f in a["filters"]))
        if not same:
            out.append(dict(key=w["key"], label=w["label"], ok=False, problems=["no such alert yet"]))
            continue
        a, problems = same[0], []
        if w["remote"] and not any(f.lower() == "remote" for f in a["filters"]):
            problems.append("it has no Remote filter, so it brings every job in the US - delete it in the alert list, "
                            "then on the search tick Remote under All filters and turn the alert on again")
        if "daily" not in a["frequency"].lower():
            problems.append(f"it is sent {a['frequency'].split(' via ')[0].lower()} - set it to Daily")
        if "email" not in a["frequency"].lower():
            problems.append("it is not sent by email - turn on email")
        if not any(f.lower() == "full-time" for f in a["filters"]):
            problems.append("no Full-time filter (optional - part-time and contract jobs are skipped anyway)")
        out.append(dict(key=w["key"], label=w["label"], ok=not [p for p in problems if "optional" not in p],
                        problems=problems, alert=a))
    return out


def run(cmd):
    import jobapply
    from playwright.sync_api import sync_playwright
    req = json.loads(REQUEST.read_text(encoding="utf-8"))
    status(reset=True, state="running", cmd=cmd, query=req["query"])
    lock = socket.socket()
    try:
        lock.bind(("127.0.0.1", config.PORT_LOCK))
    except OSError:
        return status(state="error", error="The daily run is using the browser right now - try again in a few minutes.")
    keep_open = False
    try:
        jobapply.launch()
        with sync_playwright() as pw:
            b = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{jobapply.PORT}")
            ctx = b.contexts[0]
            p = ctx.pages[0] if ctx.pages else ctx.new_page()
            if not any(c["name"] == "li_at" for c in ctx.cookies("https://www.linkedin.com")):
                keep_open = True
                p.goto("https://www.linkedin.com/login", wait_until="domcontentloaded")
                return status(state="signin", error="Not signed in to LinkedIn in WorksForMe's browser. Sign in in the "
                                                    "window that opened, then press the button again.")
            want = wanted(req)

            def manage():
                p.goto(MANAGE, wait_until="domcontentloaded")
                for _ in range(10):
                    p.wait_for_timeout(1000)
                    found = parse_manage(p.locator("body").inner_text())
                    if found is not None:
                        return found
                return None

            have = manage()
            if have is None:
                keep_open = True
                return status(state="unknown", error="LinkedIn's alert list did not open - check it in the browser window "
                                                     "(Jobs > Preferences > Job alerts).")
            fix_url = None
            if cmd == "create":
                for w, r in zip(want, judge(have, want, req["query"])):
                    if r["problems"] != ["no such alert yet"]:
                        status(step=f"{w['label']}: already there")
                        continue
                    if not w.get("geo"):
                        hits = p.evaluate(GEO_JS, w["place"]) or []
                        if not hits:
                            status(step=f"{w['label']}: LinkedIn does not know the place '{w['place']}'")
                            continue
                        w["geo"], w["place_found"] = hits[0][0].rsplit(":", 1)[-1], hits[0][1]
                    q = {"keywords": req["query"], "geoId": w["geo"], "f_TPR": "r86400"}
                    if not w["remote"]:
                        q["distance"] = str(req.get("distance") or 25)
                    p.goto(SEARCH + urlencode(q), wait_until="domcontentloaded")
                    p.wait_for_timeout(6000)
                    ticked = filters(p, level_boxes(req.get("levels")), w["remote"])
                    status(step=f"{w['label']}: search opened" + (f", ticked {', '.join(ticked)}" if ticked else ""))
                    if w["remote"] and "remote" not in [t.lower() for t in ticked]:
                        fix_url = SEARCH + urlencode(q)
                        status(step=f"{w['label']}: LinkedIn did not offer the Remote box here - not turned on")
                        continue
                    status(step=f"{w['label']}: " + ("alert turned on" if switch_on(p) else "could not find the alert switch"))
                    p.wait_for_timeout(2500)
                have = manage() or []
            res = judge(have, want, req["query"])
            keep_open = not all(r["ok"] for r in res)
            if fix_url:
                p.goto(fix_url, wait_until="domcontentloaded")
                for r in res:
                    if r["key"] == "remote" and not r["ok"]:
                        r["problems"] = ["in the browser window: All filters > tick Remote, then turn on \"Get job alerts "
                                         "for this search\" (LinkedIn did not offer Remote to WorksForMe)"]
            return status(state="done", results=res, all_ok=not keep_open, checked=dt.datetime.now().isoformat(timespec="seconds"))
    except Exception as e:
        keep_open = True
        return status(state="error", error=f"{type(e).__name__}: {str(e)[:300]}")
    finally:
        lock.close()
        if not keep_open:
            jobapply.close_chrome()


def filters(p, levels, remote):
    try:
        p.locator("[role=button], button").filter(has_text=re.compile(r"^\s*All filters\s*$")).first.click(timeout=6000)
        p.wait_for_timeout(2000)
        opts = p.evaluate(PANEL_JS) or []
    except Exception:
        return []
    want = [("Experience level", rf"^(?:{b})") for b in levels] + [("Employment type", r"^full-time")] + \
        ([(None, r"^remote$")] if remote else [])
    done = []
    for sec, rx in want:
        o = next((o for o in opts if re.search(rx, o["text"], re.I) and (sec is None or o["section"] == sec)), None)
        if o and not o["checked"]:
            try:
                p.locator(f"label[for='{o['for']}']").first.click(timeout=4000)
                p.wait_for_timeout(900)
                done.append(o["text"])
            except Exception:
                pass
    p.keyboard.press("Escape")
    p.wait_for_timeout(2500)
    return done


def switch_on(p):
    head = p.get_by_text(re.compile(r"^\s*Get job alerts for this search\s*$")).first
    try:
        head.scroll_into_view_if_needed(timeout=5000)
        sw = head.locator("xpath=following::input[@role='switch'][1]")
        if not sw.is_checked():
            sid = sw.get_attribute("id")
            lab = p.locator(f"label[for='{sid}']") if sid else None
            (lab.first if lab is not None and lab.count() else sw).click(timeout=5000, force=True)
            p.wait_for_timeout(2000)
            if not sw.is_checked():
                sw.click(timeout=5000, force=True)
                p.wait_for_timeout(2000)
        return sw.is_checked()
    except Exception:
        return False


if __name__ == "__main__":
    print(json.dumps(run(sys.argv[1] if len(sys.argv) > 1 else "check"), indent=1))
