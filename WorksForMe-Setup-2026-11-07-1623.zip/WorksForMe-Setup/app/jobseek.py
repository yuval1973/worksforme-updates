import email
import json
import re
import sys
import datetime as dt
from email.header import decode_header, make_header
from email.utils import parsedate_to_datetime
from pathlib import Path

from pydantic import BaseModel

import gmail
import llm

HERE = Path(__file__).parent
CACHE = HERE / "runs" / "jobseek_cache.json"
import config
FOLDER = config.JOB_SEEK_FOLDER
WINDOW_DAYS = 30
MAX_ACTIVE = 3
RESPONSE_KINDS = {"rejection", "interview", "assessment", "recruiter"}

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


class Mail(BaseModel):
    company: str
    role: str
    kind: str


def _dec(v):
    return " ".join(str(make_header(decode_header(v or ""))).split())


def _body(msg):
    parts = []
    for p in msg.walk():
        if p.get_content_type() in ("text/plain", "text/html") and not p.get("Content-Disposition"):
            try:
                t = p.get_payload(decode=True).decode(p.get_content_charset() or "utf-8", "replace")
            except Exception:
                continue
            parts.append(re.sub(r"<[^>]+>", " ", t))
    return " ".join(" ".join(parts).split())[:2500]


def classify(frm, subject, body):
    prompt = f"""Classify this email from a job seeker's mailbox.
kind:
- confirmation: automatic "we received your application" / "thank you for applying" with no decision.
- rejection: they are not moving forward, the position was filled, "decided to pursue other candidates"
  (often polite and starting with "thank you for your interest").
- interview: invitation to interview, scheduling, confirmation of an interview, next steps with people.
- assessment: an online test, coding challenge or take-home.
- recruiter: a person (not an automated system) writing about a role or the job seeker's application.
- other: anything else (newsletters, job alerts, account notices, "complete your application" nudges).
company: the hiring company's short name ("" if not about a job). role: the job title if named.

From: {frm}
Subject: {subject}

{body}"""
    try:
        r = llm._parse(Mail, prompt, 300)
        k = r.kind.strip().lower()
        return {"company": r.company.strip(), "role": r.role.strip(),
                "kind": k if k in RESPONSE_KINDS | {"confirmation", "other"} else "other"}
    except Exception as e:
        return {"company": "", "role": "", "kind": "other", "error": str(e)[:120]}


def _load():
    try:
        return json.loads(CACHE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def sync():
    cache = _load()
    m = gmail.connect()
    try:
        sources = [(f'"{FOLDER}"', None, "jobseek")]
        for folder, query, where in sources:
            m.select(folder, readonly=True)
            q = (query or "").replace('"', '\\"')
            uids = m.uid("SEARCH", "X-GM-RAW", f'"{q} newer_than:120d"' if q else '"newer_than:120d"')[1][0].split()
            done = 0
            for u in uids:
                hdr = email.message_from_bytes(m.uid("FETCH", u, "(BODY.PEEK[HEADER.FIELDS (MESSAGE-ID FROM SUBJECT DATE)])")[1][0][1])
                mid = (hdr["Message-ID"] or f"{where}-{u.decode()}").strip()
                if mid in cache:
                    if where == "jobseek":
                        cache[mid]["where"] = "jobseek"
                    continue
                if _dec(hdr["Subject"]).startswith(("JobBot", config.APP_NAME)):
                    continue
                msg = email.message_from_bytes(m.uid("FETCH", u, "(BODY.PEEK[])")[1][0][1])
                frm, subj = _dec(msg["From"]), _dec(msg["Subject"])
                try:
                    when = parsedate_to_datetime(msg["Date"]).astimezone(dt.timezone.utc).isoformat()
                except Exception:
                    when = ""
                c = classify(frm, subj, _body(msg))
                if c.get("error"):
                    continue
                c.update(date=when, sender=frm[:80], subject=subj[:150], where=where)
                cache[mid] = c
                done += 1
                if done % 25 == 0:
                    CACHE.parent.mkdir(exist_ok=True)
                    CACHE.write_text(json.dumps(cache, indent=1, ensure_ascii=False), encoding="utf-8")
            CACHE.parent.mkdir(exist_ok=True)
            CACHE.write_text(json.dumps(cache, indent=1, ensure_ascii=False), encoding="utf-8")
    finally:
        m.logout()
    CACHE.parent.mkdir(exist_ok=True)
    CACHE.write_text(json.dumps(cache, indent=1, ensure_ascii=False), encoding="utf-8")
    return cache


def thread_key(c):
    s = re.sub(r"^((re|fw|fwd)\s*:\s*)+", "", (c.get("subject") or "").strip(), flags=re.I).lower()
    return (norm(c.get("company")), c.get("kind"), " ".join(s.split()))


def grouped(items):
    out = {}
    for c in sorted(items, key=lambda c: c.get("date", ""), reverse=True):
        k = thread_key(c)
        if k in out:
            out[k][1] += 1
        else:
            out[k] = [c, 1]
    return [tuple(v) for v in out.values()]


def norm(company):
    c = re.sub(r"[^a-z0-9 ]", " ", (company or "").lower())
    c = re.sub(r"\b(inc|corp|corporation|llc|ltd|co|company|technologies|technology|the)\b", " ", c)
    return " ".join(c.split())


def _since(days):
    return dt.datetime.now(dt.timezone.utc) - dt.timedelta(days=days)


def active_by_company(cache=None, ledger_rows=None, days=WINDOW_DAYS):
    cache = cache if cache is not None else _load()
    since = _since(days)
    conf, resp, subm = {}, {}, {}
    daily = {}

    for c in cache.values():
        if not c.get("company") or not c.get("date"):
            continue
        if dt.datetime.fromisoformat(c["date"]) < since:
            continue
        n = norm(c["company"])
        if c["kind"] == "confirmation":
            k = daily.setdefault((n, c["date"][:10]), [0, 0])
            k[0 if "linkedin" in (c.get("sender") or "").lower() else 1] += 1
        elif c["kind"] in RESPONSE_KINDS:
            resp[n] = resp.get(n, 0) + 1
    for (n, _day), (li, emp) in daily.items():
        conf[n] = conf.get(n, 0) + max(li, emp)
    latest = {}
    for r in ledger_rows or []:
        latest[r.get("url") or id(r)] = r
    for r in latest.values():
        if (r.get("status") or "").startswith(("submitted", "applied", "submit clicked")):
            try:
                ts = r.get("ts") or ""
                t = dt.datetime.fromisoformat(ts if ts[:10] == r["date"] else r["date"]).replace(tzinfo=dt.timezone.utc)
            except ValueError:
                continue
            if t >= since:
                n = norm(r["company"])
                subm[n] = subm.get(n, 0) + 1
    return {n: max(conf.get(n, 0), subm.get(n, 0))
            for n in set(conf) | set(subm) | set(resp)}


def top_tier(company):
    return {norm(k): int(v) for k, v in (config.TARGETS.get("top_tier") or {}).items()}.get(norm(company))


def max_active(company):
    return top_tier(company) or MAX_ACTIVE


def company_slots_left(company, active=None):
    active = active if active is not None else active_by_company()
    left = max_active(company) - active.get(norm(company), 0)
    import csv
    with (HERE / "applications.csv").open(encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    for name, (cap, days) in (config.TARGETS.get("employer_limits") or {}).items():
        if norm(name) == norm(company):
            left = min(left, cap - active_by_company(None, rows, days=days).get(norm(company), 0))
    month = (dt.date.today() - dt.timedelta(days=30)).isoformat()
    if any(norm(r.get("company") or "") == norm(company) and (r.get("date") or "") >= month
           and EMPLOYER_CAP.search(r.get("notes") or "") for r in rows):
        left = 0
    return left


EMPLOYER_CAP = re.compile(r"limits? (?:for|on) applications|may not apply more than|reached the maximum (?:number )?of applications", re.I)


def responses(cache=None, days=WINDOW_DAYS):
    cache = cache if cache is not None else _load()
    since = _since(days)
    return sorted((c for c in cache.values() if c["kind"] in RESPONSE_KINDS and c.get("date")
                   and dt.datetime.fromisoformat(c["date"]) >= since), key=lambda c: c["date"], reverse=True)


if __name__ == "__main__":
    import csv
    cache = sync()
    rows = list(csv.DictReader(open(HERE / "applications.csv", encoding="utf-8")))
    act = active_by_company(cache, rows)
    print(f"{len(cache)} messages classified")
    print("\nRESPONSES (30 days):")
    for c in responses(cache):
        print(f"  {c['date'][:10]} {c['kind']:10} {c['company'][:22]:22} {c.get('role', '')[:45]}")
    print("\nACTIVE APPLICATIONS PER COMPANY (limit 3 / 30 days):")
    for n, k in sorted(act.items(), key=lambda x: -x[1]):
        if k:
            print(f"  {k}  {n}{'   <- at limit' if k >= MAX_ACTIVE else ''}")
