import json
import os
import socket
import sys
from pathlib import Path

HERE = Path(__file__).parent


def _product():
    import config
    return config.setting("edition") == "product"
sys.path.insert(0, str(HERE))
os.chdir(HERE)
sys.stdout.reconfigure(encoding="utf-8", errors="replace")
OFFLINE = "--offline" in sys.argv
NO_BROWSER = "--no-browser" in sys.argv or OFFLINE
results = []


def check(name, fn):
    try:
        out = fn()
        status, msg = (out if isinstance(out, tuple) else ("PASS", out or ""))
    except Exception as e:
        status, msg = "FAIL", f"{type(e).__name__}: {str(e).splitlines()[0][:220] if str(e) else ''}"
    results.append((status, name, msg))
    print(f"{status:4}  {name:34} {msg}")


def packages():
    import anthropic, openpyxl, pydantic, pypdf, playwright
    assert sys.version_info >= (3, 11), f"Python {sys.version.split()[0]} - 3.11 or newer needed"
    return f"Python {sys.version.split()[0]}"


def need(d, dotted, where):
    node = d
    for k in dotted.split("."):
        if not isinstance(node, dict) or k not in node or node[k] in (None, "", [], {}):
            raise ValueError(f"{where}: '{dotted}' is missing or empty")
        node = node[k]
    if isinstance(node, str) and node.startswith("<"):
        raise ValueError(f"{where}: '{dotted}' still holds the template placeholder {node[:40]!r}")
    return node


PLACEHOLDER = __import__("re").compile(r"<[^<>\"\n]{2,160}>")


def placeholders(obj, path=""):
    out = []
    if isinstance(obj, dict):
        for k, v in obj.items():
            if not str(k).startswith("_"):
                out += placeholders(v, f"{path}.{k}" if path else str(k)) + ([f"key {path}.{k}"] if PLACEHOLDER.search(str(k)) else [])
    elif isinstance(obj, list):
        for i, v in enumerate(obj):
            out += placeholders(v, f"{path}[{i}]")
    elif isinstance(obj, str) and PLACEHOLDER.search(obj):
        out.append(f"{path}: {PLACEHOLDER.search(obj).group(0)}")
    return out


def no_placeholders(name):
    left = placeholders(json.loads((HERE / name).read_text(encoding="utf-8-sig")))
    if left:
        raise ValueError(f"{name} still has template placeholders: {'; '.join(left[:4])}" + (" ..." if len(left) > 4 else ""))


REQUIRED_APPLICANT = (
    "identity.first_name", "identity.last_name", "identity.email", "identity.phone", "identity.phone_digits",
    "identity.linkedin", "location.street_address", "location.city", "location.state", "location.state_code",
    "location.zip", "location.country", "eligibility.authorized_to_work_us", "eligibility.requires_sponsorship",
    "eligibility.currently_employed", "compensation.required_range_usd", "compensation.floor.min_base_usd",
    "compensation.single_number_usd", "self_identification.gender", "self_identification.race",
    "self_identification.veteran_status", "self_identification.disability_status", "most_recent_job.title",
    "most_recent_job.company", "experience", "education_on_forms", "job_filters")


def required(P):
    cc = str((P.get("location") or {}).get("country_code") or "US").upper()
    if cc == "US":
        return REQUIRED_APPLICANT
    import countries
    r = countries.address_rules(cc)
    drop = ({"location.state", "location.state_code"} if not r["area_required"] else set()) | \
           ({"location.zip"} if not r["postal_required"] else set())
    return tuple(k for k in REQUIRED_APPLICANT if k not in drop)


def applicant(P=None):
    if P is None:
        no_placeholders("applicant.json")
        P = json.loads((HERE / "applicant.json").read_text(encoding="utf-8-sig"))
    elif left := placeholders(P):
        raise ValueError(f"applicant.json still has template placeholders: {'; '.join(left[:4])}")
    for k in required(P):
        need(P, k, "applicant.json")
    import re
    num = lambda v: isinstance(v, (int, float)) and not isinstance(v, bool)
    pos = lambda v: num(v) and v > 0
    c = P["compensation"]
    rng = c["required_range_usd"]
    assert isinstance(rng, list) and len(rng) == 2 and all(pos(x) for x in rng) and rng[0] <= rng[1], \
        "compensation.required_range_usd must be [low, high] - two positive NUMBERS (no quotes), low first"
    for k in ("min_base_usd", "min_total_usd"):
        assert pos(c["floor"].get(k)), f"compensation.floor.{k} must be a positive NUMBER (no quotes)"
    assert pos(c["single_number_usd"]), "compensation.single_number_usd must be a positive NUMBER (no quotes)"
    yr = lambda v: num(v) and 1950 <= v <= 2100
    assert yr(P["most_recent_job"].get("start_year")), "most_recent_job.start_year must be a year NUMBER"
    for d in P["education_on_forms"]:
        try:
            re.compile(d["degree_match"])
        except re.error as e:
            raise ValueError(f"education_on_forms '{d['degree']}': degree_match is not a valid regex ({e})")
    for e in P["experience"]:
        for k in ("title", "company", "location", "start_month", "start_year"):
            need(e, k, f"applicant.json experience '{e.get('title', '?')}'")
        for k in ("start_month", "start_year") + (("end_month", "end_year") if e.get("end_year") is not None else ()):
            assert num(e.get(k)), f"applicant.json experience '{e['title']}': {k} must be a NUMBER (no quotes)"
        assert 1 <= e["start_month"] <= 12 and yr(e["start_year"]), f"experience '{e['title']}': start month 1-12 / a real year"
        if e.get("end_year") is not None:
            assert 1 <= e["end_month"] <= 12 and yr(e["end_year"]), f"experience '{e['title']}': end month 1-12 / a real year"
        assert "," in e["location"] or re.fullmatch(r"[A-Za-z][A-Za-z .'-]{2,40}", e["location"].strip()), \
            f"experience '{e['title']}': location must be 'City, ST' (US), 'City, Country' or a country"
    for d in P["education_on_forms"]:
        for k in ("school", "degree", "degree_match", "field_queries"):
            need(d, k, f"applicant.json education_on_forms '{d.get('degree', '?')}'")
    return f"{P['identity']['first_name']} {P['identity']['last_name']}: {len(P['experience'])} roles, " \
           f"{len(P['education_on_forms'])} degrees"


def consistency():
    import re
    import config
    from apply import degree_level, US_STATES, same_company, url_company
    P = json.loads((HERE / "applicant.json").read_text(encoding="utf-8-sig"))
    bad, warn = [], []
    ex, mr, el, loc = P["experience"], P["most_recent_job"], P["eligibility"], P["location"]
    employed = str(el.get("currently_employed", "")).lower().startswith("y")
    if employed and ex[0].get("end_year") is not None:
        bad.append("currently employed, but the newest role (experience[0]) has an end date - set end_month/end_year to null")
    if not employed and ex[0].get("end_year") is None:
        bad.append("not currently employed, but the newest role has no end date")
    if (mr.get("title"), mr.get("company")) != (ex[0].get("title"), ex[0].get("company")):
        bad.append("most_recent_job differs from experience[0] (the newest role, listed first)")
    starts = [(e.get("start_year") or 0, e.get("start_month") or 0) for e in ex]
    if starts != sorted(starts, reverse=True):
        bad.append("experience is not newest first")
    if loc.get("country_code", "US") == "US":
        if loc.get("state_code", "").upper() not in US_STATES:
            bad.append(f"location.state_code {loc.get('state_code')!r} is not a 2-letter US state code")
        elif US_STATES[loc["state_code"].upper()] != loc.get("state"):
            bad.append(f"location.state {loc.get('state')!r} is not the full name of {loc['state_code']}")
        if len(re.sub(r"\D", "", str(P["identity"].get("phone_digits", "")))) != 10:
            bad.append("identity.phone_digits must be the 10 digits of a US number")
    from apply import DEGREE_LEVELS
    for d in P["education_on_forms"]:
        lv, kd = degree_level(d["degree"]), None
        forms = [d["degree"], f"{lv}'s degree", f"{lv}'s", f"{lv} of Science", f"{lv} of Arts"] if lv else [d["degree"]]
        if not any(re.search(d["degree_match"], x, re.I) for x in forms):
            bad.append(f"education_on_forms {d['degree']!r}: degree_match matches none of {forms[:3]} - check the regex")
    unknown = [d["degree"] for d in P["education_on_forms"] if degree_level(d["degree"]) is None]
    if unknown:
        bad.append(f"degree not recognized: {unknown} - write it the usual way (B.A., B.Sc., M.A., MPP, J.D., Ph.D., ...)")
    levels = [DEGREE_LEVELS.index(degree_level(d["degree"]) or "Master") for d in P["education_on_forms"]]
    if levels != sorted(levels):
        bad.append("education_on_forms must list the lowest degree first and the highest LAST")
    es = str(el.get("earliest_start") or "")
    if es and not re.search(r"immediate|asap|right away|^now$|\d+|\b(one|two|three|four|five|six|eight|ten|twelve)\b", es, re.I):
        bad.append(f"eligibility.earliest_start {es!r}: use 'Immediately' or 'N days / weeks / months ...' (forms need a date)")
    fl = P["compensation"]["floor"]
    if fl.get("min_total_usd", 0) < fl.get("min_base_usd", 0):
        bad.append("compensation.floor.min_total_usd is below min_base_usd")
    if P["identity"].get("email", "").lower() != str(config.EMAIL).lower():
        warn.append(f"applicant email {P['identity'].get('email')} differs from settings.json email {config.EMAIL} - intended?")
    if employed:
        cur = ex[0]["company"]
        if not any(rx.search(cur) for rx, _ in config.EXCLUDED):
            bad.append(f"currently at {cur}, but no targets.json excluded_companies rule matches it - JobBot would apply there")
        else:
            slug = (re.findall(r"[a-z0-9]+", cur.lower()) or [""])[0]
            if not any(rx.search(slug) for rx, _ in config.EXCLUDED):
                bad.append(f"excluded_companies matches {cur!r} but not {slug!r}, the name in its job links - drop the \\b / "
                           f"the suffix words from the rule")
    pdfs = {}
    for c, f in P.get("resumes", {}).items():
        if c.startswith("_"):
            continue
        pdfs.setdefault(str(config.path(f)).lower(), []).append(c)
        if c not in str(f) and any(o in str(f) for o in config.CATEGORIES if o != c):
            bad.append(f"resumes: category {c!r} points to another category's PDF ({f})")
    bad += [f"resumes: {', '.join(cs)} share one PDF" for cs in pdfs.values() if len(cs) > 1]
    word = re.search(r"\\b(OR|IN|ME|OK|OH|HI|DE|LA|MA|PA|AL|ID|CO)\\b", config.TARGETS.get("local_regex", ""), re.I)
    bare = [x for x in config.TARGETS.get("local_regex", "").split("|") if re.fullmatch(r"\s*[A-Za-z]{2}\s*", x)]
    if bare:
        bad.append(f"local_regex has bare 2-letter alternatives {bare} - they match inside words ('wa' in 'software'); "
                   f"write ', WA\\b' or the full name")
    if word:
        w = word.group(1)
        warn.append(f"local_regex has \\b{w.upper()}\\b - matched case-insensitively it hits every '{w.lower()}' in a posting; "
                    f"use ', {w.upper()}\\b' or the full state name")
    if bad:
        raise ValueError("; ".join(bad))
    return ("WARN", "; ".join(warn)) if warn else "names, dates, degrees, pay, exclusions and resumes agree"


def adapters():
    import apply
    loaded = [f"{n} v{p['version']}" + (" (replaces the built-in)" if p["builtin"] else "") for n, p in apply.PLUGINS.items()]
    if apply.PLUGIN_ERRORS:
        return "WARN", f"loaded: {', '.join(loaded) or 'none'}; NOT loaded: " + " | ".join(apply.PLUGIN_ERRORS)
    return f"{len(apply.ADAPTERS)} sites" + (f" incl. plugins: {', '.join(loaded)}" if loaded else " (no plugins)")


def settings():
    no_placeholders("settings.json")
    import config
    for k in ("email", "report_to", "job_seek_folder", "master_resume", "categories_dir", "chrome_exe"):
        need(config.SETTINGS, k, "settings.json")
    return f"{config.EMAIL} -> report to {config.REPORT_TO}; ports {config.PORT_CHROME}/{config.PORT_AGENT}/{config.PORT_LOCK}"


def targets():
    no_placeholders("targets.json")
    import config
    for k in ("persona", "fit_prompt", "categories", "default_category", "local_regex", "draft_prompt"):
        need(config.TARGETS, k, "targets.json")
    for ph in ("{title}", "{company}", "{jd}"):
        assert ph in config.FIT_PROMPT, f"targets.json fit_prompt lacks the {ph} placeholder"
    for ph in ("{company}", "{question}", "{max_chars}", "{jd}"):
        assert ph in config.TARGETS["draft_prompt"], f"targets.json draft_prompt lacks the {ph} placeholder"
    assert config.DEFAULT_CATEGORY in config.CATEGORIES, "default_category is not one of the categories"
    assert config.RELOCATE_MIN_BASE > 0 and config.RELOCATE_MIN_BASE < 10 ** 9, "targets.json relocate_min_base must be a positive NUMBER"
    import re
    for name, rx in [("local_regex", config.TARGETS.get("local_regex", ""))] + \
            [("excluded_companies", e["regex"]) for e in config.TARGETS.get("excluded_companies", [])] + \
            [("title_skips", s["regex"]) for s in config.TARGETS.get("title_skips", [])]:
        try:
            re.compile(rx)
        except re.error as e:
            raise ValueError(f"targets.json {name}: not a valid regex ({e})")
    return f"{len(config.CATEGORIES)} categories, {len(config.EXCLUDED)} excluded-company rules, {len(config.TITLE_SKIPS)} title rules"


def fit_cases():
    if not (HERE / "fit_cases.json").exists():
        return "WARN", "none yet - added in the setup's 'Teach it your taste' step after the first trial run"
    n = len(json.loads((HERE / "fit_cases.json").read_text(encoding="utf-8-sig")).get("cases", {}))
    if n < 6:
        return "WARN", (f"only {n} examples of your taste - after the first run, mark 5-10 of its jobs in the setup's "
                        "'Teach it your taste' step" if _product() else
                        f"only {n} fit cases - add the user's verdicts on 10-15 real postings (SETUP step 'fit cases')")
    return f"{n} cases"


def resumes():
    import config, llm
    P = json.loads((HERE / "applicant.json").read_text(encoding="utf-8-sig"))
    assert config.MASTER_RESUME.exists(), f"master resume not found: {config.MASTER_RESUME}"
    assert len(llm.RESUME.strip()) > 500, "master resume text is (almost) empty - is it a scanned PDF?"
    missing = [c for c in config.CATEGORIES if c not in P["resumes"] or not config.path(P["resumes"][c]).exists()]
    assert not missing, f"category resume PDF missing for: {missing} (applicant.json resumes)"
    assert llm.ROUTING.strip(), f"no routing rules: {config.CATEGORIES_DIR / 'README.md'}"
    stale, differ = [], []
    master = _resume_body(config.MASTER_RESUME, P)
    for c in config.CATEGORIES:
        pdf = config.path(P["resumes"][c])
        docx = pdf.with_suffix(".docx") if pdf.with_suffix(".docx").exists() else next(iter(sorted(pdf.parent.glob("*.docx"))), None)
        if not docx:
            continue
        if pdf.stat().st_mtime < docx.stat().st_mtime - 60:
            stale.append(c)
        if master and _resume_body(docx, P) != master:
            differ.append(c)
    assert not differ, f"category resume(s) {differ}: experience / education differ from the master - only the summary, " \
                       f"core strengths and skills may be tailored"
    if stale:
        return "WARN", f"PDF older than its Word file for {stale} - rerun python make_pdf.py on it"
    return f"master {config.MASTER_RESUME.name} ({len(llm.RESUME)} chars); {len(config.CATEGORIES)} category PDFs, " \
           f"experience identical to the master"


def _resume_body(docx, P):
    import html
    import re
    import zipfile
    if str(docx).lower().endswith(".docx"):
        x = zipfile.ZipFile(docx).read("word/document.xml").decode("utf-8")
        ps = [t for t in (" ".join(html.unescape("".join(re.findall(r"<w:t[^>]*>([^<]*)</w:t>", p))).split())
                          for p in re.findall(r"<w:p[ >].*?</w:p>", x, re.S)) if t]
    else:
        return None
    title = P["experience"][0]["title"]
    i = next((k for k, t in enumerate(ps) if title in t), None)
    return ps[i:] if i is not None else None


def secrets():
    import config
    import gmail
    import vault
    import re
    online = config.AI_PROVIDER != "anthropic" and not re.match(r"https?://(127\.0\.0\.1|localhost)\b", config.AI_BASE_URL)
    fwd = gmail.forwarded()
    need = (["ANTHROPIC_API_KEY"] if config.AI_PROVIDER == "anthropic" else []) \
        + ([config.setting("ai_key_name") or "OPENAI_API_KEY"] if online else []) + ([] if fwd else ["EMAIL_PASS"])
    for n in need:
        vault.get(n)
    if fwd:
        import fwdmail
        if not fwdmail.account():
            raise RuntimeError("the job mail keys are missing - set up Job mail again (setup: Job mail)")
    return ", ".join(need + (["the job mail keys"] if fwd else [])) + " present"


def gmail_check():
    import config, gmail
    if gmail.forwarded():
        import fwdmail
        import localmail
        m = gmail.connect()
        try:
            n_alerts = gmail.recent_alert_count(m, days=14)
            m.select(f'"{gmail.special(m, chr(92) + "All")}"', readonly=True)
            n_all = len(m.uid("SEARCH", "X-GM-RAW", '"newer_than:14d"')[1][0].split())
        finally:
            m.logout()
        st = fwdmail.status()
        owner = str(config.EMAIL or "").strip().lower()
        if not (st.get("verified") or (owner and localmail.forwarded_from(14) == owner)):
            return "FAIL", "job mail does not reach WorksForMe yet - finish the forwarding (setup: Job mail)"
        return ("PASS" if n_alerts else "WARN"), f"job mail arrives ({n_all} copies in 14 days), " \
            f"{n_alerts} LinkedIn alert email(s) in 14 days" + ("" if n_alerts else " - create the LinkedIn job alerts (daily email)")
    m = gmail.connect(tries=1)
    try:
        folders = m.list()[1]
        names = [f.decode(errors="replace") for f in folders]
        ok = any(f'"{config.JOB_SEEK_FOLDER}"' in n or n.endswith(" " + config.JOB_SEEK_FOLDER) for n in names)
        n_alerts = gmail.recent_alert_count(m, days=14)
    finally:
        m.logout()
    if not ok:
        return "FAIL", f"login OK, but the label '{config.JOB_SEEK_FOLDER}' does not exist (create it + the Gmail filter)"
    return ("PASS" if n_alerts else "WARN"), f"login OK, '{config.JOB_SEEK_FOLDER}' exists, {n_alerts} LinkedIn alert email(s) in 14 days" + \
        ("" if n_alerts else " - create the LinkedIn saved-search alerts (daily email)")


def api():
    import time
    import llm
    if llm.PROVIDER == "anthropic":
        r = llm.client().messages.create(model=llm.MODEL, max_tokens=5, messages=[{"role": "user", "content": "Say OK"}])
        return f"{llm.MODEL} answered ({r.usage.input_tokens + r.usage.output_tokens} tokens)"
    t = time.time()
    llm._parse(llm.Draft, "Reply with the single word OK.", 20)
    return f"{llm.MODEL or 'the model'} answered in {time.time() - t:.0f} s ({llm.BASE_URL})"


def browser():
    import config, jobapply
    assert Path(config.CHROME_EXE).exists(), f"browser not found at {config.CHROME_EXE} (settings.json chrome_exe)"
    lock = socket.socket()
    lock.bind(("127.0.0.1", config.PORT_LOCK))
    try:
        jobapply.launch()
        from playwright.sync_api import sync_playwright
        with sync_playwright() as pw:
            ctx = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{jobapply.PORT}").contexts[0]
            signed = any(c["name"] == "li_at" for c in ctx.cookies("https://www.linkedin.com"))
            google = any(c["name"] in ("SID", "__Secure-1PSID") for c in ctx.cookies("https://accounts.google.com"))
    finally:
        jobapply.close_chrome()
        lock.close()
    if not signed or not google:
        if _product():
            return "WARN", ("WorksForMe's browser is not signed in to " +
                            " and ".join(x for x, ok in (("LinkedIn", signed), ("Google", google)) if not ok) +
                            " - press \"Open LinkedIn sign-in\" in the Job alerts step (prefer Continue with Google)")
        return "WARN", f"Chrome OK on port {config.PORT_CHROME}; signed in: LinkedIn={signed}, Google={google} - " \
                       f"run 'python jobapply.py open https://www.linkedin.com/login' and sign in (Google too)"
    return f"Chrome OK on port {config.PORT_CHROME}; LinkedIn + Google signed in"


def ledger():
    (HERE / "runs").mkdir(exist_ok=True)
    f = HERE / "applications.csv"
    assert f.exists(), "applications.csv missing (the kit ships it with a header line)"
    with f.open("a", encoding="utf-8"):
        pass
    for j in ("low_pay_companies.json", "parked_companies.json", "google_signin.json", "locations.json"):
        json.loads((HERE / j).read_text(encoding="utf-8-sig"))
    return "applications.csv writable; runs/ and data files OK"


def scheduler():
    import subprocess
    import config
    folder = Path(os.environ.get("JOBBOT_STARTUP_DIR") or Path(os.environ["APPDATA"]) / r"Microsoft\Windows\Start Menu\Programs\Startup")
    kind = "daily run" if config.setting("edition") == "product" else "agent"
    links = sorted(folder.glob(f"{config.APP_NAME} {kind}*.lnk"))
    if not links:
        if _product():
            return "WARN", "the daily run is not on yet - the setup's last step, \"Go live\", turns it on"
        return "WARN", f"no Startup shortcut '{config.APP_NAME} agent' - install.ps1 -Shortcuts creates it (last SETUP step)"
    targets = []
    for lnk in links:
        r = subprocess.run(["powershell", "-NoProfile", "-Command",
                            f"$s = (New-Object -ComObject WScript.Shell).CreateShortcut('{lnk}'); $s.Arguments"],
                           capture_output=True, text=True, creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        targets.append((r.stdout or "").strip())
        if any(str(HERE / a).lower() in targets[-1].lower() for a in ("agent.pyw", "jobbot_agent.pyw")):
            return f"Startup shortcut '{lnk.name}' starts this install's agent (daily, from the configured time, when idle)"
    return "FAIL", f"the Startup shortcut(s) start another install ({targets[0][:110]}) - rerun install.ps1 -Shortcuts here"


if __name__ == "__main__":
    import config
    ver = next((v for v in (HERE / "VERSION.txt", HERE.parent / "VERSION.txt") if v.exists()), None)
    print(f"{config.APP_NAME} self-test in {HERE}" + (f" - {ver.read_text(encoding='utf-8').strip()}" if ver else "") + "\n")
    for name, fn in [("packages", packages), ("applicant.json", applicant), ("settings.json", settings),
                     ("targets.json", targets), ("fit_cases.json", fit_cases), ("resumes", resumes), ("consistency", consistency),
                     ("adapters", adapters),
                     ("ledger + data files", ledger), ("secrets (vault)", secrets)]:
        check(name, fn)
    if not OFFLINE:
        check("Gmail (IMAP)", gmail_check)
        check("AI model", api)
    if not NO_BROWSER:
        check("Chrome + sign-ins", browser)
    check("daily scheduler", scheduler)
    fails = [r for r in results if r[0] == "FAIL"]
    warns = [r for r in results if r[0] == "WARN"]
    print(f"\n{len(results) - len(fails) - len(warns)} PASS, {len(warns)} WARN, {len(fails)} FAIL")
    sys.exit(1 if fails else 0)
