import datetime as dt
import json
import secrets
from pathlib import Path

HERE = Path(__file__).resolve().parent
FILE = HERE / "runs" / "email_actions.json"
DAYS = 7


def _load():
    try:
        return json.loads(FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save(d):
    FILE.parent.mkdir(parents=True, exist_ok=True)
    FILE.write_text(json.dumps(d, indent=1), encoding="utf-8")


def new(kind, row):
    cut = (dt.datetime.now() - dt.timedelta(days=DAYS)).isoformat()
    d = {k: v for k, v in _load().items() if v.get("made", "") >= cut}
    tok = secrets.token_urlsafe(16)
    d[tok] = {"kind": kind, "url": row.get("url") or "", "company": row.get("company") or "", "title": row.get("title") or "",
              "made": dt.datetime.now().isoformat(timespec="seconds")}
    _save(d)
    return tok


def link(tok):
    import config
    return f"http://127.0.0.1:{int(config.setting('ports.ui', 9450))}/act?t={tok}"


def take(tok):
    d = _load()
    e = d.get(str(tok or ""))
    if not e or e.get("made", "") < (dt.datetime.now() - dt.timedelta(days=DAYS)).isoformat():
        return None
    prev = e.get("last")
    e["last"] = dt.datetime.now().isoformat(timespec="seconds")
    _save(d)
    return dict(e, previous=prev)
