import json
import os
import re
import sys
from pathlib import Path

import anthropic
from typing import Literal

from pydantic import BaseModel

import config

MODEL = config.AI_MODEL
PROVIDER = config.AI_PROVIDER
BASE_URL = config.AI_BASE_URL
REASONING = config.AI_REASONING
HERE = Path(__file__).parent
_prof = HERE / "applicant.json"
PROFILE = json.loads(_prof.read_text(encoding="utf-8-sig")) if _prof.exists() else {}
_routing = config.CATEGORIES_DIR / "README.md"
ROUTING = _routing.read_text(encoding="utf-8") if _routing.exists() else ""
if "## Routing" in ROUTING:
    ROUTING = ROUTING.split("## Routing", 1)[1].split("## Provenance", 1)[0]
CATEGORIES = config.CATEGORIES

_client = None


def _key():
    import vault
    return vault.get("ANTHROPIC_API_KEY")


def client():
    global _client
    if _client is None:
        _client = anthropic.Anthropic(api_key=_key(), max_retries=3)
    return _client


def _resume_facts():
    import zipfile
    doc = config.MASTER_RESUME
    if doc.suffix.lower() == ".docx":
        with zipfile.ZipFile(doc) as z:
            names = z.namelist()
            parts = [n for n in names if re.fullmatch(r"word/header\d*\.xml", n)] + ["word/document.xml"] \
                + [n for n in names if re.fullmatch(r"word/footer\d*\.xml", n)]
            texts = [re.sub(r"<[^>]+>", "", re.sub(r"</w:p>", "\n", z.read(n).decode("utf-8"))) for n in parts]
        return "\n".join(dict.fromkeys(t for t in texts if t.strip()))
    if doc.suffix.lower() == ".pdf":
        from pypdf import PdfReader
        return "\n".join(pg.extract_text() or "" for pg in PdfReader(str(doc)).pages)
    return doc.read_text(encoding="utf-8")


RESUME = _resume_facts() if config.MASTER_RESUME.exists() else ""

PROFILE_BRIEF = json.dumps({k: PROFILE[k] for k in (
    "identity", "location", "eligibility", "self_identification", "compensation") if k in PROFILE}, indent=1)

SYSTEM = f"""You fill job-application forms for {config.PERSONA}. Answer only from the facts below. Never invent employers,
dates, numbers, skills, certifications, or experience. If the facts do not settle a question,
say so by setting confident=false. Where the person lives NOW, and how to reach them, is the STANDING ANSWERS' location
and identity - the resume may show an older address.

STANDING ANSWERS:
{PROFILE_BRIEF}

RESUME:
{RESUME}"""


FIT_SYSTEM = SYSTEM.replace(PROFILE_BRIEF, json.dumps({k: PROFILE[k] for k in (
    "identity", "location", "eligibility", "self_identification") if k in PROFILE}, indent=1))


class Choice(BaseModel):
    answer: str
    confident: bool
    reason: str


class Category(BaseModel):
    category: str
    reason: str


class Draft(BaseModel):
    text: str


_engine = None
ENGINE_RESTART = None
ENGINE_IDLE_S = 600
_busy, _used = 0, 0.0
_model, _base_reasoning, _short = None, None, (0.0, "")
SHORT_KEEP_S, PAUSE_GB = 60, 1.0


def _friendly(short):
    import machine
    apps = machine.apps_text(short.get("apps") or [])
    return (f"Not enough free memory: the AI needs about {short['need']} GB and {short['free']} GB is free. "
            "Close some programs" + (f", such as {apps}" if apps else "") + ".")


def _refuse(short):
    global _short
    import time
    import engine
    _short = (time.time(), _friendly(short) if short else "Your PC ran out of free memory, so "
              f"{config.APP_NAME} stopped its AI for now. Close a few programs to make room.")
    raise engine.MemoryShort(_short[1], short)


def _idle_watch():
    import time
    import engine
    import machine
    global _engine
    while True:
        time.sleep(10)
        if _engine is not None and machine.memory_gb()[1] < PAUSE_GB:
            e, _engine = _engine, None
            engine.stop(e)
            try:
                _refuse(None)
            except engine.MemoryShort:
                pass
        if _engine is not None and _busy == 0 and time.time() - _used > ENGINE_IDLE_S:
            e, _engine = _engine, None
            engine.stop(e)


def _restart_own_engine():
    global _engine
    import time
    import engine
    failed = engine.LAST_PLACEMENT
    engine.stop(_engine)
    _engine = None
    if time.time() - _short[0] < SHORT_KEEP_S:
        raise engine.MemoryShort(_short[1])
    model = _model or config.setting("engine.model")
    short = engine.room_for(model)
    if short:
        _refuse(short)
    if failed:
        engine.demote(Path(model).name, failed)
    try:
        _engine = engine.start(model, log=str(HERE / "runs" / "engine.log"), after=failed)
    except engine.MemoryShort as e:
        _refuse(e.short)


def builtin():
    port = int(config.setting("ports.model", 9451))
    return bool(config.setting("engine.model")) and BASE_URL == f"http://127.0.0.1:{port}/v1"


def memory_wall():
    if not builtin():
        return None
    sys.path.insert(0, str(HERE / "product"))
    import engine
    return None if engine.up() else engine.choose(config.setting("engine.model"))[2]


def _start_own():
    global _engine, _model, _base_reasoning, REASONING
    import time
    import engine
    if time.time() - _short[0] < SHORT_KEEP_S:
        raise engine.MemoryShort(_short[1])
    path, reasoning, short = engine.choose(config.setting("engine.model"))
    if short:
        _refuse(short)
    if _base_reasoning is None:
        _base_reasoning = REASONING
    REASONING = reasoning if reasoning is not None else _base_reasoning
    _model = path
    try:
        _engine = engine.start(path, log=str(HERE / "runs" / "engine.log"))
    except engine.MemoryShort as e:
        _refuse(e.short)


def _ensure_engine():
    global _engine
    if _engine is not None or not builtin():
        return
    sys.path.insert(0, str(HERE / "product"))
    import atexit
    import engine
    global ENGINE_RESTART
    if not engine.up():
        _start_own()
        atexit.register(lambda: engine.stop(_engine))
        ENGINE_RESTART = _restart_own_engine
        if not getattr(engine, "_watching", False):
            import threading
            engine._watching = True
            threading.Thread(target=_idle_watch, daemon=True).start()


def _local(url):
    return bool(re.match(r"https?://(127\.0\.0\.1|localhost)\b", url or ""))


def _strict(s):
    if isinstance(s, dict):
        s = {k: _strict(v) for k, v in s.items()}
        if s.get("type") == "object" and "properties" in s:
            s["additionalProperties"] = False
            s["required"] = list(s["properties"])
    elif isinstance(s, list):
        s = [_strict(x) for x in s]
    return s


def _parse_openai(schema, prompt, max_tokens, system=None):
    import urllib.request
    _ensure_engine()
    body = {"model": MODEL, "temperature": 0,
            "messages": [{"role": "system", "content": system or SYSTEM}, {"role": "user", "content": prompt}],
            "response_format": {"type": "json_schema", "json_schema": {
                "name": schema.__name__, "schema": _strict(schema.model_json_schema()) if not _local(BASE_URL)
                else schema.model_json_schema(), "strict": True}}}
    if REASONING == "off":
        if _local(BASE_URL):
            body["chat_template_kwargs"] = {"enable_thinking": False}
        body["max_tokens"] = max(4 * max_tokens, 4096)
    elif REASONING:
        body["reasoning_effort"] = REASONING
        if _local(BASE_URL):
            body["chat_template_kwargs"] = {"reasoning_effort": REASONING}
        body["max_tokens"] = max(4 * max_tokens, 4096)
    else:
        body["max_tokens"] = max(4 * max_tokens, 4096)
    head = {"Content-Type": "application/json"}
    if not _local(BASE_URL):
        import vault
        head["Authorization"] = f"Bearer {vault.get(config.setting('ai_key_name') or 'OPENAI_API_KEY')}"
    global _busy, _used
    import time
    wait = 3600 if re.match(r"https?://(127\.0\.0\.1|localhost)\b", BASE_URL) else 900

    def ask(b):
        req = urllib.request.Request(f"{BASE_URL}/chat/completions", json.dumps(b).encode(), head)
        try:
            with urllib.request.urlopen(req, timeout=wait) as f:
                return json.loads(f.read().decode("utf-8"))
        except (urllib.error.HTTPError, urllib.error.URLError, ConnectionError) as e:
            if ENGINE_RESTART is None or (isinstance(e, urllib.error.HTTPError) and e.code < 500):
                raise
            ENGINE_RESTART()
            with urllib.request.urlopen(req, timeout=wait) as f:
                return json.loads(f.read().decode("utf-8"))

    def clean(o):
        text = o["choices"][0]["message"].get("content") or ""
        text = re.sub(r"(?s)<think>.*?</think>", "", text).strip()
        return re.sub(r"^```(?:json)?\s*|\s*```$", "", text)

    _busy += 1
    try:
        out = ask(body)
        try:
            return schema.model_validate_json(clean(out))
        except ValueError:
            return schema.model_validate_json(clean(ask(dict(body, temperature=0.4))))
    finally:
        _busy, _used = _busy - 1, time.time()


def _parse(schema, prompt, max_tokens=1024, system=None):
    if PROVIDER != "anthropic":
        return _parse_openai(schema, prompt, max_tokens, system)
    r = client().messages.parse(
        model=MODEL, max_tokens=max_tokens, system=system or SYSTEM,
        messages=[{"role": "user", "content": prompt}], output_format=schema,
        extra_body={"temperature": 0})
    return r.parsed_output


def pick_category(jd_text):
    prompt = f"""Choose the resume category for this job using the routing rules.
Reply with exactly one of: {", ".join(CATEGORIES)}.

ROUTING RULES:
{ROUTING}

JOB DESCRIPTION:
{jd_text[:12000]}"""
    try:
        r = _parse(Category, prompt, 400)
        if r.category in CATEGORIES:
            return r.category, r.reason
    except Exception as e:
        return config.DEFAULT_CATEGORY, f"classifier failed ({e}); default"
    return config.DEFAULT_CATEGORY, "classifier gave an unknown category; default"


class Fit(BaseModel):
    disqualifier: str
    domain: str
    domain_reason: str
    gaps: str


class FitLocal(BaseModel):
    disqualified: bool
    disqualifier: str
    domain: Literal["core", "adjacent", "none"]
    domain_reason: str
    gaps: str


class FitLocalR(BaseModel):
    team_work: str
    disqualified: bool
    disqualifier: str
    domain_reason: str
    domain: Literal["core", "adjacent", "none"]
    gaps: str


def taste_examples():
    if not config.setting("fit_examples", False):
        return ""
    p = HERE / "fit_cases.json"
    try:
        ex = json.loads(p.read_text(encoding="utf-8-sig")).get("examples") or []
    except (OSError, ValueError):
        return ""
    if not ex:
        return ""
    lines = [f"- {'WOULD APPLY' if e.get('apply') else 'WOULD SKIP'}: {e.get('title')} at {e.get('company')}" for e in ex[-12:]]
    return ("THIS PERSON'S OWN DECISIONS on real postings (their taste - judge new jobs the way they would):\n"
            + "\n".join(lines) + "\n\n")


def fit(title, company, jd_text):
    prompt = taste_examples() + config.fit_prompt(title, company, jd_text[:10000])
    try:
        local = PROVIDER != "anthropic" and config.setting("fit_schema", "constrained") != "full"
        r = _parse((FitLocalR if config.setting("fit_schema") == "reason_first" else FitLocal) if local else Fit,
                   prompt, 3000, system=FIT_SYSTEM)
        if local and not r.disqualified:
            r.disqualifier = ""
    except Exception as e:
        return "stretch", f"fit check failed: {e}"
    dq = r.disqualifier.strip()
    if dq and re.search(r"technical leadership|\btech(nical)? lead\b", title, re.I) and \
            re.search(r"hands.on|leadership|manag", dq, re.I):
        dq = ""
    if dq:
        return "skip", dq
    d = r.domain.strip().lower()
    why = r.domain_reason or ""
    if config.TARGETS.get("platform_guard") == "windows" and d in ("core", "adjacent") and re.search(r"no windows component|\b(linux|macos|mac|android|ios|qnx)[- ]only\b[^.]*\bno windows\b", why, re.I) \
            and not re.search(r"identity|authenticat|authoriz|crypto|platform[- ]neutral|incidental|not tied to", why, re.I):
        d = "none"
    verdict = {"core": "strong", "adjacent": "skip" if config.FIT_BREADTH == "core" else "strong", "none": "skip"}.get(d, "stretch")
    gaps = f" GAPS (info only): {r.gaps.strip()}." if r.gaps.strip() else ""
    return verdict, f"DOMAIN {d}: {r.domain_reason.strip()}{gaps}"


class RecruiterRead(BaseModel):
    role: str
    company: str
    sender_is: str
    kind: str
    pay: str
    location: str
    specific_role: bool


KINDS = ("full-time", "contract", "contract-to-hire", "part-time", "temporary")


def recruiter_read(sender, subject, body):
    prompt = f"""A recruiter wrote to a job seeker on LinkedIn. Fill each field ONLY from what the message says - never guess.
role: the job title offered, "" if none is named.
company: the company the person would work for, "" if not named.
sender_is: "employer" if the recruiter works for that company; "staffing" if they work for a staffing, recruiting,
  outsourcing or IT services firm that places people with its clients; "unknown" if the message does not show it.
kind: one of {", ".join(KINDS)} - or "unknown" unless the message states it.
pay: the pay exactly as written, "" if none.
location: remote / hybrid / on-site and the place, as written; "" if none.
specific_role: true only if the message offers one specific job.

FROM: {sender}
SUBJECT: {subject}
MESSAGE:
{(body or "")[:6000]}"""
    try:
        r = _parse(RecruiterRead, prompt, 700)
    except Exception:
        return None
    d = {k: (v.strip() if isinstance(v, str) else v) for k, v in r.model_dump().items()}
    d["kind"] = d["kind"].lower() if d["kind"].lower() in KINDS else "unknown"
    d["sender_is"] = d["sender_is"].lower() if d["sender_is"].lower() in ("employer", "staffing") else "unknown"
    return d


LEARNED = PROFILE.get("learned_answers") or []


def _qnorm(s):
    s = re.sub(r"^\s*still empty:\s*", "", s or "", flags=re.I)
    return " ".join(re.sub(r"[^a-z0-9 ]", " ", s.lower()).split())


def learned(question, options=None, company=""):
    import difflib
    q = _qnorm(question)
    if not q:
        return None
    for la in LEARNED:
        if la.get("company") and _qnorm(la["company"]) not in _qnorm(company):
            continue
        lq = _qnorm(la.get("question"))
        if lq and (lq == q or difflib.SequenceMatcher(None, lq, q).ratio() >= 0.9):
            a = str(la.get("answer", "")).strip()
            if not options:
                return a or None
            low = a.lower()
            return next((o for o in options if o.strip().lower() == low), None) or \
                next((o for o in options if low and low in o.lower()), None)
    return None


NOTE_ANSWER = re.compile(r"\bleave\b.{0,40}\b(blank|empty|unanswered)\b|^\W*(blank|skip)\W*$|\bunless required\b|"
                         r"\b(when|if) (it is |it's )?optional\b|\bonly when (the form )?requires?d?\b", re.I)


def answer(question, options=None, jd_text="", company=""):
    if (hit := learned(question, options, company)) is not None:
        return None if not options and NOTE_ANSWER.search(hit) else hit
    opts = ""
    if options:
        opts = "OPTIONS (answer must be exactly one of these, character for character):\n" + \
               "\n".join(f"- {o}" for o in options)
    legal = """Legal-status questions (veteran, disability, race, gender, sponsorship, clearance) must match
the standing answers by MEANING - read every option fully; wording like "a veteran, just not a
protected veteran" still claims veteran status."""
    if PROVIDER == "anthropic":
        prompt = f"""Application form question at {company or "the company"}:
{question}

{opts}

Job description, for context:
{jd_text[:6000]}

{legal}"""
    else:
        prompt = f"""Job description, for context:
{jd_text[:6000]}

{legal}

Application form question at {company or "the company"}:
{question}

{opts}"""
    try:
        r = _parse(Choice, prompt, 600)
    except Exception:
        return None
    if not r.confident:
        return None
    if PROVIDER != "anthropic" and overclaims(question, r.answer, options):
        return None
    if options:
        return r.answer if r.answer in options else None
    a = clean(r.answer.strip())
    return a if a and not NOTE_ANSWER.search(a) else None


def overclaims(question, ans, options=None):
    if not re.search(r"experience|familiar|proficien|worked with|hands-on|used|built|expert", question, re.I):
        return False
    names = [w for w in re.findall(r"(?<![\w])[A-Za-z][\w+#.-]*", question)
             if (any(c.isupper() for c in w[1:]) or any(c.isdigit() for c in w)) and len(w) > 1]
    if not names or any(re.search(rf"(?<!\w){re.escape(w)}(?!\w)", RESUME, re.I) for w in names):
        return False
    low = (options or [None])[0]
    return not (ans == low or re.match(r"\s*(no|none|never|0)\b", ans or "", re.I))


class Doubt(BaseModel):
    question: str
    answer: str
    should_be: str
    fact: str


class SecondRead(BaseModel):
    doubts: list[Doubt]


def second_read(pairs, company="", page="", lists=None):
    if not pairs and not page:
        return []
    lists = list(lists or [])
    picked = lambda i: (f"   [picked from a list: {' | '.join(o[:60] for o in lists[i][:30])}]"
                        if i < len(lists) and lists[i] else "")
    listing = "\n".join(f"{i}. {q} -> {a}{picked(i - 1)}" for i, (q, a) in enumerate(pairs, 1))
    chosen = ("\nAn answer marked [picked from a list] could only be one of those options. When the list lacks the "
              "fact's exact wording, the option closest in meaning IS correct (a cell phone listed as \"Home Cellular\", "
              "\"not a veteran\" listed only as \"I am not a protected veteran\"). Report such an answer only when ANOTHER "
              "option of that same list fits the fact better - and then copy that option exactly as should_be.\n"
              if any(lists) else "")
    review = f"\nTHE FORM'S REVIEW PAGE:\n{page[:8000]}\n" if page else ""
    eds = "\n".join(f"- {e.get('school')}" + (f" (not in a list: {e['school_fallback']})" if e.get("school_fallback") else "")
                    + f": {e.get('degree')}; field of study: {', '.join(e.get('field_queries') or []) or '-'}"
                    for e in PROFILE.get("education_on_forms") or [])
    eds = (f"\nDEGREES AS ENTERED ON FORMS (the person's own choice: a school, degree or field-of-study answer that matches "
           f"one of these, or the closest option a list offered for it, is correct even where the resume words it "
           f"differently):\n{eds}\n") if eds else ""
    prompt = f"""A program filled in this job application at {company or "the company"} for the person above. Before it is
submitted, read every answer against the STANDING ANSWERS and the RESUME.

Report an answer ONLY when it clearly contradicts a stated fact: work authorization, visa sponsorship, age, former
employment or relatives at this company, veteran / disability / gender / race / sexual orientation, security clearance,
degrees, employers, name, email, phone, address, country. Read each question fully - a question can be turned around
("... WITHOUT sponsorship?", "Are you NOT ...") and an option can say yes or no in words.
Never report: pay or salary, relocation, commute, on-site or hybrid answers, start dates, how they heard about the job,
referrals, interest or motivation, anything the facts do not settle, empty or optional answers.
No contradiction -> an empty list. Copy question and answer exactly as listed.
{eds}{chosen}
ANSWERS:
{listing}
{review}"""
    try:
        return _parse(SecondRead, prompt, 900).doubts
    except Exception:
        return []


BANNED = re.compile(r"[\u2014\u2013]|passionate|excited to|delve|thrilled|leverag|synerg|"
                    r"cutting-edge|dynamic|I am confident|tapestry", re.I)


def clean(text):
    if not text:
        return text
    text = re.sub(r"\s*[\u2014\u2013]\s*", ", ", text)
    return re.sub(r" {2,}", " ", text).strip()


def draft(question, jd_text, company, max_chars=1200):
    prompt = config.TARGETS.get("draft_prompt", "").replace("{company}", company).replace("{question}", question) \
        .replace("{max_chars}", str(max_chars)).replace("{jd}", jd_text[:8000])
    for _ in range(2):
        try:
            t = _parse(Draft, prompt, 800).text.strip()
        except Exception:
            return None
        t = clean(t)
        if t and len(t) <= max_chars and not BANNED.search(t):
            return t
        prompt += "\n\nYour previous attempt broke a rule (length, a dash, or a banned word). Try again."
    return None


if __name__ == "__main__":
    print(pick_category("Senior Embedded Engineer. Secure boot, TPM, firmware updates for IoT devices."))
    print(answer("Are you legally authorized to work in the United States?", ["Yes", "No"]))
    print(answer("Please select your veteran status.",
                 ["I IDENTIFY AS A VETERAN, JUST NOT A PROTECTED VETERAN", "I AM NOT A VETERAN",
                  "I DO NOT WISH TO SELF-IDENTIFY"]))
