import re
import sys
from pathlib import Path
from xml.sax.saxutils import quoteattr

import config
import gmail

HERE = Path(__file__).parent
LINKEDIN_LABEL = config.LINKEDIN_FOLDER
SEEK_WORDS = ('subject:(application OR applying OR candidacy OR candidate OR interest OR considering OR "thank you" OR '
              '"thanks for applying" OR "thanks for your interest" OR interview OR "next steps" OR "update on" OR position OR role OR Recruiter) '
              '((position OR role OR candidacy OR recruiter OR recruiting OR "hiring team" OR talent OR opportunity) '
              '-unsubscribe)')
HIRING_SITES = ("greenhouse-mail.io OR greenhouse.io OR lever.co OR ashbyhq.com OR icims.com OR smartrecruiters.com OR "
                "taleo.net OR jobvite.com OR eightfold.ai OR phenompeople.com OR paradox.ai OR goodtime.io OR "
                "hirevue.com OR amazon.jobs OR jobgether.com OR workablemail.com OR breezy.hr OR recruitee.com OR "
                "teamtailor.com OR pinpointhq.com")
INTERVIEW_WORDS = 'interview OR interviews OR "phone screen" OR "call confirmed" OR "call scheduled"'
HIRING_PHRASES = ('"hiring team" OR "recruiting team" OR "talent acquisition" OR "your candidacy" OR '
                  '"thank you for applying" OR "thanks for applying" OR "invitation to apply"')
HR_SITES = "myworkday.com OR successfactors.com OR oraclecloud.com OR rippling.com OR bamboohr.com"
HR_HIRING_WORDS = ("hiring OR application OR applying OR applied OR candidate OR candidacy OR interview OR assessment OR "
                   "questionnaire OR offer OR recruiting OR recruiter")

def labels():
    m = gmail.connect()
    try:
        have = {l.decode(errors="replace").rsplit(' "/" ', 1)[-1].strip('"') for l in m.list()[1]}
        chosen = [config.JOB_SEEK_FOLDER, config.LINKEDIN_FOLDER]
        for lab in dict.fromkeys([p.rsplit("/", 1)[0] for p in chosen if "/" in p] + chosen):
            if lab.upper() == "INBOX":
                continue
            if lab in have:
                print(f"label exists: {lab}")
            else:
                typ, _ = m.create(f'"{lab}"')
                print(f"label created: {lab}" if typ == "OK" else f"could not create {lab}: {typ}")
    finally:
        m.logout()


def filters():
    skip = [("shouldArchive", "true")] if config.setting("job_mail_skip_inbox", False) else []

    def entry(props):
        p = "".join(f"<apps:property name={quoteattr(k)} value={quoteattr(v)}/>" for k, v in props)
        return f"<entry><category term='filter'></category><title>Mail Filter</title><content></content>{p}</entry>"
    xml = ("<?xml version='1.0' encoding='UTF-8'?><feed xmlns='http://www.w3.org/2005/Atom' "
           "xmlns:apps='http://schemas.google.com/apps/2006'><title>Mail Filters</title>"
           + entry([("from", "jobalerts-noreply@linkedin.com OR jobs-noreply@linkedin.com"),
                    ("doesNotHaveTheWord", "application"), ("label", config.LINKEDIN_FOLDER), ("shouldArchive", "true")])
           + entry([("hasTheWord", SEEK_WORDS), ("doesNotHaveTheWord", "from:jobalerts-noreply@linkedin.com"),
                    ("label", config.JOB_SEEK_FOLDER)] + skip)
           + entry([("from", "inmail-hit-reply@linkedin.com"), ("label", config.JOB_SEEK_FOLDER)] + skip)
           + "</feed>")
    out = HERE / "gmail_filters.xml"
    out.write_text(xml, encoding="utf-8")
    print(f"\nwrote {out}\nImport it: Gmail > Settings > See all settings > Filters and Blocked Addresses > "
          f"Import filters > choose this file > Open file > Create filters.")


FILTERS_FILE = f"{config.APP_NAME} Gmail filters.xml"


def downloads_dir():
    import ctypes
    import uuid
    buf = ctypes.c_wchar_p()
    try:
        guid = ctypes.c_char_p(uuid.UUID("374DE290-123F-4565-9164-39C4925E467B").bytes_le)
        if ctypes.windll.shell32.SHGetKnownFolderPath(guid, 0, None, ctypes.byref(buf)) == 0 and buf.value:
            path = Path(buf.value)
            ctypes.windll.ole32.CoTaskMemFree(buf)
            return path
    except (OSError, AttributeError, ValueError):
        pass
    return Path.home() / "Downloads"


NEW_FILTERS_FILE = f"{config.APP_NAME} Gmail filters - new.xml"
CRITERIA = ("from", "to", "subject", "hasTheWord", "doesNotHaveTheWord")


def save_filters(address, folder=None, only=None):
    folder = Path(folder or downloads_dir())
    folder.mkdir(parents=True, exist_ok=True)
    out = folder / (FILTERS_FILE if only is None else NEW_FILTERS_FILE)
    tmp = out.with_suffix(".tmp")
    tmp.write_text(forward_filters(address, only=only), encoding="utf-8")
    tmp.replace(out)
    return out


NOT_JOB = ("unsubscribe OR rental OR tenant OR lease OR leasing OR apartment OR landlord OR mortgage OR loan OR "
           "scholarship OR tuition OR admissions")


def seek_rules():
    return [[("from", "inmail-hit-reply@linkedin.com OR " + HIRING_SITES)],
            [("from", "jobs-noreply@linkedin.com"), ("subject", '"your application"')],
            [("hasTheWord", SEEK_WORDS), ("doesNotHaveTheWord", NOT_JOB)],
            [("subject", INTERVIEW_WORDS), ("doesNotHaveTheWord", NOT_JOB)],
            [("hasTheWord", HIRING_PHRASES), ("doesNotHaveTheWord", NOT_JOB)],
            [("from", HR_SITES), ("subject", HR_HIRING_WORDS)]]


def rule_query(props):
    d = dict(props)
    return " ".join(x for x in (f"from:({d['from']})" if d.get("from") else "",
                                f"subject:({d['subject']})" if d.get("subject") else "",
                                f"({d['hasTheWord']})" if d.get("hasTheWord") else "",
                                f"-({d['doesNotHaveTheWord']})" if d.get("doesNotHaveTheWord") else "") if x)


def forward_rules(keep_alerts=False):
    return [[("from", "jobalerts-noreply@linkedin.com OR jobs-noreply@linkedin.com"), ("doesNotHaveTheWord", "application")]
            + ([] if keep_alerts else [("shouldTrash", "true")])] + seek_rules() + [
            [("from", "oracle.com OR oraclecloud.com"), ("subject", '"confirm your identity" OR "identity verification"')],
            [("subject", "refer OR referred OR referral OR referring"), ("doesNotHaveTheWord", "unsubscribe")],
            [("subject", f'"{config.APP_NAME} forwarding check"')]]


def rule_key(props):
    import hashlib
    crit = "|".join(f"{k}={v}" for k, v in props if k in CRITERIA)
    return hashlib.sha1(crit.encode("utf-8")).hexdigest()[:10]


def rule_keys():
    return [rule_key(p) for p in forward_rules()]


def filters_due():
    saved = config.setting("filters_saved")
    if config.setting("mail_source") != "forward" or not config.setting("mail_address") or saved is None:
        return []
    return [k for k in rule_keys() if k not in set(saved)]


def forward_filters(address, keep_alerts=False, only=None):
    def entry(props):
        p = "".join(f"<apps:property name={quoteattr(k)} value={quoteattr(v)}/>" for k, v in props)
        return f"<entry><category term='filter'></category><title>Mail Filter</title><content></content>{p}</entry>"
    rules = [p for p in forward_rules(keep_alerts) if only is None or rule_key(p) in only]
    return ("<?xml version='1.0' encoding='UTF-8'?><feed xmlns='http://www.w3.org/2005/Atom' "
            "xmlns:apps='http://schemas.google.com/apps/2006'><title>Mail Filters</title>"
            + "".join(entry(p + [("forwardTo", address)]) for p in rules)
            + "</feed>")


def check():
    m = gmail.connect()
    try:
        out = {}
        for lab in (config.LINKEDIN_FOLDER, config.JOB_SEEK_FOLDER):
            typ, data = m.select(f'"{lab}"', readonly=True)
            out[lab] = int(data[0]) if typ == "OK" else None
        m.select("INBOX", readonly=True)
        lab = re.sub(r"[\s/&]+", "-", config.LINKEDIN_FOLDER.lower())
        loose = m.uid("SEARCH", "X-GM-RAW", f'"from:jobalerts-noreply@linkedin.com -label:{lab} newer_than:7d"')[1][0].split()
    finally:
        m.logout()
    for lab, n in out.items():
        print(f"{lab:20} {'MISSING - run python gmail_setup.py' if n is None else f'{n} message(s)'}")
    print(f"LinkedIn alerts in the inbox without the label (last 7 days): {len(loose)}"
          + (" - the filter is not imported yet, or 'Also apply to matching conversations' was not ticked" if loose else ""))
    return out, len(loose)


if __name__ == "__main__":
    if "--check" in sys.argv:
        check()
    else:
        labels()
        filters()
