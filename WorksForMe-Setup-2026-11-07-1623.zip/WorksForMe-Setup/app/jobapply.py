import json
import os
import socket
import subprocess
import sys
import time
from pathlib import Path

from playwright.sync_api import sync_playwright

import config
PORT = config.PORT_CHROME

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
HOME = config.BROWSER_HOME
PROFILE = HOME / "chrome_profile"
STATE = HOME / "state.json"
CHROME = config.CHROME_EXE

FIELDS_JS = r"""
() => {
  const vis = el => {
    if (el.type === 'file') return true;
    const r = el.getBoundingClientRect(), s = getComputedStyle(el);
    return r.width > 0 && r.height > 0 && s.visibility !== 'hidden' && s.display !== 'none';
  };
  const clean = t => (t || '').replace(/\s+/g, ' ').trim().slice(0, 140);
  const labelOf = el => {
    if (el.labels && el.labels.length) return clean([...el.labels].map(l => l.innerText).join(' | '));
    const al = el.getAttribute('aria-label'); if (al) return clean(al);
    const lb = el.getAttribute('aria-labelledby');
    if (lb) return clean(lb.split(/\s+/).map(i => document.getElementById(i)?.innerText || '').join(' '));
    const lg = el.closest('fieldset')?.querySelector('legend'); if (lg) return clean(lg.innerText);
    let p = el.parentElement;
    for (let i = 0; i < 4 && p; i++, p = p.parentElement) {
      const t = clean(p.innerText); if (t && t.length < 140) return t;
    }
    return clean(el.placeholder || el.name || el.id);
  };
  const sel = el => {
    if (el.id && document.querySelectorAll('#' + CSS.escape(el.id)).length === 1) return '#' + CSS.escape(el.id);
    if (el.name) {
      let s = `${el.tagName.toLowerCase()}[name="${el.name}"]`;
      if (el.type === 'radio' || el.type === 'checkbox') s += `[value="${el.value}"]`;
      if (document.querySelectorAll(s).length === 1) return s;
    }
    const path = [];
    for (let n = el; n && n.nodeType === 1 && n !== document.body; n = n.parentElement) {
      let i = 1; for (let s = n; (s = s.previousElementSibling);) if (s.tagName === n.tagName) i++;
      path.unshift(`${n.tagName.toLowerCase()}:nth-of-type(${i})`);
    }
    return 'body > ' + path.join(' > ');
  };
  const out = [];
  for (const el of document.querySelectorAll('input, select, textarea, [role="combobox"]')) {
    const t = (el.type || el.getAttribute('role') || el.tagName).toLowerCase();
    if (['hidden', 'submit', 'button', 'image', 'reset', 'search'].includes(t)) continue;
    if (!vis(el)) continue;
    const f = { sel: sel(el), type: el.tagName === 'SELECT' ? 'select' : t, label: labelOf(el),
                req: el.required || el.getAttribute('aria-required') === 'true' };
    if (el.tagName === 'SELECT') {
      f.value = el.selectedOptions[0]?.text?.trim() || '';
      f.options = [...el.options].map(o => o.text.trim()).filter(Boolean).slice(0, 25);
    } else if (t === 'radio' || t === 'checkbox') {
      f.value = el.checked ? 'CHECKED' : ''; f.option = clean(el.value);
    } else if (t === 'file') {
      f.value = el.files?.length ? el.files[0].name : '';
    } else {
      f.value = clean(el.value || el.innerText);
    }
    out.push(f);
  }
  return out;
}
"""


def port_open():
    with socket.socket() as s:
        s.settimeout(0.5)
        return s.connect_ex(("127.0.0.1", PORT)) == 0


def launch():
    if port_open():
        return "Chrome already running on port %d" % PORT
    PROFILE.mkdir(parents=True, exist_ok=True)
    subprocess.Popen(
        [CHROME, f"--remote-debugging-port={PORT}", f"--user-data-dir={PROFILE}",
         "--no-first-run", "--no-default-browser-check",
         "--disable-features=CalculateNativeWinOcclusion", "--disable-backgrounding-occluded-windows",
         "--disable-renderer-backgrounding", "--disable-background-timer-throttling", "about:blank"],
        creationflags=subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    for _ in range(60):
        if port_open():
            return "Chrome launched on port %d, profile %s" % (PORT, PROFILE)
        time.sleep(0.25)
    sys.exit("Chrome did not open the debug port")


def linkedin_google_signin(ctx, p, wait_s=40):
    import re
    me = json.loads((Path(__file__).parent / "applicant.json").read_text(encoding="utf-8-sig"))["identity"]["email"]
    has = lambda: any(c["name"] == "li_at" for c in ctx.cookies("https://www.linkedin.com"))
    if "/login" not in p.url:
        p.goto("https://www.linkedin.com/login", wait_until="domcontentloaded")
    for _ in range(8):
        if has():
            return True
        p.wait_for_timeout(1000)
    btn = p.frame_locator("iframe[title='Sign in with Google Button']:visible").first.locator("[role=button]").first
    try:
        before = set(ctx.pages)
        btn.click(timeout=8000)
    except Exception:
        return has()
    for _ in range(wait_s):
        p.wait_for_timeout(1000)
        if has():
            return True
        g = next((q for q in [p, *(set(ctx.pages) - before)]
                  if not q.is_closed() and "accounts.google.com" in q.url), None)
        if not g:
            continue
        try:
            if g.locator("input[type=password]:visible").count():
                return False
            tile = g.locator(f"[data-identifier='{me}']:visible")
            if tile.count():
                tile.first.click()
                continue
            body = g.locator("body").inner_text()
            if re.search(r"signing back in", body, re.I):
                g.get_by_role("button", name=re.compile(r"^continue$", re.I)).first.click()
                continue
            if re.search(r"wants (additional )?access|\bAllow\b|create (an |your )?account", body, re.I):
                return False
        except Exception:
            continue
    return has()


def close_chrome(browser=None):
    if not port_open():
        return "not running"
    try:
        if browser is not None:
            browser.new_browser_cdp_session().send("Browser.close")
        else:
            with sync_playwright() as pw:
                b = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{PORT}")
                b.new_browser_cdp_session().send("Browser.close")
    except Exception:
        pass
    for _ in range(20):
        if not port_open():
            return "closed"
        time.sleep(0.25)
    subprocess.run(["powershell", "-NoProfile", "-Command",
                    f"Get-CimInstance Win32_Process -Filter \"Name='{Path(CHROME).name}'\" | "
                    "Where-Object { $_.CommandLine -match [regex]::Escape('" + str(PROFILE) + "') } | "
                    "ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"], capture_output=True)
    return "closed (forced)"


def load_state():
    try:
        return json.loads(STATE.read_text())
    except Exception:
        return {}


def save_state(**kw):
    s = load_state()
    s.update(kw)
    HOME.mkdir(parents=True, exist_ok=True)
    STATE.write_text(json.dumps(s))


def target_id(page):
    cdp = page.context.new_cdp_session(page)
    try:
        return cdp.send("Target.getTargetInfo")["targetInfo"]["targetId"]
    finally:
        cdp.detach()


def current_page(ctx):
    pages = ctx.pages
    if not pages:
        return ctx.new_page()
    want = load_state().get("target")
    for p in pages:
        try:
            if target_id(p) == want:
                return p
        except Exception:
            pass
    return pages[-1]


def resolve(page, ref):
    if "|" in ref and ref.split("|", 1)[0].startswith("f"):
        idx, css = ref.split("|", 1)
        return page.frames[int(idx[1:])], css
    return page.main_frame, ref


def cmd_fields(page):
    n = 0
    for i, fr in enumerate(page.frames):
        try:
            items = fr.evaluate(FIELDS_JS)
        except Exception:
            continue
        for f in items:
            n += 1
            extra = ""
            if "options" in f:
                extra = "  options=" + " / ".join(f["options"])
            elif "option" in f:
                extra = "  option=" + f["option"]
            req = "*" if f["req"] else " "
            print(f"f{i}|{f['sel']}\n    {req}[{f['type']}] {f['label']!r}  value={f['value']!r}{extra}")
    print(f"-- {n} fields across {len(page.frames)} frames")


def cmd_text(page, maxlen):
    for i, fr in enumerate(page.frames):
        try:
            t = fr.evaluate("() => document.body ? document.body.innerText : ''")
        except Exception:
            continue
        t = "\n".join(l.strip() for l in t.splitlines() if l.strip())
        if len(t) > 40:
            print(f"===== frame f{i}: {fr.url[:100]}")
            print(t[:maxlen])


USAGE = """commands:
  launch                       start the job-apply Chrome (no-op if running)
  open URL                     open URL in a new tab and make it current
  tabs | use N                 list tabs / make tab N current
  text [MAX]                   visible text of the current tab, all frames (default 12000 chars)
  fields                       list form fields with refs, labels, values, options
  fill REF VALUE               set a text field
  type REF VALUE               click, clear, and type key by key (for widgets that ignore fill)
  select REF OPTION            choose a <select> option by visible text
  check REF | uncheck REF      tick or clear a checkbox / radio
  upload REF FILE              attach a file to an <input type=file>
  uploadvia REF FILE           click REF (a button) and attach FILE to the file chooser it opens
  click REF                    click an element
  clicktext TEXT               click the first visible element whose text is TEXT
  press KEY                    keyboard key on the focused element (Enter, Tab, ArrowDown, ...)
  js CODE [FRAME]              evaluate JS in the page (or frame index) and print the result
  shot FILE [full]             screenshot the current tab
  wait SECONDS                 sleep, then wait for the page to settle"""


def main():
    a = sys.argv[1:]
    if not a:
        sys.exit(USAGE)
    cmd = a[0]
    if cmd == "launch":
        print(launch())
        return
    if not port_open():
        print(launch())
    with sync_playwright() as pw:
        browser = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{PORT}")
        ctx = browser.contexts[0]
        if cmd == "open":
            page = ctx.new_page()
            page.goto(a[1], wait_until="domcontentloaded", timeout=60000)
            try:
                page.wait_for_load_state("networkidle", timeout=8000)
            except Exception:
                pass
            page.bring_to_front()
            save_state(target=target_id(page))
            print(page.title(), "|", page.url)
            return
        if cmd == "tabs":
            cur = current_page(ctx)
            for i, p in enumerate(ctx.pages):
                print(("*" if p == cur else " "), i, p.title()[:60], "|", p.url[:100])
            return
        if cmd == "use":
            page = ctx.pages[int(a[1])]
            page.bring_to_front()
            save_state(target=target_id(page))
            print(page.title(), "|", page.url)
            return
        page = current_page(ctx)
        if cmd == "text":
            cmd_text(page, int(a[1]) if len(a) > 1 else 12000)
        elif cmd == "fields":
            cmd_fields(page)
        elif cmd in ("fill", "type", "select", "check", "uncheck", "upload", "uploadvia", "click"):
            fr, css = resolve(page, a[1])
            loc = fr.locator(css).first
            if cmd == "fill":
                loc.fill(a[2])
            elif cmd == "type":
                loc.click()
                loc.press("Control+A")
                loc.press("Delete")
                loc.press_sequentially(a[2], delay=25)
            elif cmd == "select":
                loc.select_option(label=a[2])
            elif cmd == "check":
                loc.check(force=True)
            elif cmd == "uncheck":
                loc.uncheck(force=True)
            elif cmd == "upload":
                loc.set_input_files(a[2])
            elif cmd == "uploadvia":
                with page.expect_file_chooser(timeout=15000) as fc:
                    loc.click()
                fc.value.set_files(a[2])
            elif cmd == "click":
                loc.click()
            print("ok", cmd, a[1])
        elif cmd == "clicktext":
            page.get_by_text(a[1], exact=True).locator("visible=true").first.click()
            print("ok clicked", repr(a[1]))
        elif cmd == "press":
            page.keyboard.press(a[1])
            print("ok pressed", a[1])
        elif cmd == "js":
            fr = page.frames[int(a[2])] if len(a) > 2 else page.main_frame
            print(json.dumps(fr.evaluate(a[1]), indent=1, default=str)[:20000])
        elif cmd == "shot":
            page.screenshot(path=a[1], full_page=(len(a) > 2 and a[2] == "full"))
            print("saved", a[1])
        elif cmd == "wait":
            time.sleep(float(a[1]))
            try:
                page.wait_for_load_state("networkidle", timeout=8000)
            except Exception:
                pass
            print(page.title(), "|", page.url)
        else:
            sys.exit("unknown command: " + cmd + "\n\n" + USAGE)


if __name__ == "__main__":
    main()
