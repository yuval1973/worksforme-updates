import base64
import ctypes
import ctypes.wintypes as wt
import hashlib
import hmac
import json
import os
import secrets
import urllib.error
import urllib.request
from pathlib import Path

import config

MAGIC = b"WFM1"
INFO = b"WorksForMe mail v1"
P = 2 ** 255 - 19
BASE = (9).to_bytes(32, "little")
KEY_NAME, TOKEN_NAME = "MAIL_KEY", "MAIL_TOKEN"


def server():
    return str(config.setting("mail_server", "https://mail.worksformehq.com")).rstrip("/")


def _scalar(k):
    b = bytearray(k)
    b[0] &= 248
    b[31] &= 127
    b[31] |= 64
    return int.from_bytes(b, "little")


def x25519(k, u):
    n, x1 = _scalar(k), int.from_bytes(u, "little") & ((1 << 255) - 1)
    x2, z2, x3, z3, swap = 1, 0, x1, 1, 0
    for t in reversed(range(255)):
        bit = (n >> t) & 1
        swap ^= bit
        if swap:
            x2, x3, z2, z3 = x3, x2, z3, z2
        swap = bit
        a, b = (x2 + z2) % P, (x2 - z2) % P
        aa, bb = a * a % P, b * b % P
        e = (aa - bb) % P
        c, d = (x3 + z3) % P, (x3 - z3) % P
        da, cb = d * a % P, c * b % P
        x3, z3 = (da + cb) ** 2 % P, x1 * (da - cb) ** 2 % P
        x2, z2 = aa * bb % P, e * (aa + 121665 * e) % P
    if swap:
        x2, z2 = x3, z3
    return (x2 * pow(z2, P - 2, P) % P).to_bytes(32, "little")


def public_key(priv):
    return x25519(priv, BASE)


def hkdf(ikm, salt, info, n=32):
    prk = hmac.new(salt, ikm, hashlib.sha256).digest()
    out, t, i = b"", b"", 1
    while len(out) < n:
        t = hmac.new(prk, t + info + bytes([i]), hashlib.sha256).digest()
        out, i = out + t, i + 1
    return out[:n]


class _AuthInfo(ctypes.Structure):
    _fields_ = [("cbSize", wt.ULONG), ("dwInfoVersion", wt.ULONG), ("pbNonce", ctypes.c_void_p), ("cbNonce", wt.ULONG),
                ("pbAuthData", ctypes.c_void_p), ("cbAuthData", wt.ULONG), ("pbTag", ctypes.c_void_p), ("cbTag", wt.ULONG),
                ("pbMacContext", ctypes.c_void_p), ("cbMacContext", wt.ULONG), ("cbAAD", wt.ULONG),
                ("cbData", ctypes.c_ulonglong), ("dwFlags", wt.ULONG)]


_bc = ctypes.WinDLL("bcrypt") if os.name == "nt" else None


def aes_gcm(key, iv, data, aad, decrypt):
    if not _bc:
        raise OSError("AES-GCM needs Windows")
    alg, hkey = ctypes.c_void_p(), ctypes.c_void_p()
    if _bc.BCryptOpenAlgorithmProvider(ctypes.byref(alg), "AES", None, 0):
        raise OSError("AES is not available")
    try:
        mode = ctypes.create_unicode_buffer("ChainingModeGCM")
        if _bc.BCryptSetProperty(alg, "ChainingMode", mode, ctypes.sizeof(mode), 0):
            raise OSError("AES-GCM is not available")
        kb = ctypes.create_string_buffer(key, len(key))
        if _bc.BCryptGenerateSymmetricKey(alg, ctypes.byref(hkey), None, 0, kb, len(key), 0):
            raise OSError("bad key")
        try:
            body, tag = (data[:-16], data[-16:]) if decrypt else (data, b"\0" * 16)
            nonce, ad = ctypes.create_string_buffer(iv, len(iv)), ctypes.create_string_buffer(aad, len(aad))
            tg, src = ctypes.create_string_buffer(tag, 16), ctypes.create_string_buffer(body, len(body))
            info = _AuthInfo(cbSize=ctypes.sizeof(_AuthInfo), dwInfoVersion=1,
                             pbNonce=ctypes.cast(nonce, ctypes.c_void_p), cbNonce=len(iv),
                             pbAuthData=ctypes.cast(ad, ctypes.c_void_p), cbAuthData=len(aad),
                             pbTag=ctypes.cast(tg, ctypes.c_void_p), cbTag=16)
            out, got = ctypes.create_string_buffer(max(len(body), 1)), wt.ULONG()
            fn = _bc.BCryptDecrypt if decrypt else _bc.BCryptEncrypt
            st = fn(hkey, src, len(body), ctypes.byref(info), None, 0, out, len(body), ctypes.byref(got), 0)
            if st:
                raise ValueError("the message does not open with this key" if decrypt else f"encrypt failed ({st:#x})")
            return out.raw[:got.value] if decrypt else out.raw[:got.value] + tg.raw
        finally:
            _bc.BCryptDestroyKey(hkey)
    finally:
        _bc.BCryptCloseAlgorithmProvider(alg, 0)


def _key(shared, epub, pub):
    if not any(shared):
        raise ValueError("a bad public key")
    return hkdf(shared, epub + pub, INFO)


def seal(pub, plaintext, aad):
    eph = secrets.token_bytes(32)
    epub, iv = public_key(eph), secrets.token_bytes(12)
    return MAGIC + epub + iv + aes_gcm(_key(x25519(eph, pub), epub, pub), iv, plaintext, aad, False)


def unseal(priv, blob, aad):
    if blob[:4] != MAGIC or len(blob) < 4 + 32 + 12 + 16:
        raise ValueError("not a WorksForMe mail")
    epub, iv, ct = blob[4:36], blob[36:48], blob[48:]
    return aes_gcm(_key(x25519(priv, epub), epub, public_key(priv)), iv, ct, aad, True)


def b64u(b):
    return base64.urlsafe_b64encode(b).rstrip(b"=").decode()


def unb64u(s):
    return base64.urlsafe_b64decode(s + "=" * (-len(s) % 4))


def _vault():
    import vault
    return vault


def account():
    v = _vault()
    ident, key, token = config.setting("mail_id"), v._cm_read(KEY_NAME), v._cm_read(TOKEN_NAME)
    if not (ident and key and token):
        return None
    return {"id": ident, "address": config.setting("mail_address", ""), "key": bytes.fromhex(key), "token": token}


def _save_settings(**kw):
    config.save(**kw)


class ServerError(Exception):
    pass


def call(method, path, body=None, acct=None, timeout=30):
    head = {"Content-Type": "application/json", "User-Agent": f"{config.APP_NAME}"}
    if acct:
        head.update({"Authorization": f"Bearer {acct['token']}", "X-WFM-Id": acct["id"]})
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(server() + path, data=data, method=method, headers=head)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode("utf-8") or "{}")
    except urllib.error.HTTPError as e:
        try:
            msg = json.loads(e.read().decode("utf-8")).get("error")
        except Exception:
            msg = None
        raise ServerError(msg or f"the mail service answered {e.code}") from None
    except (urllib.error.URLError, OSError) as e:
        raise ServerError("the mail service could not be reached") from None


def register(name=""):
    have = account()
    if have:
        return have["address"]
    priv = secrets.token_bytes(32)
    r = call("POST", "/v1/register", {"public_key": b64u(public_key(priv)), "name": str(name or "").split("@")[0]})
    v = _vault()
    v._cm_write(KEY_NAME, priv.hex())
    v._cm_write(TOKEN_NAME, r["token"])
    _save_settings(mail_source="forward", mail_id=r["id"], mail_address=r["address"])
    return r["address"]


def fetch(acct=None):
    acct = acct or account()
    if not acct:
        return []
    items = call("GET", "/v1/mail", acct=acct).get("items") or []
    out = []
    for it in items:
        try:
            out.append((it["key"], unseal(acct["key"], unb64u(it["data"]), acct["id"].encode())))
        except (ValueError, KeyError):
            out.append((it.get("key"), None))
    return out


def ack(keys, acct=None):
    acct = acct or account()
    keys = [k for k in keys if k]
    if acct and keys:
        call("POST", "/v1/ack", {"keys": keys}, acct=acct)


def status(acct=None):
    acct = acct or account()
    return call("GET", "/v1/status", acct=acct) if acct else {"registered": False}


def confirm(code, acct=None):
    acct = acct or account()
    return call("POST", "/v1/owner/confirm", {"code": code}, acct=acct) if acct else {"verified": False}


def forget(acct=None, timeout=15):
    acct = acct or account()
    return call("POST", "/v1/forget", {}, acct=acct, timeout=timeout) if acct else {"forgotten": False}


def send_message(msg, to="self"):
    acct = account()
    if not acct:
        raise ServerError("this PC is not connected to the mail service yet")
    text = html = None
    files = []
    for part in msg.walk():
        if part.is_multipart():
            continue
        ctype, name = part.get_content_type(), part.get_filename()
        cid = (part.get("Content-ID") or "").strip("<> ")
        data = part.get_payload(decode=True) or b""
        if ctype == "text/plain" and not name and text is None:
            text = data.decode(part.get_content_charset() or "utf-8", "replace")
        elif ctype == "text/html" and not name and html is None:
            html = data.decode(part.get_content_charset() or "utf-8", "replace")
        else:
            files.append({"filename": name or (cid or "file"), "content": base64.b64encode(data).decode(),
                          "content_type": ctype, **({"content_id": cid} if cid else {})})
    body = {"to": to, "subject": str(msg.get("Subject") or ""), "text": text, "html": html, "attachments": files}
    return call("POST", "/v1/send", body, acct=acct, timeout=60)


def store_dir():
    return Path(config.HERE) / "runs" / "mail"
