import csv
import datetime as dt
import json
import os
import re
import subprocess
import config
import time
import sys
import traceback
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
LOGF = HERE / "runs" / f"daily-{dt.date.today()}.log"
LOGF.parent.mkdir(exist_ok=True)
SCHEDULED = sys.stdout is None
if not SCHEDULED:
    try:
        SCHEDULED = LOGF.exists() and os.path.samestat(os.fstat(sys.stdout.fileno()), os.stat(LOGF))
    except (OSError, ValueError, AttributeError):
        pass
if SCHEDULED:
    sys.stdout = sys.stderr = open(LOGF, "a", encoding="utf-8", buffering=1)
PY = str(Path(sys.executable).with_name("python.exe"))
DAILY_CAP = config.DAILY_CAP
ADJ_MAX_APPLICANTS = 100
ADJ_MAX_AGE_DAYS = 3
QUEUE_MAX = int(config.TARGETS.get("queue_max", 25))
QUEUE_PER_COMPANY = int(config.TARGETS.get("queue_per_company", 3))
GREAT_MID_BASE = int(config.TARGETS.get("great_min_mid_base") or 0)
QUEUE_MAX_DAYS = 30
QUEUE_PIN = [re.compile(x, re.I) for x in config.TARGETS.get("queue_pin", []) if x]


def pinned(r):
    return any(rx.search(f"{r.get('company', '')} - {r.get('title', '')}") for rx in QUEUE_PIN)
HELD = None
POOL_DAYS = 32
TRANSIENT_SKIP = re.compile(r"dropped from the (?:on-hold )?queue: (?:\d+ applicants > \d+|queue full|"
                            r"queue keeps the best \d+ per company)|^duplicate listing of the same role")
MAX_TRIES = 3
SCORER_SINCE = dt.datetime(2026, 9, 27, 21, 19)
DRY = "--dry-run" in sys.argv
SHADOW = config.SHADOW

sys.stdout.reconfigure(encoding="utf-8", errors="replace")
problems = []
asks = []
REVIEWS_FULL = []
POSTPONED = {"short": None}
RETRY = HERE / "runs" / "retry_daily_run.txt"
POSTPONED_DAYS = HERE / "runs" / "postponed_days.json"


def posted_days(text):
    m = re.search(r"(\d+)\s+(minute|hour|day|week|month)", text or "", re.I)
    if not m:
        return None
    n, unit = int(m.group(1)), m.group(2).lower()
    return {"minute": 0, "hour": 0, "day": n, "week": 7 * n, "month": 30 * n}[unit]


def log(msg):
    line = f"[{dt.datetime.now():%H:%M:%S}] {msg}"
    print(line, flush=True)
    if SCHEDULED:
        return
    with LOGF.open("a", encoding="utf-8") as f:
        f.write(line + "\n")


def transient(e):
    import imaplib
    import smtplib
    return isinstance(e, (imaplib.IMAP4.abort, imaplib.IMAP4.error, smtplib.SMTPException, ConnectionError, TimeoutError,
                          OSError)) and not isinstance(e, (FileNotFoundError, PermissionError))


def stage(name, fn, *a):
    log(f"== {name}")
    try:
        for attempt in range(3):
            try:
                return fn(*a)
            except Exception as e:
                if attempt == 2 or not transient(e):
                    raise
                log(f"   transient {type(e).__name__}: {str(e)[:100]} - retrying {name} in {60 * (attempt + 1)} s")
                time.sleep(60 * (attempt + 1))
    except Exception as e:
        if type(e).__name__ == "MemoryShort":
            log(f"NOTE {name}: {e}")
            if not POSTPONED["short"]:
                import llm
                short = llm.memory_wall()
                if short:
                    postpone(short)
            return None
        problems.append(f"{name}: {type(e).__name__}: {str(e).splitlines()[0][:200] if str(e) else ''}")
        log("ERROR " + problems[-1])
        with LOGF.open("a", encoding="utf-8") as f:
            f.write(traceback.format_exc() + "\n")
        file_failure(name, e)
        return None


def file_failure(name, e):
    if DRY or SHADOW:
        return None
    try:
        sys.path.insert(0, str(HERE / "product"))
        import support
        rid = support.send_failure(f"daily run: {name}", e)
        log(f"   service request {rid} filed" if rid else "   no service request (problem reports are off)")
        return rid
    except Exception as x:
        log(f"   service request not filed: {type(x).__name__}: {str(x)[:120]}")
        return None


def ledger():
    with (HERE / "applications.csv").open(encoding="utf-8") as f:
        return list(csv.DictReader(f))


def latest_by_url(rows):
    out = {}
    for r in rows:
        out[r.get("url")] = r
    return out


def new_alert_jobs():
    import gmail
    from triage import seen_urls
    for attempt in range(4):
        m = gmail.connect()
        try:
            alerts = gmail.alerts(m, dedupe=True)
            recent = gmail.recent_alert_count(m, days=2)
            break
        except Exception as e:
            if attempt == 3:
                raise
            log(f"   IMAP hiccup ({type(e).__name__}: {str(e)[:80]}) - reconnecting, try {attempt + 2}/4")
            time.sleep(30 * (attempt + 1))
        finally:
            try:
                m.logout()
            except Exception:
                pass
    seen = seen_urls()
    ids = {}
    for uid, date, subject, jobs in alerts:
        for j in jobs:
            if j not in seen:
                ids[j] = subject[:60]
    log(f"{len(alerts)} alert emails in the last 14 days; {len(ids)} new jobs")
    if not recent and live_days() < 2:
        log("no LinkedIn alert emails yet - normal in the first days after Go live (they start within a day)")
    elif not recent:
        asks.append(("No job alerts in 2 days", f"Check that your LinkedIn job alerts are on and go to {config.EMAIL}."))
        log("WARN no job alerts in 2 days")
    return ids


def live_days():
    if config.setting("edition") != "product":
        return 99
    import os
    lnk = Path(os.environ["APPDATA"]) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / \
        f"{config.APP_NAME} daily run.lnk"
    return (time.time() - lnk.stat().st_ctime) / 86400 if lnk.exists() else 0


def score(ids):
    import triage
    rows = triage.score(ids) if ids else []
    failed = [r for r in rows if r.get("verdict") == "error" and (r.get("reason") or "").startswith("fit check failed")]
    if failed:
        log(f"WARN {len(failed)} fit check(s) failed ({failed[0]['reason'][18:140]}) - those jobs are retried in the next run")
    return rows


def build_pool():
    rows = ledger()
    latest = latest_by_url(rows)
    tries = {}
    for r in rows:
        if (r.get("status") or "").startswith("error"):
            tries[r["url"]] = tries.get(r["url"], 0) + 1
    since = dt.datetime.now() - dt.timedelta(days=POOL_DAYS)
    from referrals import HOLD_STATUS
    held = [r.get("date") for r in latest.values() if (r.get("status") or "").startswith(HOLD_STATUS) and r.get("date")]
    if held:
        since = min(since, dt.datetime.fromisoformat(min(held)) - dt.timedelta(days=POOL_DAYS))
    fits, first_seen = {}, {}
    for f in sorted((HERE / "runs").glob("triage-*.csv")):
        try:
            when = dt.datetime.strptime(f.stem[len("triage-"):], "%Y-%m-%d_%H%M")
        except ValueError:
            continue
        if when < since or when < SCORER_SINCE:
            continue
        for r in csv.DictReader(f.open(encoding="utf-8")):
            if r.get("verdict") == "strong":
                fits[r["url"]] = r
                first_seen.setdefault(r["url"], when)
    from apply import excluded
    import jobseek
    key = lambda c, t: (re.sub(r"[^a-z0-9]", "", (c or "").lower())[:20],
                        re.sub(r"[^a-z0-9]", "", re.sub(r"\((?=[^)]*\d{4,})[^)]*\)", "", (t or "").lower())))
    final = list(latest.values()) + [r for r in rows if not r.get("url")]
    handled = {key(r.get("company"), r.get("title")) for r in final
               if (r.get("status") or "").startswith(("submitted", "applied", "submit clicked", "skipped"))
               and "job closed" not in (r.get("notes") or "") and not TRANSIENT_SKIP.search(r.get("notes") or "")
               and r.get("title")}
    applied = {key(r.get("company"), r.get("title")) for r in final
               if (r.get("status") or "").startswith(("submitted", "applied", "submit clicked")) and r.get("title")}
    pool = []
    for url, r in fits.items():
        if why := excluded(r.get("company"), r.get("title")):
            prev = (latest.get(url) or {}).get("status") or ""
            if prev.startswith(("waiting", "queued")) and not DRY:
                from apply import log_row
                log_row(date=dt.date.today(), company=r["company"], title=r["title"], url=url, status="skipped",
                        notes=f"dropped from the queue: {why}")
            continue
        st = (latest.get(url) or {}).get("status") or ""
        readmit = st.startswith("skipped") and bool(jobseek.top_tier(r.get("company"))) and             re.search(r"dropped from the queue: (?:queue full|queue keeps the best 3 per company)", (latest.get(url) or {}).get("notes") or "")
        if not st and key(r.get("company"), r.get("title")) in handled:
            log(f"   repost of a handled job: {r['company']} - {r['title'][:50]}")
            continue
        if (st.startswith(("waiting", "queued", "error")) or readmit) and key(r.get("company"), r.get("title")) in applied:
            log(f"   already applied to this role via another listing: {r['company']} - {r['title'][:50]}")
            if not DRY:
                from apply import log_row
                log_row(date=dt.date.today(), company=r["company"], title=r["title"], url=url, status="skipped",
                        notes="dropped from the queue: already applied to this role (another listing / by you)")
            continue
        if st and not st.startswith(("waiting", "queued", "error")) and not readmit:
            continue
        if st.startswith("error") and tries.get(url, 0) >= MAX_TRIES:
            continue
        core = (r.get("reason") or "").startswith("DOMAIN core")
        appl = int(r["applicants"]) if (r.get("applicants") or "").isdigit() else None
        age = posted_days(r.get("posted"))
        if not core and not ((appl is not None and appl <= ADJ_MAX_APPLICANTS) or (age is not None and age <= ADJ_MAX_AGE_DAYS)):
            log(f"   not now (adjacent, {appl} applicants, {r.get('posted')}): {r['company']} - {r['title'][:50]}")
            continue
        pool.append({**r, "core": core, "appl": appl if appl is not None else 10 ** 6, "prev": st,
                     "seen": first_seen.get(url)})
    pool.sort(key=lambda r: (not r["core"], r["appl"]))
    keep, dupes = {}, []
    for r in sorted(pool, key=lambda r: (r.get("ats") == "easy-apply", r["appl"])):
        k = key(r.get("company"), r.get("title"))
        (dupes.append((r, keep[k])) if k in keep else keep.__setitem__(k, r))
    if dupes:
        from apply import log_row
        for r, kept in dupes:
            log(f"   duplicate listing of {kept['company']} - {kept['title'][:45]} (kept {kept['url']})")
            if not DRY:
                log_row(date=dt.date.today(), company=r["company"], title=r["title"], url=r["url"],
                        applicants=r.get("applicants", ""), status="skipped",
                        notes=f"duplicate listing of the same role - applying via {kept['url']}")
        pool = [r for r in pool if r in keep.values()]
    log(f"pool: {len(pool)} jobs ({sum(r['core'] for r in pool)} core)")
    return pool


def linkedin_signed_in():
    import jobapply
    from playwright.sync_api import sync_playwright
    if not jobapply.port_open():
        jobapply.launch()
    with sync_playwright() as pw:
        ctx = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{jobapply.PORT}").contexts[0]
        p = ctx.new_page()
        p.goto("https://www.linkedin.com/feed/", wait_until="domcontentloaded")
        p.wait_for_timeout(3000)
        has = lambda: any(c["name"] == "li_at" for c in ctx.cookies("https://www.linkedin.com"))
        if not has():
            if jobapply.linkedin_google_signin(ctx, p):
                p.goto("https://www.linkedin.com/feed/", wait_until="domcontentloaded")
                p.wait_for_timeout(3000)
                log("LinkedIn: was signed out, signed back in with Google")
        ok = "/feed" in p.url and has()
        p.close()
    return ok


HOLD_INFO = {}
QUEUE = []
SHADOW_INFO = []


def recheck_held(pool):
    import socket
    import jobapply
    from apply import CLOSED
    from playwright.sync_api import sync_playwright
    jobs = [r for r in pool if re.search(r"linkedin\.com/jobs/view/\d+", r["url"])]
    out = {}
    if not jobs:
        return out
    lock = socket.socket()
    try:
        lock.bind(("127.0.0.1", config.PORT_LOCK))
    except OSError:
        log("   applicant re-check skipped: another JobBot run holds the browser")
        return out
    try:
        if not jobapply.port_open():
            jobapply.launch()
        with sync_playwright() as pw:
            ctx = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{jobapply.PORT}").contexts[0]
            page = ctx.new_page()
            for r in jobs:
                try:
                    page.goto(r["url"], wait_until="domcontentloaded", timeout=45000)
                    page.wait_for_timeout(2500)
                    if not any(c["name"] == "li_at" for c in ctx.cookies("https://www.linkedin.com")):
                        log("WARN applicant re-check: LinkedIn signed out - held jobs not re-checked today")
                        break
                    main = page.locator("main").inner_text(timeout=15000)
                    head = " ".join(l.strip() for l in main.splitlines()[:8] if l.strip())
                    m = re.search(r"Candidates who clicked apply\s+([\d,]+)", main) or \
                        re.search(r"([\d,]+) (?:people clicked apply|applicants)", head)
                    appl = int(m.group(1).replace(",", "")) if m else (101 if "Over 100" in head else None)
                    over = re.search(r"\bover\s+([\d,]+)\s+(?:applicants|people clicked apply)", head, re.I)
                    if over and not re.search(r"Candidates who clicked apply\s+[\d,]+", main):
                        appl = int(over.group(1).replace(",", "")) + 1
                    out[r["url"]] = {"applicants": appl}
                    from apply import note_pay
                    note_pay(r["url"], main.split("About the job", 1)[-1][:20000])
                    c = CLOSED.search(main[:20000])
                    if c:
                        out[r["url"]]["closed"] = f"job closed ({c.group(0)[:60]})"
                except Exception as e:
                    log(f"   re-check failed ({type(e).__name__}): {r['company']} - {r['title'][:40]}")
    finally:
        log("browser: " + jobapply.close_chrome())
        lock.close()
    return out


def pay_label(rng):
    return f"${rng[0] // 1000}K-${rng[1] // 1000}K" if rng else "no range"


def rank_and_trim(pool, fresh):
    from apply import pay_of, PAY_FLOOR
    import jobseek
    kept, dropped = [], []
    for r in pool:
        now = fresh.get(r["url"], {})
        r["appl_now"] = now.get("applicants", r["appl"] if r["appl"] < 10 ** 6 else None)
        r["pay"] = pay_of(r["url"])
        appl = r["appl_now"]
        age = (dt.datetime.now() - r["seen"]).days if r.get("seen") else None
        if pinned(r):
            (dropped.append((r, now["closed"])) if now.get("closed") else kept.append(r))
            continue
        why = now.get("closed") or \
            (None if r["core"] or appl is None or appl <= ADJ_MAX_APPLICANTS else f"{appl} applicants > {ADJ_MAX_APPLICANTS} (adjacent fit)") or \
            (f"posted base {pay_label(r['pay'])} tops out below the ${PAY_FLOOR // 1000}K floor" if r["pay"] and r["pay"][1] < PAY_FLOOR else None) or \
            (f"queued {age} days ago (> {QUEUE_MAX_DAYS})" if age is not None and age > QUEUE_MAX_DAYS else None)
        (dropped.append((r, why)) if why else kept.append(r))
    rank = lambda r: (not pinned(r), r["appl_now"] is not None and r["appl_now"] > ADJ_MAX_APPLICANTS, r["pay"] is None,
                      -(sum(r["pay"]) if r["pay"] else 0), not r["core"], r["appl_now"] if r["appl_now"] is not None else 10 ** 6)
    kept.sort(key=rank)
    per, out, regular = {}, [], 0
    for r in kept:
        co = re.sub(r"[^a-z0-9]", "", (r.get("company") or "").lower())
        if pinned(r):
            out.append(r)
            continue
        tier = jobseek.top_tier(r.get("company"))
        per[co] = per.get(co, 0) + 1
        if per[co] > max(tier or 0, QUEUE_PER_COMPANY):
            dropped.append((r, f"queue keeps the best {max(tier or 0, QUEUE_PER_COMPANY)} per company"))
        elif not tier and regular >= QUEUE_MAX:
            dropped.append((r, f"queue full ({QUEUE_MAX}) - lower pay / more crowded than the jobs kept"))
        else:
            out.append(r)
            regular += not tier
    return out, dropped


def is_great(r):
    return GREAT_MID_BASE > 0 and bool(r.get("pay")) and (r["pay"][0] + r["pay"][1]) / 2 >= GREAT_MID_BASE


def bypass_why(r):
    import jobseek
    return "great pay" if is_great(r) else ("top tier" if jobseek.top_tier(r.get("company")) else None)


def apply_pool(pool):
    from apply import log_row
    today = dt.date.today().isoformat()
    counted = ("submitted", "submit clicked") + (() if config.AUTO_SUBMIT else ("ready for review",))
    done_today = {u for u, r in latest_by_url(ledger()).items()
                  if r.get("date") == today and (r.get("status") or "").startswith(counted)}
    count = len(done_today)
    fresh = recheck_held(pool) if HELD and not (DRY or SHADOW) else {}
    pool, dropped = rank_and_trim(pool, fresh)
    QUEUE[:] = pool
    for r, why in dropped:
        label = f"{'core' if r['core'] else 'adj '} {r['company'][:22]} - {r['title'][:50]}"
        if not (DRY or SHADOW):
            log_row(date=dt.date.today(), company=r["company"], title=r["title"], url=r["url"], applicants=r["appl_now"] or "",
                    status="skipped", notes=f"dropped from the queue: {why}")
        HOLD_INFO.setdefault("dropped", []).append((label, why))
        log(f"   dropped  {label}: {why}")
    if HELD:
        from referrals import HOLD_STATUS
        great = [r for r in pool if bypass_why(r)]
        HOLD_INFO.update(until=HELD, queued=[], new=[], great=[])
        for r in pool:
            label = f"{'core' if r['core'] else 'adj '} {r['company'][:22]} - {r['title'][:50]}"
            appl = r["appl_now"]
            if r in great:
                HOLD_INFO["great"].append((label, appl, pay_label(r["pay"]), r["url"], bypass_why(r)))
                log(f"   {bypass_why(r).upper()} ({pay_label(r['pay'])}) - trying despite the hold: {label}")
                continue
            if not r["prev"].startswith(HOLD_STATUS) and not (DRY or SHADOW):
                log_row(date=dt.date.today(), company=r["company"], title=r["title"], url=r["url"],
                        applicants=appl or "", status=HOLD_STATUS,
                        notes=f"applying on hold until {HELD} (Apply/HOLD) - queued; applied by the usual rules when it ends")
                HOLD_INFO["new"].append(label)
            HOLD_INFO["queued"].append((label, appl, pay_label(r["pay"])))
            log(f"   held  {label} ({appl if appl is not None else '?'} appl, {pay_label(r['pay'])})")
        log(f"applying on hold: {len(HOLD_INFO['queued'])} queued ({len(HOLD_INFO['new'])} new), "
            f"{len(HOLD_INFO.get('dropped', []))} dropped, {len(great)} great pay / top tier (tried despite the hold)")
        if not great:
            return
        pool = great
    import report
    waiting = len(waiting_reviews())
    if waiting >= report.REVIEW_FULL:
        REVIEWS_FULL.append(waiting)
        log(f"{waiting} applications are waiting for your Submit - no new ones until you check them")
        asks.append((f"{waiting} applications are waiting for your Submit",
                     "New applications start again once you check these. Press \"Finish in browser\" on the dashboard."))
        return
    log(f"already submitted today: {count}/{DAILY_CAP}")
    for r in pool:
        label = f"{'core' if r['core'] else 'adj '} {r['company'][:22]} - {r['title'][:50]} ({r['appl'] if r['appl'] < 10 ** 6 else '?'} appl)"
        if count >= DAILY_CAP:
            if not r["prev"].startswith("queued") and not (DRY or SHADOW):
                log_row(date=dt.date.today(), company=r["company"], title=r["title"], url=r["url"],
                        applicants=r.get("applicants", ""), status="queued: daily cap",
                        notes=f"daily cap {DAILY_CAP} reached - tomorrow's run takes it first if still a fit")
            log(f"   queued  {label}")
            continue
        if DRY or SHADOW:
            log(f"   WOULD APPLY  {label}")
            SHADOW_INFO.append(label)
            count += 1
            continue
        import jobseek
        if jobseek.company_slots_left(r["company"], jobseek.active_by_company(None, ledger())) <= 0:
            if not r["prev"].startswith("waiting: company limit"):
                log_row(date=dt.date.today(), company=r["company"], title=r["title"], url=r["url"],
                        applicants=r.get("applicants", ""), status="waiting: company limit",
                        notes=f"{jobseek.max_active(r['company'])} applications at {r['company']} in {jobseek.WINDOW_DAYS} days (or the employer's own cap)")
            log(f"   waiting (company limit, no browser)  {label}")
            continue
        log(f"   applying {label}")
        with LOGF.open("a", encoding="utf-8") as out:
            subprocess.run([PY, str(HERE / "apply.py"), r["url"], "--unattended"] + ([] if config.AUTO_SUBMIT else ["--no-submit"]),
                           cwd=HERE, timeout=1200,
                           stdout=out, stderr=subprocess.STDOUT,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        st = (latest_by_url(ledger()).get(r["url"]) or {}).get("status", "")
        log(f"      -> {st}")
        if st.startswith(counted):
            count += 1


PRACTICE_MAX = 4
PRACTICE_PROVEN = 10
PRACTICE_LOG = HERE / "runs" / "practice.csv"
PRACTICE_SITES = HERE / "runs" / "practice_sites.json"
NEAR_MISS = re.compile(r"^waiting: (company|employer) limit|^queued|dropped from the (on-hold )?queue: (queue full|queue keeps|"
                       r"\d+ applicants >)|\d+ applicants > \d+|below the \$[\d,]+ base floor", re.I)


def practice_runs(pool):
    import sites
    from collections import Counter
    rows = list(csv.DictReader(PRACTICE_LOG.open(encoding="utf-8"))) if PRACTICE_LOG.exists() else []
    real = ledger()
    seen = {r["company"].lower(): r["ats"].lower() for r in real + rows if r.get("ats") and r.get("company")}
    proven = {a for a, n in Counter((r.get("ats") or "").lower() for r in real
                                    if (r.get("status") or "").startswith("submitted")).items() if a and n >= PRACTICE_PROVEN}

    lately = (dt.date.today() - dt.timedelta(days=60)).isoformat()
    applied = {r["company"].lower() for r in real if (r.get("date") or "") >= lately and r.get("company")
               and re.match(r"submitted|applied|submit clicked", r.get("status") or "")}

    def ground(company):
        a, c = seen.get((company or "").lower()), (company or "").lower()
        return None if c in applied else 0 if a is None else None if a in sites.PRACTICE_NEVER else 2 if a in proven else 1
    done = {r["url"] for r in rows if not (r.get("status") or "").startswith(sites.STATUS)}
    host_of = {r["company"].lower(): sites.host(r["action_url"]) for r in rows if r.get("action_url")}
    keep = sites.FILE
    sites.FILE = PRACTICE_SITES
    try:
        waiting = set(sites._load())
    finally:
        sites.FILE = keep
    if HELD or SHADOW:
        cands = [(r["url"], r["company"]) for r in QUEUE or pool if not bypass_why(r)]
    else:
        since = (dt.date.today() - dt.timedelta(days=14)).isoformat()
        latest = [r for r in latest_by_url(ledger()).values() if (r.get("date") or "") >= since]
        latest.sort(key=lambda r: r.get("date") or "", reverse=True)
        cands = [(r["url"], r["company"]) for r in latest
                 if NEAR_MISS.search(r.get("status") or "") or (r.get("status") or "").startswith("skipped")
                 and NEAR_MISS.search(r.get("notes") or "")]
    picked, companies, tried = [], set(), 0
    ranked = sorted(((ground(c), u, c) for u, c in cands if ground(c) is not None), key=lambda x: x[0])
    todo = [r for r in ranked if r[1] not in done and host_of.get((r[2] or "").lower()) not in waiting]
    log(f"practice: up to {PRACTICE_MAX} of {len(cands)} {'queued' if HELD or SHADOW else 'near-miss'} job(s) - never "
        "submitted" + ("" if todo else " (nothing new to try - a quiet day)"))
    for g, url, company in todo:
        c = (company or "").lower()
        if c in companies or g == 2 and any(p[0] == 2 for p in picked):
            continue
        if len(picked) >= PRACTICE_MAX or tried >= PRACTICE_MAX + 2:
            break
        companies.add(c)
        tried += 1
        with LOGF.open("a", encoding="utf-8") as out:
            subprocess.run([PY, str(HERE / "apply.py"), url, "--practice", "--unattended", "--no-count-check",
                            "--no-company-limit"], cwd=HERE, timeout=900, stdout=out, stderr=subprocess.STDOUT,
                           creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
        now = list(csv.DictReader(PRACTICE_LOG.open(encoding="utf-8"))) if PRACTICE_LOG.exists() else []
        last = next((r for r in reversed(now) if r.get("url") == url), {})
        if not (last.get("status") or "").startswith("skipped"):
            picked.append((g, url, company))
        found = sites.practice_finding(last)
        if found and last.get("action_url"):
            sites.FILE = PRACTICE_SITES
            try:
                sites.mark_practice(last["action_url"], last.get("ats", ""), f"{found}: {(last.get('notes') or '')[:200]}", url)
            finally:
                sites.FILE = keep
        log(f"   practice {company[:22]}: {(last.get('status') or 'no result')[:40]}" + (f" - {found} (reported, waits for the fix)" if found else ""))


def jobseek_sync():
    import jobseek
    cache = jobseek.sync()
    log(f"Job Seek: {len(cache)} messages classified in total")
    from apply import write_ledger
    write_ledger()


def trash_alerts():
    import gmail
    from triage import seen_urls
    m = gmail.connect()
    try:
        done = gmail.processed(gmail.alerts(m), seen_urls())
        n = gmail.trash(m, [a[0] for a in done])
    finally:
        m.logout()
    log(f"moved {n} processed alert emails to Gmail Trash")
    from apply import trash_code_emails
    k = trash_code_emails(older_than_hours=24)
    if k:
        log(f"moved {k} stale security-code email(s) to Gmail Trash")


def waiting_reviews():
    if config.AUTO_SUBMIT:
        return []
    import apply
    return [r for r in apply.pending_signins() if (r.get("status") or "").startswith("ready for review")]


def review_asks(report):
    out = []
    today = dt.date.today().isoformat()
    earlier = [r for r in waiting_reviews() if (r.get("date") or "") < today]
    if earlier and not REVIEWS_FULL:
        out.append((f"{len(earlier)} earlier application{'s are' if len(earlier) > 1 else ' is'} waiting for your Submit",
                    "Press \"Finish in browser\" on the dashboard."))
    n, since = report.review_nudge(list(latest_by_url(ledger()).values()), config.SETTINGS)
    if n and str(config.setting("review_nudge_mailed") or "") <= since:
        out.append(report.nudge_ask(n))
        if not (DRY or SHADOW):
            config.save(review_nudge_mailed=today)
    return out


def filter_asks():
    try:
        import gmail_setup
        due = gmail_setup.filters_due()
    except Exception as e:
        file_failure("new Gmail filters", e)
        return []
    mark = ",".join(due)
    if not due or str(config.setting("filters_mailed") or "") == mark:
        return []
    if not (DRY or SHADOW):
        config.save(filters_mailed=mark)
    return [("Add the new Gmail filters", "Open the dashboard and press \"Add them\".")]


def send_report():
    import report
    hold = None
    if HELD and HOLD_INFO:
        today, latest = dt.date.today().isoformat(), latest_by_url(ledger())
        tried = sum(1 for _l, _a, _p, url, _w in HOLD_INFO.get("great", [])
                    if (latest.get(url) or {}).get("date") == today
                    and not ((latest.get(url) or {}).get("status") or "").startswith(("waiting", "queued")))
        hold = dict(until=HOLD_INFO["until"], new=len(HOLD_INFO["new"]),
                    queued=len(HOLD_INFO["queued"]) + len(HOLD_INFO.get("great", [])) - tried)
    if POSTPONED["short"] and postponed_streak():
        asks.append(postponed_ask(POSTPONED["short"]))
    asks.extend(review_asks(report) + filter_asks())
    r = report.compose(dt.date.today().isoformat(), asks=asks, hold=hold,
                       shadow=list(SHADOW_INFO) if SHADOW else None)
    if not r["anything"]:
        log("nothing applied and nothing needs you - no email (quiet day)")
        return
    d = r["data"]
    needs_me = bool(d["needs"] or d["asks"] or d["inmails"])
    if config.DAILY_EMAIL_MODE == "needs" and not needs_me and not SHADOW:
        out = HERE / "runs" / f"report-{dt.date.today()}.txt"
        out.write_text(r["subject"] + "\n\n" + r["text"], encoding="utf-8")
        log(f"nothing needs you - no email (daily email: only when something needs you); report in {out.name}")
        return
    if not config.DAILY_EMAIL:
        out = HERE / "runs" / f"report-{dt.date.today()}.txt"
        out.write_text(r["subject"] + "\n\n" + r["text"], encoding="utf-8")
        log(f"daily email off - report written to {out.name}")
        return
    report.send(r["subject"], r["text"], r["html"])
    log("report sent: " + r["subject"])


CONFIRM_DAYS = 2


def confirmations():
    import jobseek
    from apply import log_row
    mails = [c for c in jobseek._load().values() if c.get("kind") == "confirmation" and c.get("company")]
    done = late = 0
    for url, r in latest_by_url(ledger()).items():
        if not (r.get("status") or "").startswith("submit clicked") or not r.get("date"):
            continue
        co = jobseek.norm(r.get("company"))
        hit = next((c for c in mails if co and (jobseek.norm(c["company"]) == co or co in jobseek.norm(c["company"]))
                    and (c.get("date") or "")[:10] >= r["date"]), None)
        kw = dict(date=dt.date.today(), company=r.get("company", ""), title=r.get("title", ""), url=url, ats=r.get("ats", ""),
                  category=r.get("category", ""), summary=r.get("summary", ""), action_url=r.get("action_url", ""))
        if hit:
            log_row(**kw, status="submitted", notes=f"confirmed by the employer's email ({hit.get('subject', '')[:90]}, "
                                                    f"{hit['date'][:10]}) - the page showed no confirmation")
            done += 1
        elif (dt.date.today() - dt.date.fromisoformat(r["date"])).days >= CONFIRM_DAYS:
            log_row(**kw, status="needs you", notes=f"Submit was pressed on {r['date']} but no confirmation came (page or "
                                                    "email) - not accepted? Check the employer's site and apply again")
            late += 1
    rows = ledger()
    words = lambda s: {w for w in re.findall(r"[a-z0-9]+", (s or "").lower()) if len(w) > 2 and w not in ("and", "the", "for")}
    mine = 0
    for url, r in latest_by_url(rows).items():
        if not (r.get("status") or "").startswith(("waiting: site not supported", "waiting: site broken", "needs you")):
            continue
        co = jobseek.norm(r.get("company"))
        since = min((x.get("date") or "9999") for x in rows if x.get("url") == url
                    and (x.get("status") or "").startswith(("waiting: site", "needs you")))
        if not co or any(jobseek.norm(x.get("company")) == co and (x.get("status") or "").startswith("submitted")
                         and (x.get("date") or "") >= since for x in rows):
            continue
        t = words(r.get("title"))
        hit = next((c for c in mails if (jobseek.norm(c["company"]) == co or co in jobseek.norm(c["company"]))
                    and (c.get("date") or "")[:10] >= since
                    and (not c.get("role") or len(words(c["role"]) & t) >= max(1, min(len(t), len(words(c["role"]))) // 2))),
                   None)
        if hit:
            log_row(date=dt.date.today(), company=r.get("company", ""), title=r.get("title", ""), url=url,
                    ats=r.get("ats", ""), summary=r.get("summary", ""), status="applied (by you)",
                    notes=f"you applied yourself - the employer's confirmation email ({hit.get('subject', '')[:90]}, "
                          f"{hit['date'][:10]})")
            mine += 1
    log(f"confirmations: {done} confirmed by email, {late} still unconfirmed after {CONFIRM_DAYS} days, "
        f"{mine} applied by you (seen in the employer's email)")


def referral_emails():
    import referrals
    applied, trashed = referrals.run(log=log, dry=DRY, py=PY, logfile=LOGF)
    log(f"referrals: {applied} applied, {trashed} email(s) done")


def recruiter_inmails():
    import referrals
    n = referrals.recruiters(log=log, dry=DRY, py=PY, logfile=LOGF)
    log(f"recruiter InMails: {n} application(s) attempted")


def support_reports():
    sys.path.insert(0, str(HERE / "product"))
    import support
    sent = support.send_new()
    log(f"support reports sent: {len(sent)}" + "".join(f"\n   {s}" for s in sent))


def product_refresh():
    import product_refresh as pr
    log("   " + pr.run(log))


def share_adapters():
    import share_adapters as sa
    n = sa.run(log)
    if n:
        log(f"{n} new adapter(s) mailed to {config.setting('adapter_share_to')}")


def send_weekly():
    import weekly
    subject = weekly.send_if_due()
    log(f"weekly numbers saved (runs/weekly-*.txt): {subject}" if subject else "weekly: not due")


AI_WAIT = {"from": None, "s": 7200, "step": 300}


def ai_wall():
    import llm
    AI_WAIT["from"] = dt.datetime.now()
    short, waited = llm.memory_wall(), 0
    while short and waited < (0 if DRY else AI_WAIT["s"]):
        log(f"   built-in AI: {short['free']} GB free, needs {short['need']} GB - waiting for memory "
            f"({waited // 60} min so far)")
        time.sleep(AI_WAIT["step"])
        waited += AI_WAIT["step"]
        short = llm.memory_wall()
    log(f"   built-in AI: {short['free']} GB free, needs {short['need']} GB - {short['apps']}" if short
        else "   memory: enough for the AI" if llm.builtin() else "   online AI - no check")
    return short


def postpone(short):
    POSTPONED["short"] = short
    log("NOTE " + memory_notice(short)[1])
    if DRY:
        return
    today = dt.date.today().isoformat()
    try:
        days = json.loads(POSTPONED_DAYS.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        days = []
    POSTPONED_DAYS.write_text(json.dumps(sorted(set(days) | {today})[-10:]), encoding="utf-8")
    at = dt.datetime.now() + dt.timedelta(hours=2)
    if at.date().isoformat() == today and at.hour < 21:
        RETRY.write_text(at.isoformat(timespec="minutes"), encoding="utf-8")
        log(f"   the daily run tries again after {at:%H:%M}, once the PC is idle")


def postponed_streak(n=3, today=None):
    try:
        got = set(json.loads(POSTPONED_DAYS.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        return False
    today = today or dt.date.today()
    return all((today - dt.timedelta(days=k)).isoformat() in got for k in range(n))


def postponed_ask(short):
    import machine
    apps = machine.apps_text((short or {}).get("apps") or [])
    return ("The daily run was postponed 3 days in a row",
            "Your PC didn't have enough free memory for the AI" + (f" (using the most: {apps})" if apps else "")
            + ". Close programs you aren't using, or pick another time in Settings > Schedule.")


def clear_postponed():
    if not DRY:
        POSTPONED_DAYS.unlink(missing_ok=True)
        RETRY.unlink(missing_ok=True)


def memory_notice(short):
    import machine
    apps = machine.apps_text(short["apps"])
    start, now = AI_WAIT["from"] or dt.datetime.now(), dt.datetime.now()
    when = f"between {start:%H:%M} and {now:%H:%M}" if (now - start).total_seconds() > 600 else f"at {now:%H:%M}"
    return ("Today's run was postponed",
            f"Your PC didn't have enough free memory {when}: the AI needs about {short['need']} GB and "
            f"{short['free']} GB was free." + (f" Using the most: {apps}." if apps else "")
            + " New jobs carry over to the next run. Closing programs you aren't using fixes it.")


def tidy_runs(runs=None, today=None):
    runs, today, n = Path(runs or HERE / "runs"), today or dt.date.today(), 0
    for f in (runs.iterdir() if runs.exists() else []):
        m = re.match(r"(?:daily-)?(\d{4}-\d{2}-\d{2})", f.name)
        if not (f.is_file() and m):
            continue
        keep = 90 if re.fullmatch(r"daily-[\d-]+\.log|.+_needs-you-form\.json", f.name) else \
            365 if re.search(r"^[\d-]+_\d{4}_.+\.(png|txt)$", f.name) else None
        try:
            old = keep and (today - dt.date.fromisoformat(m.group(1))).days > keep
        except ValueError:
            old = False
        if old:
            f.unlink(missing_ok=True)
            n += 1
    cut = dt.datetime.combine(today, dt.time()).timestamp() - 90 * 86400
    for f in ((runs / "jd").glob("*.txt") if (runs / "jd").exists() else []):
        if f.stat().st_mtime < cut:
            f.unlink(missing_ok=True)
            n += 1
    return n


def tidy():
    n = tidy_runs()
    log(f"tidy: {n} old run file(s) removed (logs + saved forms 90 days, screenshots + form notes 1 year)" if n
        else "tidy: nothing old to remove")


def main():
    log(f"JobBot daily run{' (DRY RUN)' if DRY else ''}{' (SHADOW: read + score + report only)' if SHADOW else ''}")
    try:
        import ctypes
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001)
    except Exception:
        pass
    pause = HERE / "PAUSED"
    if pause.exists():
        until = re.search(r"\d{4}-\d{2}-\d{2}", pause.read_text(encoding="utf-8", errors="ignore") or "")
        if until and dt.date.fromisoformat(until.group(0)) <= dt.date.today():
            pause.unlink()
            log(f"pause ended ({until.group(0)}) - resuming")
        else:
            log("PAUSED (Apply/PAUSED exists" + (f", until {until.group(0)}" if until else "") +
                ") - nothing done; delete the file to resume")
            return
    global HELD
    hold = HERE / "HOLD"
    if hold.exists():
        until = re.search(r"\d{4}-\d{2}-\d{2}", hold.read_text(encoding="utf-8", errors="ignore") or "")
        if until and dt.date.fromisoformat(until.group(0)) <= dt.date.today():
            hold.unlink()
            log(f"hold ended ({until.group(0)}) - applying resumes; the held jobs go first by the usual priority")
        else:
            HELD = until.group(0) if until else "further notice"
            log(f"APPLYING ON HOLD (Apply/HOLD, until {HELD}) - fits are queued, nothing is applied")
    try:
        ids = stage("new alert jobs", new_alert_jobs) or {}
        signin_flag = HERE / "runs" / "linkedin-signin-needed"
        if stage("LinkedIn sign-in check", linkedin_signed_in):
            signin_flag.unlink(missing_ok=True)
            wall = stage("AI memory check", ai_wall)
            if wall:
                postpone(wall)
            else:
                if not SHADOW:
                    stage("referral emails", referral_emails)
                    stage("recruiter InMails", recruiter_inmails)
                stage("score", score, ids)
                pool = stage("pool", build_pool) or []
                stage("apply", apply_pool, pool)
                if config.setting("practice", True) and config.setting("support_to") and not DRY:
                    stage("practice", practice_runs, pool)
                if not POSTPONED["short"]:
                    clear_postponed()
        else:
            asks.append(("Sign in to LinkedIn", "Press \"Finish in browser\" on the dashboard to sign in."))
            log("ERROR signed out of LinkedIn")
            if not DRY:
                signin_flag.write_text(dt.datetime.now().isoformat(timespec="seconds"), encoding="utf-8")
        if not DRY:
            stage("Job Seek sync", jobseek_sync)
            if not SHADOW:
                stage("confirmations", confirmations)
                stage("trash processed alerts", trash_alerts)
                if (HERE / "product_refresh.py").exists():
                    stage("product refresh", product_refresh)
            stage("report", send_report)
            if not SHADOW and config.setting("support_reports", False) and (HERE / "product" / "support.py").exists():
                stage("support reports", support_reports)
            if not SHADOW:
                if (HERE / "weekly.py").exists():
                    stage("weekly numbers", send_weekly)
                stage("share new adapters", share_adapters)
            stage("tidy", tidy)
    finally:
        import jobapply
        log("browser: " + jobapply.close_chrome())
        log("done" + (f" with {len(problems)} problem(s)" if problems else ""))


if __name__ == "__main__":
    main()
