import datetime as dt
import hashlib
import json
import re
from pathlib import Path
from urllib.parse import urlparse

HERE = Path(__file__).resolve().parent
FILE = HERE / "runs" / "broken_sites.json"
FAILS_TO_BREAK = 2
WAIT_DAYS = 3
STATUS = "waiting: site broken"
TECHNICAL = re.compile(r"no adapter|unsupported site|not accepted|traceback|exception|timed? ?out|failed|crash|"
                       r"could not (?:fill|find|click|read)|selector|unexpected|stuck on|too many pages|"
                       r"does not go past|shows no error|keeps failing", re.I)
USERS_OWN = re.compile(r"sign-?in|captcha|bot check|verification code|security code|password|"
                       r"create (an |the )?account|ready for review|your call|easy apply|employer limit|company limit|on hold",
                       re.I)


def technical(reason):
    return bool(TECHNICAL.search(reason or "")) and not USERS_OWN.search(reason or "")


def host(url):
    h = urlparse(url if "//" in (url or "") else f"//{url}").netloc.lower()
    return h[4:] if h.startswith("www.") else h


def app_version():
    v = HERE / "VERSION.txt"
    if v.exists():
        return v.read_text(encoding="utf-8").strip()
    h = hashlib.sha1((HERE / "apply.py").read_bytes())
    for f in sorted((HERE / "adapters").glob("*")) if (HERE / "adapters").is_dir() else []:
        if f.is_file():
            h.update(f.name.encode() + f.read_bytes())
    return "dev " + h.hexdigest()[:12]


def _load():
    try:
        d = json.loads(FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}
    ver = app_version()
    return {k: v for k, v in d.items() if v.get("version") == ver}


def _save(d):
    FILE.parent.mkdir(parents=True, exist_ok=True)
    FILE.write_text(json.dumps(d, indent=1), encoding="utf-8")


def is_broken(url_or_host):
    try:
        e = _load().get(host(url_or_host))
    except Exception:
        return None
    return e if e and e.get("fails", 0) >= FAILS_TO_BREAK else None


def note_failure(url_or_host, ats, reason, job=""):
    if not technical(reason):
        return False
    d, h = _load(), host(url_or_host)
    if not h:
        return False
    e = d.setdefault(h, {"version": app_version(), "ats": ats, "fails": 0, "first": dt.date.today().isoformat(), "jobs": []})
    e["fails"] += 1
    e["reason"], e["last"] = reason[:300], dt.date.today().isoformat()
    if job and job not in e["jobs"]:
        e["jobs"].append(job)
    _save(d)
    return e["fails"] == FAILS_TO_BREAK


PRACTICE_SIGNIN = {"workday", "icims", "oracle", "google", "eightfold"}
PRACTICE_NEVER = PRACTICE_SIGNIN | {"linkedin easy"}


def practice_finding(row):
    st, notes = (row.get("status") or "").lower(), row.get("notes") or ""
    if "practice guard - submit attempt" in notes.lower():
        return "submit attempt blocked"
    if "checked before submit" in notes.lower():
        return "second reader doubt"
    if st.startswith(("error", "waiting: site not supported", "waiting: site broken")):
        return st.split("(")[0].strip()[:40]
    if st.startswith("needs you"):
        if re.search(r"questions left for you", notes, re.I):
            return "questions left"
        return None if USERS_OWN.search(notes) else "stopped"
    return None


def mark_practice(url_or_host, ats, why, job=""):
    d, h = _load(), host(url_or_host)
    if not h:
        return
    d[h] = {"version": app_version(), "ats": ats, "fails": FAILS_TO_BREAK, "first": dt.date.today().isoformat(),
            "last": dt.date.today().isoformat(), "reason": (why or "")[:300], "jobs": [job] if job else []}
    _save(d)


def waited_days(ledger_rows, url, status=STATUS):
    first = min((r.get("date") or "" for r in ledger_rows if r.get("url") == url and (r.get("status") or "").startswith(status)),
                default="")
    return (dt.date.today() - dt.date.fromisoformat(first)).days if first else 0


if __name__ == "__main__":
    d = _load()
    print(f"version {app_version()}: " + ("; ".join(f"{h} ({e['ats']}): {e['fails']} failures, last {e['last']} - {e['reason'][:100]}"
                                                    for h, e in d.items()) or "no site marked"))
