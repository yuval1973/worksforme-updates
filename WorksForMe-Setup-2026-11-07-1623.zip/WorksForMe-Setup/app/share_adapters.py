import hashlib
import io
import json
import re
import smtplib
import sys
import zipfile
from email.mime.application import MIMEApplication
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import config

DIR = HERE / "adapters"
LOG = DIR / "shared.json"


def personal_markers():
    try:
        P = json.loads((HERE / "applicant.json").read_text(encoding="utf-8-sig"))
    except (OSError, ValueError):
        return []
    idn, loc = P.get("identity", {}), P.get("location", {})
    vals = [idn.get("first_name"), idn.get("last_name"), idn.get("preferred_name"), idn.get("email"), idn.get("linkedin"),
            loc.get("street_address"), loc.get("zip"), config.EMAIL]
    return [str(v).strip() for v in vals if v and len(str(v).strip()) >= 3]


def leaks(text):
    hits = [m for m in personal_markers() if re.search(rf"(?<![\w@.]){re.escape(m)}(?![\w])", text, re.I)]
    try:
        P = json.loads((HERE / "applicant.json").read_text(encoding="utf-8-sig"))
        digits = re.sub(r"\D", "", str(P["identity"].get("phone_digits") or P["identity"].get("phone") or ""))
    except (OSError, ValueError, KeyError):
        digits = ""
    if len(digits) >= 7 and digits[-7:] in re.sub(r"\D", "", text):
        hits.append("phone number")
    return hits


def candidates():
    import apply
    out = []
    for f in sorted(DIR.glob("*.py")) if DIR.is_dir() else []:
        if f.name.startswith(("_", ".")):
            continue
        meta = next(({"name": n, **p} for n, p in apply.PLUGINS.items() if p["file"] == f.name), None)
        if meta:
            out.append((f, meta))
    return out


def package(f, meta):
    text = f.read_text(encoding="utf-8")
    tested = re.search(r"^TESTED_ON\s*=\s*[\"']([^\"']+)", text, re.M)
    readme = (f"{config.APP_NAME} adapter plugin: {meta['name']} v{meta['version']}\nHosts: {meta['hosts'].pattern}\n"
              f"Tested on: {tested.group(1) if tested else '(not stated)'}\nFrom: {config.setting('owner', '')}\n\n"
              f"Install: save this zip in the adapters folder of the program - it loads on the next run.\n")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr(f.name, text)
        z.writestr("README.txt", readme)
    return buf.getvalue(), readme


def run(log=print, dry=False):
    to = str(config.setting("adapter_share_to", "") or "").strip()
    if not to:
        return 0
    try:
        sent = json.loads(LOG.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        sent = {}
    n = 0
    for f, meta in candidates():
        text = f.read_text(encoding="utf-8")
        digest = hashlib.sha256(text.encode()).hexdigest()[:16]
        key = f"{meta['name']} v{meta['version']}"
        if sent.get(key, {}).get("sha") == digest:
            continue
        if key in sent:
            log(f"adapter {key} changed but kept VERSION {meta['version']} - raise VERSION to share the new one")
            continue
        if not re.search(r"^TESTED_ON\s*=\s*[\"']https?://", text, re.M):
            log(f"adapter {key} not shared yet: no TESTED_ON (set it once it has filled a real form - ADAPTERS.md)")
            continue
        hits = leaks(text)
        if hits:
            log(f"adapter {key} NOT shared: it contains your personal details ({len(hits)} found) - they belong in "
                f"applicant.json, not in the adapter (ask Claude Code to move them, see ADAPTERS.md)")
            continue
        blob, readme = package(f, meta)
        name = f"{meta['name']}-v{meta['version']}.zip"
        if dry:
            log(f"WOULD share {name} -> {to}")
            continue
        msg = MIMEMultipart()
        msg["Subject"] = f"{config.APP_NAME} adapter: {meta['name']} v{meta['version']}"
        msg["From"], msg["To"] = config.EMAIL, to
        msg.attach(MIMEText(readme, "plain", "utf-8"))
        part = MIMEApplication(blob, Name=name)
        part["Content-Disposition"] = f'attachment; filename="{name}"'
        msg.attach(part)
        import vault
        with smtplib.SMTP("smtp.gmail.com", 587, timeout=30) as s:
            s.starttls()
            s.login(config.EMAIL, vault.get("EMAIL_PASS"))
            s.sendmail(config.EMAIL, [to], msg.as_string())
        sent[key] = {"sha": digest, "to": to, "file": f.name}
        LOG.write_text(json.dumps(sent, indent=1), encoding="utf-8")
        log(f"shared adapter {name} -> {to}")
        n += 1
    return n


if __name__ == "__main__":
    run(dry="--dry-run" in sys.argv)
