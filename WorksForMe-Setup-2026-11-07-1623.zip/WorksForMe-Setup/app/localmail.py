import email
import hashlib
import html
import json
import re
import sqlite3
import time
from email.header import decode_header, make_header
from email.utils import parsedate_to_datetime
from pathlib import Path

import config

INBOX, ALL, TRASH = "INBOX", "[Gmail]/All Mail", "[Gmail]/Trash"
KEEP_DAYS, TRASH_DAYS, TEXT_MAX = 150, 30, 12000
CHECK = re.compile(r"wfm-check-([a-z0-9]{8,40})")
INLINE_TAG = re.compile(r"(?i)</?(span|b|i|u|a|strong|em|font|small|sup|sub|mark|abbr|code|wbr)\b[^>]*>")
ASKED = re.compile(r"([\w.+'-]+@[\w-]+(?:\.[\w-]+)+) has requested to automatically forward mail")


def root():
    return Path(config.HERE) / "runs" / "mail"


def _dec(v):
    try:
        return str(make_header(decode_header(v or "")))
    except Exception:
        return str(v or "")


def norm_label(name):
    return re.sub(r"[\s/]+", "-", str(name or "").strip().lower())


def _attachment_text(part):
    data, name = part.get_payload(decode=True) or b"", (part.get_filename() or "").lower()
    try:
        if part.get_content_type() == "application/pdf" or name.endswith(".pdf"):
            import io
            import pypdf
            pages = pypdf.PdfReader(io.BytesIO(data)).pages[:6]
            return " ".join((p.extract_text() or "") for p in pages)
        if name.endswith(".docx"):
            import io
            import zipfile
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                return re.sub(r"<[^>]+>", " ", z.read("word/document.xml").decode("utf-8", "replace"))
    except Exception:
        return ""
    return ""


def _body_text(msg):
    out = []
    for part in msg.walk():
        if part.is_multipart():
            continue
        if part.get_filename() and part.get_content_maintype() != "text":
            out.append(_attachment_text(part)[:TEXT_MAX])
            continue
        if part.get_content_maintype() == "text" or part.get_content_type() == "application/ics":
            try:
                s = (part.get_payload(decode=True) or b"").decode(part.get_content_charset() or "utf-8", "replace")
            except LookupError:
                s = (part.get_payload(decode=True) or b"").decode("utf-8", "replace")
            if part.get_content_type() == "text/html":
                s = re.sub(r"(?is)<(script|style)\b.*?</\1>", " ", s)
                s = html.unescape(re.sub(r"<[^>]+>", " ", INLINE_TAG.sub("", s)))
            out.append(s)
        if sum(len(x) for x in out) > TEXT_MAX:
            break
    return re.sub(r"\s+", " ", " ".join(out))[:TEXT_MAX]


def view(raw, arrived=None):
    msg = email.message_from_bytes(raw)
    frm, subj = _dec(msg.get("From")), _dec(msg.get("Subject"))
    to = " ".join(_dec(msg.get(h)) for h in ("To", "Cc", "Delivered-To", "X-Forwarded-To", "X-Original-To"))
    try:
        ts = parsedate_to_datetime(msg.get("Date")).timestamp()
    except Exception:
        ts = None
    arrived = arrived or time.time()
    fwd = re.search(r"[\w.+'-]+@[\w-]+(?:\.[\w-]+)+", _dec(msg.get("X-Forwarded-For")))
    return {"from": frm.lower(), "to": to.lower(), "subject": subj, "msgid": str(msg.get("Message-ID") or "").strip(),
            "date": ts or arrived, "arrived": arrived, "att": any(p.get_filename() for p in msg.walk()),
            "fwd": fwd.group(0).lower() if fwd else "", "text": " ".join((subj, frm, to, _body_text(msg))).lower()}


def _tokens(q):
    out, i, n = [], 0, len(q)
    while i < n:
        c = q[i]
        if c.isspace():
            i += 1
        elif c in "(){}":
            out.append(c)
            i += 1
        elif c == "-" and i + 1 < n and not q[i + 1].isspace():
            out.append("-")
            i += 1
        elif c == '"':
            j, buf = i + 1, []
            while j < n and q[j] != '"':
                if q[j] == "\\" and j + 1 < n:
                    buf.append(q[j + 1])
                    j += 2
                    continue
                buf.append(q[j])
                j += 1
            out.append(("P", "".join(buf)))
            i = j + 1
        else:
            j = i
            while j < n and not q[j].isspace() and q[j] not in '(){}"':
                j += 1
            out.append(("W", q[i:j]))
            i = j
    return out


class _Parser:
    def __init__(self, q):
        self.t, self.i = _tokens(q), 0

    def peek(self):
        return self.t[self.i] if self.i < len(self.t) else None

    def take(self):
        tok = self.peek()
        self.i += 1
        return tok

    def close(self, c):
        if self.peek() == c:
            self.take()

    def any_(self, field=None):
        parts = []
        while self.peek() is not None and self.peek() not in (")", "}"):
            if self.peek() == ("W", "OR"):
                self.take()
                continue
            parts.append(self.or_(field))
        return parts[0] if len(parts) == 1 else ("and", parts)

    def or_(self, field=None):
        parts = [self.one(field)]
        while self.peek() == ("W", "OR"):
            self.take()
            if self.peek() is None or self.peek() in (")", "}"):
                break
            parts.append(self.one(field))
        return parts[0] if len(parts) == 1 else ("or", parts)

    def one(self, field):
        if self.peek() == "-":
            self.take()
            return ("not", self.one(field))
        tok = self.take()
        if tok == "(":
            e = self.any_(field)
            self.close(")")
            return e
        if tok == "{":
            parts = []
            while self.peek() not in ("}", None):
                parts.append(self.one(field))
            self.close("}")
            return ("or", parts)
        if tok in (")", "}"):
            return ("and", [])
        kind, val = tok
        if kind == "W" and re.fullmatch(r"[a-z_]+:", val, re.I):
            f, nxt = val[:-1].lower(), self.peek()
            if nxt == "(":
                self.take()
                e = self.any_(f)
                self.close(")")
                return e
            if isinstance(nxt, tuple) and nxt[0] == "P":
                self.take()
                return ("term", f, nxt[1])
            return ("term", f, "")
        if kind == "W" and re.match(r"[a-z_]+:", val, re.I):
            f, v = val.split(":", 1)
            return ("term", f.lower(), v)
        return ("term", field, val)


def parse(q):
    return _Parser(q or "").any_()


def _words(term, text):
    t = re.escape(term.lower().strip()).replace(r"\ ", r"\s+")
    return bool(t) and re.search(rf"(?<![a-z0-9]){t}(?![a-z0-9])", text) is not None


def _age(v):
    m = re.fullmatch(r"(\d+)([dmy]?)", v.strip().lower())
    if not m:
        return None
    return int(m.group(1)) * {"": 1, "d": 1, "m": 30, "y": 365}[m.group(2)] * 86400


def match(node, v, labels, trash, now=None):
    kind = node[0]
    if kind == "and":
        return all(match(x, v, labels, trash, now) for x in node[1])
    if kind == "or":
        return any(match(x, v, labels, trash, now) for x in node[1])
    if kind == "not":
        return not match(node[1], v, labels, trash, now)
    _, field, val = node
    low = val.lower()
    if field == "from":
        pre = r"(?<![a-z0-9])" if low[:1].isalnum() else ""
        post = r"(?![a-z0-9])" if low[-1:].isalnum() else ""
        return bool(low) and re.search(pre + re.escape(low) + post, v["from"]) is not None
    if field in ("to", "cc", "deliveredto"):
        return low in v["to"]
    if field == "subject":
        return _words(low, v["subject"].lower())
    if field in ("newer_than", "older_than"):
        age = _age(low)
        if age is None:
            return False
        newer = v["arrived"] >= (now or time.time()) - age
        return newer if field == "newer_than" else not newer
    if field == "in":
        return {"inbox": INBOX in labels and not trash, "trash": trash, "anywhere": True}.get(low, False)
    if field == "label":
        return norm_label(val) in {norm_label(x) for x in labels}
    if field == "rfc822msgid":
        return low.strip("<>") == v["msgid"].lower().strip("<>")
    if field == "has":
        return low == "attachment" and v["att"]
    return _words(f"{field}:{val}" if field else val, v["text"])


SEEK = []
CODE_MAIL = re.compile(r"security code|verification code|one[- ]time (pass)?code|confirm your identity|"
                       r"identity verification|verify your (email|identity)", re.I)


def labels_for(v):
    import gmail_setup
    skip = bool(config.setting("job_mail_skip_inbox", False))
    alerts = re.search(r"jobalerts-noreply@linkedin\.com|jobs-noreply@linkedin\.com", v["from"])
    labels = set() if alerts and "application" not in v["text"] else {INBOX}
    if alerts and "application" not in v["text"]:
        labels.add(config.LINKEDIN_FOLDER)
    if not SEEK:
        SEEK.extend(parse(gmail_setup.rule_query(r)) for r in gmail_setup.seek_rules())
    seek = any(match(q, v, labels, False) for q in SEEK) and "jobalerts-noreply@linkedin.com" not in v["from"] \
        and not CODE_MAIL.search(v["subject"])
    if seek:
        labels.add(config.JOB_SEEK_FOLDER)
        if skip:
            labels.discard(INBOX)
    return sorted(labels)


def _in(folder, labels, trash):
    if folder == TRASH:
        return trash
    if trash:
        return False
    if folder == ALL:
        return True
    if folder.upper() == INBOX:
        return INBOX in labels
    return norm_label(folder) in {norm_label(l) for l in labels}


class Store:
    def __init__(self, base=None):
        self.base = Path(base or root())
        self.base.mkdir(parents=True, exist_ok=True)
        self.db = sqlite3.connect(str(self.base / "mail.db"), timeout=60, isolation_level=None)
        self.db.execute("PRAGMA auto_vacuum = INCREMENTAL")
        self.db.execute("PRAGMA journal_mode = WAL")
        self.db.execute("CREATE TABLE IF NOT EXISTS msgs (uid INTEGER PRIMARY KEY AUTOINCREMENT, sha TEXT UNIQUE NOT NULL, "
                        "labels TEXT NOT NULL, trash INTEGER NOT NULL DEFAULT 0, trashed REAL, arrived REAL NOT NULL, "
                        "view TEXT NOT NULL, raw BLOB NOT NULL)")
        self.db.execute("CREATE TABLE IF NOT EXISTS labels (name TEXT PRIMARY KEY)")

    def close(self):
        self.db.close()

    def labels(self):
        have = {r[0] for r in self.db.execute("SELECT name FROM labels")}
        for (ls,) in self.db.execute("SELECT DISTINCT labels FROM msgs"):
            have.update(json.loads(ls))
        return sorted(l for l in have if l != INBOX)

    def add_label(self, name):
        if name:
            self.db.execute("INSERT OR IGNORE INTO labels (name) VALUES (?)", (name,))

    def add(self, raw, arrived=None, v=None):
        v = v or view(raw, arrived)
        cur = self.db.execute("INSERT OR IGNORE INTO msgs (sha, labels, arrived, view, raw) VALUES (?, ?, ?, ?, ?)",
                              (hashlib.sha256(raw).hexdigest(), json.dumps(labels_for(v)), v["arrived"], json.dumps(v), raw))
        return cur.lastrowid if cur.rowcount == 1 else None

    def get(self, uid):
        r = self.db.execute("SELECT labels, trash, view FROM msgs WHERE uid = ?", (int(uid),)).fetchone()
        return {"labels": json.loads(r[0]), "trash": bool(r[1]), "view": json.loads(r[2])} if r else None

    def raw(self, uid):
        r = self.db.execute("SELECT raw FROM msgs WHERE uid = ?", (int(uid),)).fetchone()
        return bytes(r[0]) if r else None

    def entries(self, folder):
        out = []
        for uid, ls, trash, v in self.db.execute("SELECT uid, labels, trash, view FROM msgs ORDER BY uid"):
            labels = json.loads(ls)
            if _in(folder, labels, bool(trash)):
                out.append((str(uid), labels, bool(trash), json.loads(v)))
        return out

    def uids(self, folder):
        return [str(uid) for uid, ls, trash in self.db.execute("SELECT uid, labels, trash FROM msgs ORDER BY uid")
                if _in(folder, json.loads(ls), bool(trash))]

    def views(self, since):
        return [json.loads(v) for (v,) in self.db.execute("SELECT view FROM msgs WHERE arrived >= ? ORDER BY uid", (since,))]

    def move(self, uids, target, move, current):
        self.db.execute("BEGIN IMMEDIATE")
        try:
            for u in uids:
                m = self.get(u)
                if not m:
                    continue
                if target == TRASH:
                    self.db.execute("UPDATE msgs SET trash = 1, trashed = ? WHERE uid = ?", (time.time(), int(u)))
                    continue
                labels = m["labels"]
                if move and current not in (ALL, TRASH):
                    labels = [l for l in labels if norm_label(l) != norm_label(current)]
                if target not in labels:
                    labels.append(target)
                self.db.execute("UPDATE msgs SET labels = ? WHERE uid = ?", (json.dumps(labels), int(u)))
            self.db.execute("COMMIT")
        except Exception:
            self.db.execute("ROLLBACK")
            raise

    def purge(self, now=None):
        now = now or time.time()
        self.db.execute("DELETE FROM msgs WHERE arrived < ? OR (trash = 1 AND trashed < ?)",
                        (now - KEEP_DAYS * 86400, now - TRASH_DAYS * 86400))
        self.db.execute("PRAGMA incremental_vacuum")


def _unquote(s):
    s = (s.decode() if isinstance(s, bytes) else str(s)).strip()
    if len(s) >= 2 and s[0] == s[-1] == '"':
        s = s[1:-1].replace('\\"', '"').replace("\\\\", "\\")
    return s


def _headers(raw, names):
    head = raw.split(b"\r\n\r\n", 1)[0] if b"\r\n\r\n" in raw else raw.split(b"\n\n", 1)[0]
    lines, out = re.split(rb"\r?\n", head), []
    keep = False
    for line in lines:
        if line[:1] in (b" ", b"\t"):
            if keep:
                out.append(line)
            continue
        keep = line.split(b":", 1)[0].strip().lower().decode(errors="replace") in names
        if keep:
            out.append(line)
    return b"\r\n".join(out) + b"\r\n\r\n"


class Box:
    def __init__(self, store):
        self.s, self.cur = store, INBOX

    def list(self, *a):
        rows = [(r"\HasNoChildren", INBOX), (r"\All \HasNoChildren", ALL), (r"\Trash \HasNoChildren", TRASH)]
        rows += [(r"\HasNoChildren", l) for l in self.s.labels()]
        return "OK", [f'({f}) "/" "{n}"'.encode() for f, n in rows]

    def select(self, mailbox=INBOX, readonly=False):
        self.cur = _unquote(mailbox)
        return "OK", [str(len(self.s.uids(self.cur))).encode()]

    def create(self, mailbox):
        self.s.add_label(_unquote(mailbox))
        return "OK", [b"Success"]

    def uid(self, command, *args):
        command = command.upper()
        if command == "SEARCH":
            return "OK", [" ".join(self._search([a for a in args if a is not None])).encode()]
        if command == "FETCH":
            return self._fetch(args[0], str(args[1]))
        if command in ("MOVE", "COPY"):
            return self._move(args[0], _unquote(args[1]), command == "MOVE")
        return "OK", [None]

    def _search(self, args):
        key = str(args[0]).upper() if args else "ALL"
        if key == "X-GM-RAW":
            tree, now = parse(_unquote(args[1])), time.time()
            return [u for u, labels, trash, v in self.s.entries(self.cur) if match(tree, v, labels, trash, now)]
        if key == "HEADER" and len(args) >= 3 and str(args[1]).lower() == "message-id":
            want = _unquote(args[2]).strip("<>").lower()
            return [u for u, _l, _t, v in self.s.entries(self.cur) if v["msgid"].strip("<>").lower() == want]
        return self.s.uids(self.cur)

    def _fetch(self, uid, spec):
        u = (uid.decode() if isinstance(uid, bytes) else str(uid)).split(",")[0].strip()
        raw = self.s.raw(u) if u.isdigit() else None
        if raw is None:
            return "OK", [None]
        m = re.search(r"HEADER\.FIELDS\s*\(([^)]*)\)", spec, re.I)
        data = _headers(raw, {n.lower() for n in m.group(1).split()}) if m else raw
        what = f"BODY[HEADER.FIELDS ({m.group(1).upper()})]" if m else "BODY[]"
        return "OK", [(f"{u} (UID {u} {what} {{{len(data)}}}".encode(), data), b")"]

    def _move(self, uids, target, move):
        ids = [x.strip() for x in (uids.decode() if isinstance(uids, bytes) else str(uids)).split(",") if x.strip().isdigit()]
        self.s.move(ids, target, move, self.cur)
        return "OK", [None]

    def logout(self):
        self.s.close()
        return "BYE", [b"done"]

    def close(self):
        return "OK", [None]


def sync(store, log=None):
    import fwdmail
    acct = fwdmail.account()
    if not acct:
        return 0
    got, codes = 0, set()
    for _ in range(40):
        items = fwdmail.fetch(acct)
        if not items:
            break
        for key, raw in items:
            if raw is None:
                continue
            v = view(raw, _arrived(key))
            if store.add(raw, v=v):
                got += 1
            codes.update(CHECK.findall(v["text"]))
        fwdmail.ack([k for k, _ in items], acct)
        if len(items) < 25:
            break
    for c in codes:
        fwdmail.confirm("WFM-CHECK-" + c, acct)
    return got


def _recent_views(days):
    s = Store()
    try:
        return s.views(time.time() - days * 86400)
    finally:
        s.close()


def confirm_codes(days=7):
    import fwdmail
    codes = {c for v in _recent_views(days) for c in CHECK.findall(v["text"])}
    return any(fwdmail.confirm("WFM-CHECK-" + c).get("verified") for c in codes)


def forwarded_from(days=7):
    seen = [v["fwd"] for v in _recent_views(days) if v.get("fwd")]
    return seen[-1] if seen else ""


def asked_from(days=7):
    for v in reversed(_recent_views(days)):
        m = ASKED.search(v["text"]) if "forwarding-noreply@google.com" in v["from"] else None
        if m:
            return m.group(1)
    return ""


def mailbox_of(addr):
    s = str(addr or "").strip().lower()
    if "<" in s:
        s = s[s.rfind("<") + 1:].split(">")[0]
    local, _, domain = s.rpartition("@")
    local = local.split("+")[0]
    if not local or "." not in domain:
        return ""
    if domain in ("gmail.com", "googlemail.com"):
        return local.replace(".", "") + "@gmail.com"
    return f"{local}@{domain}"


def same_mailbox(a, b):
    return bool(mailbox_of(a)) and mailbox_of(a) == mailbox_of(b)


def _arrived(key):
    m = re.search(r":(\d{13})-", key or "")
    return int(m.group(1)) / 1000 if m else None


def connect(log=None):
    s = Store()
    try:
        sync(s)
    except Exception as e:
        if log:
            log(f"mail service: {e}")
    s.purge()
    return Box(s)


def folders():
    s = Store()
    try:
        return [INBOX] + s.labels()
    finally:
        s.close()
