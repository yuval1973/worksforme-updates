import email
import imaplib
import re
import sys
from email.header import decode_header, make_header

import config
from report import app_password


ALERTS = ('from:(jobalerts-noreply@linkedin.com OR jobs-noreply@linkedin.com) -subject:application '
          '-in:trash newer_than:14d')

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def forwarded():
    return config.setting("mail_source") == "forward"


def folders():
    if forwarded():
        import localmail
        return localmail.folders()
    m = imaplib.IMAP4_SSL("imap.gmail.com", timeout=15)
    try:
        m.login(config.EMAIL, app_password())
        names = []
        for line in m.list()[1]:
            s = line.decode(errors="replace")
            if "\\Noselect" in s:
                continue
            name = s.rsplit(' "/" ', 1)[-1].strip().strip('"')
            if not re.match(r"\[(Gmail|Google Mail|Imap)\]|(Drafts|Junk E-?mail|Deleted Items|Sent Items|Outbox|Trash|"
                            r"Spam|Notes|Conversation History)$", name, re.I):
                names.append(name)
        return sorted(names, key=lambda n: (n != "INBOX", n.lower()))
    finally:
        try:
            m.logout()
        except Exception:
            pass


def connect(tries=4):
    import time
    if forwarded():
        import localmail
        return localmail.connect()
    for k in range(tries):
        try:
            m = imaplib.IMAP4_SSL("imap.gmail.com", timeout=60)
            m.login(config.EMAIL, app_password())
            return m
        except (OSError, imaplib.IMAP4.abort) as e:
            if k == tries - 1:
                raise
            time.sleep(10 * (k + 1))


def special(m, flag):
    for line in m.list()[1]:
        s = line.decode()
        if flag in s:
            return re.search(r'"([^"]+)"\s*$', s).group(1)
    raise RuntimeError(f"no {flag} folder")


def recent_alert_count(m, days=2):
    q = f"from:jobalerts-noreply@linkedin.com newer_than:{days}d"
    n = 0
    for box in ("All", "Trash"):
        m.select(f'"{special(m, chr(92) + box)}"', readonly=True)
        n += len(m.uid("SEARCH", "X-GM-RAW", f'"{q}"')[1][0].split())
    return n


def alerts(m, dedupe=False):
    m.select(f'"{special(m, chr(92) + "All")}"', readonly=True)
    uids = m.uid("SEARCH", "X-GM-RAW", f'"{ALERTS}"')[1][0].split()
    out, seen_ids = [], set()
    for uid in uids:
        msg = email.message_from_bytes(m.uid("FETCH", uid, "(BODY.PEEK[])")[1][0][1])
        if dedupe and msg["Message-ID"] in seen_ids:
            continue
        seen_ids.add(msg["Message-ID"])
        body = "".join(p.get_payload(decode=True).decode(p.get_content_charset() or "utf-8", "replace")
                       for p in msg.walk() if p.get_content_type() in ("text/html", "text/plain"))
        ids = list(dict.fromkeys(re.findall(r"jobs/view/(\d+)", body)))
        out.append((uid.decode(), msg["Date"], " ".join(str(make_header(decode_header(msg["Subject"] or ""))).split()), ids))
    return out


def trash(m, uids):
    if not uids:
        return 0
    m.select(f'"{special(m, chr(92) + "All")}"')
    typ, _ = m.uid("MOVE", ",".join(uids), f'"{special(m, chr(92) + "Trash")}"')
    if typ != "OK":
        raise RuntimeError(f"IMAP MOVE failed: {typ}")
    return len(uids)


def processed(alert_list, seen):
    return [a for a in alert_list if a[3] and all(j in seen for j in a[3])]


if __name__ == "__main__":
    from triage import seen_urls
    m = connect()
    try:
        al, seen = alerts(m), seen_urls()
        done = processed(al, seen)
        for uid, date, subj, ids in al:
            mark = "done" if (uid, date, subj, ids) in done else f"{sum(j not in seen for j in ids)} new"
            print(f"{uid:>7} | {date[:22]:22} | {len(ids):2} jobs | {mark:6} | {subj[:60]}")
        if "--trash-processed" in sys.argv:
            print("moved to Trash:", trash(m, [a[0] for a in done]))
    finally:
        m.logout()
