import json
import os
import re
from pathlib import Path

HERE = Path(__file__).parent


def _load(name):
    f = HERE / name
    return json.loads(f.read_text(encoding="utf-8-sig")) if f.exists() else {}


SETTINGS = _load("settings.json")
TARGETS = _load("targets.json")


def path(value):
    p = Path(os.path.expandvars(str(value)))
    return p if p.is_absolute() else (HERE / p).resolve()


def save(**kw):
    f = HERE / "settings.json"
    s = json.loads(f.read_text(encoding="utf-8-sig")) if f.exists() else {}
    s.update(kw)
    tmp = f.with_suffix(".json.tmp")
    tmp.write_text(json.dumps(s, indent=1, ensure_ascii=False), encoding="utf-8")
    tmp.replace(f)
    SETTINGS.update(kw)


def setting(key, default=None):
    node = SETTINGS
    for part in key.split("."):
        if not isinstance(node, dict) or part not in node:
            return default
        node = node[part]
    return node


EMAIL = setting("email", "")
REPORT_TO = setting("report_to", EMAIL)
DEFAULT_JOB_SEEK_FOLDER = "WorksForMe/Conversations"
DEFAULT_LINKEDIN_FOLDER = "WorksForMe/LinkedIn Alerts"
JOB_SEEK_FOLDER = setting("job_seek_folder", DEFAULT_JOB_SEEK_FOLDER)
LINKEDIN_FOLDER = setting("linkedin_folder", DEFAULT_LINKEDIN_FOLDER)
CHROME_EXE = setting("chrome_exe", r"C:\Program Files\Google\Chrome\Application\chrome.exe")
BROWSER_HOME = path(setting("browser_home", r"%USERPROFILE%\JobApply"))
PORT_CHROME = int(setting("ports.chrome", 9444))
PORT_AGENT = int(setting("ports.agent", 9445))
PORT_LOCK = int(setting("ports.lock", 9446))
RUN_AT = setting("daily_run.at", "06:00")
IDLE_MIN = int(setting("daily_run.idle_minutes", 10))
AI_MODEL = setting("ai_model", "claude-haiku-4-5")
SHADOW = bool(setting("shadow", False))
DAILY_EMAIL = bool(setting("daily_email", True))
_de = setting("daily_email", True)
DAILY_EMAIL_MODE = "all" if _de in (True, "all") else "needs" if _de == "needs" else "off"
DAILY_EMAIL = DAILY_EMAIL_MODE != "off"
DAILY_CAP = int(setting("daily_cap", 5))
FIT_BREADTH = str(setting("fit_breadth", "related")).lower()
AI_PROVIDER = str(setting("ai_provider", "anthropic")).lower()
AI_BASE_URL = str(setting("ai_base_url", "http://127.0.0.1:11434/v1")).rstrip("/")
AI_REASONING = str(setting("ai_reasoning", ""))
APP_NAME = str(setting("app_name", "WorksForMe"))
LEDGER_FILE = str(setting("ledger_file", "Job Applications.xlsx"))
MASTER_RESUME = path(setting("master_resume", "../Resume.docx"))
CATEGORIES_DIR = path(setting("categories_dir", "../Categories"))
OWNER = setting("owner", "the applicant")
AUTO_SUBMIT = bool(setting("auto_submit", False))
VAULT_PREFIX = setting("vault_prefix", "JobBot/")


def _rx(s):
    return re.compile(s, re.I)


EXCLUDED = [(_rx(e["regex"]), e["reason"]) for e in TARGETS.get("excluded_companies", [])]
FORCEABLE = tuple(TARGETS.get("forceable", []))
TITLE_SKIPS = [(_rx(t["regex"]), t["reason"]) for t in TARGETS.get("title_skips", [])]
LOCAL = _rx(TARGETS.get("local_regex", r"(?!x)x"))
RELOCATE_MIN_BASE = int(TARGETS.get("relocate_min_base", 10 ** 9))
CATEGORIES = TARGETS.get("categories", ["Generalist"])
DEFAULT_CATEGORY = TARGETS.get("default_category", CATEGORIES[0])
PERSONA = TARGETS.get("persona", f"{OWNER}, a job seeker")
FIT_PROMPT = TARGETS.get("fit_prompt", "")


def fit_prompt(title, company, jd):
    return FIT_PROMPT.replace("{title}", title).replace("{company}", company).replace("{jd}", jd)


if __name__ == "__main__":
    print("settings:", json.dumps(SETTINGS, indent=1)[:1500])
    print("excluded:", [why for _, why in EXCLUDED])
    print("title skips:", [why for _, why in TITLE_SKIPS])
    print("categories:", CATEGORIES, "| default:", DEFAULT_CATEGORY)
    print("master resume:", MASTER_RESUME, MASTER_RESUME.exists())
    print("browser home:", BROWSER_HOME, "| ports:", PORT_CHROME, PORT_AGENT, PORT_LOCK)
