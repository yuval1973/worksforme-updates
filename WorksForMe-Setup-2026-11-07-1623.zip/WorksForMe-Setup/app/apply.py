import csv
import datetime as dt
import html
import json
import re
import sys
import time
from pathlib import Path
from urllib.parse import urlparse

from playwright.sync_api import sync_playwright, TimeoutError as PWTimeout

import config
import jobapply
import llm
import sites

HERE = Path(__file__).parent
P = llm.PROFILE
RUNS = HERE / "runs"
LOG = HERE / "applications.csv"
MAX_APPLICANTS = P["job_filters"]["max_applicants"] or float("inf")

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def say(msg):
    print(f"[{dt.datetime.now():%H:%M:%S}] {str(msg).replace('JobBot', config.APP_NAME)}", flush=True)


CONTINUE = HERE / "CONTINUE"
WAITING = HERE / "runs" / "waiting.json"
UNATTENDED = "--unattended" in sys.argv
REFERRAL = "--referral" in sys.argv
SOURCE = sys.argv[sys.argv.index("--source") + 1] if "--source" in sys.argv[:-1] else None
RECRUITER = "--recruiter" in sys.argv
PRACTICE = "--practice" in sys.argv
PRACTICE_SIGNIN = sites.PRACTICE_SIGNIN
PLACEHOLDER = "Practice run - not an application."


def stand_in(p):
    import phonenumbers as pn
    idn, loc = p.setdefault("identity", {}), p.setdefault("location", {})
    region = str(idn.get("phone_region") or loc.get("country_code") or "US").upper()
    try:
        n = pn.example_number_for_type(region, pn.PhoneNumberType.MOBILE) or pn.example_number(region)
        phone, digits = pn.format_number(n, pn.PhoneNumberFormat.INTERNATIONAL), str(n.national_number)
    except Exception:
        phone, digits = "+1 201-555-0123", "2015550123"
    idn.update(first_name="Practice", last_name="Run", preferred_name="Practice", email="practice@example.com",
               phone=phone, phone_digits=digits, linkedin="https://www.linkedin.com/in/practice-run", github=None,
               website=None)
    loc["street_address"] = "100 Main Street"
    if isinstance(p.get("most_recent_job"), dict):
        p["most_recent_job"]["company"] = "Practice Company"
    p["free_text"] = {k: PLACEHOLDER for k in (p.get("free_text") or {})}
    return p


def unreal(real, fake):
    pairs = []
    for k, v in real.items():
        rx = r"(?:\+\d{1,3}[\s.-]*)?\(?" + r"[\s.()-]*".join(map(re.escape, v)) if k == "phone_digits" else re.escape(v)
        pairs.append((re.compile(rx, re.I), str(fake.get(k) or "")))
    pairs.sort(key=lambda p: -len(p[0].pattern))

    def mask(s):
        if not isinstance(s, str):
            return s
        for rx, new in pairs:
            s = rx.sub(new, s)
        return s
    return mask


if PRACTICE:
    UNATTENDED = True
    LOG = RUNS / "practice.csv"
    sites.FILE = RUNS / "practice_sites.json"
    _real = {k: v.strip() for k, v in dict(P.get("identity") or {}, street_address=(P.get("location") or {}).get(
        "street_address")).items() if isinstance(v, str) and len(v.strip()) > 2 and not k.startswith("_")
        and k not in ("phone_type", "phone_country_code", "phone_region")}
    stand_in(P)
    _mask = unreal(_real, dict(P["identity"], street_address=P["location"]["street_address"]))
    llm.SYSTEM, llm.FIT_SYSTEM = _mask(llm.SYSTEM), _mask(llm.FIT_SYSTEM)
    llm.PROFILE_BRIEF, llm.RESUME = _mask(llm.PROFILE_BRIEF), _mask(llm.RESUME)
    _answer = llm.answer
    llm.answer = lambda *a, **k: _mask(_answer(*a, **k))
    llm.draft = lambda *a, **k: PLACEHOLDER
    from playwright.sync_api import FileChooser, Locator
    Locator.set_input_files = lambda self, *a, **k: say("practice: no file uploaded")
    FileChooser.set_files = lambda self, *a, **k: say("practice: no file uploaded")
SOURCE = SOURCE or ("Recruiter" if RECRUITER else None)
JD_MARKERS = re.compile(r"responsibilit|qualification|requirement|what you(?:'ll| will)|you will|about the (?:role|team|job|position)|"
                        r"meet the team|experience (?:in|with)|who you are|the role", re.I)


GOOGLE_SITES = HERE / "google_signin.json"


def google_sites():
    try:
        return set(json.loads(GOOGLE_SITES.read_text(encoding="utf-8")))
    except (OSError, ValueError):
        return set()


def remember_google_site(host):
    sites = google_sites() | {host}
    GOOGLE_SITES.write_text(json.dumps(sorted(sites), indent=1), encoding="utf-8")


class NeedsUser(RuntimeError):

    def __init__(self, msg=""):
        msg = re.sub(r"double-click '?JobBot pending'?", 'press "Finish in browser" on the dashboard', str(msg))
        msg = msg.replace("run JobBot pending again", 'press "Finish in browser" again')
        super().__init__(msg.replace("JobBot pending", '"Finish in browser"'))


class AlreadyApplied(RuntimeError):
    pass


def check_already_applied(ctx_or_page):
    pages = getattr(ctx_or_page, "pages", None) or [ctx_or_page]
    for pg in pages:
        try:
            if pg.is_closed():
                continue
            body = pg.locator("body").inner_text(timeout=3000)
            if m := re.search(r"already applied|you('ve| have) (already )?applied (for|to) this", body, re.I):
                said = " ".join(body[max(0, m.start() - 60):m.end() + 60].split())
                raise AlreadyApplied(f"the employer's site says you already applied to this job (\"{said}\" - "
                                     f"{urlparse(pg.url).netloc})")
        except AlreadyApplied:
            raise
        except Exception:
            continue


class JobClosed(RuntimeError):
    pass


CLOSED = re.compile(r"(no longer|not currently) accepting applications|this job (has been|is) closed|job has been closed|"
                    r"position has been (filled|closed)|(job|position|posting) is no longer (available|active|open)",
                    re.I)


def check_closed(page, wait=0):
    if wait:
        page.wait_for_timeout(wait)
    try:
        m = CLOSED.search(page.locator("body").inner_text(timeout=5000)[:20000])
    except Exception:
        return
    if m:
        raise JobClosed(f"job closed ({m.group(0)})")


class SiteDown(RuntimeError):
    pass


class SiteBroken(RuntimeError):
    pass


class NoAdapter(RuntimeError):
    pass


SITE_DOWN_TRIES = 3
DOWN_TEXT = re.compile(r"\b50[234]\b.{0,40}(bad gateway|unavailable|time-?out)|bad gateway|internal server error|"
                       r"service (is )?(temporarily )?unavailable|gateway time-?out|temporarily unavailable|"
                       r"(down|offline|closed) for (scheduled |planned )?maintenance|(scheduled|planned) maintenance|"
                       r"(performing|undergoing) (scheduled |planned )?maintenance|we.ll be back (soon|shortly)", re.I | re.S)
OUTAGE = []


def watch_outage(ctx):
    ctx.on("request", lambda r: OUTAGE.append(urlparse(r.url).netloc) if "/wday/drs/outage" in r.url else None)


def site_down(page):
    if OUTAGE:
        return f"the hiring site is down for planned maintenance ({OUTAGE[-1]})"
    try:
        status = page.evaluate("() => (performance.getEntriesByType('navigation')[0] || {}).responseStatus || 0")
        body = page.locator("body").inner_text(timeout=5000)
    except Exception:
        return None
    if status >= 500:
        return f"server error {status} at {urlparse(page.url).netloc}"
    m = DOWN_TEXT.search(body) if len(body) < 2500 else None
    return f"error page at {urlparse(page.url).netloc} ({' '.join(m.group(0).split())[:60]})" if m else None


CODE_QUERY ='from:greenhouse-mail.io subject:"security code"'
CODE_KINDS = {
    "greenhouse": (CODE_QUERY, r"application:\s*(?:<[^>]+>\s*)*([A-Za-z0-9]{6,10})\b"),
    "oracle": ('subject:("confirm your identity" OR "identity verification")', r"(?:pass ?code|verification code|\bcode\b[^.\d]{0,60}?:)\W{0,5}(\d{4,8})\b"),
}


def _code_mail_is(company, msg, text=""):
    word = re.sub(r"[^a-z0-9]", "", (company or "").split()[0].lower()) if company else ""
    return not word or word in re.sub(r"[^a-z0-9]", "", ((msg["Subject"] or "") + (msg["From"] or "") + text).lower())


OFFERED_CODES = HERE / "runs" / "offered_codes.json"


def _offered():
    try:
        return set(json.loads(OFFERED_CODES.read_text(encoding="utf-8")))
    except Exception:
        return set()


def clear_clipboard():
    import ctypes
    try:
        if ctypes.windll.user32.OpenClipboard(None):
            ctypes.windll.user32.EmptyClipboard()
            ctypes.windll.user32.CloseClipboard()
    except Exception:
        pass


def greenhouse_code(company, since, wait_s=300, kind="greenhouse", done=None):
    query, code_rx = CODE_KINDS[kind]
    import email as _email
    import subprocess
    from email.utils import parsedate_to_datetime
    import gmail
    deadline = time.time() + wait_s
    while time.time() < deadline:
        if done and done():
            return None
        m = gmail.connect()
        try:
            m.select(f'"{gmail.special(m, chr(92) + "All")}"', readonly=True)
            q = query.replace('"', '\\"') + " newer_than:1d"
            for uid in reversed(m.uid("SEARCH", "X-GM-RAW", f'"{q}"')[1][0].split()):
                msg = _email.message_from_bytes(m.uid("FETCH", uid, "(BODY.PEEK[])")[1][0][1])
                if parsedate_to_datetime(msg["Date"]) < since:
                    continue
                text = ""
                for part in msg.walk():
                    if part.get_content_type() in ("text/plain", "text/html"):
                        text += part.get_payload(decode=True).decode(part.get_content_charset() or "utf-8", "replace")
                if kind == "greenhouse" and company.lower() not in (msg["Subject"] or "").lower():
                    continue
                if kind != "greenhouse" and not _code_mail_is(company, msg, text):
                    continue
                hit = re.search(code_rx, text) or re.search(code_rx, html.unescape(re.sub(r"<[^>]+>", " ", text)))
                if hit and hit.group(1) in _offered():
                    continue
                if hit:
                    subprocess.run("clip", input=hit.group(1), text=True, shell=True)
                    try:
                        OFFERED_CODES.write_text(json.dumps(sorted(_offered() | {hit.group(1)})[-50:]), encoding="utf-8")
                    except Exception:
                        pass
                    return hit.group(1)
        finally:
            m.logout()
        print(f"   waiting for {company}'s code email ...", flush=True)
        for _ in range(10):
            if done and done():
                return None
            time.sleep(1)
    return None


def trash_code_emails(company=None, older_than_hours=0):
    import email as _email
    from email.utils import parsedate_to_datetime
    import gmail
    cut = dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=older_than_hours)
    m = gmail.connect()
    try:
        m.select(f'"{gmail.special(m, chr(92) + "All")}"', readonly=True)
        uids = []
        oracle_cos = set()
        if LOG.exists():
            with LOG.open(encoding="utf-8") as f:
                oracle_cos = {r["company"] for r in csv.DictReader(f) if r.get("ats") == "oracle" and r.get("company")}
        for kind, (query, _) in CODE_KINDS.items():
            q = query.replace('"', '\\"')
            for uid in m.uid("SEARCH", "X-GM-RAW", f'"{q}"')[1][0].split():
                h = _email.message_from_bytes(m.uid("FETCH", uid, "(BODY.PEEK[HEADER.FIELDS (SUBJECT FROM DATE)])")[1][0][1])
                if kind == "greenhouse":
                    mine = not company or company.lower() in (h["Subject"] or "").lower()
                else:
                    mine = any(_code_mail_is(c, h) for c in ([company] if company else oracle_cos))
                if mine and parsedate_to_datetime(h["Date"]) <= cut:
                    uids.append(uid.decode())
        return gmail.trash(m, uids) if uids else 0
    finally:
        m.logout()


def human(msg):
    print("\n" + "=" * 70 + f"\nNEEDS YOU: {msg}\n" + "=" * 70, flush=True)
    if UNATTENDED:
        raise NeedsUser(msg)
    if sys.stdin and sys.stdin.isatty() and sys.stdout.isatty():
        return input("> ").strip()
    CONTINUE.unlink(missing_ok=True)
    print(f"(headless: waiting for {CONTINUE} ...)", flush=True)
    try:
        WAITING.write_text(json.dumps({"msg": msg, "since": dt.datetime.now().isoformat(timespec="seconds")}), encoding="utf-8")
    except OSError:
        pass
    try:
        for _ in range(900):
            if CONTINUE.exists():
                CONTINUE.unlink(missing_ok=True)
                return ""
            time.sleep(1)
        return ""
    finally:
        WAITING.unlink(missing_ok=True)


FIELDS = ["date", "company", "title", "url", "ats", "category", "applicants", "status", "notes",
          "summary", "action_url", "ts"]
PENDING_HOURS = 14 * 24


def log_row(**kw):
    if LOG.exists():
        with LOG.open(encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        if rows and list(rows[0].keys()) != FIELDS:
            with LOG.open("w", newline="", encoding="utf-8") as f:
                w = csv.DictWriter(f, fieldnames=FIELDS)
                w.writeheader()
                for r in rows:
                    w.writerow({k: r.get(k, "") for k in FIELDS})
    new = not LOG.exists()
    with LOG.open("a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=FIELDS)
        if new:
            w.writeheader()
        kw.setdefault("ts", dt.datetime.now().isoformat(timespec="seconds"))
        if REFERRAL and not str(kw.get("notes", "")).startswith("REFERRAL"):
            kw["notes"] = "REFERRAL | " + str(kw.get("notes", ""))
        if RECRUITER and not str(kw.get("notes", "")).startswith("RECRUITER"):
            kw["notes"] = "RECRUITER | " + str(kw.get("notes", ""))
        w.writerow({k: kw.get(k, "") for k in FIELDS})
    if not PRACTICE:
        write_ledger()


SECTION = re.compile(r"(what you.ll do|what you will do|what you will be doing|what you.ll be doing|"
                     r"responsibilities|about the role|the role|your role|in this role|the opportunity|"
                     r"job summary|role summary|position summary)\s*:?\s*\n", re.I)
SUMMARY_CUE = re.compile(r"\bas an? (principal|senior|staff|lead|sr\.?)\b|\bwe(?: are|.re) (looking for|seeking|hiring)\b|"
                         r"\bin this role,? you\b|\bthis role (is|will|sits)\b|\bthe .{0,40} team is looking\b", re.I)
ROLE_CUE = re.compile(r"\b(you will|you.ll|in this role|this role|the team)\b", re.I)


def short_jd(jd, n=320):
    jd = jd or ""
    paras = [p for p in jd.split("\n") if len(p.strip()) > 40]
    summ = next((i for i, p in enumerate(paras) if SUMMARY_CUE.search(p)), None)
    m = SECTION.search(jd)
    if summ is not None:
        body = "\n".join(paras[summ:])
    elif m:
        body = jd[m.end():]
    else:
        start = next((i for i, p in enumerate(paras) if i > 0 and ROLE_CUE.search(p)), 0)
        body = "\n".join(paras[start:])
    lines = [l.strip(" -*•\t") for l in body.split("\n") if l.strip(" -*•\t")]
    body = " ".join(l if l[-1:] in ".!?:;" else l + "." for l in lines)
    body = re.sub(r"\s+", " ", body).strip()
    if len(body) <= n:
        return body
    cut = body[:n]
    return (cut[: cut.rfind(". ") + 1] or cut).strip() + ("" if cut.endswith(".") else " ...")


def resume_shown(page, path, wait_s=10, also=None):
    if PRACTICE:
        return True
    for _ in range(wait_s * 2):
        body = page.locator("body").inner_text()
        if Path(path).name in body or (also and re.search(also, body, re.I)):
            return True
        page.wait_for_timeout(500)
    return False


def relisting_of(company, title, jd):
    norm = lambda s: re.sub(r"[^a-z0-9]", "", (s or "").lower())
    body = lambda summ: norm(re.sub(r"^PAY:[^\n]*\n", "", summ or ""))[:150]
    c, t, d = norm(company)[:20], norm(title), body(short_jd(jd))
    if not (c and t and len(d) >= 60) or not LOG.exists():
        return None
    latest = {}
    with LOG.open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            latest[r.get("url") or id(r)] = r
    if True:
        for r in latest.values():
            if norm(r.get("company"))[:20] != c or not (r.get("status") or "").startswith(("submitted", "applied", "submit clicked")):
                continue
            rt = norm(r.get("title"))
            if (rt == t or (min(len(rt), len(t)) >= 15 and (rt.startswith(t) or t.startswith(rt)))) and body(r.get("summary")) == d:
                return r
    return None


LEDGER = HERE / config.LEDGER_FILE


REJECTED_FILL, DECLINED_FILL = "F8CBAD", "D9D9D9"


def closed_rows(rows):
    import jobseek
    words = lambda s: {w for w in re.findall(r"[a-z0-9+#]+", (s or "").lower()) if len(w) > 2}
    out = {}
    live = [r for r in rows if (r.get("status") or "").lower().startswith(("submitted", "applied", "submit clicked"))]
    declined = set(DECLINED_ONLY) | {k for k, v in P["job_filters"].get("parked_companies", {}).items()
                                     if not k.startswith("_") and "declined" in v.lower()}
    for r in rows:
        if (r.get("status") or "").lower().startswith("declined"):
            out[id(r)] = (DECLINED_FILL, "DECLINED by you")
    for r in live:
        if any(jobseek.norm(d) == jobseek.norm(r.get("company")) for d in declined):
            out[id(r)] = (DECLINED_FILL, "DECLINED by you")
    try:
        cache = jobseek._load()
    except Exception:
        return out
    for c in cache.values():
        if c.get("kind") != "rejection" or not c.get("company") or not c.get("date"):
            continue
        day = c["date"][:10]
        cands = [r for r in live if jobseek.norm(r.get("company")) == jobseek.norm(c["company"])
                 and (r.get("date") or "") <= day and id(r) not in out]
        pick = None
        if c.get("role"):
            role = words(c["role"])
            scored = sorted(((len(role & words(r.get("title"))) / max(len(role), 1), r) for r in cands),
                            key=lambda x: -x[0])
            if scored and scored[0][0] >= 0.6:
                pick = scored[0][1]
        elif len(cands) == 1:
            pick = cands[0]
        if pick is not None:
            out[id(pick)] = (REJECTED_FILL, f"REJECTED {day} (Job Seek)")
    return out


def write_ledger():
    if not config.setting("excel_ledger", True):
        return
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Font, PatternFill
        with LOG.open(encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        wb = Workbook()
        ws = wb.active
        ws.title = "Applications"
        cols = ["date", "company", "title", "location", "status", "url", "summary", "notes"]
        where = locations()
        ws.append([c.capitalize() for c in cols])
        fills = {"submitted": "C6EFCE", "applied": "C6EFCE", "ready": "FFEB9C",
                 "skipped": "EDEDED", "error": "FFC7CE"}
        latest = {}
        for r in rows:
            latest.pop(r.get("url") or id(r), None)
            latest[r.get("url") or id(r)] = r
        rows = [r for r in latest.values() if not (r.get("status") or "").lower().startswith("skipped")]
        closed = closed_rows(rows)
        rows = [r for r in rows if not (id(r) in closed and closed[id(r)][0] == DECLINED_FILL)]
        for r in reversed(rows):
            shade = closed.get(id(r))
            cap = lambda v: v if len(v) <= 300 else v[:300].rstrip() + "…"
            note = (f"{shade[1]} | " if shade else "") + (r.get("notes") or "")
            ws.append([r.get(c, "") if c == "url" else cap(note if c == "notes" else where.get(r.get("url") or "", "")
                       or where.get(f"nourl|{r.get('company')}|{r.get('title')}|{r.get('date')}", "")
                       if c == "location" else (r.get(c) or "")) for c in cols])
            st = (r.get("status") or "").lower()
            color = next((v for k, v in fills.items() if st.startswith(k)), None)
            if color:
                ws.cell(ws.max_row, cols.index("status") + 1).fill = PatternFill("solid", fgColor=color)
            if shade:
                for k in range(1, len(cols) + 1):
                    ws.cell(ws.max_row, k).fill = PatternFill("solid", fgColor=shade[0])
            u = ws.cell(ws.max_row, cols.index("url") + 1)
            if u.value:
                u.hyperlink, u.style = u.value, "Hyperlink"
        wrap = Alignment(wrap_text=True, vertical="top")
        for row in ws.iter_rows():
            for cell in row:
                cell.alignment = wrap
        for c in ws[1]:
            c.font = Font(bold=True)
        for col, w in zip("ABCDEFGH", (11, 20, 46, 26, 24, 40, 70, 80)):
            ws.column_dimensions[col].width = w
        ws.freeze_panes = "A2"
        ws.auto_filter.ref = ws.dimensions
        lg = wb.create_sheet("Legend")
        for text, colour in (("Rejected by the employer (rejection email in Job Seek; date in Notes)", REJECTED_FILL),):
            lg.append([text])
            lg.cell(lg.max_row, 1).fill = PatternFill("solid", fgColor=colour)
        lg.column_dimensions["A"].width = 70
        wb.save(LEDGER)
    except PermissionError:
        say("ledger is open in Excel - not updated this time")
    except Exception as e:
        say(f"ledger not updated: {e}")


REJECT = re.compile(r"^\s*(reject( all)?( cookies)?|decline( all)?|refuse( all)?|deny|"
                    r"(use |allow )?(only )?(strictly )?(necessary|essential|required)( cookies)?( only)?)\s*$", re.I)


def dismiss_cookies(page):
    for fr in page.frames:
        try:
            ot = fr.locator("#onetrust-reject-all-handler")
            if ot.count() and ot.first.is_visible():
                ot.first.click()
                return "OneTrust reject-all"
            for role in ("button", "link"):
                btns = fr.get_by_role(role, name=REJECT)
                for i in range(btns.count()):
                    b = btns.nth(i)
                    if b.is_visible():
                        name = b.inner_text().strip()
                        b.click()
                        page.wait_for_timeout(500)
                        return name
        except Exception:
            continue
    return None


MARKETING = re.compile(r"recommendation|newsletter|marketing|talent (community|network|pool)|job alerts?|similar (jobs|roles)"
                       r"|promotional|updates? (by|via) e-?mail|e-?mail me|keep me (informed|updated)|future opportunit"
                       r"|\bsms\b|text messag|whats ?app", re.I)
AGREE = re.compile(r"^\s*(i\s+)?(agree|accept|acknowledge)(\s*(&|and)\s*(continue|proceed))?\s*$|^\s*continue\s*$", re.I)


def privacy_dialog(page, wait_s=10):
    dlg = page.locator("[role=dialog]:visible, [aria-modal=true]:visible").filter(
        has_text=re.compile(r"privacy|personal (information|data)|consent|terms", re.I))
    for _ in range(int(wait_s * 2)):
        if dlg.count():
            break
        page.wait_for_timeout(500)
    else:
        return None
    d, off = dlg.first, []
    for box in d.locator("input[type=checkbox]").all():
        try:
            lab = box.evaluate("e => (e.labels && e.labels[0] ? e.labels[0].innerText : '') || "
                               "(e.closest('label, div') || e).innerText || ''")
            if box.is_checked() and MARKETING.search(lab or ""):
                box.uncheck(force=True)
                off.append(" ".join(lab.split())[:60])
        except Exception:
            continue
    btn = d.get_by_role("button", name=AGREE)
    if not btn.count():
        return None
    name = btn.first.inner_text().strip()
    btn.first.click()
    page.wait_for_timeout(800)
    return f"privacy consent '{name}'" + (f"; marketing opt-in unticked: {'; '.join(off)}" if off else "")


EXCLUDED = config.EXCLUDED
FORCEABLE = config.FORCEABLE
TITLE_SKIPS = config.TITLE_SKIPS

DECLINED = {k: v for k, v in P["job_filters"].get("declined_companies", {}).items() if not k.startswith("_")}
DECLINED_ONLY = dict(DECLINED)
DECLINED.update({k: "parked - " + v for k, v in P["job_filters"].get("parked_companies", {}).items() if not k.startswith("_")})
PAY_FLOOR = P["compensation"]["floor"]["min_base_usd"]
_USD = r"\$\s?(\d{2,3}(?:,\d{3})+(?:\.\d+)?|\d{2,3}(?:\.\d+)?\s?[kK])"
PAY_RANGE = re.compile(_USD + r"\s*(?:-|–|—|to)\s*(?:USD\s*)?" + _USD, re.I)


def hourly_tail(text, end):
    return bool(re.match(r"\s*(?:/\s*h(?:ou)?r\b|per hour|an hour|hourly)", text[end:end + 15], re.I))


def pay_below_floor(jd):
    highs = []
    for m in PAY_RANGE.finditer(jd or ""):
        if hourly_tail(jd, m.end()):
            continue
        hi = max(float(x.replace(",", "").rstrip("kK ").strip()) * (1000 if x.strip()[-1] in "kK" else 1)
                 for x in m.groups())
        if 30_000 <= hi <= 2_000_000:
            highs.append(hi)
    if highs and max(highs) < PAY_FLOOR:
        return f"posted pay range tops out at ${max(highs):,.0f} - below the ${PAY_FLOOR:,.0f} base floor (applicant.json)"
    return None


LOCAL = config.LOCAL
LOCATION_Q = re.compile(r"relocat|on-?site|in[- ]office|in the office|(hq|headquarters|office)\b.{0,40}(week|days)|"
                        r"from (our |the )?[\w' ]{0,40}(hq|headquarters|office)|\b\d\s*(x|times|days)\b.{0,15}(a |per )?week|"
                        r"commut|hybrid", re.I)
RELOCATE_MIN_BASE = config.RELOCATE_MIN_BASE


def relocation_choice(ans, opts):
    opts = [o for o in opts if o and o.strip()]
    if ans == "No":
        return next((o for o in opts if re.match(r"\s*no\b", o, re.I)), None)
    yes = [o for o in opts if not re.match(r"\s*(no\b|not\b|unwilling|i am not|i'?m not)", o, re.I)]
    selfr = lambda o: re.search(r"self|own (cost|expense)|without (relocation )?(assistance|support)|no assistance", o, re.I)
    neutral = lambda o: re.search(r"open to|willing|to be discussed|discuss|negotiab|flexible", o, re.I) and not selfr(o) \
        and not re.search(r"require[sd]? (relocation )?(assistance|support)|assistance (is )?required", o, re.I)
    plain = lambda o: re.match(r"\s*yes\s*[.!]?\s*$", o, re.I)
    for test in (neutral, plain, selfr):
        hit = next((o for o in yes if test(o)), None)
        if hit:
            return hit
    return next((o for o in yes if re.match(r"\s*yes\b", o, re.I)), None)


class LocAnswer(str):
    def __call__(self, opts):
        return relocation_choice(str(self), opts)


def current_company():
    employed = not str(P.get("eligibility", {}).get("currently_employed", "No")).strip().lower().startswith("no")
    return P.get("most_recent_job", {}).get("company", "") if employed else ""


def _local_towns():
    alts = [x for x in LOCAL.pattern.split("|") if x.strip()]
    keep = [x for x in alts if "remote" not in x.lower()]
    try:
        return re.compile("|".join(keep), re.I) if keep and all(x.count("(") == x.count(")") for x in keep) else re.compile(r"(?!x)x")
    except re.error:
        return re.compile(r"(?!x)x")


LOCAL_PLACES = _local_towns()
JOB_WHERE = ""
_WHERE_LINE = re.compile(r"(?:^|\n)\s*(?:job |work |primary |office )?locations?\s*[:\-–]\s*([^\n]{2,90})|"
                         r"\b(?:based|located) in ([A-Z][^\n.;]{2,60})|"
                         r"\b((?:fully|100%) remote|remote[- ](?:first|friendly|eligible|role|position|opportunity)|"
                         r"(?:work|working) (?:from home|remotely))\b", re.I)


def jd_location(jd):
    return " | ".join(next(g for g in m.groups() if g) for m in _WHERE_LINE.finditer(jd or ""))[:400]


WORK_ADDRESS_Q = re.compile(r"(?<!mail )\baddress\b[^?]{0,60}\bwork(ing)?\b|\bwork(ing)? from (what|which) address", re.I)


def work_address(label, jd, where=None):
    if not label or not WORK_ADDRESS_Q.search(label):
        return None
    loc = P.get("location") or {}
    home = place_text(", ".join(x for x in (loc.get("city"), loc.get("state_code")) if x))
    if where is None:
        where = JOB_WHERE or jd_location(jd)
    if re.search(r"\brelocating\b", label, re.I) and where and not LOCAL.search(where) and \
            location_answer("Are you willing to relocate?", jd, where) == "Yes":
        return "relocating"
    return home or None


def location_answer(label, jd, where=None):
    addr = work_address(label, jd, where)
    if addr:
        return addr
    tr = travel_answer(label)
    if tr:
        return LocAnswer(tr)
    if not label or not LOCATION_Q.search(label):
        return None
    if where is None:
        where = JOB_WHERE or jd_location(jd)
    other_city = re.search(r"\b(new york|nyc|san francisco|boston|austin|chicago|london|denver|los angeles|atlanta|dallas|"
                           r"houston|miami|washington,? d\.?c|arlington|mountain view|sunnyvale|san jose|toronto)\b", label, re.I)
    if other_city and LOCAL.search(other_city.group(0)):
        other_city = None
    if (LOCAL_PLACES.search(label) and not other_city) or (not other_city and where and LOCAL.search(where)):
        return LocAnswer("Yes")
    lows = []
    for m in PAY_RANGE.finditer(jd or ""):
        if hourly_tail(jd, m.end()):
            continue
        lo = min(float(x.replace(",", "").rstrip("kK ").strip()) * (1000 if x.strip()[-1] in "kK" else 1) for x in m.groups())
        if 30_000 <= lo <= 2_000_000:
            lows.append(lo)
    return LocAnswer("Yes" if lows and max(lows) >= RELOCATE_MIN_BASE else "No")


def pay_facts(text):
    text = text or ""
    ranges = []
    for m in PAY_RANGE.finditer(text):
        if hourly_tail(text, m.end()):
            continue
        lo, hi = (float(x.replace(",", "").rstrip("kK ").strip()) * (1000 if x.strip()[-1] in "kK" else 1) for x in m.groups())
        if 30_000 <= hi <= 2_000_000 and (lo, hi) not in ranges:
            ranges.append((lo, hi))
    out = []
    if ranges:
        out.append("range " + ", ".join(f"${lo / 1000:,.0f}K-${hi / 1000:,.0f}K" for lo, hi in ranges[:3]))
    so = re.search(r"sign[- ]?on( bonus)?|signing bonus", text, re.I)
    if so:
        amt = re.search(r"\$\s?\d[\d,]*\s?[kK]?", text[max(0, so.start() - 60):so.end() + 60])
        out.append("sign-on" + (f" {amt.group(0).replace(' ', '')}" if amt else " mentioned"))
    plain = re.sub(r"sign[- ]?on bonus|signing bonus", "", text, flags=re.I)
    if re.search(r"\bbonus", plain, re.I):
        pct = re.search(r"(\d{1,2})\s?%[^.\n]{0,25}\bbonus|\bbonus[^.\n]{0,40}?(\d{1,2})\s?%", plain, re.I)
        out.append("bonus" + (f" {pct.group(1) or pct.group(2)}%" if pct else ""))
    eq = re.search(r"\bRSUs?\b|restricted stock|stock options?|stock grants?|equity (grant|award|compensation|"
                   r"package|component|refresh)|(offers?|includes?|eligible for|plus|and|\+)\s+equity\b", text, re.I)
    if eq and not re.search(r"equity (and|&|,) inclusion", text[max(0, eq.start() - 5):eq.end() + 15], re.I):
        out.append("equity (RSU)" if re.search(r"\bRSUs?\b|restricted stock", text, re.I) else "equity")
    if re.search(r"\bESPP\b|employee stock purchase", text, re.I):
        out.append("ESPP")
    k = re.search(r"401\s?\(?k\)?[^.\n]{0,60}?\bmatch", text, re.I)
    if k:
        pct = re.search(r"(\d{1,3}(?:\.\d)?)\s?%", text[k.start():k.end() + 60])
        out.append("401(k) match" + (f" {pct.group(1)}%" if pct else ""))
    if re.search(r"profit[- ]sharing", text, re.I):
        out.append("profit sharing")
    if re.search(r"relocation (assistance|package|support|benefits?|reimbursement|stipend|bonus)|"
                 r"relocation (is |may be )?(available|provided|offered|supported)", text, re.I):
        out.append("relocation offered")
    return " | ".join(out)


LOW_PAY = HERE / "low_pay_companies.json"
LOCATIONS = HERE / "locations.json"


def linkedin_location(main_text):
    lines = [l.strip() for l in (main_text or "").splitlines() if l.strip()]
    where = next((l.split("·")[0].strip() for l in lines[1:6] if "·" in l and re.search(r"ago|applicant|clicked", l)), "")
    mode = re.search(r"\b(Remote|Hybrid|On-site)\b", " ".join(lines[:14]))
    return " · ".join(x for x in (where, mode.group(1) if mode else "") if x)


def note_location(url, where):
    if not (url and where):
        return
    try:
        d = json.loads(LOCATIONS.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    if d.get(url) != where:
        d[url] = where
        LOCATIONS.write_text(json.dumps(d, indent=1, ensure_ascii=False), encoding="utf-8")


PAYS = HERE / "pay.json"


def job_key(url):
    m = re.search(r"linkedin\.com/jobs/view/(\d+)", url or "")
    return f"li:{m.group(1)}" if m else (url or "").split("?")[0].rstrip("/")


def base_range(text):
    best = None
    for m in PAY_RANGE.finditer(text or ""):
        if hourly_tail(text, m.end()):
            continue
        lo, hi = sorted(float(x.replace(",", "").rstrip("kK ").strip()) * (1000 if x.strip()[-1] in "kK" else 1)
                        for x in m.groups())
        if 30_000 <= lo and hi <= 2_000_000 and (best is None or lo + hi > sum(best)):
            best = (int(lo), int(hi))
    return best


def note_pay(url, text):
    rng = base_range(text)
    if not (url and rng):
        return
    try:
        d = json.loads(PAYS.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    if d.get(job_key(url)) != list(rng):
        d[job_key(url)] = list(rng)
        PAYS.write_text(json.dumps(d, indent=1), encoding="utf-8")


def pay_of(url):
    try:
        v = json.loads(PAYS.read_text(encoding="utf-8")).get(job_key(url))
    except (OSError, ValueError):
        return None
    return tuple(v) if v else None


def locations():
    try:
        return json.loads(LOCATIONS.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _low_pay():
    try:
        return json.loads(LOW_PAY.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def note_low_pay(company, title, why):
    _remember(LOW_PAY, company, title, why)


def _remember(path, company, title, why):
    if not company:
        return
    try:
        d = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    d.setdefault(company, []).append({"date": dt.date.today().isoformat(), "title": title, "evidence": why})
    path.write_text(json.dumps(d, indent=1, ensure_ascii=False), encoding="utf-8")


PARKED = HERE / "parked_companies.json"
NON_FTE = re.compile(r"\b(c2c|corp[- ]to[- ]corp|w-?2\b|1099|contract[- ]to[- ]hire|"
                     r"(on behalf of|for) our client|our client(,| is| has| seeks)|client is (seeking|looking)|"
                     r"on behalf of (a|an|one of our|our) (partner|client)( company| companies)?|"
                     r"(for|with) (a|one of our) (partner|client) compan(y|ies)|"
                     r"contract (role|position|assignment|opportunity|engagement|duration|length|term)|"
                     r"\d{1,2}\+?[- ]?(months?|mos?) (contract|assignment|engagement)|"
                     r"duration:?\s*\d{1,2}\+?\s*(months?|mos?)\b|(employment|job) type:?\s*contract|"
                     r"this is a (\d{1,2}[- ]month )?contract)", re.I)
HOURLY = re.compile(r"\$\s?\d{2,3}(?:\.\d{2})?\s*(?:(?:-|–|to)\s*\$?\s?\d{2,3}(?:\.\d{2})?)?\s*"
                    r"(?:/\s*h(?:ou)?r\b|per hour|an hour|hourly)", re.I)


PLUGINS = {}
EMPLOYMENT_TYPES = {str(t).lower() for t in config.TARGETS.get("employment_types") or ["full-time"]}


C2H = re.compile(r"contract[- ]to[- ](hire|perm)|\bc2h\b|temp[- ]to[- ]perm|right[- ]to[- ]hire", re.I)


def contract_ok(jd):
    return "contract" in EMPLOYMENT_TYPES or ("contract-to-hire" in EMPLOYMENT_TYPES and bool(C2H.search(jd or "")))


def fte_check(company, title, jd, head=""):
    jd = jd or ""
    m = re.search(r"\b(Full-time|Contract|Temporary|Part-time|Internship)\b", head or "")
    kind = m.group(1).lower() if m else ""
    yearly = [x for x in PAY_RANGE.finditer(jd)
              if not hourly_tail(jd, x.end())]
    if kind and not (contract_ok(jd) if kind == "contract" else kind in EMPLOYMENT_TYPES):
        why = f"LinkedIn job type: {m.group(1)}"
    elif kind and kind != "full-time":
        return None
    elif not contract_ok(jd) and NON_FTE.search(jd):
        why = f"contract terms in the JD ('{NON_FTE.search(jd).group(0)}')"
    elif not (EMPLOYMENT_TYPES & {"part-time", "contract", "contract-to-hire", "temporary", "internship", "hourly"}) \
            and HOURLY.search(jd) and not yearly:
        why = f"pay stated hourly only ('{HOURLY.search(jd).group(0).strip()}') - a contract signal"
    else:
        return None
    _remember(PARKED, company, title, why)
    if EMPLOYMENT_TYPES == {"full-time"}:
        return f"not full-time: {why} - FTE only for now; company remembered in parked_companies.json"
    return f"not a wanted employment type: {why} (targets.json employment_types: {', '.join(sorted(EMPLOYMENT_TYPES))})"


def pay_check(company, title, jd):
    low = pay_below_floor(jd)
    if low:
        note_low_pay(company, title, low)
        return low, None
    seen = next((v for k, v in _low_pay().items() if jobseek_norm(k) == jobseek_norm(company)), None)
    if seen and not PAY_RANGE.search(jd or ""):
        last = seen[-1]
        return None, (f"known below-bar payer ({last['date']}, {last['title'][:40]}: {last['evidence'][:70]}); "
                      f"no range in this posting - check the pay before applying")
    return None, None


def jobseek_norm(name):
    return re.sub(r"[^a-z0-9]", "", (name or "").lower().replace(", inc", "").replace(" inc", ""))


def excluded(company, title="", declined=True):
    for rx, why in EXCLUDED:
        if rx.search(company or ""):
            return why
    if declined:
        for name, why in DECLINED.items():
            if re.search(rf"\b{re.escape(name)}\b", company or "", re.I):
                return f"{name}: {why}"
    for rx, why in TITLE_SKIPS:
        if rx.search(title or ""):
            return why
    return None

BOARD_SLUG = re.compile(r"(?:greenhouse\.io|lever\.co|ashbyhq\.com|gem\.com|jobvite\.com|rippling\.com|workable\.com|"
                        r"smartrecruiters\.com|breezy\.hr|recruitee\.com|teamtailor\.com)/(?:[a-z]{2}(?:-[A-Z]{2})?/)?"
                        r"([A-Za-z0-9][\w-]*)", re.I)
_GENERIC_LABEL = {"www", "jobs", "careers", "career", "job-boards", "boards", "apply", "ats", "explore", "hire", "talent",
                  "recruiting", "embed", "job_app", "v1", "en", "us", "app"}


def url_company(url):
    u = urlparse(url or "")
    for p in PLUGINS.values():
        m = p["slug"] and p["slug"].search(u.netloc + u.path)
        if m:
            return m.group(1)
    q = re.search(r"(?:^|&)for=([\w-]+)", u.query)
    if "greenhouse" in u.netloc and q:
        return q.group(1)
    m = BOARD_SLUG.search(u.netloc + u.path)
    if m and m.group(1).lower() not in _GENERIC_LABEL:
        return m.group(1)
    labels = [x for x in u.netloc.lower().split(".") if x]
    return next((x for x in labels if x not in _GENERIC_LABEL), labels[0] if labels else "")


def excluded_page(page, company):
    u = urlparse(page.url)
    spaced = re.sub(r"[./_-]+", " ", u.netloc + u.path)
    for text in (company, url_company(page.url), spaced, spaced.replace(" ", "")):
        for rx, why in EXCLUDED:
            if rx.search(text or ""):
                return why, None
    slug = re.sub(r"[^a-z0-9]", "", url_company(page.url).lower())
    for rx, why in EXCLUDED:
        for alt in rx.pattern.split("|"):
            core = re.sub(r"\\b|\\\.|\s", lambda m: "." if m.group(0) == "\\." else "", alt).lower()
            core = re.sub(r"[^a-z0-9]", "", core) if re.fullmatch(r"[\w .&'-]+", core) else ""
            if len(core) >= 4 and slug != core and slug.startswith(core):
                return None, f"the job link's company '{slug}' looks like {core!r} ({why})"
    try:
        names = page.evaluate("""() => [document.title, ...[...document.querySelectorAll(
            'meta[property="og:site_name"], meta[property="og:title"], meta[name="application-name"]')].map(m => m.content)]""")
    except Exception:
        names = [page.title()]
    for rx, why in EXCLUDED:
        if any(rx.search(n or "") for n in names):
            return None, f"the page names an excluded company ({why}): {' | '.join(n for n in names if n)[:120]}"
    return None, None


def linkedin_hop(ctx, page):
    page.wait_for_timeout(2500)
    if re.search(r"authwall|/login|/signup|/uas/", page.url) or re.search(r"join linkedin|sign up|log ?in", page.title(), re.I) \
            or not any(c["name"] == "li_at" for c in page.context.cookies("https://www.linkedin.com")):
        raise RuntimeError("LinkedIn is signed out in the job-apply Chrome - job not read; retried next run")
    main = page.locator("main").inner_text(timeout=15000)
    head = " ".join(main.splitlines()[:12])
    global JOB_WHERE
    JOB_WHERE = linkedin_location(main)
    note_location(page.url.split("?")[0], JOB_WHERE)
    info = {"title": page.title().split("|")[0].strip(), "head": head}
    m = re.search(r"Candidates who clicked apply\s+([\d,]+)", main)
    over = re.search(r"\bOver ([\d,]+) (?:people clicked apply|applicants)", main, re.I)
    m = m or (None if over else re.search(r"([\d,]+) (?:people clicked apply|applicants)", main))
    if m:
        info["applicants"] = int(m.group(1).replace(",", ""))
    elif over:
        info["applicants"] = int(over.group(1).replace(",", "")) + 1
    info["company"] = main.splitlines()[0].strip() if main else ""
    about = main.split("About the job", 1)[-1]
    info["jd"] = re.split(r"Set alert for similar jobs|See how you compare", about)[0][:15000]
    if re.search(r"\bEasy Apply\b", head) or page.get_by_role("button", name=re.compile(r"^\s*Easy Apply", re.I)).count():
        info["skip"] = "LinkedIn Easy Apply - not automated"
        return None, info
    link = page.get_by_role("link", name=re.compile("Apply on company website", re.I))
    if not link.count():
        link = page.get_by_role("button", name=re.compile(r"^Apply", re.I))
    if not link.count():
        info["skip"] = "no Apply button found"
        return None, info
    with ctx.expect_page(timeout=20000) as newp:
        link.first.click()
    emp = newp.value
    emp.wait_for_load_state("domcontentloaded")
    return emp, info


SOURCE_Q = (r"brought you|(where|how) did you (first )?(hear|find|learn|see|come across)|learn(ed)? about (this|the) "
            r"(job|role|position|opening|opportunity)|referral source|^\s*source\s*$")
SOURCE_FALLBACK = [("LinkedIn", r"^linked\s?in"), ("Job board", r"job ?board|online|website|internet"), ("Other", r"^other$")]


YESNO_Q = re.compile(r"\s*(are|is|do|does|did|have|has|had|will|would|can|could|were|was|should|may)\b", re.I)


def detect_ats(url):
    if PLUGINS and (name := plugin_host(url)):
        return name
    h = urlparse(url).netloc.lower()
    if "myworkdayjobs.com" in h or "myworkdaysite.com" in h:
        return "workday"
    if "greenhouse.io" in h or "gh_jid=" in url:
        return "greenhouse"
    if "lever.co" in h:
        return "lever"
    if ("google.com" in h and "/about/careers" in url) or "careers.google.com" in h:
        return "google"
    if "eightfold.ai" in h or "explore.jobs.netflix.net" in h or \
            re.search(r"/careers/apply\?(?=.*\bpid=\d)(?=.*\bdomain=)|/careers/job/\d{9,}", url):
        return "eightfold"
    if "rippling.com" in h:
        return "rippling"
    if "ashbyhq.com" in h:
        return "ashby"
    if h == "jobs.gem.com":
        return "gem"
    if h == "jobs.jobvite.com":
        return "jobvite"
    if h.endswith(".icims.com"):
        return "icims"
    if "phenom" in url.lower() or "jobseqno=" in url.lower():
        return "phenom"
    if "oraclecloud.com" in h and "candidateexperience" in url.lower():
        return "oracle"
    return None


ATS_HREF = re.compile(r"myworkdayjobs\.com|myworkdaysite\.com|greenhouse\.io|lever\.co|ashbyhq\.com|ats\.rippling\.com|jobs\.gem\.com|jobs\.jobvite\.com|\.icims\.com/jobs|"
                      r"oraclecloud\.com/hcmUI/CandidateExperience")


def resolve_ats(ctx, page):
    ats = detect_ats(page.url)
    if ats and ats != "phenom":
        return page
    page.wait_for_timeout(2500)
    href = page.evaluate("""([rx, applyOnly]) => { const re = new RegExp(rx, 'i');
        const as = [...document.querySelectorAll('a[href]')].filter(a => re.test(a.href));
        const apply = as.find(a => /^\\s*apply/i.test(a.innerText) || /^\\s*apply/i.test(a.title || ''));
        const pick = applyOnly ? apply : apply || as.find(a => /\\/jobs?\\//i.test(a.href)) || as[0];
        return pick ? pick.href : null; }""", [ATS_HREF.pattern, ats == "phenom"])
    if href:
        page.goto(href, wait_until="domcontentloaded")
        return page if detect_ats(page.url) else None
    if ats:
        return page
    btn = page.get_by_role("link", name=re.compile(r"^\s*apply", re.I))
    if not btn.count():
        btn = page.get_by_role("button", name=re.compile(r"^\s*apply", re.I))
    if not btn.count():
        return None
    try:
        with ctx.expect_page(timeout=8000) as newp:
            btn.first.click()
        nxt = newp.value
    except Exception:
        nxt = page
    nxt.wait_for_load_state("domcontentloaded")
    nxt.wait_for_timeout(2000)
    return nxt if detect_ats(nxt.url) else None


SI = P.get("self_identification", {})
ELIG = P.get("eligibility", {})
STANDING = P.get("standing_answers", {})
DECLINE_OPT = re.compile(r"decline|prefer not|don.?t wish|do not wish|choose not|not (to )?(disclose|answer|say|specify)|"
                         r"rather not|wish not|not wish", re.I)


def _says(v, rx):
    return bool(re.match(rx, str(v or ""), re.I))


def _declines(v):
    return _says(v, r"\s*(decline|prefer not|i (don.?t|do not) (wish|want)|choose not|i choose not)")


def yes_no(v, default=None):
    return "Yes" if _says(v, r"\s*yes\b") else "No" if _says(v, r"\s*no\b") else default


def not_veteran():
    v = str(SI.get("veteran_status") or "")
    if not v.strip():
        return True
    return bool(re.search(r"\bnot a veteran\b|^\s*no\b|\bnone\b|never served", v, re.I)) and not _declines(v)


def when_required(v):
    s = str(v or "")
    if ";" not in s:
        return None
    part = re.sub(r"\s*\([^)]*\)\s*$", "", s.split(";", 1)[1]).strip()
    part = re.sub(r"^(when|if) (the form )?(required|requires?)( an answer| it)?\s*[:,-]?\s*", "", part, flags=re.I)
    part = re.sub(r"\s*(only )?when (the form )?requires?d?( an answer)?\.?$", "", part, flags=re.I).strip()
    return part if part and not re.match(r"leave|blank", part, re.I) else None


def eeo_pick(kind, opts):
    opts = [o for o in opts if o and o.strip()]
    key = {"gender": "gender", "race": "race", "hispanic": "hispanic_latino", "veteran": "veteran_status",
           "disability": "disability_status", "orientation": "sexual_orientation", "transgender": "transgender"}[kind]
    v = str(SI.get(key, "") or "")
    if re.match(r"\s*(leave )?blank", v, re.I):
        v = when_required(v) or ""
    first = lambda rx: next((x for x in opts if re.search(rx, x.strip(), re.I)), None)
    if _declines(v):
        return first(DECLINE_OPT.pattern)
    if kind == "gender":
        g = v.strip().lower()
        want = ("male", "man") if g in ("male", "man") else ("female", "woman") if g in ("female", "woman") else (g,)
        return next((x for x in opts if x.strip().lower() in want), None)
    if kind == "race":
        return first(rf"^{re.escape(v.strip().split()[0])}") if v.strip() else None
    if kind == "hispanic":
        if _says(v, r"\s*no\b"):
            return next((x for x in opts if x.strip().lower() == "no"), None) or first(r"^not hispanic|^no\b")
        return next((x for x in opts if x.strip().lower() == "yes"), None) or first(r"^(yes|hispanic)") if _says(v, r"\s*yes\b") else None
    if kind == "veteran":
        if re.search(r"not a veteran|never served|no military", v, re.I):
            return next((x for x in opts if re.search(r"not a veteran", x, re.I) and not re.search(r"identify as a veteran", x, re.I)), None) \
                or first(r"^i am not a protected veteran") or first(r"neither") or first(r"^no\b")
        return None
    if kind in ("disability", "transgender"):
        return first(r"^no\b") if _says(v, r"\s*no\b") else first(r"^yes\b") if _says(v, r"\s*yes\b") else None
    if kind == "orientation":
        m = re.search(r"heterosexual|straight|gay|lesbian|bisexual|asexual|pansexual|queer", v, re.I)
        if not m:
            return None
        rx = r"heterosexual|straight" if m.group(0).lower() in ("heterosexual", "straight") else re.escape(m.group(0))
        return first(rx)
    return None


def eeo(kind):
    return lambda o: eeo_pick(kind, o)


def eeo_list(kind):
    return lambda o: [x] if (x := eeo_pick(kind, o)) else []


PRONOUNS = when_required(SI.get("pronouns"))
LGBT_REQUIRED = when_required(SI.get("lgbtq"))
EARLIEST_START = str(ELIG.get("earliest_start") or "Immediately")
RELOCATE = yes_no(ELIG.get("willing_to_relocate"), "No")
TRAVEL = yes_no(ELIG.get("willing_to_travel"), "No")
CLEARANCE = yes_no(ELIG.get("security_clearance"), "No")
NON_COMPETE = str(STANDING.get("non_compete") or "No")
EMPLOYED = yes_no(ELIG.get("currently_employed"), "No")
CONTACT_EMPLOYER = yes_no(ELIG.get("may_contact_current_employer"))
WEB_STACK = STANDING.get("web_stack")
BACKEND_FRONTEND = str(P.get("backend_frontend") or "")
AUTHORIZED = yes_no(ELIG.get("authorized_to_work_us"), "Yes")
SPONSOR = yes_no(ELIG.get("requires_sponsorship"), "No")
OVER_18 = yes_no(ELIG.get("over_18"), "Yes")
_AUTH = (r"authori[sz](?:ed|ation) to (?:lawfully |legally )?work|legally (?:authori[sz]ed|eligible|able|permitted)|eligib\w* (?:to|for) "
         r"(?:work|employment)|right to work|proof of .{0,40}(?:eligib|authori[sz]|right)|work (?:permit|eligibility)")
_NEED = (r"\b(?:requir|need|seek)\w*\b.{0,60}\b(?:sponsor|visa|employer support|authori[sz]ation|work permit)|"
         r"\bsponsor\w*\b.{0,40}\b(?:requir|need)")
_WITHOUT = r"\bwithout\b.{0,40}\bsponsor"
_STATUS = r"^(?![^?]*\b(?:status|type|kind|which|what|describe|explain)\b)"
AUTH_RX = rf"^(?=[\s\S]*{_WITHOUT})|{_STATUS}(?![\s\S]*(?:{_NEED}))(?=[\s\S]*(?:{_AUTH}))"
SPONSOR_RX = (rf"^(?![\s\S]*{_WITHOUT})(?:(?!{_AUTH})[\s\S])*?(?:{_NEED})|"
              rf"{_STATUS}(?![\s\S]*{_WITHOUT})(?![\s\S]*(?:{_AUTH}))(?=[\s\S]*(?:sponsor|\bvisa\b))")


def work_auth(q):
    return AUTHORIZED if re.search(AUTH_RX, q or "", re.I) else SPONSOR if re.search(SPONSOR_RX, q or "", re.I) else None


NOT_ANSWERS = re.compile(r"^(resume|cover letter|e-signature|education|experience|privacy consent|screenshot|"
                         r"second reader|checked before submit)\b", re.I)
NOT_FACTS = re.compile(r"salary|compensation|\bpay\b|wage|hourly|\brate\b|desired|expected (base|total)|how did you hear|"
                       r"\bsource\b|referr|start date|when can you start|available to start|notice period", re.I)
STAND_IN_Q = re.compile(r"\bname\b|e-?mail|phone|linkedin|website|github|portfolio|street|address|current (company|employer)|"
                        r"cover letter|signature", re.I)


def _plain(s):
    return re.sub(r"[^a-z0-9]+", " ", str(s or "").lower()).strip()


def offer(form, pick, options):
    opts = [" ".join(str(o).split()) for o in options or [] if str(o or "").strip()]
    if pick and len(opts) > 1:
        form.__dict__.setdefault("offered", {})[_plain(pick)] = opts[:80]


def offered_list(form, answer):
    return (getattr(form, "offered", None) or {}).get(_plain(answer))


def answered_pairs(notes, body=""):
    body, out = " ".join((body or "").split()), []
    for n in notes or []:
        m = re.match(r"\s*(.+?)\s*->\s*(.+?)\s*$", n or "", re.S)
        if not m:
            continue
        q, a = " ".join(m.group(1).split()), m.group(2).strip()
        if NOT_ANSWERS.match(q) or len(a) > 150 or re.search(r"[A-Za-z]:\\", a):
            continue
        if len(q) >= 45 and not q.endswith(("?", ".", ":")) and body:
            full = re.search(re.escape(q) + r"[^?]{0,300}\?", body)
            q = full.group(0) if full else q
        out.append((q, a))
    return out


def form_education(q, a):
    al = (a or "").strip().lower()
    if not al or not re.search(r"school|degree|field of study|major|discipline|education|universit|college", q, re.I):
        return False
    for e in P.get("education_on_forms") or []:
        if al in {(e.get("school") or "").lower(), (e.get("school_fallback") or "").lower()}:
            return True
        if re.search(r"degree", q, re.I) and e.get("degree_match") and re.search(e["degree_match"], a, re.I):
            return True
        if any(f.lower() in al or al in f.lower() for f in e.get("field_queries") or [] if f):
            return True
    return False


def eeo_agrees(q, a):
    return any(re.search(rx, q, re.I) and fn([a]) == a for rx, fn in EEO)


MOBILE = re.compile(r"mobile|cell", re.I)


def phone_type_agrees(q, a):
    return bool(re.search(r"phone.{0,20}type|device type", q, re.I) and MOBILE.search(a)
                and MOBILE.search(_pref("phone_type", "Mobile")))


def second_read(form, submit, page=None):
    body = ""
    try:
        body = form.p.locator("body").inner_text()[:30000]
    except Exception:
        pass
    pairs = answered_pairs(getattr(form, "notes", []), body)
    found = []
    for q, a in pairs:
        want = work_auth(q)
        if want and re.match(r"\s*(yes|no)\b", a, re.I) and not a.lower().startswith(want.lower()):
            found.append(f'"{q[:150]}" was answered "{a}", the profile says "{want}"')
    asked = {q[:40].lower() for q, _ in pairs}
    lists = [offered_list(form, a) for _, a in pairs]
    for d in llm.second_read(pairs, getattr(form, "company", ""), page or "", lists):
        q, a, want = re.sub(r"\s*->.*$", "", " ".join(d.question.split())), d.answer.strip(), d.should_be.strip()
        opts = offered_list(form, a)
        if (q[:40].lower() not in asked or NOT_FACTS.search(q) or LOCATION_Q.search(q) or not want or form_education(q, a)
                or opts and not any(_plain(want) == _plain(o) for o in opts)
                or eeo_agrees(q, a) or phone_type_agrees(q, a)
                or PRACTICE and STAND_IN_Q.search(q)
                or a.lower() == want.lower() or work_auth(q) and a.lower().startswith(work_auth(q).lower())):
            continue
        if not any(q[:40] in f for f in found):
            found.append(f'"{q[:150]}" was answered "{a}", the profile says "{want}" ({d.fact[:80]})')
    if not found:
        form.notes.append(f"second reader: {len(pairs)} answers agree with the profile ({sum(1 for x in lists if x)} "
                          f"picked from lists)")
        return None
    msg = "checked before Submit, not sent: " + " || ".join(found)
    form.notes.append(msg)
    if submit and UNATTENDED:
        raise NeedsUser(msg)
    say(msg)
    return msg


US_STATES_CODES = set("AL AK AZ AR CA CO CT DE DC FL GA HI ID IL IN IA KS KY LA ME MD MA MI MN MS MO MT NE NV NH NJ NM NY "
                      "NC ND OH OK OR PA RI SC SD TN TX UT VT VA WA WV WI WY".split())
_EDU = " ".join(f"{d.get('degree', '')} {d.get('field', '')}" for d in P.get("education_on_forms", []) + P.get("education", []))
HAS_BACHELOR = bool(re.search(r"\bB\.?\s?(A|Sc?|S|Eng)\b|bachelor", _EDU, re.I))
HAS_MASTER = bool(re.search(r"\bM\.?\s?(A|Sc?|S|Eng|BA|PP|PA|PH|FA|Ed|SW)\b|\bLL\.?M\b|master", _EDU, re.I))
HAS_DOCTORATE = bool(re.search(r"ph\.?\s?d|doctor|\bJ\.?D\b|juris|\bEd\.?D\b", _EDU, re.I))
GOV = yes_no(ELIG.get("government_employee_or_relative"), "No")
def _pref(key, default):
    v = STANDING.get(key)
    return default if v in (None, "") else str(v)


ONSITE_OK = _pref("onsite_ok", "Yes")
AI_POLICY_ACK = _pref("ai_policy_ack", "Yes")
CONTACT_METHOD = _pref("contact_method", "Email")
CLOSE_RELATIONSHIP = _pref("close_relationship_with_employee", "No")
AFFILIATE_EMPLOYEE = _pref("employed_by_affiliate", "No")
REFERRED_BY_LEADER = _pref("referred_by_leader", "No")
REFERRER_NAME = _pref("referrer_name", "N/A")
CONTRACTOR_HERE = _pref("contractor_here", "No")
SOURCE_ANSWER = _pref("how_did_you_hear", "LinkedIn")
RELATIVES_AT = [c for c in ELIG.get("relatives_at_companies") or [] if isinstance(c, str) and c.strip()]
RELATIVE_RX = (r"related to (anyone|someone|any|an?)\b.{0,40}\b(employee|employed|staff|officer|director|board member|"
               r"works? (at|for|here))|related to anyone|\b(any|a|your|have) relatives?\b|\brelatives? (who|that|employed|"
               r"working|currently)|family member.*employ", r"familial|personal relationship",
               r"family relationship|close personal contact")
_TZ = {"Pacific": "WA OR CA NV", "Mountain": "AZ CO ID MT NM UT WY", "Alaska": "AK", "Hawaii": "HI",
       "Central": "AL AR IL IA KS LA MN MS MO NE ND OK SD TN TX WI"}
TIME_ZONE = P.get("location", {}).get("time_zone") or next(
    (z for z, st in _TZ.items() if P.get("location", {}).get("state_code", "").upper() in st.split()),
    "Eastern" if P.get("location", {}).get("state_code", "").upper() in US_STATES_CODES else None)


import countries
_LOC, _IDN = P.get("location") or {}, P.get("identity") or {}
HOME = str(_LOC.get("country_code") or "US").upper()
HOME_NAME = "United States" if HOME == "US" else countries.name(HOME)
PHONE_CC = str(_IDN.get("phone_country_code") or "1")
PHONE_REGION = str(_IDN.get("phone_region") or ("US" if PHONE_CC == "1" else HOME)).upper()
PHONE_NAME = "United States" if PHONE_REGION == "US" else countries.name(PHONE_REGION)


def _alt(cc):
    names = [countries.name(cc)] + countries.ALIASES.get(cc, [])
    return "|".join(re.escape(n) for n in sorted(set(names), key=len, reverse=True))


def _ai_pick(what, opts):
    try:
        return llm.answer(f"Which option is {what}?", [o for o in opts if o]) if opts else None
    except Exception:
        return None


def home_pick(us):
    return us if HOME == "US" else (lambda o: countries.pick_country(o, HOME) or _ai_pick(f"the country {HOME_NAME}", o))


def phone_pick(us):
    if PHONE_REGION == "US" and us is not None:
        return us
    return lambda o: countries.pick_phone_code(o, PHONE_REGION, PHONE_CC) or \
        _ai_pick(f"the phone country code +{PHONE_CC} ({PHONE_NAME})", o)


def home_rx(us):
    return us if HOME == "US" else rf"^({_alt(HOME)})(\s*\(?\+[\d\s-]+\)?)?$"


def phone_rx(us):
    return us if PHONE_REGION == "US" else rf"^({_alt(PHONE_REGION)})\b.*\+{PHONE_CC}\b|^\+{PHONE_CC}\b|^({_alt(PHONE_REGION)})$"


def place_pick(opts):
    city = countries.norm(_LOC.get("city"))
    names = {countries.norm(n) for n in [HOME_NAME] + countries.ALIASES.get(HOME, [])}
    here = [o for o in opts if any(n and re.search(rf"\b{re.escape(n)}\b", countries.norm(o)) for n in names)]

    def score(o):
        first = countries.norm(o.split(",")[0])
        if not first or not city:
            return 0
        if first == city:
            return 3
        if city.startswith(first + " ") or first.startswith(city + " "):
            return 2
        return 1 if {w for w in city.split() if len(w) >= 4} & set(first.split()) else 0
    best = max(here, key=score, default=None)
    if best and score(best):
        return best
    return _ai_pick(f"the place where the person lives: {_LOC.get('city')}, {HOME_NAME}", opts)


def place_rx(us):
    return us if HOME == "US" else place_pick


def place_text(us):
    return us if HOME == "US" else f"{_LOC.get('city') or ''}, {HOME_NAME}"


def region_pick(o):
    st, sc = _LOC.get("state") or "", _LOC.get("state_code") or ""
    hit = next((x for x in o if x and x in (st, sc)), None)
    if hit or HOME == "US":
        return hit
    words = {w for w in countries.norm(_LOC.get("city")).split() if len(w) >= 4}
    return next((x for x in o if words & set(countries.norm(x).split())), None)


DEGREE_LEVELS =["High School", "Certificate", "Associate", "Bachelor", "Master", "Doctor"]


def degree_level(deg):
    d = str(deg or "").strip()
    if re.search(r"\bph\.?\s?d\b|doctor|\bD\.?D\.?S\b|\bD\.?V\.?M\b|\bJ\.?\s?D\b|juris|\bEd\.?\s?D\b|\bM\.?\s?D\b|D\.?\s?Phil|Psy\.?\s?D|\bD\.?B\.?A\b|"
                 r"\bD\.?\s?Sc\b|\bPharm\.?\s?D|\bD\.?N\.?P\b", d, re.I):
        return "Doctor"
    if re.search(r"(post)?graduate (diploma|certificate)", d, re.I):
        return "Certificate"
    if re.search(r"laurea magistrale|magistr", d, re.I):
        return "Master"
    if re.match(r"(B\.?\s?(A|Sc?|S|E|Eng|S\.?E|F\.?A|B\.?A|Ed|Arch|Tech|Com|S\.?N|Mus|Phil|Pharm)\b\.?|A\.?B\b\.?|S\.?B\b\.?|Sc\.?\s?B\b\.?|LL\.?\s?B\b|bachelor|"
                r"baccalaur|laurea\b)", d, re.I):
        return "Bachelor"
    if re.match(r"(M\.?\s?(A|Sc?|S|E|Eng|B\.?A|P\.?P|P\.?A|P\.?H|F\.?A|Ed|S\.?W|Phil|Arch|Div|Res|I\.?A|L\.?S|L\.?I\.?S|Fin|Acc|"
                r"Tech|Mus|S\.?N|Pharm)\b\.?|laurea magistrale|"
                r"LL\.?\s?M\b|master|magister)", d, re.I):
        return "Master"
    if re.match(r"(A\.?\s?(A|S|A\.?S)\b\.?|associate)", d, re.I):
        return "Associate"
    if re.search(r"high school|secondary|G\.?E\.?D\b|diploma", d, re.I):
        return "High School"
    if re.search(r"certificat", d, re.I):
        return "Certificate"
    return None


_LEVELS = {degree_level(d.get("degree")) for d in P.get("education_on_forms", []) + P.get("education", [])}
HAS_BACHELOR = HAS_BACHELOR or bool(_LEVELS & {"Bachelor", "Master", "Doctor"})
HAS_MASTER = HAS_MASTER or "Master" in _LEVELS
HAS_DOCTORATE = HAS_DOCTORATE or "Doctor" in _LEVELS


def degree_kind(deg):
    d = str(deg or "").strip()
    if re.match(r"[BM]\.?\s?A\b", d, re.I) or re.search(r"\bof arts\b", d, re.I):
        return "Arts"
    if re.match(r"[BM]\.?\s?Sc?\b", d, re.I) or re.search(r"\bof science\b", d, re.I):
        return "Science"
    return None


def career_years():
    ys = [int(e["start_year"]) for e in P.get("experience", []) if str(e.get("start_year", "")).isdigit()]
    return dt.date.today().year - min(ys) if ys else 0


YEARS = career_years()
_NUM = {"one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "eight": 8, "ten": 10, "twelve": 12}


def start_date():
    s = EARLIEST_START.lower()
    m = re.search(r"(\d+|one|two|three|four|five|six|eight|ten|twelve)\s*(day|week|month)", s)
    if not m:
        return dt.date.today()
    n = int(m.group(1)) if m.group(1).isdigit() else _NUM[m.group(1)]
    days = {"day": 1, "week": 7, "month": 30}[m.group(2)] * n
    return dt.date.today() + dt.timedelta(days=days)


START_DATE = start_date()
_TRAVEL = str(ELIG.get("willing_to_travel") or "")
TRAVEL = "Yes" if yes_no(_TRAVEL) == "Yes" or re.search(r"up to|\d+\s*%|occasional", _TRAVEL, re.I) else yes_no(_TRAVEL, "No")
_tp = re.search(r"(\d+)\s*%", _TRAVEL)
TRAVEL_MAX_PCT = int(_tp.group(1)) if _tp else None
TRAVEL_Q = re.compile(r"willing to travel|travel up to|require[sd]? travel|percent(age)? of travel|travel (requirement|\d)", re.I)


def travel_answer(label):
    if not label or not TRAVEL_Q.search(label):
        return None
    if TRAVEL == "No":
        return "No"
    q = re.search(r"(\d+)\s*%", label)
    return "Yes" if TRAVEL_MAX_PCT is None or not q or int(q.group(1)) <= TRAVEL_MAX_PCT else "No"


def years_option(opts):
    best = None
    for o in opts:
        nums = [int(x) for x in re.findall(r"\d+", o)]
        if not nums:
            continue
        lo, hi = nums[0], (nums[1] if len(nums) > 1 else (10 ** 6 if re.search(r"\+|more|over|above", o, re.I) else nums[0]))
        if lo <= YEARS <= hi:
            return o
        if lo <= YEARS and (best is None or lo > best[0]):
            best = (lo, o)
    return best[1] if best else None


def _name_words(name):
    return [w for w in re.findall(r"[a-z0-9]+", (name or "").lower()) if w not in ("inc", "llc", "ltd", "corp", "corporation", "co", "the")]


def same_company(a, b):
    x, y = _name_words(a), _name_words(b)
    if not x or not y:
        return False
    short, long_ = sorted((x, y), key=len)
    return long_[:len(short)] == short or "".join(x) == "".join(y)


def former_employer(company):
    return any(same_company(company, e.get("company")) for e in P.get("experience", []))
US_STATES = {"AL": "Alabama", "AK": "Alaska", "AZ": "Arizona", "AR": "Arkansas", "CA": "California", "CO": "Colorado",
             "CT": "Connecticut", "DE": "Delaware", "DC": "District of Columbia", "FL": "Florida", "GA": "Georgia",
             "HI": "Hawaii", "ID": "Idaho", "IL": "Illinois", "IN": "Indiana", "IA": "Iowa", "KS": "Kansas",
             "KY": "Kentucky", "LA": "Louisiana", "ME": "Maine", "MD": "Maryland", "MA": "Massachusetts", "MI": "Michigan",
             "MN": "Minnesota", "MS": "Mississippi", "MO": "Missouri", "MT": "Montana", "NE": "Nebraska", "NV": "Nevada",
             "NH": "New Hampshire", "NJ": "New Jersey", "NM": "New Mexico", "NY": "New York", "NC": "North Carolina",
             "ND": "North Dakota", "OH": "Ohio", "OK": "Oklahoma", "OR": "Oregon", "PA": "Pennsylvania", "RI": "Rhode Island",
             "SC": "South Carolina", "SD": "South Dakota", "TN": "Tennessee", "TX": "Texas", "UT": "Utah", "VT": "Vermont",
             "VA": "Virginia", "WA": "Washington", "WV": "West Virginia", "WI": "Wisconsin", "WY": "Wyoming"}


def split_location(loc):
    parts = [x.strip() for x in str(loc or "").split(",")]
    if len(parts) == 1 and parts[0]:
        p = parts[0]
        if p.upper() in US_STATES:
            return "", US_STATES[p.upper()], "United States"
        return ("", p, "United States") if p in US_STATES.values() else ("", "", p)
    city, rest = parts[0], (parts[1] if len(parts) > 1 else "")
    if rest.upper() in US_STATES:
        return city, US_STATES[rest.upper()], "United States"
    if rest in US_STATES.values():
        return city, rest, "United States"
    return city, "", rest or "United States"


def is_current(job):
    return not job.get("end_year")


PREV_RX = (r"previously (been )?(employed|worked)|former employee|worked (for|at) .* before|currently or have you previously",
           r"ever worked for|have you worked (for|at)|worked for .* as an employee")


def personalize_for(company):
    ans = "Yes" if former_employer(company) else "No"
    rel = "Yes" if any(same_company(company, c) for c in RELATIVES_AT) else "No"
    for cls in (Workday, Greenhouse, Ashby, Phenom) + tuple(ADAPTERS[n] for n in PLUGINS):
        if "RULES" in cls.__dict__ and isinstance(cls.RULES, list):
            cls.RULES = [(rx, ans if rx in PREV_RX else rel if rx in RELATIVE_RX else a) for rx, a in cls.RULES]
    Eightfold.RULES = [(rx, (r"^yes\b" if ans == "Yes" else r"^no\b") if rx == r"worked for|employed by" else w)
                       for rx, w in Eightfold.RULES]
    Oracle.QUESTIONS = [(rx, ("Yes" if former_employer("Oracle") and re.search(r"oracle", company or "", re.I) else "No")
                         if rx == r"ex-?oracle employee" else a) for rx, a in Oracle.QUESTIONS]


WD = "[data-automation-id='{}']"


class Workday:

    def __init__(self, page, jd, company, resume_pdf):
        self.p, self.jd, self.company, self.resume = page, jd, company, resume_pdf
        self.notes = []
        self.reloads = 0


    def main(self):
        return self.p.locator("main")

    def text(self, loc, value):
        loc.scroll_into_view_if_needed()
        loc.click()
        loc.press("Control+A")
        loc.press("Delete")
        loc.press_sequentially(value, delay=8)
        loc.press("Tab")

    def dropdown(self, btn, choose):
        self.close_prompts()
        btn.scroll_into_view_if_needed()
        btn.click()
        listbox = lambda: (self.p.locator(f"[id='{btn.get_attribute('aria-controls')}']") if btn.get_attribute("aria-controls")
                           else self.p.locator("[role=listbox]:visible").filter(
                               has_not=self.p.locator("[data-automation-id='promptOption']")).last)
        lb = listbox()
        try:
            lb.wait_for(timeout=8000)
        except PWTimeout:
            self.p.keyboard.press("Escape")
            self.close_prompts()
            try:
                btn.click(timeout=5000)
            except PWTimeout:
                btn.evaluate("e => e.click()")
            lb = listbox()
            try:
                lb.wait_for(timeout=8000)
            except PWTimeout:
                self.p.keyboard.press("Escape")
                return None, []
        real = lambda o: [x for x in o if x.lower() != "select one"]
        for again in (False, True):
            for _ in range(16):
                opts = [o.strip() for o in lb.locator("[role=option]").all_inner_texts() if o.strip()]
                if real(opts):
                    break
                self.p.wait_for_timeout(500)
            if real(opts) or again:
                break
            self.p.keyboard.press("Escape")
            self.p.wait_for_timeout(500)
            btn.click()
            lb = listbox()
            try:
                lb.wait_for(timeout=8000)
            except PWTimeout:
                break
        pick = choose(opts) if callable(choose) else next(
            (o for o in opts if o.lower() == choose.lower()), None) or next(
            (o for o in opts if o.lower().startswith(choose.lower())), None)
        if not pick:
            self.p.keyboard.press("Escape")
            return None, opts
        lb.locator("[role=option]").filter(has_text=re.compile("^" + re.escape(pick) + "$")).first.click()
        self.p.wait_for_timeout(500)
        offer(self, pick, real(opts))
        return pick, opts

    def multiselect(self, inp, query, choose=None):
        self.close_prompts()
        inp.scroll_into_view_if_needed()
        try:
            inp.click(timeout=5000)
        except PWTimeout:
            self.p.keyboard.press("Escape")
            self.close_prompts()
            try:
                inp.click(timeout=5000)
            except PWTimeout:
                inp.focus()
        inp.fill(query)
        inp.press("Enter")
        self.p.wait_for_timeout(1800)
        opts_loc = self.p.locator("[data-automation-id='promptOption']")
        opts = [o.strip() for o in opts_loc.all_inner_texts() if o.strip()]
        pick = choose(opts) if choose else next(
            (o for o in opts if o.lower() == query.lower()), opts[0] if opts else None)
        if pick:
            opts_loc.filter(has_text=re.compile("^" + re.escape(pick) + "$")).first.click()
            self.p.wait_for_timeout(600)
            offer(self, pick, opts)
        self.close_prompts()
        return pick

    def close_prompts(self):
        for _ in range(6):
            if not self.p.locator("[data-automation-id='promptOption']:visible").count():
                return
            self.p.keyboard.press("Escape")
            self.p.wait_for_timeout(300)
        self.p.keyboard.press("Tab")
        self.p.wait_for_timeout(300)

    def date(self, root_sel, month, year):
        m = self.p.locator(f"{root_sel}[id$='dateSectionMonth-input']").first
        val = f"{month:02d}{year}"
        if not m.count():
            m = self.p.locator(f"{root_sel}[id$='dateSectionYear-input']").first
            val = f"{year}"
        m.scroll_into_view_if_needed()
        m.focus()
        self.p.keyboard.type(val, delay=40)
        self.p.keyboard.press("Tab")

    def tick(self, box):
        if box.is_checked():
            return True
        box.evaluate("e => e.click()")
        self.p.wait_for_timeout(300)
        if not box.is_checked():
            box.evaluate("e => (e.labels && e.labels[0] ? e.labels[0] : e.parentElement).click()")
            self.p.wait_for_timeout(300)
        return box.is_checked()

    def by_id_suffix(self, suffix):
        return self.p.locator(f"main [id$='{suffix}']").first


    def step(self):
        dismiss_cookies(self.p)
        try:
            t = self.p.locator(WD.format("progressBarActiveStep")).inner_text(timeout=3000)
        except PWTimeout:
            t = ""
        t = " ".join(t.split())
        return re.sub(r"^current step \d+ of \d+\s*", "", t, flags=re.I) or t

    def errors(self):
        errs = self.p.evaluate("""() => [...document.querySelectorAll('[aria-invalid=true]')].map(e =>
            ((e.closest('[data-automation-id^=formField-]') || e).innerText || e.id).replace(/\\s+/g, ' ').trim().slice(0, 140))""")
        if not errs:
            banner = self.p.locator(WD.format("errorHeading"))
            errs = [b.strip() for b in banner.all_inner_texts() if b.strip()]
        return errs

    def crashed(self):
        try:
            body = self.p.locator("body").inner_text(timeout=3000)
        except Exception:
            return False
        return bool(re.search(r"something went wrong", body, re.I) and re.search(r"refresh the page", body, re.I))

    def recover(self):
        if not self.crashed() or self.reloads >= 3:
            return False
        self.reloads += 1
        say(f"Workday error page - reloading (try {self.reloads})")
        self.p.reload(wait_until="domcontentloaded")
        self.p.wait_for_timeout(6000)
        return True

    def next(self):
        before = self.step()
        try:
            self.p.locator(WD.format("pageFooterNextButton")).click(timeout=15000)
        except PWTimeout:
            return False
        for _ in range(40):
            self.p.wait_for_timeout(500)
            if self.step() != before:
                return True
            if self.errors():
                return False
        return False


    def start(self):
        p = self.p
        p.wait_for_timeout(2500)
        in_form = lambda: p.locator(WD.format("progressBar")).count() or             p.locator(WD.format("pageFooterNextButton")).count()
        if in_form() and not self.on_login_page():
            say("resuming an application already in progress")
            return True
        apply_btn = p.locator(WD.format("adventureButton"))
        if not apply_btn.count():
            apply_btn = p.get_by_role("button", name=re.compile(r"^\s*(apply|continue application)", re.I))
        check_already_applied(p.context)
        apply_btn.first.click(timeout=15000)
        p.wait_for_timeout(1500)
        check_already_applied(p.context)
        manual = p.locator(WD.format("applyManually"))
        for _ in range(16):
            p.wait_for_timeout(500)
            if manual.count() or p.locator(WD.format("progressBar")).count():
                break
        if manual.count():
            manual.first.click()
        self.watch_google()
        tried_google = False
        for i in range(600):
            if i % 3 == 0 or p.is_closed():
                check_already_applied(p.context)
            if p.locator(WD.format("progressBar")).count() and not self.on_login_page():
                self.learn_google()
                return True
            if not tried_google and self.on_login_page():
                tried_google = True
                link = p.locator(WD.format("signInLink") + ":visible, button:visible:text-is('Sign In'), a:visible:text-is('Sign In')")
                if p.locator("input[type=password]:visible").count() >= 2 and link.count():
                    try:
                        link.last.click(timeout=5000)
                        p.wait_for_timeout(2500)
                        say("switched from Create Account to the Sign In form")
                    except PWTimeout:
                        say("could not switch to the Sign In form")
                if self.try_known_google():
                    continue
                if self.try_saved_password():
                    continue
            if UNATTENDED and i >= 3 and self.on_login_page():
                raise NeedsUser("sign-in needed - this company's Workday has no Google sign-in and Chrome has no saved password "
                                 "(sign in once via JobBot pending and let Chrome SAVE the password - then it is automatic)"
                                 if getattr(self, "no_google_button", False) else
                                 "sign-in needed - no earlier Google sign-in at this company's Workday")
            if i == 3:
                say("waiting for you: sign in (Google) or create the account in the job-apply Chrome")
            p.wait_for_timeout(1000)
        return False

    def settle(self):
        try:
            self.p.locator("[data-automation-id^='formField-']").first.wait_for(timeout=20000)
        except PWTimeout:
            pass
        last, same = -1, 0
        for _ in range(30):
            self.p.wait_for_timeout(500)
            try:
                n = self.p.evaluate("() => document.querySelectorAll('main input, main button, main textarea').length")
            except Exception:
                n = -2
            same, last = (same + 1 if n == last else 0), n
            if same >= 4:
                break

    def host(self):
        return urlparse(self.p.url).netloc.lower()

    def watch_google(self):
        self.saw_google = False
        def seen(frame):
            if "accounts.google.com" in frame.url:
                self.saw_google = True
        def new_page(pg):
            if "accounts.google.com" in pg.url:
                self.saw_google = True
            pg.on("framenavigated", seen)
        self.p.on("framenavigated", seen)
        self.p.context.on("page", new_page)

    def learn_google(self):
        if self.saw_google and self.host() not in google_sites():
            remember_google_site(self.host())
            say(f"remembered: Google sign-in works at {self.host()}")

    def try_known_google(self):
        if self.host() not in google_sites():
            say(f"first Google sign-in at {self.host()} - trying it (stops at any password / consent screen)")
        if self.google_sso():
            say("signed in with Google")
            return True
        return False

    def google_sso(self):
        p, ctx = self.p, self.p.context
        btn = p.locator(WD.format("GoogleSignInButton") + ":visible")
        try:
            btn.first.wait_for(timeout=8000)
        except PWTimeout:
            say("no 'Sign in with Google' button on this sign-in page")
            self.no_google_button = True
            return False
        before = set(ctx.pages)
        btn.first.click()
        me = P["identity"]["email"]
        for _ in range(30):
            p.wait_for_timeout(1000)
            if not self.on_login_page():
                return True
            g = next((q for q in [p, *(set(ctx.pages) - before)]
                      if not q.is_closed() and "accounts.google.com" in q.url), None)
            if not g:
                continue
            if g.locator("input[type=password]:visible").count():
                return False
            tile = g.locator(f"[data-identifier='{me}']:visible")
            if tile.count():
                tile.first.click()
                continue
            if re.search(r"signing back in", g.locator("body").inner_text(), re.I):
                g.get_by_role("button", name=re.compile(r"^continue$", re.I)).first.click()
                continue
            if re.search(r"wants (additional )?access|\bAllow\b|create (an |your )?account", g.locator("body").inner_text(), re.I):
                return False
        return not self.on_login_page()

    def start_wait_login(self):
        for _ in range(600):
            if not self.on_login_page():
                return True
            self.p.wait_for_timeout(1000)
        return False

    def on_login_page(self):
        if self.p.locator("input[type=password]:visible").count():
            return True
        return bool(re.search(r"sign in|create account|log ?in", self.step(), re.I))

    def try_saved_password(self):
        p = self.p
        pw = p.locator("input[type=password]:visible")
        for _ in range(16):
            if pw.count():
                break
            p.wait_for_timeout(500)
        if pw.count() >= 2:
            link = p.locator(WD.format("signInLink") + ":visible, button:visible:text-is('Sign In'), a:visible:text-is('Sign In')")
            if link.count():
                try:
                    link.last.click(timeout=5000)
                    p.wait_for_timeout(2500)
                    say("switched from Create Account to the Sign In form")
                except PWTimeout:
                    pass
        for _ in range(8):
            if pw.count() == 1 and pw.first.evaluate("e => e.matches(':-webkit-autofill')"):
                break
            p.wait_for_timeout(500)
        else:
            return False
        pw.first.click()
        p.wait_for_timeout(400)
        for sel in (WD.format("click_filter") + "[aria-label='Sign In']:visible", WD.format("signInSubmitButton") + ":visible",
                    "button:visible:text-is('Sign In')"):
            btn = p.locator(sel)
            if btn.count():
                btn.first.click()
                break
        else:
            return False
        say("signed in with Chrome's saved password (autofilled by Chrome)")
        for _ in range(30):
            p.wait_for_timeout(500)
            if not self.on_login_page():
                return True
        say("the saved password did not get past the sign-in page")
        return False


    RULES = [
        (r"month (you|that you) (could|can|would) start|(earliest|available) start(ing)? month|start month of availability",
         START_DATE.strftime("%B")),
    ] + ([] if REFERRAL else [
        (r"were you referred|referred (to this position|for this (role|position|job))|by a (senior leader|current employee)",
         REFERRED_BY_LEADER),
        (r"referred by|referrer|who referred you|name of (the )?(person|employee) who referred|referral (name|source)",
         REFERRER_NAME),
    ]) + [
        (AUTH_RX, AUTHORIZED),
    ] + ([(r"(what|which) (type|kind) of visa|type of visa|visa (type|status) and", "Not applicable")]
         if SPONSOR == "No" else []) + [
        (SPONSOR_RX, SPONSOR),
        (r"non-?compete|non-?solicit", NON_COMPETE),
        (PREV_RX[0], "No"),
        (r"18 years|age of 18|legal age", OVER_18),
        (r"relocat", RELOCATE),
        (r"willing to travel|travel up to|require travel", TRAVEL),
        (r"clearance|polygraph", CLEARANCE),
        (r"are you currently employed|currently employed\?", EMPLOYED),
    ] + ([(r"(may|can) we contact (your )?(current|present) employer|contact your (current|present) employer", CONTACT_EMPLOYER)]
         if CONTACT_EMPLOYER else []) + [
        (RELATIVE_RX[0], "No"),
        (r"government official|government entity|employed by .{0,30}government", GOV),
    ]

    def rule(self, label):
        loc = location_answer(label, self.jd)
        if loc:
            return loc
        for rx, ans in self.RULES:
            if re.search(rx, label, re.I):
                return ans
        return None

    def generic_pass(self):
        if self.on_login_page():
            raise RuntimeError("refusing to fill a sign-in / create-account page")
        fields = self.p.locator("main [data-automation-id^='formField-']")
        for i in range(fields.count()):
            f = fields.nth(i)
            try:
                if not f.is_visible():
                    continue
                label = " ".join(f.locator("label, legend").first.inner_text(timeout=1000).split())
            except Exception:
                continue
            req = "*" in label
            label = label.replace("*", "").strip()
            low = label.lower()
            if re.match(r"(degree|school|field of study|overall result|gpa|job title|company|location|"
                        r"from|to|i currently work|role description|url)\b", low):
                continue
            if re.search(r"salary|compensation|pay expectation", low):
                if req:
                    self.notes.append(f"REQUIRED salary field left for you: {label}")
                    human(f"'{label}' is required. Fill it in the browser, then press Enter.")
                continue
            btn = f.locator("button[aria-haspopup=listbox]")
            radios = f.locator("input[type=radio]")
            area = f.locator("textarea")
            txt = f.locator("input[type=text]")
            if btn.count():
                if btn.first.inner_text().strip() not in ("Select One", ""):
                    continue
                ans = self.rule(label)
                pick, opts = self.dropdown(btn.first, lambda o: (
                    (ans(o) if callable(ans) else None) or
                    next((x for x in o if ans and x.lower() == ans.lower()), None) or
                    llm.answer(label, [x for x in o if x != "Select One"], self.jd, self.company)))
                if not pick and req:
                    human(f"Couldn't answer '{label}' (options: {opts}). Choose it in the browser, then Enter.")
                self.notes.append(f"{label} -> {pick}" + (f"  (options: {opts})" if LOCATION_Q.search(label) else ""))
            elif radios.count():
                if f.locator("input[type=radio]:checked").count():
                    continue
                opts = [r.strip() for r in f.locator("label").all_inner_texts()[1:] if r.strip()]
                ans = self.rule(label)
                pick = (ans(opts) if callable(ans) else None) or \
                    next((o for o in opts if ans and o.lower() == ans.lower()), None) or \
                    llm.answer(label, opts, self.jd, self.company)
                if pick:
                    f.get_by_text(pick, exact=True).first.click()
                    self.notes.append(f"{label} -> {pick}" + (f"  (options: {opts})" if LOCATION_Q.search(label) else ""))
                elif req:
                    human(f"Couldn't answer '{label}'. Choose it in the browser, then Enter.")
            elif area.count():
                if area.first.input_value().strip():
                    continue
                if re.search(r"why|interest|motivat|tell us|cover|about you", low):
                    t = llm.draft(label, self.jd, self.company)
                else:
                    t = llm.answer(label, None, self.jd, self.company)
                if t:
                    self.text(area.first, t)
                    self.notes.append(f"{label} -> [free text] {t}")
                elif req:
                    human(f"Couldn't draft '{label}'. Type it in the browser, then Enter.")
            elif txt.count() and not txt.first.input_value().strip() and req:
                t = self.rule(label) or llm.answer(label, None, self.jd, self.company)
                if t:
                    self.text(txt.first, t)
                    self.notes.append(f"{label} -> {t}")
                else:
                    human(f"Couldn't answer '{label}'. Fill it in the browser, then Enter.")


    def my_information(self):
        idn, loc = P["identity"], P["location"]
        src = self.p.locator("main [id$='source--source'], main [data-automation-id='formField-source'] input").first
        if src.count() and not self.p.locator("main [data-automation-id='formField-source'] [data-automation-id='selectedItem']").count():
            board = lambda o: (next((x for x in o if "linkedin" in x.lower()), None)
                               or next((x for x in o if re.search(r"job board|website|online", x, re.I)), None))
            if SOURCE:
                got = self.multiselect(src, SOURCE, lambda o: next((x for x in o if re.search(SOURCE, x, re.I)), None))
                if not got:
                    got = self.multiselect(src, "LinkedIn", board)
                    self.notes.append(f"How did you hear: no '{SOURCE}' option -> {got or 'left for you'}")
                    if not got:
                        human(f"'How did you hear about us' has no '{SOURCE}' or LinkedIn / job board option - pick the "
                              f"closest one in the browser, then continue.")
            elif REFERRAL:
                self.multiselect(src, "Referral", lambda o: next((x for x in o if re.search(r"referr", x, re.I)), None))
            else:
                self.multiselect(src, "LinkedIn", board)
        ctry = self.p.locator("main button[id$='country--country']").first
        cur = ctry.inner_text().strip() if ctry.count() else ""
        if ctry.count() and not (re.match(r"united states", cur, re.I) if HOME == "US" else countries.pick_country([cur], HOME)):
            got, _ = self.dropdown(ctry, home_pick(lambda o: next((x for x in o if re.match(r"^United States( of America)?$", x)), None)))
            self.notes.append(f"country -> {got}")
            if not got:
                human(f"Country is not {HOME_NAME} and no {HOME_NAME} option was found - set it in the browser, then continue.")
            self.p.wait_for_timeout(2000)
        for sfx, val in (("legalName--firstName", idn["first_name"]),
                         ("legalName--lastName", idn["last_name"]),
                         ("addressLine1", loc["street_address"]),
                         ("city", loc["city"]),
                         ("postalCode", loc["zip"]),
                         ("phoneNumber--phoneNumber", idn["phone_digits"])):
            el = self.by_id_suffix(sfx)
            if el.count() and el.is_visible():
                self.text(el, val)
        for sfx, val in (("countryRegion", loc["state"] if HOME == "US" else region_pick), ("phoneType", "Mobile")):
            el = self.p.locator(f"main button[id$='{sfx}']").first
            if el.count() and el.inner_text().strip() in ("Select One", "") and val:
                self.dropdown(el, val)
        code = self.p.locator("main [id$='countryPhoneCode'] input, main input[id$='countryPhoneCode']").first
        if PHONE_REGION != HOME and code.count():
            got = self.multiselect(code, PHONE_NAME, phone_pick(None))
            self.notes.append(f"phone country code -> {got}")
        self.generic_pass()

    def _delete_all(self, input_suffix):
        for _ in range(20):
            done = self.p.evaluate("""(sfx) => {
                for (const b of document.querySelectorAll('main button')) {
                  if (b.innerText.trim() !== 'Delete') continue;
                  let c = b; for (let k = 0; k < 8 && c; k++) { c = c.parentElement;
                    if (c && c.querySelector(`input[id$="${sfx}"]`)) { b.click(); return true; } }
                }
                return false; }""", input_suffix)
            if not done:
                return
            self.p.wait_for_timeout(700)

    def _add(self, section, input_suffix):
        sfxs = input_suffix.split("|")
        sel = ", ".join(f"main [id$='{x}']" for x in sfxs)
        before = self.p.locator(sel).count()
        ok = self.p.evaluate("""(sec) => {
            for (const b of document.querySelectorAll('main button')) {
              const t = b.innerText.trim(); if (t !== 'Add' && t !== 'Add Another') continue;
              let c = b; for (let k = 0; k < 10 && c; k++) { c = c.parentElement;
                const id = c && c.getAttribute('aria-labelledby');
                const h = id && document.getElementById(id.split(' ')[0]);
                if (h && h.innerText.trim().startsWith(sec)) { b.click(); return true; } }
            }
            return false; }""", section)
        if not ok:
            raise RuntimeError(f"no Add button for {section}")
        for _ in range(30):
            self.p.wait_for_timeout(300)
            els = self.p.locator(sel)
            if els.count() > before:
                eid = els.nth(els.count() - 1).get_attribute("id")
                self.last_suffix = next(x for x in sfxs if eid.endswith(x))
                return eid[: -len(self.last_suffix)]
        raise RuntimeError(f"{section}: new entry did not appear")

    def _leftover(self, *suffixes):
        roots = []
        for sfx in suffixes:
            for el in self.p.locator(f"main input[id$='{sfx}']").all():
                roots.append((el.get_attribute("id")[: -len(sfx)], sfx))
        return roots

    def _has_section(self, section):
        return self.p.evaluate("""(sec) => [...document.querySelectorAll('main button')].some(b => {
              const t = b.innerText.trim(); if (t !== 'Add' && t !== 'Add Another') return false;
              let c = b; for (let k = 0; k < 10 && c; k++) { c = c.parentElement;
                const id = c && c.getAttribute('aria-labelledby');
                const h = id && document.getElementById(id.split(' ')[0]);
                if (h && h.innerText.trim().startsWith(sec)) return true; }
              return false; })""", section)

    def my_experience(self):
        self._delete_all("--jobTitle")
        keep = self._leftover("--jobTitle")
        jobs = P["experience"] if keep or self._has_section("Work Experience") else []
        if not jobs:
            self.notes.append("no Work Experience section on this form (GM-style: resume only)")
        for job in jobs:
            root = keep.pop(0)[0] if keep else self._add("Work Experience", "--jobTitle")
            sel = f"main [id^='{root}']"
            self.text(self.p.locator(f"main [id='{root}--jobTitle']"), job["title"])
            self.text(self.p.locator(f"main [id='{root}--companyName']"), job["company"])
            loc_in = self.p.locator(f"main [id='{root}--location']")
            if loc_in.count():
                self.text(loc_in, job["location"])
            self.date(f"main [id^='{root}--startDate']", job["start_month"], job["start_year"])
            if is_current(job):
                cur = self.p.locator(f"main [id='{root}--currentlyWorkHere']")
                if cur.count():
                    self.tick(cur.first)
            else:
                self.date(f"main [id^='{root}--endDate']", job["end_month"], job["end_year"])
            desc = self.p.locator(f"main [id='{root}--roleDescription']")
            if desc.count():
                self.text(desc, job.get("description") or "")
        self._delete_all("--schoolName")
        self._delete_all("--school")
        keep_ed = self._leftover("--schoolName", "--school")
        degrees = P["education_on_forms"] if keep_ed or self._has_section("Education") else []
        if not degrees:
            self.notes.append("no Education section on this form")
        for ed in degrees:
            if keep_ed:
                root, self.last_suffix = keep_ed.pop(0)
            else:
                root = self._add("Education", "--schoolName|--school")
            if self.last_suffix == "--schoolName":
                self.text(self.p.locator(f"main [id='{root}--schoolName']"), ed["school"])
            else:
                box = self.p.locator(f"main [id='{root}--school'] input, main input[id='{root}--school']").first
                same = lambda s: lambda o: next((x for x in o if x.lower() == s.lower()), None) or \
                    next((x for x in o if s.lower() in x.lower()), None)
                got = self.multiselect(box, ed["school"], same(ed["school"])) \
                    or (ed.get("school_fallback") and self.multiselect(box, ed["school_fallback"], same(ed["school_fallback"]))) \
                    or self.multiselect(box, "Other", lambda o: next((x for x in o if x.strip().lower() == "other"), None))
                self.notes.append(f"{ed['school']}: school list -> {got}")
            deg = self.p.locator(f"main button[id='{root}--degree']")
            if deg.count():
                alts = [re.compile(a, re.I) for a in ed["degree_match"].split("|")]
                pick, opts = self.dropdown(deg, lambda o: next((x for a in alts for x in o if a.search(x)), None))
                self.notes.append(f"{ed['school']}: degree -> {pick}")
                if not pick:
                    human(f"No degree option matched {ed['degree']} (options: {opts}). Set it, then Enter.")
            fos = self.p.locator(f"main [id^='{root}--fieldOfStudy'] input, main input[id^='{root}--fieldOfStudy']").first
            if fos.count():
                for q in ed["field_queries"]:
                    got = self.multiselect(fos, q, lambda o, q=q: next((x for x in o if x.lower() == q.lower()), None)
                                           or next((x for x in o if q.lower() in x.lower()), None))
                    if got:
                        self.notes.append(f"{ed['school']}: field of study -> {got}")
                        break
        items = self.p.locator(WD.format("file-upload-item"))
        while items.count() > 1:
            items.last.locator("button").last.click()
            self.p.wait_for_timeout(1000)
        up = self.p.locator("main input[type=file]").first
        if up.count() and not items.count():
            up.set_input_files(self.resume)
            self.p.wait_for_timeout(4000)
            if not resume_shown(self.p, self.resume):
                human("The resume upload is not shown on My Experience - attach it in the browser, then Enter.")
        have = [u.input_value() for u in self.p.locator("main input[id$='--url']").all()]
        if not any("linkedin.com/in/" in (u or "") for u in have):
            try:
                root = self._add("Websites", "--url")
                self.text(self.p.locator(f"main [id='{root}--url']"), P["identity"]["linkedin"])
            except Exception:
                pass
        self.generic_pass()

    def voluntary(self):
        eeo_rules = [(r"hispanic|latino", eeo("hispanic")), (r"race|ethnic", eeo("race")), (r"gender|sex", eeo("gender")),
                     (r"veteran", eeo("veteran"))]
        fields = self.p.locator("main [data-automation-id^='formField-']")
        for i in range(fields.count()):
            f = fields.nth(i)
            btn = f.locator("button[aria-haspopup=listbox]")
            if not btn.count() or btn.first.inner_text().strip() not in ("Select One", ""):
                continue
            label = f.inner_text()
            for rx, chooser in eeo_rules:
                if re.search(rx, label, re.I):
                    pick, opts = self.dropdown(btn.first, chooser)
                    if not pick:
                        pick = llm.answer(label.split("\n")[0], opts)
                        if pick:
                            self.dropdown(btn.first, pick)
                    self.notes.append(f"EEO {rx} -> {pick}")
                    break
        for i in range(fields.count()):
            f = fields.nth(i)
            boxes = f.locator("input[type=checkbox]")
            if not boxes.count() or f.locator("input[type=checkbox]:checked").count():
                continue
            if not re.search(r"race|ethnic", f.inner_text().split("\n")[0], re.I):
                continue
            labs = [boxes.nth(j).evaluate("e => (e.labels && e.labels[0] ? e.labels[0].innerText : e.closest('div').innerText)")
                    for j in range(boxes.count())]
            pick = eeo_pick("race", [l.strip() for l in labs])
            for j, lab in enumerate(labs):
                if pick and lab.strip() == pick:
                    self.tick(boxes.nth(j))
                    self.notes.append(f"EEO race (checkboxes) -> {lab.strip()[:60]}")
                    break
        self._tick_agreements()
        self.generic_pass()

    def _tick_agreements(self):
        boxes = self.p.locator("main input[type=checkbox]")
        for i in range(boxes.count()):
            b = boxes.nth(i)
            lab = b.evaluate("e => (e.labels && e.labels[0] ? e.labels[0].innerText : e.closest('div').innerText)")
            if re.search(r"certif|agree|acknowledg|consent|i have read|terms", lab, re.I) and not NO_TEXT.search(lab) \
                    and not b.is_checked():
                self.tick(b)
                self.notes.append(f"ticked: {lab.strip()[:90]}")

    def self_identify(self):
        name = self.p.locator("main [id$='--name'], main input[id*='name']").first
        if name.count() and not name.input_value().strip():
            self.text(name, f"{P['identity']['first_name']} {P['identity']['last_name']}")
        today = dt.date.today()
        mon = self.p.locator("main [id$='dateSectionMonth-input']").first
        if mon.count() and not mon.input_value().strip():
            mon.focus()
            self.p.keyboard.type(f"{today:%m%d%Y}", delay=40)
        boxes = self.p.locator("main input[type=checkbox]")
        for _ in range(20):
            if boxes.count():
                break
            self.p.wait_for_timeout(500)
        for i in range(boxes.count()):
            b = boxes.nth(i)
            lab = b.evaluate("""e => (e.labels && e.labels[0] ? e.labels[0].innerText : '') ||
                (e.getAttribute('aria-labelledby') || '').split(' ').map(i => document.getElementById(i)?.innerText || '').join(' ').trim() ||
                e.getAttribute('aria-label') || (e.closest('[data-automation-id*=checkbox], div')?.parentElement?.innerText || '')""")
            if re.search(r"disabilit", lab, re.I) and eeo_pick("disability", [lab.strip()]):
                self.tick(b)
                self.notes.append("disability -> " + lab.strip())
        self.generic_pass()


    def run(self, submit=False):
        if not self.start():
            return "sign-in not completed", None
        handled = {}
        for _ in range(15):
            if self.recover():
                continue
            s = self.step()
            say(f"page: {s}")
            if self.on_login_page() and self.try_known_google():
                continue
            if self.on_login_page():
                if UNATTENDED:
                    raise NeedsUser("sign-in required mid-application")
                say("back on a sign-in page - waiting for you")
                if not self.start_wait_login():
                    return "sign-in not completed", None
                self.learn_google()
                continue
            if s.lower().startswith("review"):
                for _ in range(40):
                    review = self.main().inner_text()
                    if "Loading" not in review[-200:] and re.search(r"\bSubmit\b", review):
                        break
                    self.p.wait_for_timeout(500)
                doubt = second_read(self, submit, page=review)
                if submit and not doubt:
                    self.p.locator(WD.format("pageFooterNextButton")).click()
                    self.p.wait_for_timeout(6000)
                    ok = "submitted" in self.p.locator("body").inner_text().lower()
                    return ("submitted" if ok else "submit clicked - confirmation not seen"), review
                return "ready for review", review + (f"\n{doubt}" if doubt else "")
            self.settle()
            handled[s] = handled.get(s, 0) + 1
            if handled[s] > 2:
                return f"stuck on '{s}': {self.errors()}", None
            low = s.lower()
            if low.startswith("my information"):
                self.my_information()
            elif low.startswith("my experience"):
                self.my_experience()
            elif low.startswith("voluntary"):
                self.voluntary()
            elif low.startswith("self identify"):
                self.self_identify()
            else:
                self.generic_pass()
            if not self.next():
                if self.recover():
                    handled[s] -= 1
                    continue
                errs = self.errors()
                say(f"validation errors: {errs}")
                if not errs:
                    self.p.wait_for_timeout(10000)
                    if self.step() != s or self.next():
                        continue
                    if down := site_down(self.p):
                        raise SiteDown(down)
                    if self.crashed():
                        raise SiteDown("the hiring site keeps failing ('something went wrong' after 3 reloads)")
                    errs = self.errors()
                    say(f"validation errors (second try): {errs}")
                human("Fix the flagged fields in the browser, then press Enter. Flagged: " + " || ".join(errs[:4]) if errs else
                      f"The form does not go past '{s}' and shows no error - check that page in the browser, then press Enter.")
                self.next()
        return "too many pages", None


SALARY = re.compile(r"salary|compensation|pay range|desired (base )?pay", re.I)
NEVER_FILL = re.compile(r"(?-i:\b(GPA|GRE|GMAT|SAT|ACT)\b)|grade point", re.I)
NA_OPTION = lambda opts: next((o for o in opts if re.search(
    r"not applicable|do not recall|don.t recall|\bn/?a\b|prefer not|not available", o, re.I)), None)
NO_TEXT = re.compile(r"\bsms\b|text messag|\btexts?\b|whats ?app|mobile messag|recurring (automated )?messages", re.I)
NAME_SAY_Q = re.compile(r"pronounc\w*( of)? your (full )?name|name pronunciation|how (do|should|would) (you|we) say your name", re.I)
SHARE_Q = re.compile(r"additional (information|comments|details)|cover letter|anything else", re.I)


def salary_answer(label, numeric=False):
    lo, hi = P["compensation"]["required_range_usd"]
    if numeric or re.search(r"\b(digits?|numeric|number only|whole number)\b", label, re.I):
        return str(P["compensation"].get("single_number_usd", (lo + hi) // 2))
    if re.search(r"\b(beginning|start|minimum|min|low(er)?|bottom)\b", label, re.I):
        return str(lo)
    if re.search(r"\b(end|maximum|max|upper|high(er)?|top)\b", label, re.I):
        return str(hi)
    return f"{lo}-{hi}"


VETERAN_OK = eeo("veteran")
EEO = [
    (r"hispanic|latino", eeo("hispanic")),
    (r"race|ethnic", eeo("race")),
    (r"gender identity|\bgender\b|\bsex\b", eeo("gender")),
    (r"veteran|military", eeo("veteran")),
    (r"disabilit", eeo("disability")),
    (r"sexual orientation|sexuality", eeo("orientation")),
    (r"transgender", eeo("transgender")),
    (r"clearance", lambda o: next((x for x in o if re.search(r"never held|^none\b|^no\b|no clearance|not applicable",
                                                              x.strip(), re.I)), None) if CLEARANCE == "No" else None),
]


class Greenhouse:

    RULES = Workday.RULES + [
        (PREV_RX[1], "No"),
        (RELATIVE_RX[1], "No"),
        (SOURCE_Q, SOURCE_ANSWER),
        (r"non-?compete|non-?solicit", NON_COMPETE),
    ] + ([
        (r"^(?!.*\bor\b).*(typescript|node\.?js|\breact\b|angular|vue\.?js)", WEB_STACK)] if WEB_STACK else []) + [
        (r"willing to work (from|in) the office|work from the office|on-?site", ONSITE_OK),
        (r"government official", GOV),
        (r"when can you start|earliest (possible )?start|start date|available to start|notice period", EARLIEST_START),
        (r"ai policy", AI_POLICY_ACK),
        (r"(preferred|best) (method|way) (of|to) (contact|communicat)|how (should|would you like|do you prefer).{0,20}(contact|reach)|contact preference",
         CONTACT_METHOD),
    ] + ([(r"pronoun(?!c)", PRONOUNS)] if PRONOUNS else []) + (
        [(r"lgbt", LGBT_REQUIRED)] if LGBT_REQUIRED else [])
    SKIP = re.compile(r"pronoun|lgbt|sexual orientation|sexuality|transgender|if you answered|have you used|website|cover letter", re.I)
    ASK = re.compile(r"(?!x)x")

    def __init__(self, page, jd, company, resume_pdf):
        self.p, self.jd, self.company, self.resume = page, jd, company, resume_pdf
        self.notes, self.open_q = [], []

    def text(self, sel, value):
        f = self.p.locator(sel)
        if f.count() and not f.first.input_value():
            f.first.fill(value)

    def choose(self, inp, chooser):
        inp.scroll_into_view_if_needed()
        inp.focus()
        opts = self.p.locator("[role=option]:visible")
        texts = []
        for attempt in range(4):
            self.p.keyboard.press("ArrowDown")
            self.p.wait_for_timeout(500 + 300 * attempt)
            texts = [t.strip() for t in opts.all_inner_texts()]
            if texts:
                break
            inp.focus()
        pick = chooser(texts) if callable(chooser) else (chooser if chooser in texts else None)
        if pick:
            opts.nth(texts.index(pick)).click()
            offer(self, pick, texts)
        else:
            self.p.keyboard.press("Escape")
        self.p.wait_for_timeout(200)
        return pick, texts

    def autocomplete(self, inp, typed, want):
        inp.click()
        inp.fill(typed)
        self.p.wait_for_timeout(1500)
        opts = self.p.locator("[role=option]:visible")
        texts = [t.strip() for t in opts.all_inner_texts()]
        pick = want(texts) if callable(want) else next((t for t in texts if re.search(want, t, re.I)), None)
        if pick:
            opts.nth(texts.index(pick)).click()
        else:
            inp.fill("")
            self.p.keyboard.press("Escape")
            self.p.wait_for_timeout(200)
        return pick

    def fields(self):
        return self.p.evaluate("""() => [...document.querySelectorAll('form input[id], form textarea[id]')]
          .filter(e => !['hidden', 'file', 'checkbox', 'search'].includes(e.type))
          .map(e => { const l = document.querySelector(`label[for="${e.id}"]`);
            const combo = e.getAttribute('role') === 'combobox';
            const ctl = combo && e.closest('[class*=select__control]');
            const help = [...new Set([...(e.getAttribute('aria-describedby') || '').split(/\\s+/), e.id + '-description'])]
              .map(x => x && document.getElementById(x)).filter(Boolean).map(x => x.innerText.trim()).join(' ');
            return {id: e.id, label: l ? l.innerText.trim() : '', combo, area: e.tagName === 'TEXTAREA', help,
                    required: e.getAttribute('aria-required') === 'true' || e.required,
                    filled: combo ? !!(ctl && ctl.querySelector('[class*=single-value], [class*=multi-value]')) : !!e.value}; })""")

    def answer(self, f):
        label, inp = f["label"], self.p.locator(f"[id='{f['id']}']")
        if NEVER_FILL.search(label):
            if f["combo"]:
                pick, _ = self.choose(inp, NA_OPTION)
                self.notes.append(f"{label[:40]} -> {pick}")
            return
        if self.ASK.search(label):
            self.open_q.append(label[:120])
            return
        if SALARY.search(label) and not f["combo"]:
            if f["required"]:
                self.text(f"[id='{f['id']}']", salary_answer(label))
                self.notes.append(f"{label[:50]} -> {salary_answer(label)}")
            return
        if self.SKIP.search(label) and not f["required"]:
            return
        for rx, chooser in EEO:
            if f["combo"] and re.search(rx, label, re.I):
                pick, opts = self.choose(inp, chooser)
                if not pick and f["required"]:
                    pick = llm.answer(label, opts)
                    if pick:
                        self.choose(inp, pick)
                self.notes.append(f"EEO {label[:40]} -> {pick}")
                return
        if re.search(r"linkedin", label, re.I) and not f["combo"]:
            inp.fill(P["identity"]["linkedin"])
            return self.notes.append("LinkedIn profile -> filled")
        if f["combo"] and re.match(r"\s*(school|university|institution|college)( name)?\s*\*?\s*$", label, re.I):
            school = P["education_on_forms"][-1]["school"]
            pick = self.autocomplete(inp, school, re.escape(school)) or \
                self.autocomplete(inp, school.split()[0], re.escape(school)) or \
                self.autocomplete(inp, "Other", r"^other$")
            self.notes.append(f"{label[:40]} -> {pick}")
            if not pick and f["required"]:
                self.open_q.append(label[:100])
            return
        if not f["combo"] and NAME_SAY_Q.search(f"{label} {f.get('help', '')}"):
            if f["required"]:
                name = f"{P['identity']['first_name']} {P['identity']['last_name']}"
                inp.fill(name)
                self.notes.append(f"{label[:50]} -> {name}")
            return
        ans = (location_answer(label, self.jd) or next((a for rx, a in self.RULES if re.search(rx, label, re.I)), None))
        if f["combo"]:
            if re.search(r"preferred office|office location", label, re.I):
                ans = lambda o: next((x for x in o if LOCAL.search(x)), None)
            chooser = ans if callable(ans) else (lambda o, a=ans: next((x for x in o if a and
                      (x.lower() == a.lower() or x.lower().startswith(a.lower()))), None))
            pick, opts = self.choose(inp, chooser)
            if not pick and isinstance(ans, str):
                pick = self.autocomplete(inp, ans, rf"^{re.escape(ans)}")
            if not pick and f["required"]:
                pick = llm.answer(label, opts, self.jd, self.company)
                if pick:
                    self.choose(inp, pick)
            if not pick and f["required"]:
                self.open_q.append(label[:120])
            self.notes.append(f"{label[:50]} -> {pick}")
        elif ans and isinstance(ans, str):
            inp.fill(ans)
            self.notes.append(f"{label[:50]} -> {ans}")
        elif f["required"]:
            ans = llm.answer(label, None, self.jd, self.company)
            if not ans and f.get("area") and SHARE_Q.search(f"{label} {f.get('help', '')}"):
                ans = llm.draft(": ".join(x for x in (label.rstrip("* "), f.get("help")) if x), self.jd, self.company)
            if ans:
                inp.fill(ans)
                self.notes.append(f"{label[:50]} -> {ans[:60]}")
            else:
                self.open_q.append(label[:120])

    def education(self):
        if not self.p.locator("[id='school--0']").count():
            return set()
        handled = set()
        for i, ed in enumerate(reversed(P["education_on_forms"])):
            if i and not self.p.locator(f"[id='school--{i}']").count():
                add = self.p.locator("[class*=education--container] button", has_text=re.compile(r"add another", re.I))
                if not add.count():
                    self.open_q.append(f"education: no 'Add another' for {ed['degree']}")
                    break
                add.first.click()
                self.p.wait_for_timeout(800)
            got = {}
            school = self.p.locator(f"[id='school--{i}']").first
            want = r"[-\s]?".join(re.escape(w) for w in re.split(r"[-\s]+", ed["school"]))
            short = " ".join(re.split(r"[-\s]+", ed["school"])[-2:])
            fb = ed.get("school_fallback")
            got["school"] = self.autocomplete(school, ed["school"], want) or \
                self.autocomplete(school, short, want) or \
                (fb and self.autocomplete(school, fb, re.escape(fb))) or \
                self.autocomplete(school, "Other", r"^(\d+\s*-\s*)?other$")
            deg = self.p.locator(f"[id='degree--{i}']").first
            ba = ed["degree"].upper().startswith("B")
            arts = bool(re.match(r"[BM]\.?A\b", ed["degree"], re.I))
            specific = ((r"bachelor of arts|\bB\.?A\.?\b" if arts else r"bachelor of science|\bB\.?Sc?\.?\b") if ba else
                        (r"master of arts|\bM\.?A\.?\b(?!.*business)" if arts else r"master of science|\bM\.?Sc?\.?\b(?!.*business)"))
            for want_deg in (specific, r"^bachelor'?s(\s+degree)?$" if ba else r"^master'?s(\s+degree)?$"):
                got["degree"] = self.autocomplete(deg, "Bachelor" if ba else "Master", want_deg)
                if got["degree"]:
                    break
            disc = self.p.locator(f"[id='discipline--{i}']").first
            got["field"] = next((g for g in (self.autocomplete(disc, q, re.escape(q)) for q in ed["field_queries"]) if g), None)
            handled |= {f"school--{i}", f"degree--{i}", f"discipline--{i}"}
            self.notes.append(f"education {i}: {got['school']} | {got['degree']} | {got['field']}")
            for k, v in got.items():
                if not v:
                    self.open_q.append(f"education: {k} for {ed['degree']} ({ed['school']})")
        return handled

    def employment(self):
        if not self.p.locator("[id='company-name-0']").count():
            return set()
        job = P["experience"][0]
        month = lambda n: dt.date(2000, n, 1).strftime("%B")
        current = is_current(job)
        handled = set()
        fields = [("company-name-0", job["company"]), ("title-0", job["title"]), ("start-date-year-0", str(job["start_year"]))]
        if not current:
            fields.append(("end-date-year-0", str(job["end_year"])))
        for fid, val in fields:
            el = self.p.locator(f"[id='{fid}']")
            if el.count():
                el.first.fill(val)
                handled.add(fid)
        for fid, n in [("start-date-month-0", job["start_month"])] + ([] if current else [("end-date-month-0", job["end_month"])]):
            el = self.p.locator(f"[id='{fid}']")
            if el.count():
                pick, _ = self.choose(el.first, month(n))
                handled.add(fid)
                if not pick:
                    self.open_q.append(f"work history: {fid} ({month(n)}) not selectable")
        cur = self.p.locator("[id='current-role-0_1']")
        if cur.count() and cur.first.is_checked() != current:
            cur.first.check() if current else cur.first.uncheck()
        self.notes.append(f"work history -> {job['title']}, {job['company']}, {month(job['start_month'])} {job['start_year']} - "
                          + ("present" if current else f"{month(job['end_month'])} {job['end_year']}"))
        return handled

    def fill(self):
        idn, loc = P["identity"], P["location"]
        self.text("#first_name", idn["first_name"])
        self.text("#last_name", idn["last_name"])
        self.text("#email", idn["email"])
        if self.p.locator("#country").count():
            us = lambda o: min((x for x in o if re.match(re.escape(loc["country"]) + r" \+", x)), key=len, default=None)
            self.notes.append("country -> " + str(self.choose(self.p.locator("#country"), phone_pick(us))[0]))
        self.text("#phone", idn["phone_digits"])
        city = self.p.locator("#candidate-location")
        if city.count() and not city.input_value():
            self.notes.append("location -> " + str(self.autocomplete(city, loc["city"], place_rx(rf"{loc['city']}.*{loc['state']}"))))
        self.p.locator("input#resume").set_input_files(self.resume)
        self.notes.append("resume -> " + self.resume)
        self.p.wait_for_timeout(2000)
        if not resume_shown(self.p, self.resume):
            self.open_q.append("resume: uploaded file not shown on the form")
        done = {"first_name", "last_name", "email", "phone", "country", "candidate-location"} | self.employment() | \
            self.education()
        for _ in range(4):
            todo = [f for f in self.fields() if f["id"] not in done and not f["filled"] and f["label"]]
            if not todo:
                break
            for f in todo:
                done.add(f["id"])
                self.answer(f)
        for f in self.fields():
            if f["required"] and f["combo"] and not f["filled"] and f["label"] and \
                    not re.match(r"(school|degree|discipline)--|(start|end)-date", f["id"]):
                self.p.keyboard.press("Escape")
                self.p.wait_for_timeout(400)
                self.answer(f)
                if next((x["filled"] for x in self.fields() if x["id"] == f["id"]), False):
                    self.open_q = [q for q in self.open_q if q not in (f["label"][:120], f["label"][:100])]
        for b in self.p.locator("form input[type=checkbox]").all():
            lab = b.evaluate("e => (e.labels && e.labels[0] ? e.labels[0].innerText : '')")
            if NO_TEXT.search(lab):
                continue
            if b.get_attribute("required") is not None or re.search(r"consent|agree|acknowledg", lab, re.I):
                if not b.is_checked():
                    b.check()
                    self.notes.append(f"ticked: {lab[:80]}")

    def unembed(self):
        if "greenhouse.io" in urlparse(self.p.url).netloc:
            return
        src = None
        for _ in range(20):
            src = self.p.evaluate("""() => { const f = [...document.querySelectorAll('iframe')]
                .find(f => f.src.includes('greenhouse.io')); return f ? f.src : null; }""")
            if src:
                break
            self.p.wait_for_timeout(500)
        if not src:
            m = re.search(r"https?://[a-z.\-]*greenhouse\.io/embed/job_app\?[^\"'<> ]+", self.p.content())
            src = html.unescape(m.group(0)) if m else None
        if not src:
            go = self.p.get_by_role("button", name=re.compile(r"^\s*apply( now| for this job)?\s*$", re.I))
            if not go.count():
                go = self.p.get_by_role("link", name=re.compile(r"^\s*apply( now| for this job)?\s*$", re.I))
            if go.count():
                go.first.click()
                for _ in range(20):
                    self.p.wait_for_timeout(500)
                    src = self.p.evaluate("""() => { const f = [...document.querySelectorAll('iframe')]
                        .find(f => f.src.includes('greenhouse.io')); return f ? f.src : null; }""")
                    if src or "greenhouse.io" in urlparse(self.p.url).netloc:
                        break
                if not src and "greenhouse.io" in urlparse(self.p.url).netloc:
                    return
        if not src:
            raise RuntimeError(f"Greenhouse form not found on {urlparse(self.p.url).netloc}")
        say(f"embedded Greenhouse form -> {urlparse(src).netloc}")
        self.p.goto(src, wait_until="domcontentloaded")
        self.p.wait_for_timeout(2000)

    def run(self, submit=True):
        dismiss_cookies(self.p)
        self.unembed()
        self.fill()
        review = "\n".join(self.notes)
        if self.open_q:
            msg = "questions left for you: " + " || ".join(self.open_q)
            self.notes.append(msg)
            if UNATTENDED:
                raise NeedsUser(msg)
            return "ready for review", review + "\n" + msg
        if (doubt := second_read(self, submit)) or not submit:
            return "ready for review", review + (f"\n{doubt}" if doubt else "")
        since = dt.datetime.now(dt.timezone.utc) - dt.timedelta(minutes=2)
        self.p.get_by_role("button", name=re.compile(r"submit application", re.I)).click()
        for _ in range(20):
            self.p.wait_for_timeout(1000)
            body = self.p.locator("body").inner_text()
            if "/confirmation" in self.p.url or CONFIRMED.search(body):
                if not UNATTENDED:
                    clear_clipboard()
                    trash_code_emails(self.company)
                return "submitted", review
            if re.search(r"security code|verification code", body, re.I):
                if UNATTENDED:
                    raise NeedsUser("Greenhouse sent an email security code - enter it to finish")
                code = greenhouse_code(self.company, since)
                human((f"Greenhouse's security code is {code} - it is on your clipboard: click the code box in the "
                       f"browser, Ctrl+V, submit, then press Enter here.") if code else
                      "Greenhouse wants the security code from your email - enter it in the browser, then press Enter.")
        return unconfirmed(self.p, self.company), review


class Ashby:

    ENTRY = "[class*='_fieldEntry_'], .ashby-application-form-field-entry"
    RULES = Greenhouse.RULES + [
        (r"current (job )?title", P["most_recent_job"]["title"]),
        (r"close personal relationship|relationships? with .*employ", CLOSE_RELATIONSHIP),
        (r"legally authori[sz]ed|authori[sz]ed to work", AUTHORIZED),
    ] + ([
        (r"back ?end|front ?end|expertise and preference",
         lambda o: next((x for x in o if re.search(r"equal|balanced|both|full.?stack", x, re.I)), None))]
        if re.search(r"equal|balanced|both|full.?stack", BACKEND_FRONTEND, re.I) else [])
    SKIP = re.compile(r"pronoun|twitter|github|portfolio|other website|current company|if you responded|"
                      r"additional information|best self|accommodat|interested in learning|newsletter|"
                      r"talent (community|network)|cover letter", re.I)
    ASK = re.compile(r"salary|compensation|pay range", re.I)
    EEO_RULES = [
        (r"racial|ethnic|race", eeo_list("race")),
        (r"transgender", eeo_list("transgender")),
        (r"gender", eeo_list("gender")),
        (r"lgbt", lambda o: [x for x in o if LGBT_REQUIRED and x.strip().lower() == LGBT_REQUIRED.lower()]),
        (r"disabilit", eeo_list("disability")),
        (r"militar|veteran", eeo_list("veteran")),
    ]

    def __init__(self, page, jd, company, resume_pdf):
        self.p, self.jd, self.company, self.resume = page, jd, company, resume_pdf
        self.notes, self.open_q = [], []

    def entries(self):
        return self.p.evaluate("""(sel) => [...document.querySelectorAll(sel)]
          .filter(e => !e.parentElement.closest(sel)).map((e, i) => {
            e.dataset.jbI = i;
            const t = e.querySelector('label, legend');
            const title = t ? t.innerText.replace(/\\s+/g, ' ').trim() : '';
            const ins = [...e.querySelectorAll('input, textarea')];
            const opts = ins.filter(x => x.type === 'radio' || x.type === 'checkbox')
                            .map(x => (x.labels && x.labels[0] ? x.labels[0].innerText : '').trim());
            const btns = [...e.querySelectorAll('button')].map(b => b.innerText.trim());
            const kind = ins.some(x => x.type === 'file') ? 'file'
                : btns.includes('Yes') && btns.includes('No') ? 'yesno'
                : ins.some(x => x.type === 'radio') ? 'radio'
                : ins.filter(x => x.type === 'checkbox').length > 1 ? 'checkboxes'
                : ins.some(x => x.type === 'checkbox') ? 'checkbox'
                : ins.some(x => x.tagName === 'TEXTAREA') ? 'textarea'
                : btns.length && ins.some(x => x.type === 'text') ? 'typeahead' : 'text';
            const required = /\\*\\s*$/.test(title) || !!e.querySelector('[required], [aria-required=true]')
                || !!(t && /required/i.test(t.className));
            const filled = ins.some(x => (x.type === 'radio' || x.type === 'checkbox') ? x.checked
                                         : x.type === 'file' ? x.files.length : !!x.value)
                || !!e.querySelector('button[aria-pressed=true], button[class*=active], button[class*=selected]');
            return {i, title: title.replace(/\\s*\\*\\s*$/, ''), kind, required, filled, opts}; })""", self.ENTRY)

    def entry(self, f):
        return self.p.locator(f"[data-jb-i='{f['i']}']")

    def pick(self, f, texts):
        e = self.entry(f)
        state = lambda t: e.evaluate("""(el, t) => { const x = [...el.querySelectorAll('input[type=radio], input[type=checkbox]')]
            .find(i => i.labels && i.labels[0] && i.labels[0].innerText.trim() === t); return x ? x.checked : null; }""", t)
        label = lambda t: e.locator("label").filter(has_text=re.compile(r"^\s*" + re.escape(t) + r"\s*$")).first
        for _ in range(3):
            todo = [t for t in texts if state(t) is False]
            if not todo:
                break
            for t in todo:
                label(t).click()
                self.p.wait_for_timeout(400)
        lost = [t for t in texts if not state(t)]
        for t in lost:
            self.open_q.append(f"could not tick '{t}' in: {f['title'][:60]}")
        offer(self, ", ".join(texts), f.get("opts"))
        self.notes.append(f"{f['title'][:50]} -> {', '.join(texts)}")

    def text(self, f, value):
        value = llm.clean(value)
        self.entry(f).locator("input, textarea").first.fill(value)
        self.notes.append(f"{f['title'][:50]} -> {value[:60]}")

    def typeahead(self, f, typed, want):
        inp = self.entry(f).locator("input").first
        inp.click(); inp.fill(typed)
        self.p.wait_for_timeout(1500)
        opts = self.p.locator("[role=option]:visible")
        texts = [t.strip() for t in opts.all_inner_texts()]
        chosen = want(texts) if callable(want) else None
        hit = (texts.index(chosen) if chosen in texts else None) if callable(want) else \
            next((i for i, t in enumerate(texts) if re.search(want, t, re.I)), None)
        if hit is not None:
            opts.nth(hit).click()
        self.notes.append(f"{f['title'][:50]} -> {texts[hit] if hit is not None else None}")
        return hit is not None

    def pick_date(self, f, inp):
        today = START_DATE
        for text in (today.strftime("%m/%d/%Y"), today.strftime("%Y-%m-%d")):
            inp.click()
            inp.fill(text)
            self.p.keyboard.press("Enter")
            self.p.wait_for_timeout(500)
            if inp.input_value():
                self.p.keyboard.press("Escape")
                return self.notes.append(f"{f['title'][:50]} -> {inp.input_value()}")
        inp.click()
        self.p.wait_for_timeout(600)
        cell = self.p.locator("[aria-current=date]:visible, [class*=today]:visible").first
        if cell.count():
            cell.click()
            self.p.wait_for_timeout(400)
        if inp.input_value():
            return self.notes.append(f"{f['title'][:50]} -> {inp.input_value()}")
        if f["required"]:
            self.open_q.append(f["title"][:100])

    def languages(self, opts):
        mine = re.search(r"Languages:([^\n]*)", llm.RESUME)
        mine = [x.strip().split(" (")[0] for x in (mine.group(1) if mine else "").split(",") if x.strip()]
        mine += P.get("form_languages_extra", [])
        norm = lambda s: s.lower().replace(" ", "").rstrip(".")
        hits = [o for o in opts if any(norm(o) == norm(m) for m in mine)]
        if any(not any(norm(o) == norm(m) for o in opts) for m in mine) and any(o.lower() == "other" for o in opts):
            hits.append(next(o for o in opts if o.lower() == "other"))
        return hits

    def answer(self, f):
        title, kind, req = f["title"], f["kind"], f["required"]
        idn = P["identity"]
        if NEVER_FILL.search(title):
            if kind in ("radio", "checkboxes") and NA_OPTION(f["opts"]):
                self.pick(f, [NA_OPTION(f["opts"])])
            return
        if self.ASK.search(title):
            if req and kind == "text":
                return self.text(f, salary_answer(title))
            if req:
                self.open_q.append(title[:100])
            return
        if re.search(r"full name|^name$", title, re.I):
            return self.text(f, f"{idn['first_name']} {idn['last_name']}")
        if re.search(r"^email", title, re.I):
            return self.text(f, idn["email"])
        if re.search(r"phone", title, re.I):
            return self.text(f, idn["phone"])
        if re.search(r"linkedin", title, re.I) and kind == "text":
            return self.text(f, idn["linkedin"])
        if re.search(r"location|where are you (currently )?(based|located|living)", title, re.I) and kind in ("typeahead", "text"):
            loc = P["location"]
            if kind == "typeahead" and self.typeahead(f, loc["city"], place_rx(rf"{loc['city']}.*({loc['state']}|{loc['state_code']})")):
                return
            return self.text(f, place_text(f"{loc['city']}, {loc['state_code']}"))
        if self.SKIP.search(title) and not req:
            return
        if kind in ("radio", "checkboxes"):
            for rx, chooser in self.EEO_RULES:
                if re.search(rx, title, re.I):
                    got = chooser(f["opts"])
                    if got:
                        return self.pick(f, got[:1])
                    if req:
                        self.open_q.append(title[:100])
                    return
            if kind == "checkboxes" and re.search(r"\bla\w{0,3}g\w*ages?\b|programming|tech(nology)? stack", title, re.I):
                got = self.languages(f["opts"])
                return self.pick(f, got) if got else None
            ans = (location_answer(title, self.jd) or next((a for rx, a in self.RULES if re.search(rx, title, re.I)), None))
            ans = ans(f["opts"]) if callable(ans) else ans
            ans = ans if ans in f["opts"] else llm.answer(title, f["opts"], self.jd, self.company)
            if ans and ans in f["opts"]:
                return self.pick(f, [ans])
            if req:
                self.open_q.append(title[:100])
            return
        if kind == "checkbox":
            if NO_TEXT.search(title + " " + " ".join(f["opts"])):
                return
            if req or re.search(r"i (understand|agree|acknowledge|certify|consent)", title + " ".join(f["opts"]), re.I):
                box = self.entry(f).locator("input[type=checkbox]").first
                if not box.is_checked():
                    box.check(force=True)
                self.notes.append(f"ticked: {(title or ' '.join(f['opts']))[:70]}")
            return
        if kind == "yesno":
            ans = (location_answer(title, self.jd) or next((a for rx, a in self.RULES if re.search(rx, title, re.I)), None)) or \
                llm.answer(title, ["Yes", "No"], self.jd, self.company)
            if ans in ("Yes", "No"):
                self.entry(f).get_by_role("button", name=ans, exact=True).click()
                self.notes.append(f"{title[:50]} -> {ans}")
            elif req:
                self.open_q.append(title[:100])
            return
        if kind == "typeahead":
            if re.search(SOURCE_Q, title, re.I):
                if not any(self.typeahead(f, typed, want) for typed, want in SOURCE_FALLBACK) and req:
                    self.open_q.append(title[:100])
                return
            ans = (location_answer(title, self.jd) or next((a for rx, a in self.RULES if re.search(rx, title, re.I)), None))
            if not (ans and self.typeahead(f, ans, re.escape(ans))) and req:
                self.open_q.append(title[:100])
            return
        long_q = re.search(r"why (us|\w+\?)|why do you want|why are you interested|tell us about|describe|"
                           r"walk us through|give (us )?an example|in \d+\W{0,3}\d*\s*sentences|what experience|"
                           r"please (share|explain|elaborate)|as much detail|what interests you", title, re.I)
        if kind in ("textarea", "text") and long_q:
            txt = llm.draft(title, self.jd, self.company)
            if txt:
                self.text(f, txt)
            elif req:
                self.open_q.append(title[:100])
            return
        inp = self.entry(f).locator("input").first
        if kind == "text" and inp.count() and re.search(r"date", inp.get_attribute("placeholder") or "", re.I):
            return self.pick_date(f, inp)
        ans = (location_answer(title, self.jd) or next((a for rx, a in self.RULES if re.search(rx, title, re.I)), None))
        if ans in ("Yes", "No") and not YESNO_Q.match(title):
            ans = None
        if ans is None and req:
            ans = llm.answer(title, None, self.jd, self.company)
        if ans:
            self.text(f, ans)
        elif req:
            self.open_q.append(title[:100])

    def fill(self):
        self.p.locator("input[type=file]#_systemfield_resume, input[type=file]").last.set_input_files(self.resume)
        self.notes.append("resume -> " + self.resume)
        self.p.wait_for_timeout(4000)
        if not resume_shown(self.p, self.resume):
            self.open_q.append("resume: uploaded file not shown on the form")
        done = set()
        key = lambda f: (f["title"], f["kind"], tuple(f["opts"]))
        for _ in range(4):
            todo = [f for f in self.entries() if key(f) not in done and f["kind"] != "file"]
            if not todo:
                break
            for f in todo:
                done.add(key(f))
                if not f["filled"] or f["kind"] in ("text", "typeahead"):
                    self.answer(f)
                    self.p.wait_for_timeout(400)
        missing = [f["title"][:80] for f in self.entries()
                   if f["required"] and not f["filled"] and f["kind"] != "file" and not NEVER_FILL.search(f["title"])]
        for t in missing:
            if not any(t[:40] in q for q in self.open_q):
                self.open_q.append(f"still empty: {t}")

    def run(self, submit=True):
        dismiss_cookies(self.p)
        if "/application" not in self.p.url:
            tab = self.p.get_by_role("tab", name=re.compile("application", re.I))
            if tab.count():
                tab.first.click()
                self.p.wait_for_timeout(2500)
        self.fill()
        review = "\n".join(self.notes)
        if self.open_q:
            msg = "questions left for you: " + " || ".join(self.open_q)
            self.notes.append(msg)
            if UNATTENDED:
                raise NeedsUser(msg)
            return "ready for review", review + "\n" + msg
        if (doubt := second_read(self, submit)) or not submit:
            return "ready for review", review + (f"\n{doubt}" if doubt else "")
        answers, fired = [], []

        def on_response(r):
            if "ashbyhq.com" in r.url and "graphql" in r.url and "ubmit" in r.url + (r.request.post_data or ""):
                try:
                    answers.append(f"{r.status} {r.text()[:400]}")
                except Exception as e:
                    answers.append(f"{r.status} (unreadable: {type(e).__name__})")
        self.p.on("response", on_response)
        self.p.on("request", lambda r: fired.append(r.url) if r.method == "POST" and
                  ("recaptcha" in r.url or "non-user-graphql" in r.url) else None)
        btn = self.p.get_by_role("button", name=re.compile(r"submit application", re.I))
        for rnd in range(2):
            fired.clear()
            answers.clear()
            for attempt in range(3):
                self.p.keyboard.press("Escape")
                self.p.evaluate("() => document.activeElement && document.activeElement.blur()")
                self.p.wait_for_timeout(600)
                btn.first.scroll_into_view_if_needed()
                btn.first.click()
                for _ in range(8):
                    if fired:
                        break
                    self.p.wait_for_timeout(500)
                if fired:
                    break
                say(f"Ashby: Submit click {attempt + 1} sent nothing - closing popovers, retrying")
            for _ in range(20):
                self.p.wait_for_timeout(1000)
                body = self.p.locator("body").inner_text()
                if CONFIRMED.search(body) or re.search(r"confirmation|success|thank", self.p.url, re.I):
                    return "submitted", review
                if any("Missing entry" in a for a in answers):
                    break
            missing = {m.strip() for a in answers for m in re.findall(r"Missing entry for required field: ([^\"\\]+)", a)}
            if rnd or not missing:
                break
            say(f"Ashby says empty: {', '.join(sorted(missing))} - re-filling and submitting again")
            for f in self.entries():
                if any(f["title"].strip().lower().startswith(m.lower()[:40]) for m in missing):
                    ans = (location_answer(f["title"], self.jd) or next((a for rx, a in self.RULES if re.search(rx, f["title"], re.I)), None))
                    if f["kind"] == "yesno" and ans in ("Yes", "No"):
                        for b in ({"Yes": "No", "No": "Yes"}[ans], ans):
                            self.entry(f).get_by_role("button", name=b, exact=True).click()
                            self.p.wait_for_timeout(400)
                    else:
                        self.answer(f)
                        self.p.wait_for_timeout(400)
        self.notes.append("Ashby submit answer: " + (" || ".join(answers) or "no submit call seen"))
        say(self.notes[-1][:300])
        return unconfirmed(self.p, self.company) + "; " + self.notes[-1][:250], review


class Rippling(Ashby):

    HANDLED = ["input-resume", "input-first_name", "input-last_name", "input-email", "input-phone_number",
               "input-linkedin_link", "input-cover_letter", "input-current_company", "input-select-search-input",
               "sms_opt_in"]
    BLOCKS = r"""() => [...document.querySelectorAll("[data-testid=field]")]
        .filter(fd => fd.offsetParent !== null && fd.querySelector("[data-testid^='customQuestions.'], [data-testid^='eeoc.']"))
        .map((fd, i) => {
            fd.dataset.jbI = i;
            const ctl = fd.querySelector("textarea, div[role=combobox], input[role=combobox], input[type=checkbox], " +
                                         "input[type=radio], input:not([type=hidden]):not([type=file])");
            const own = [...fd.parentElement.children].filter(c => !c.contains(fd)).map(c => c.innerText).join(' ');
            const lab = ctl ? (ctl.getAttribute('aria-labelledby') || '').split(' ').map(x => document.getElementById(x))
                                 .filter(Boolean).map(x => x.innerText).join(' ') : '';
            const boxes = [...fd.querySelectorAll('input[type=checkbox], input[type=radio]')];
            const raw = (boxes.length ? own.trim() || lab.trim() : lab.trim() || own.trim())
                .replace(/\s+/g, ' ').replace(/\s*\d+\s*\/\s*\d+\s*$/, '').trim();
            const kind = !ctl ? 'text' : ctl.type === 'radio' ? 'radio' : boxes.length > 1 ? 'checkboxes'
                : ctl.type === 'checkbox' ? 'checkbox' : ctl.tagName === 'TEXTAREA' ? 'textarea'
                : ctl.getAttribute('role') === 'combobox' ? 'combo' : 'text';
            const rest = fd.innerText.replace(lab, '').replace(/\s*\d+\s*\/\s*\d+\s*$/, '').trim();
            const shown = !ctl ? '' : ctl.matches('div') ? ctl.innerText.trim() : ctl.getAttribute('role') === 'combobox'
                ? (ctl.value || rest) : ctl.value || '';
            const filled = boxes.length ? boxes.some(b => b.checked) : !!shown && !/^\s*(select|search)\b/i.test(shown);
            const opts = boxes.map(b => { let c = b; for (let k = 0; k < 4 && c.parentElement; k++) { c = c.parentElement;
                if (c.innerText.trim()) return c.innerText.trim(); } return ''; });
            const required = /\*\s*$/.test(raw) || !!(ctl && (ctl.required || ctl.getAttribute('aria-required') === 'true'));
            return {i, title: raw.replace(/\s*\*\s*$/, ''), kind, required, filled, opts}; })"""

    def tid(self, name):
        return self.p.locator(f"[data-testid='{name}']")

    def tidtext(self, name, value):
        f = self.tid(name)
        if not f.count():
            return
        f.first.click()
        f.first.fill(value)
        self.p.wait_for_timeout(400)
        self.notes.append(f"{name[6:]} -> {value}")

    def entries(self):
        return self.p.evaluate(self.BLOCKS)

    def entry(self, f):
        return self.p.locator(f"[data-testid=field][data-jb-i='{f['i']}']")

    def options(self, f):
        self.entry(f).locator("div[role=combobox], input[role=combobox]").first.click()
        opts = []
        for _ in range(8):
            self.p.wait_for_timeout(400)
            opts = [t.strip() for t in self.p.locator("[role=option]:visible").all_inner_texts() if t.strip()]
            if opts:
                break
        self.p.keyboard.press("Escape")
        self.p.wait_for_timeout(300)
        return opts

    def pick(self, f, texts):
        e, done = self.entry(f), []
        for want in texts:
            exact = re.compile(rf"^\s*{re.escape(want)}\s*$")
            ctl = e.locator("div[role=combobox], input[role=combobox]").first
            for _ in range(2):
                if ctl.count():
                    ctl.click()
                    self.p.wait_for_timeout(600)
                    opt = self.p.locator("[role=option]:visible").filter(has_text=exact).first
                else:
                    opt = e.get_by_text(exact).first
                if opt.count():
                    opt.click()
                    self.p.wait_for_timeout(400)
                if want in e.inner_text() or ctl.count() and want == (ctl.input_value() if ctl.evaluate("x => x.tagName") == "INPUT" else ""):
                    done.append(want)
                    break
                self.p.keyboard.press("Escape")
        for want in texts:
            if want not in done:
                self.open_q.append(f"could not choose '{want}' in: {f['title'][:60]}")
        offer(self, ", ".join(texts), f.get("opts"))
        self.notes.append(f"{f['title'][:50]} -> {', '.join(texts)}")

    def answer(self, f):
        if f["kind"] == "combo":
            f = dict(f, kind="radio", opts=self.options(f))
            if not f["opts"]:
                if f["required"]:
                    self.open_q.append(f"{f['title'][:80]} (no options offered)")
                return
        if f["kind"] == "checkbox":
            title, label = f["title"], " ".join(f["opts"])
            if NO_TEXT.search(f"{title} {label}") or not (f["required"] or re.search(
                    r"i (understand|agree|acknowledge|certify|consent)", f"{title} {label}", re.I)):
                return
            e = self.entry(f)
            box = e.locator("input[type=checkbox]").first
            if not box.is_checked():
                e.locator("[data-testid^='checkbox-label']").first.click()
                self.p.wait_for_timeout(400)
            if box.is_checked():
                self.notes.append(f"ticked: {title[:70]}")
            else:
                self.open_q.append(f"could not tick: {title[:80]}")
            return
        return Ashby.answer(self, f)

    def labelled(self, label):
        idx = self.p.evaluate("""(label) => [...document.querySelectorAll('input')].findIndex(e => {
            let c = e; for (let i = 0; i < 6 && c.parentElement; i++) { c = c.parentElement;
                const t = c.innerText.trim(); if (t.length > 3) return t.toLowerCase().startsWith(label); }
            return false; })""", label.lower())
        return self.p.locator("input").nth(idx) if idx >= 0 else None

    def search_pick(self, inp, typed, want):
        inp.click()
        inp.fill(typed)
        opts, texts = self.p.locator("[role=option]:visible"), []
        for _ in range(16):
            self.p.wait_for_timeout(500)
            texts = [t.strip() for t in opts.all_inner_texts()]
            if texts:
                break
        chosen = want(texts) if callable(want) else None
        pick = (texts.index(chosen) if chosen in texts else None) if callable(want) else \
            next((i for i, t in enumerate(texts) if re.search(want, t, re.I)), None)
        if pick is None:
            self.p.keyboard.press("Escape")
            return None
        opts.nth(pick).click()
        self.p.wait_for_timeout(400)
        return texts[pick]

    def fill(self):
        idn, loc = P["identity"], P["location"]
        self.tid("input-resume").first.set_input_files(self.resume)
        self.notes.append("resume -> " + self.resume)
        for _ in range(40):
            self.p.wait_for_timeout(500)
            if re.search(r"parsing was (successful|unsuccessful)|could not (be )?parse|parsing failed",
                         self.p.locator("body").inner_text(), re.I):
                break
        self.p.wait_for_timeout(1000)
        if not resume_shown(self.p, self.resume, also=r"parsing was successful"):
            self.open_q.append("resume: uploaded file not shown on the form")
        self.tidtext("input-first_name", idn["first_name"])
        self.tidtext("input-last_name", idn["last_name"])
        self.tidtext("input-email", idn["email"])
        self.tidtext("input-linkedin_link", idn["linkedin"])
        cc = self.p.evaluate("""() => { const ph = document.querySelector("[data-testid='input-phone_number']");
            let c = ph; for (let i = 0; i < 6 && c && c.parentElement; i++) { c = c.parentElement;
                const s = c.querySelector("[data-testid='input-select-search-input']"); if (s) return [s.id, c.innerText]; }
            return null; }""")
        if cc and f"+{PHONE_CC}" not in cc[1]:
            got = self.search_pick(self.p.locator(f"[id='{cc[0]}']"), PHONE_NAME, phone_rx(r"United States|\+1\b"))
            self.notes.append(f"phone country -> {got}")
        ph = self.tid("input-phone_number").first
        ph.click()
        ph.press("Control+a")
        ph.press("Backspace")
        ph.press_sequentially(idn["phone_digits"], delay=60)
        ph.press("Tab")
        self.p.wait_for_timeout(400)
        self.notes.append(f"phone_number -> {idn['phone_digits']} (typed)")
        cur = self.tid("input-current_company")
        if cur.count() and cur.first.input_value() != current_company():
            cur.first.fill(current_company())
            self.notes.append(f"current company -> {current_company() or '(cleared; between jobs)'}")
        where = self.labelled("location")
        if where is not None:
            want = place_rx(rf"{loc['city']}.*({loc['state']}|{loc['state_code']})")
            got = self.search_pick(where, f"{loc['city']}, {loc['state_code']}", want) or self.search_pick(where, loc["city"], want)
            if got:
                self.notes.append(f"location -> {got}")
            else:
                self.open_q.append(f"Location (no {P['location']['city']} option offered)")
        sms = self.tid("sms_opt_in")
        if sms.count():
            sms.first.get_by_text(re.compile(r"^\s*No\b", re.I)).first.click()
            self.notes.append("text messages -> No (do not consent)")
        done = set()
        for _ in range(2):
            todo = [f for f in self.entries() if not f["filled"] and (f["title"], f["kind"]) not in done]
            for f in todo:
                done.add((f["title"], f["kind"]))
                self.answer(f)
                self.p.wait_for_timeout(300)
        for f in self.entries():
            if (f["required"] and not f["filled"] and not NEVER_FILL.search(f["title"])
                    and not any(f["title"][:40] in q for q in self.open_q)):
                self.open_q.append(f"still empty: {f['title'][:80]}")
        left = self.p.evaluate(r"""(handled) => [...document.querySelectorAll(
                'input:not([type=hidden]):not([type=file]):not([type=radio]):not([type=checkbox]), textarea')]
            .filter(e => e.offsetParent !== null && (e.required || e.getAttribute('aria-required') === 'true') && !e.value
                    && !e.closest("[data-testid^='customQuestions.'], [data-testid^='eeoc.']")
                    && !handled.includes(e.getAttribute('data-testid') || ''))
            .map(e => ((e.getAttribute('aria-labelledby') || '').split(' ').map(x => document.getElementById(x))
                       .filter(Boolean).map(x => x.innerText.trim()).join(' ') || e.placeholder || 'a required field').slice(0, 90))""",
                               self.HANDLED)
        for q in left:
            if not q.lower().startswith("location"):
                self.open_q.append(f"still empty: {q}")

    def run(self, submit=True):
        dismiss_cookies(self.p)
        if not self.tid("input-resume").count():
            go = self.p.get_by_role("link", name=re.compile(r"^\s*apply( now| for this job)?\s*$", re.I))
            if not go.count():
                go = self.p.get_by_role("button", name=re.compile(r"^\s*apply( now| for this job)?\s*$", re.I))
            go.first.click()
            self.tid("input-resume").first.wait_for(state="attached", timeout=20000)
            self.p.wait_for_timeout(1500)
        self.fill()
        review = "\n".join(self.notes)
        if self.open_q:
            msg = "questions left for you: " + " || ".join(self.open_q)
            self.notes.append(msg)
            if UNATTENDED:
                raise NeedsUser(msg)
            return "ready for review", review + "\n" + msg
        errs = [e for e in self.p.get_by_text(re.compile(r"field is required|is invalid", re.I)).all_inner_texts() if e.strip()]
        if errs:
            msg = f"form still shows {len(errs)} error(s): {errs[0][:80]}"
            self.notes.append(msg)
            if UNATTENDED:
                raise NeedsUser(msg)
            return "ready for review", review + "\n" + msg
        if (doubt := second_read(self, submit)) or not submit:
            return "ready for review", review + (f"\n{doubt}" if doubt else "")
        self.p.keyboard.press("Escape")
        self.p.get_by_role("button", name=re.compile(r"^\s*apply\s*$", re.I)).last.click()
        for _ in range(25):
            self.p.wait_for_timeout(1000)
            if CONFIRMED.search(self.p.locator("body").inner_text()) or re.search(r"confirmation|success|thank", self.p.url, re.I):
                return "submitted", review
        return unconfirmed(self.p, self.company), review


class Gem(Ashby):

    def entries(self):
        return self.p.evaluate("""() => {
            const ins = [...document.querySelectorAll('input:not([type=hidden]), textarea, select, [role=combobox]')];
            if (!ins.length) return [];
            let box = ins[0].parentElement;
            while (box && !ins.every(x => box.contains(x))) box = box.parentElement;
            if (!box) return [];
            return [...box.children].filter(b => b.querySelector('input, textarea, select, [role=combobox]')).map((e, i) => {
                e.dataset.jbI = i;
                const t = e.querySelector('label:not([for]), legend, span');
                const raw = t ? t.innerText.replace(/\\s+/g, ' ').trim() : '';
                const ins = [...e.querySelectorAll('input, textarea')];
                const lab = x => (x.labels && x.labels[0] ? x.labels[0].innerText : '').trim();
                const opts = ins.filter(x => x.type === 'radio' || x.type === 'checkbox').map(lab);
                const kind = ins.some(x => x.type === 'file') ? 'file'
                    : e.querySelector('select') ? 'select'
                    : ins.some(x => x.type === 'radio') ? 'radio'
                    : ins.filter(x => x.type === 'checkbox').length > 1 ? 'checkboxes'
                    : ins.some(x => x.type === 'checkbox') ? 'checkbox'
                    : ins.some(x => x.tagName === 'TEXTAREA') ? 'textarea'
                    : e.querySelector('[role=combobox]') ? 'typeahead' : 'text';
                const required = /\\*\\s*$/.test(raw) || !!e.querySelector('[required], [aria-required=true]');
                const filled = ins.some(x => (x.type === 'radio' || x.type === 'checkbox') ? x.checked
                                             : x.type === 'file' ? x.files.length : !!x.value)
                    || !!(e.querySelector('select') && e.querySelector('select').value);
                return {i, title: raw.replace(/\\s*\\*\\s*$/, ''), kind, required, filled, opts}; }); }""")

    def answer(self, f):
        idn = P["identity"]
        if re.match(r"first name", f["title"], re.I):
            return self.text(f, idn["first_name"])
        if re.match(r"last name", f["title"], re.I):
            return self.text(f, idn["last_name"])
        if f["kind"] == "select":
            sel = self.entry(f).locator("select").first
            opts = [o.strip() for o in sel.locator("option").all_inner_texts() if o.strip() and not re.match(r"select", o.strip(), re.I)]
            ans = location_answer(f["title"], self.jd) or next((a for rx, a in self.RULES if re.search(rx, f["title"], re.I)), None)
            ans = ans(opts) if callable(ans) else ans
            ans = ans if ans in opts else llm.answer(f["title"], opts, self.jd, self.company)
            if ans in opts:
                sel.select_option(label=ans)
                self.notes.append(f"{f['title'][:50]} -> {ans}")
            elif f["required"]:
                self.open_q.append(f["title"][:100])
            return
        return super().answer(f)

    def fill(self):
        self.p.locator("input[type=file]").first.set_input_files(self.resume)
        self.notes.append("resume -> " + self.resume)
        self.p.wait_for_timeout(3000)
        if Path(self.resume).name not in self.p.locator("body").inner_text():
            self.open_q.append("resume: uploaded file not shown on the form")
        for f in self.entries():
            if f["kind"] != "file" and (not f["filled"] or f["kind"] == "text"):
                self.answer(f)
                self.p.wait_for_timeout(300)
        for f in self.entries():
            if f["required"] and not f["filled"] and not NEVER_FILL.search(f["title"]) and \
                    not any(f["title"][:40] in q for q in self.open_q):
                self.open_q.append(f"still empty: {f['title'][:80]}")

    def run(self, submit=True):
        dismiss_cookies(self.p)
        self.p.locator("input[type=file]").first.wait_for(state="attached", timeout=20000)
        self.fill()
        review = "\n".join(self.notes)
        if self.open_q:
            msg = "questions left for you: " + " || ".join(self.open_q)
            self.notes.append(msg)
            if UNATTENDED:
                raise NeedsUser(msg)
            return "ready for review", review + "\n" + msg
        if (doubt := second_read(self, submit)) or not submit:
            return "ready for review", review + (f"\n{doubt}" if doubt else "")
        btn = self.p.get_by_role("button", name=re.compile(r"^\s*apply without saving\s*$", re.I))
        if not btn.count():
            msg = "no 'Apply without saving' button - submit by hand"
            if UNATTENDED:
                raise NeedsUser(msg)
            return "ready for review", review + "\n" + msg
        btn.first.scroll_into_view_if_needed()
        btn.first.click()
        for _ in range(25):
            self.p.wait_for_timeout(1000)
            if CONFIRMED.search(self.p.locator("body").inner_text()) or re.search(r"confirmation|success|thank", self.p.url, re.I):
                return "submitted", review
        return unconfirmed(self.p, self.company), review


class Jobvite(Gem):

    EEO_RULES = Ashby.EEO_RULES
    SUBMIT = re.compile(r"^\s*(submit|send)( (my )?application)?\s*$", re.I)

    def entries(self):
        return self.p.evaluate("""() => {
            const wrap = e => e.closest('[class*=form-field]:not([class*=form-field-control]):not([class*=form-field-input])')
                              || e.closest('[class*=form-field]');
            const ctl = [...document.querySelectorAll('input:not([type=hidden]):not([type=file]), textarea, select')].filter(e => e.offsetParent);
            const ws = []; for (const e of ctl) { const w = wrap(e); if (w && !ws.includes(w)) ws.push(w); }
            return ws.map((e, i) => {
                e.dataset.jbI = i;
                const first = e.innerText.trim().split(String.fromCharCode(10))[0].trim();
                const ins = [...e.querySelectorAll('input:not([type=hidden]):not([type=file]), textarea, select')];
                const lab = x => (x.labels && x.labels[0] ? x.labels[0].innerText : '').trim();
                const sel = e.querySelector('select');
                const opts = sel ? [...sel.options].map(o => o.text.trim()).filter(t => t && !/^select/i.test(t))
                                 : ins.filter(x => x.type === 'radio' || x.type === 'checkbox').map(lab);
                const kind = sel ? 'select' : ins.some(x => x.type === 'radio') ? 'radio'
                    : ins.filter(x => x.type === 'checkbox').length > 1 ? 'checkboxes'
                    : ins.some(x => x.type === 'checkbox') ? 'checkbox'
                    : ins.some(x => x.type === 'date') ? 'date'
                    : ins.some(x => x.tagName === 'TEXTAREA') ? 'textarea' : 'text';
                const required = /\\*\\s*$/.test(first) || ins.some(x => x.required || x.getAttribute('aria-required') === 'true');
                const filled = ins.some(x => (x.type === 'radio' || x.type === 'checkbox') ? x.checked : !!x.value);
                return {i, title: first.replace(/\\s*\\*\\s*$/, ''), kind, required, filled, opts}; }); }""")

    def answer(self, f):
        idn, loc = P["identity"], P["location"]
        title, kind = f["title"], f["kind"]
        if kind == "date":
            self.entry(f).locator("input[type=date]").first.fill(dt.date.today().isoformat())
            return self.notes.append(f"{title[:40]} -> today")
        if re.match(r"your name|signature|full (legal )?name", title, re.I) and kind == "text":
            return self.text(f, f"{idn['first_name']} {idn['last_name']}")
        if re.match(r"city\b", title, re.I) and kind == "text":
            return self.text(f, loc["city"])
        if re.search(r"enter n/?a\b", title, re.I) and kind in ("text", "textarea"):
            return self.text(f, "N/A")
        if kind == "radio" and not re.search(r"veteran|disabilit", title, re.I):
            for rx in (r"militar|veteran", r"disabilit"):
                if any(re.search(rx, o, re.I) for o in f["opts"]):
                    got = next(ch for r, ch in self.EEO_RULES if r == rx)(f["opts"])
                    if got:
                        return self.pick(f, got[:1])
        if kind == "select" and HOME != "US" and re.match(r"country|state|province|region", title, re.I):
            sel = self.entry(f).locator("select").first
            pick = (home_pick(None) if re.match(r"country", title, re.I) else region_pick)(f["opts"])
            if pick:
                sel.select_option(label=pick)
                self.p.wait_for_timeout(800)
                return self.notes.append(f"{title[:50]} -> {pick}")
        if kind == "select":
            sel = self.entry(f).locator("select").first
            want = ("United States" if re.match(r"country", title, re.I)
                    else loc["state"] if re.match(r"state|province", title, re.I)
                    else "No" if NO_TEXT.search(title) else None)
            if want:
                pick = next((o for o in f["opts"] if o == want or o == loc.get("state_code")), None) or \
                    next((o for o in f["opts"] if re.match(re.escape(want), o, re.I)), None)
                if pick:
                    sel.select_option(label=pick)
                    self.p.wait_for_timeout(800)
                    return self.notes.append(f"{title[:50]} -> {pick}")
        return super().answer(f)

    def consent(self):
        sel = self.p.locator("#jv-country-select")
        if not sel.count():
            return
        opts = [o.strip() for o in sel.locator("option").all_inner_texts()]
        pick = next((o for o in opts if re.search(r"united states", o, re.I)), None) or \
            next((o for o in opts if o and not re.match(r"select", o, re.I) and re.search(r"english", o, re.I)), None) or \
            next((o for o in opts if o and not re.match(r"select", o, re.I)), None)
        sel.select_option(label=pick)
        self.p.wait_for_timeout(2000)
        self.p.get_by_role("button", name=re.compile(r"i accept", re.I)).first.click()
        self.p.wait_for_timeout(4000)
        self.notes.append(f"data consent: {pick} -> I Accept")

    def fill(self):
        if self.p.locator("input[type=file]").count() and not re.search(re.escape(Path(self.resume).name), self.p.locator("body").inner_text()):
            idx = self.p.evaluate("""() => [...document.querySelectorAll('input[type=file]')].findIndex(i => {
                let c = i; for (let k = 0; k < 8 && c; k++) { c = c.parentElement; if (c && /resume|cv/i.test(c.innerText)) return !/cover letter/i.test(c.innerText.slice(0, 40)); }
                return false; })""")
            self.p.locator("input[type=file]").nth(max(idx, 0)).set_input_files(self.resume)
            self.notes.append("resume -> " + self.resume)
            for _ in range(30):
                self.p.wait_for_timeout(500)
                if any(f["filled"] for f in self.entries()):
                    break
            self.p.wait_for_timeout(1500)
            if Path(self.resume).name not in self.p.locator("body").inner_text():
                self.open_q.append("resume: uploaded file not shown on the form")

    def page(self):
        done = set()
        for _ in range(3):
            todo = [f for f in self.entries() if (f["title"], f["kind"]) not in done]
            if not todo:
                break
            for f in todo:
                done.add((f["title"], f["kind"]))
                if not f["filled"] or f["kind"] == "date":
                    self.answer(f)
                    self.p.wait_for_timeout(250)

    def run(self, submit=True):
        dismiss_cookies(self.p)
        if not self.p.locator("#jv-country-select, input[type=file]").count():
            go = self.p.get_by_role("link", name=re.compile(r"^\s*apply( now| for this job)?\s*$", re.I))
            if go.count():
                go.first.click()
                self.p.wait_for_timeout(4000)
        self.consent()
        self.fill()
        for step in range(10):
            self.page()
            submit_btn = self.p.get_by_role("button", name=self.SUBMIT)
            if submit_btn.count():
                break
            if PRACTICE:
                return practice_stop(self)
            before = self.p.locator("body").inner_text()[:3000]
            self.p.get_by_role("button", name=re.compile(r"next", re.I)).first.click(timeout=10000)
            self.p.wait_for_timeout(4000)
            errs = [e.strip()[:100] for e in self.p.locator("[class*=error]:visible, [role=alert]:visible").all_inner_texts() if e.strip()]
            if errs and self.p.locator("body").inner_text()[:3000] == before:
                self.page()
                self.p.get_by_role("button", name=re.compile(r"next", re.I)).first.click(timeout=10000)
                self.p.wait_for_timeout(4000)
                if self.p.locator("body").inner_text()[:3000] == before:
                    left = [f["title"][:80] for f in self.entries() if f["required"] and not f["filled"]]
                    self.open_q.append("Jobvite page not accepted: " + " || ".join(left or errs[:2]))
                    break
        review = "\n".join(self.notes)
        if self.open_q:
            msg = "questions left for you: " + " || ".join(self.open_q)
            self.notes.append(msg)
            if UNATTENDED:
                raise NeedsUser(msg)
            return "ready for review", review + "\n" + msg
        if (doubt := second_read(self, submit)) or not submit:
            return "ready for review", review + (f"\n{doubt}" if doubt else "")
        self.p.get_by_role("button", name=self.SUBMIT).first.click(timeout=10000)
        for _ in range(25):
            self.p.wait_for_timeout(1000)
            body = self.p.locator("body").inner_text()
            if re.search(r"you('ve| have) already applied", body, re.I):
                raise AlreadyApplied(f"{self.company}: Jobvite says \"You've already applied!\" (a re-listed job)")
            if CONFIRMED.search(body) or re.search(r"confirm|success|thank", self.p.url, re.I):
                return "submitted", review
        return unconfirmed(self.p, self.company), review


class ICIMS:

    SUBMIT = "input[id$='_form_submit_i']:visible, button[id$='_form_submit_i']:visible"

    def __init__(self, page, jd, company, resume_pdf):
        self.page, self.jd, self.company, self.resume = page, jd, company, resume_pdf
        self.p = page
        self.notes, self.open_q = [], []

    def frame(self):
        return next((f for f in self.page.frames if "icims.com" in f.url and "in_iframe" in f.url), self.page.main_frame)

    def fields(self):
        return self.frame().evaluate("""() => {
            const out = [], seen = new Set();
            for (const e of document.querySelectorAll('input:not([type=hidden]):not([type=submit]):not([type=button]), select, textarea')) {
              const w = e.tagName === 'SELECT' && e.hasAttribute('icimsdropdown-enabled') && document.getElementById(e.id + '_icimsDropdown');
              const dd = !!(w && w.offsetParent);
              if (dd) {
                out.push({id: e.id, name: e.name, tag: 'SELECT', type: 'dd', dd: true,
                          title: (e.getAttribute('data-label') || '').trim(), value: e.value || '',
                          req: e.getAttribute('i_required') === 'true', opts: []});
                continue;
              }
              if (!e.offsetParent && e.type !== 'file') continue;
              const key = e.type === 'radio' ? 'r:' + e.name : (e.id || e.name);
              if (!key || seen.has(key)) continue; seen.add(key);
              let lab = document.querySelector('label[for="' + e.id + '"]');
              let title = lab ? lab.innerText : '';
              if (e.type === 'radio' || !title) {
                const fs = e.closest('fieldset'); const row = e.closest('[class*=Row], [class*=field], .form-group');
                title = (fs && fs.querySelector('legend') ? fs.querySelector('legend').innerText : '') || (row ? row.innerText.split(String.fromCharCode(10))[0] : title);
              }
              title = (title || '').replace(/\\s+/g, ' ').trim();
              const radios = e.type === 'radio' ? [...document.querySelectorAll('input[type=radio][name="' + e.name + '"]')] : [];
              out.push({id: e.id, name: e.name, tag: e.tagName, type: e.type, title: title.replace(/\\s*\\*\\s*$/, ''),
                req: /\\*/.test(title) || e.required || e.getAttribute('aria-required') === 'true',
                value: e.type === 'radio' ? (radios.find(r => r.checked) || {}).value || '' : (e.type === 'checkbox' ? (e.checked ? 'on' : '') : (e.value || '')),
                opts: e.tagName === 'SELECT' ? [...e.options].map(o => o.text.trim()).filter(t => t && !/^(select|- ?select|choose|--|—)/i.test(t))
                      : radios.map(r => { const l = document.querySelector('label[for="' + r.id + '"]'); return l ? l.innerText.trim() : r.value; })});
            }
            return out; }""")

    def el(self, f):
        fr = self.frame()
        return fr.locator(f"[id='{f['id']}']") if f["id"] else fr.locator(f"[name='{f['name']}']")

    def dd_options(self, f, typed=None):
        fr = self.frame()
        fr.locator(f"[id='{f['id']}_icimsDropdown']").click()
        self.page.wait_for_timeout(1500)
        if typed and fr.locator(f"[id='{f['id']}_icimsDropdown_ctnr'] input.dropdown-search").count():
            self.page.keyboard.type(typed, delay=60)
            self.page.wait_for_timeout(2000)
        items = fr.locator(f"[id='{f['id']}_dropdown-results'] li[role=option]")
        return items, [(t or "").strip() for t in items.evaluate_all("els => els.map(e => e.getAttribute('title') || e.innerText)")]

    def put(self, f, value, typed=None):
        e = self.el(f).first
        if f.get("dd"):
            items, opts = self.dd_options(f, typed)
            choose = lambda real: value(real) if callable(value) else next(
                (o for o in real if o.lower() == str(value).lower()), None) or next(
                (o for o in real if o.lower().startswith(str(value).lower())), None)
            pick = choose([o for o in opts if o and not o.startswith("—")])
            for _ in range(12):
                if pick:
                    break
                n = len(opts)
                self.frame().evaluate("(id) => { const u = document.getElementById(id + '_dropdown-results'); if (u) u.scrollTop = u.scrollHeight; }", f["id"])
                self.page.wait_for_timeout(1200)
                items = self.frame().locator(f"[id='{f['id']}_dropdown-results'] li[role=option]")
                opts = [(t or "").strip() for t in items.evaluate_all("els => els.map(e => e.getAttribute('title') || e.innerText)")]
                pick = choose([o for o in opts if o and not o.startswith("—")])
                if len(opts) == n:
                    break
            if not pick:
                self.page.keyboard.press("Escape")
                return None
            items.nth(opts.index(pick)).click()
            self.page.wait_for_timeout(800)
            offer(self, pick, [o for o in opts if o and not o.startswith("—")])
            self.notes.append(f"{f['title'][:50]} -> {pick}")
            return pick
        if f["tag"] == "SELECT":
            pick = value(f["opts"]) if callable(value) else next(
                (o for o in f["opts"] if o.lower() == str(value).lower()), None) or next(
                (o for o in f["opts"] if o.lower().startswith(str(value).lower())), None)
            if not pick:
                return None
            e.select_option(label=pick)
            offer(self, pick, f["opts"])
            value = pick
        elif f["type"] == "radio":
            pick = value(f["opts"]) if callable(value) else next((o for o in f["opts"] if o.lower() == str(value).lower()), None)
            if not pick:
                return None
            self.frame().locator(f"input[type=radio][name='{f['name']}']").nth(f["opts"].index(pick)).check(force=True)
            offer(self, pick, f["opts"])
            value = pick
        elif f["type"] == "checkbox":
            for act in (lambda: e.check(force=True), lambda: e.evaluate("x => x.click()"),
                        lambda: self.frame().locator(f"label[for='{f['id']}']").first.click()):
                if e.is_checked():
                    break
                try:
                    act()
                except Exception:
                    pass
                self.page.wait_for_timeout(300)
            if not e.is_checked():
                self.open_q.append(f"could not tick: {f['title'][:60]}")
                return None
        else:
            e.fill(llm.clean(str(value)))
        self.notes.append(f"{f['title'][:50]} -> {str(value)[:60]}")
        return value

    def date_parts(self, fields, i, year, month):
        for f in fields[i:i + 3]:
            if f["id"].endswith("_Month"):
                self.put(f, lambda o: next((x for x in o if x.lower().startswith(self.MONTHS[month - 1].lower()[:3])), None)
                         or next((x for x in o if x.lstrip("0") == str(month)), None))
            elif f["id"].endswith("_Date"):
                self.put(f, lambda o: next((x for x in o if x.lstrip("0") == "1"), None))
            elif f["id"].endswith("_Year"):
                self.put(f, str(year))

    MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October",
              "November", "December"]

    def experience(self, fields):
        groups = {}
        for f in fields:
            m = re.match(r"(-?\d+)_", f["id"] or "")
            if m:
                groups.setdefault(m.group(1), []).append(f)
        rows = [g for g in groups.values() if any(re.match(r"employer|company", f["title"], re.I) for f in g)]
        if not rows:
            return set()
        done = set()
        for g, job in zip(rows, trim_history(P["experience"], len(rows))):
            dates = [i for i, f in enumerate(g) if f["id"].endswith("_Month")]
            for i, f in enumerate(g):
                low = f["title"].lower()
                if re.match(r"employer|company", low):
                    self.put(f, job["company"])
                elif re.match(r"(job )?title|position", low):
                    self.put(f, job["title"])
                elif re.match(r"description|responsibilit|duties", low) and f["tag"] == "TEXTAREA":
                    self.put(f, job.get("description") or "")
                elif f["id"].endswith("_Month"):
                    key = "start" if i == dates[0] else "end"
                    if key == "start" or not is_current(job):
                        self.date_parts(g, i, job[f"{key}_year"], job[f"{key}_month"])
                done.add(f["id"])
            for f in g:
                done.add(f["id"])
        self.notes.append(f"work history rewritten from data: {min(len(rows), len(P['experience']))} rows")
        return done

    def answer(self, f, fields, i):
        idn, loc, job = P["identity"], P["location"], P["experience"][0]
        t, low = f["title"], f["title"].lower()
        if re.search(r"login|password", f["id"] + " " + t, re.I) or f["type"] in ("password", "file"):
            return
        if NO_TEXT.search(t) and f["tag"] == "SELECT":
            return self.put(f, lambda o: next((x for x in o if re.match(r"\s*no\b", x, re.I)), None))
        if re.search(r"authori[sz]ed to work", t, re.I) and AUTHORIZED == "Yes" and SPONSOR == "No" \
                and any(re.search(r"any employer", o, re.I) for o in f["opts"]):
            return self.put(f, lambda o: next((x for x in o if re.search(r"authori[sz]ed.*any employer", x, re.I)), None))
        if re.search(r"non-?compete|non-?solicit", t, re.I):
            na = P.get("standing_answers", {}).get("non_compete")
            if na and f["opts"]:
                return self.put(f, lambda o: next((x for x in o if x.lower().startswith(na.lower())), None))
            self.open_q.append(t[:100])
            return
        if f.get("dd"):
            if re.match(r"country", low):
                return self.put(f, home_pick(lambda o: next((x for x in o if re.match(r"united states( of america)?$", x, re.I)), None)),
                                typed=HOME_NAME)
            if re.match(r"state|province", low):
                return self.put(f, lambda o: next((x for x in o if x in (loc["state"], loc["state_code"])), None) if HOME == "US"
                                else region_pick(o), typed=loc["state"] or None)
            if re.search(r"time ?zone", low):
                if not TIME_ZONE:
                    self.open_q.append(t[:100])
                    return
                return self.put(f, lambda o: next((x for x in o if re.search(TIME_ZONE, x, re.I)), None), typed=TIME_ZONE)
            _, opts = self.dd_options(f)
            self.page.keyboard.press("Escape")
            f = dict(f, opts=[o for o in opts if o and not o.startswith("—")])
        if re.search(r"middle name|street address 2|address line 2", low):
            return
        if re.search(r"first name", low):
            return self.put(f, idn["first_name"])
        if re.search(r"last name", low):
            return self.put(f, idn["last_name"])
        if re.search(r"e-?mail", low) and f["tag"] != "SELECT":
            return self.put(f, idn["email"])
        if re.search(r"linkedin", low):
            return self.put(f, idn["linkedin"])
        if "PhoneType" in f["id"] or re.match(r"type$", low):
            return self.put(f, lambda o: next((x for x in o if re.search(r"mobile|cell", x, re.I)), None))
        if "PhoneNumber" in f["id"] or re.match(r"(phone|number)$", low):
            return self.put(f, idn["phone_digits"] if PHONE_REGION == "US" else idn["phone"])
        if re.match(r"street address$|address( line)? ?1?$", low):
            return self.put(f, loc["street_address"])
        if re.match(r"city$", low):
            return self.put(f, loc["city"])
        if re.match(r"zip|postal", low):
            return self.put(f, loc["zip"])
        if re.match(r"state|province", low):
            return self.put(f, lambda o: next((x for x in o if x in (loc["state"], loc["state_code"])), None) if HOME == "US"
                            else region_pick(o))
        if re.match(r"country", low):
            return self.put(f, home_pick(lambda o: next((x for x in o if re.match(r"united states( of america)?$", x, re.I)), None)))
        if re.match(r"employer|company( name)?$", low):
            return self.put(f, job["company"])
        if re.match(r"(job )?title$", low):
            return self.put(f, job["title"])
        if f["id"].endswith("_Month") and i + 2 < len(fields):
            first = not any(x["id"].endswith("_Month") for x in fields[:i])
            key = "start" if first else "end"
            return self.date_parts(fields, i, job[f"{key}_year"], job[f"{key}_month"])
        if re.match(r"description", low) and f["tag"] == "TEXTAREA":
            return self.put(f, job.get("description") or "")
        if re.search(SOURCE_Q, t, re.I) or re.match(r"please specify", low):
            if f["tag"] != "SELECT":
                return self.put(f, "LinkedIn")
            return self.put(f, lambda o: next((x for x in o if re.search(r"linked\s?in", x, re.I)), None) or next(
                (x for x in o if re.search(r"job board|online|website|internet", x, re.I)), None) or next(
                (x for x in o if re.search(r"not applicable|^n/?a$", x, re.I)), None))
        for rx, chooser in Jobvite.EEO_RULES:
            if re.search(rx, t, re.I) and f["opts"]:
                got = chooser(f["opts"])
                if got:
                    return self.put(f, got[0])
        if SALARY.search(t) and f["req"] and f["tag"] != "SELECT":
            e = self.el(f).first
            numeric = (e.get_attribute("type") or "") == "number" or (e.get_attribute("inputmode") or "") == "numeric"
            return self.put(f, salary_answer(t, numeric=numeric))
        ans = location_answer(t, self.jd) or next((a for rx, a in Ashby.RULES if re.search(rx, t, re.I)), None)
        if f["opts"]:
            pick = (ans(f["opts"]) if callable(ans) else None) or next(
                (o for o in f["opts"] if ans and o.lower() == str(ans).lower()), None) or (
                llm.answer(t, f["opts"], self.jd, self.company) if f["req"] or ans else None)
            if pick in f["opts"]:
                return self.put(f, pick)
            if f["req"]:
                self.open_q.append(t[:100])
            return
        if f["type"] == "checkbox":
            if re.search(r"i (agree|acknowledge|certify|consent|understand)|terms|privacy", t, re.I) and not NO_TEXT.search(t):
                return self.put(f, True)
            return
        if ans and (str(ans) not in ("Yes", "No") or YESNO_Q.match(t)):
            return self.put(f, ans)
        if f["req"]:
            txt = llm.draft(t, self.jd, self.company) if f["tag"] == "TEXTAREA" else llm.answer(t, None, self.jd, self.company)
            if txt:
                return self.put(f, txt)
            self.open_q.append(t[:100])

    def step(self):
        m = re.search(r"Step\s+(\d+)\s+of\s+(\d+)\.\s*([^(\n/]+)\(Current Step\)", self.frame().locator("body").inner_text())
        return (int(m.group(1)), int(m.group(2)), m.group(3).strip()) if m else (0, 0, "")

    def saved_password(self):
        fr = self.frame()
        pw = fr.locator("input[type=password]:visible")
        for _ in range(8):
            if pw.count() == 1 and pw.first.evaluate("e => e.matches(':-webkit-autofill')"):
                break
            self.page.wait_for_timeout(500)
        else:
            return False
        pw.first.click()
        self.page.wait_for_timeout(400)
        btn = fr.locator("input[type=submit]:visible, button[type=submit]:visible").filter(
            has_not=fr.locator("[id$='_form_save_i']"))
        if not btn.count():
            return False
        btn.first.click()
        self.page.wait_for_timeout(5000)
        say("iCIMS: signed in with Chrome's saved password (autofilled by Chrome)")
        return not self.frame().locator("input[type=password]:visible").count()

    def login(self):
        fr = self.frame()
        go = fr.locator("a, button").filter(has_text=re.compile(r"apply for this job", re.I))
        if go.count():
            go.first.click()
            self.page.wait_for_timeout(5000)
        fr = self.frame()
        if fr.locator("input#email:visible").count():
            fr.locator("input#email").fill(P["identity"]["email"])
            fr.locator("#enterEmailSubmitButton").click()
            self.page.wait_for_timeout(5000)
        def past():
            try:
                f = self.frame()
                return "/login" not in f.url or not f.locator("input#email:visible").count()
            except Exception:
                return False
        if self.saved_password():
            return True
        if past():
            return True
        if UNATTENDED:
            raise NeedsUser("sign-in: iCIMS shows a CAPTCHA (hCaptcha) after the email - double-click 'JobBot pending', "
                             "solve it; the script fills the form (you type the login + password it asks for)")
        say("waiting for you: solve the hCaptcha in the browser (click Next first if no puzzle shows)")
        for _ in range(600):
            try:
                if self.frame().locator("input[type=password]:visible").count() == 1 and self.saved_password():
                    return True
            except Exception:
                pass
            if past():
                time.sleep(3)
                return True
            time.sleep(1)
        return False

    def run(self, submit=True):
        dismiss_cookies(self.page)
        if not self.login():
            return "sign-in not completed", None
        for _ in range(8):
            n, total, name = self.step()
            say(f"page: step {n} of {total} {name}")
            fr = self.frame()
            up = fr.locator("input[type=file][id*='Resume'], input[type=file][name*='Resume']")
            if up.count() and not resume_shown(fr, self.resume, wait_s=1):
                up.first.set_input_files(self.resume)
                self.notes.append("resume -> " + self.resume)
                self.page.wait_for_timeout(8000)
                if not resume_shown(self.frame(), self.resume):
                    self.open_q.append("resume: uploaded file not shown on the form")
            handled, tried = None, set()
            for _ in range(3):
                fields = self.fields()
                if handled is None:
                    handled = self.experience(fields)
                todo = [(i, f) for i, f in enumerate(fields) if f["id"] not in handled
                        and (not f["value"].strip() or (f.get("dd") and f["value"] in ("-999", "-1")))
                        and (f["id"], f["title"]) not in tried]
                if not todo:
                    break
                for i, f in todo:
                    tried.add((f["id"], f["title"]))
                    try:
                        self.answer(f, fields, i)
                    except Exception as e:
                        self.open_q.append(f"{f['title'][:60]}: {type(e).__name__}")
            pw = self.frame().locator("input[type=password]:visible")
            if pw.count() and any(not x.input_value() for x in pw.all()):
                if UNATTENDED:
                    raise NeedsUser("sign-in: iCIMS 'Create a login' - double-click 'JobBot pending' and type a login + "
                                     "password (let Chrome save it); the script fills the rest")
                say("waiting for you: fill 'Create a login' (Login + Password, let Chrome save it) - nothing else")
                for _ in range(600):
                    if all(x.input_value() for x in self.frame().locator("input[type=password]:visible").all()) and \
                            all(x.input_value() for x in self.frame().locator("input[id$='Login']:visible").all()):
                        break
                    time.sleep(1)
            btn_txt = " ".join(self.frame().locator(self.SUBMIT).evaluate_all("els => els.map(e => e.value || e.innerText || '')"))
            last = bool(n == total) if total else bool(re.search(r"submit", btn_txt, re.I))
            if last:
                review = self.frame().locator("body").inner_text()[:12000]
                if self.open_q:
                    msg = "questions left for you: " + " || ".join(self.open_q)
                    self.notes.append(msg)
                    if UNATTENDED:
                        raise NeedsUser(msg)
                    say("STILL OPEN - fill these, then submit: " + " || ".join(self.open_q))
                    return "ready for review", review
                if (doubt := second_read(self, submit)) or not submit:
                    return "ready for review", review + (f"\n{doubt}" if doubt else "")
            before = self.frame().locator("body").inner_text()[:3000]
            self.frame().locator(self.SUBMIT).first.click(timeout=10000)
            self.page.wait_for_timeout(6000)
            errs = [x.strip() for x in self.frame().locator("[class*=error]:visible, [role=alert]:visible").all_inner_texts() if x.strip()]
            if any(SALARY.search(x) and re.search(r"digit|number", x, re.I) for x in errs):
                for f in self.fields():
                    if SALARY.search(f["title"]) and f["tag"] != "SELECT" and f["type"] not in ("checkbox", "radio"):
                        self.put(f, salary_answer(f["title"], numeric=True))
                self.frame().locator(self.SUBMIT).first.click(timeout=10000)
                self.page.wait_for_timeout(6000)
            body = self.frame().locator("body").inner_text()
            if last or CONFIRMED.search(body) or re.search(r"thank you for (applying|your (application|interest))", body, re.I):
                if CONFIRMED.search(body) or re.search(r"thank you", body, re.I):
                    return "submitted", "\n".join(self.notes)
                return unconfirmed(self.page, self.company), "\n".join(self.notes)
            if self.frame().locator("body").inner_text()[:3000] == before:
                errs = [e.strip()[:100] for e in self.frame().locator("[class*=error]:visible, [role=alert]:visible").all_inner_texts() if e.strip()]
                self.open_q.append(f"iCIMS step {n} not accepted: " + " || ".join(errs[:3]))
                msg = "questions left for you: " + " || ".join(self.open_q)
                if UNATTENDED:
                    raise NeedsUser(msg)
                return "ready for review", "\n".join(self.notes) + "\n" + msg
        return "too many pages", None


CONFIRMED = re.compile(r"thanks? (you )?for (applying|your (application|interest))|application (was |has been )?"
                       r"(successfully )?(submitted|received)|successfully submitted|we('ve| have) received your application|"
                       r"your application for .{1,160}? (has been|was) (successfully )?(submitted|received)",
                       re.I)


def unconfirmed(page, company):
    errs = [e.strip()[:120] for e in page.locator("[class*=error]:visible, [role=alert]:visible").all_inner_texts() if e.strip()]
    shot = RUNS / f"{dt.datetime.now():%Y-%m-%d_%H%M}_{re.sub(r'[^A-Za-z0-9]+', '-', company)[:30]}_after-submit.png"
    try:
        page.screenshot(path=str(shot), full_page=True)
    except Exception:
        shot = None
    return "submit clicked - confirmation not seen" + (f"; errors: {' | '.join(errs[:3])}" if errs else "") + \
        (f"; screenshot runs/{shot.name}" if shot else "")


def trim_history(jobs, cap):
    keep = list(jobs)
    desc = lambda j: j["title"] + " " + j.get("description", "")
    for key in P.get("experience_drop_order_when_capped", []):
        if len(keep) <= cap:
            break
        keep = [j for j in keep if key.lower() not in desc(j).lower()] or keep
    protected = lambda j: any(k.lower() in desc(j).lower() for k in P.get("experience_never_drop", []))
    while len(keep) > cap:
        victim = next((j for j in reversed(keep) if not protected(j)), keep[-1])
        keep.remove(victim)
    dropped = [j for j in jobs if j not in keep]
    keep = [dict(j) for j in keep]
    when = lambda j, k: (j[k + "_year"], j[k + "_month"])
    for newer, older in zip(keep, keep[1:]):
        if any(when(older, "end") <= when(d, "start") and when(d, "end") <= when(newer, "start") for d in dropped):
            older["end_year"], older["end_month"] = newer["start_year"], newer["start_month"]
    return keep


class Phenom:

    RULES = Greenhouse.RULES + [
        (r"government official|government entity", GOV),
        (RELATIVE_RX[2], "No"),
        (r"years of (relevant )?(work )?experience", years_option),
    ]

    def __init__(self, page, jd, company, resume_pdf):
        self.p, self.jd, self.company, self.resume = page, jd, company, resume_pdf
        self.notes, self.open_q = [], []

    def by(self, x):
        return self.p.locator(f"[id='{x}'], [name='{x}']").first

    def select(self, loc, want):
        opts = [o.strip() for o in loc.locator("option").all_inner_texts() if o.strip() and o.strip() != "Please Select"]
        if callable(want):
            hit = want(opts)
        else:
            hits = [o for o in opts if re.search(want, o, re.I)]
            hit = min(hits, key=len) if hits else None
        if hit:
            try:
                loc.select_option(label=hit, timeout=5000)
            except PWTimeout:
                ok = loc.evaluate("""(s, t) => { const o = [...s.options].find(o => o.text.trim() === t);
                    if (!o) return false; s.value = o.value;
                    s.dispatchEvent(new Event('input', {bubbles: true})); s.dispatchEvent(new Event('change', {bubbles: true}));
                    return s.value === o.value; }""", hit)
                say(f"select via page for {loc.get_attribute('id')}: {'ok' if ok else 'FAILED'}")
                if not ok:
                    hit = None
            self.p.wait_for_timeout(500)
            offer(self, hit, opts)
        return hit, opts

    def date(self, fid, text):
        f = self.by(fid)
        f.scroll_into_view_if_needed()
        f.focus()
        self.p.keyboard.press("Control+a")
        self.p.keyboard.press("Backspace")
        f.type(text, delay=60)
        self.p.keyboard.press("Tab")
        self.p.wait_for_timeout(300)
        if f.input_value() != text:
            f.evaluate("""(e, t) => { const set = Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set;
                set.call(e, t); ['input', 'change', 'blur'].forEach(k => e.dispatchEvent(new Event(k, {bubbles: true}))); }""", text)
            self.p.wait_for_timeout(300)
        if f.input_value() != text:
            self.open_q.append(f"date {fid}: wanted {text}, form shows {f.input_value()}")

    def click_js(self, elem_id):
        self.p.evaluate("(i) => document.getElementById(i).click()", elem_id)

    def step(self):
        m = re.search(r"stepname=([A-Za-z]+)", self.p.url)
        return m.group(1) if m else ""

    def errors(self):
        return [e.strip()[:120] for e in self.p.locator("[class*=error]:visible, [role=alert]:visible").all_inner_texts() if e.strip()]

    def personal(self):
        idn, loc = P["identity"], P["location"]
        self.p.locator("input[type=file]").first.set_input_files(self.resume)
        self.notes.append("resume -> " + self.resume)
        self.p.wait_for_timeout(6000)
        self.select(self.p.locator("select#country").first, home_pick(r"^United States( of America)?$"))
        self.p.wait_for_timeout(2500)
        for fid, val in [("cntryFields.firstName", idn["first_name"]), ("cntryFields.lastName", idn["last_name"]),
                         ("cntryFields.city", loc["city"]), ("email", idn["email"]),
                         ("phoneWidget.phoneNumber", idn["phone_digits"])]:
            f = self.by(fid)
            if f.count():
                f.fill(val)
        region = rf"^{loc['state']}$" if HOME == "US" else region_pick
        for fid, want in [("cntryFields.region", region), ("deviceType", r"mobile"),
                          ("phoneWidget.countryPhoneCode", phone_pick(r"United States.*\+1")), ("applicantSource", r"linkedin")]:
            f = self.by(fid)
            if f.count():
                self.notes.append(f"{fid} -> {self.select(f, want)[0]}")
        if self.p.locator("[id='previousWorkerConfirmation.No']").count():
            self.click_js("previousWorkerConfirmation.No")
        if self.p.locator("#consent").count() and not self.p.locator("#consent").first.is_checked():
            self.click_js("consent")
            self.notes.append("ticked: consent")

    def _resize(self, kind, n, add_id, remove_prefix):
        count = lambda: self.p.locator(f"fieldset[id^='{kind}[']").count()
        for _ in range(12):
            c = count()
            if c == n:
                return c
            if c < n and not self.p.locator(f"[id='{add_id}']").count():
                return c
            if c > n:
                self.p.evaluate("(pre) => { const b = [...document.querySelectorAll(`[id^='${pre}']`)]; b[b.length - 1].click(); }",
                                remove_prefix)
            else:
                self.click_js(add_id)
            self.p.wait_for_timeout(900)
        raise RuntimeError(f"could not make {kind} hold {n} entries (has {count()})")

    def work_and_education(self):
        jobs = P["experience"]
        cap = self._resize("experienceData", len(jobs), "array-button-add-experienceData", "work-experience-array-button-remove-")
        if cap < len(jobs):
            jobs = trim_history(jobs, cap)
            kept = {(j["title"], j["start_year"]) for j in jobs}
            dropped = [j for j in P["experience"] if (j["title"], j["start_year"]) not in kept]
            self.notes.append(f"form allows {cap} roles; dropped the least relevant "
                              f"({', '.join(j['title'] + ' ' + str(j['start_year']) for j in dropped)}) - the resume has all")
        for i, j in enumerate(jobs):
            r = f"experienceData[{i}]"
            self.by(f"{r}.title").fill(j["title"])
            self.by(f"{r}.companyName").fill(j["company"])
            cur = self.by(f"{r}.fromTo.currentlyWorkHere")
            if cur.count() and cur.is_checked() != is_current(j):
                self.click_js(f"{r}.fromTo.currentlyWorkHere")
            self.date(f"{r}.fromTo.startDate", f"{j['start_month']:02d}/{j['start_year']}")
            if not is_current(j):
                self.date(f"{r}.fromTo.endDate", f"{j['end_month']:02d}/{j['end_year']}")
        self.notes.append(f"work history rebuilt from data: {len(jobs)} roles")
        edu = P["education_on_forms"]
        if self._resize("educationData", len(edu), "array-button-add-educationData", "education-details-array-button-remove-") < len(edu):
            self.open_q.append("education: form holds fewer entries than the profile's degrees")
        for i, e in enumerate(edu):
            r = f"educationData[{i}]"
            school = self.by(f"{r}.schoolName")
            school.click(); school.fill(e["school"])
            self.p.wait_for_timeout(1800)
            opts = self.p.locator("[role=option]:visible")
            texts = [t.strip() for t in opts.all_inner_texts()]
            hit = next((k for k, t in enumerate(texts) if t.lower() == e["school"].lower()), None)
            if hit is None:
                hit = next((k for k, t in enumerate(texts) if e["school"].lower() in t.lower()), None)
            if hit is None and e.get("school_fallback"):
                school.fill(e["school_fallback"])
                self.p.wait_for_timeout(1800)
                texts = [t.strip() for t in opts.all_inner_texts()]
                hit = next((k for k, t in enumerate(texts) if e["school_fallback"].lower() in t.lower()), None)
            if hit is not None:
                opts.nth(hit).click()
            else:
                self.p.keyboard.press("Escape")
            level, kind = degree_level(e["degree"]), degree_kind(e["degree"])
            deg, _ = self.select(self.by(f"{r}.degree"), rf"^{level} of {kind}$" if kind else rf"^{level}'?s?( degree)?\b")
            self.notes.append(f"education {i}: {e['school']} ({texts[hit] if hit is not None else 'typed'}) -> {deg}")

    def generic(self):
        rows = self.p.evaluate(r"""() => [...document.querySelectorAll('select, input[type=text], textarea, input[type=checkbox]')]
            .filter(e => e.offsetParent && !e.closest('header, nav, footer') && e.id)
            .map(e => { const l = document.querySelector(`label[for="${CSS.escape(e.id)}"]`) ||
                                  (e.getAttribute('aria-labelledby') && document.getElementById(e.getAttribute('aria-labelledby')));
                return {id: e.id, tag: e.tagName, type: e.type, value: e.type === 'checkbox' ? (e.checked ? 'x' : '') : e.value,
                        required: e.required || e.getAttribute('aria-required') === 'true' || !!(l && /\*/.test(l.innerText)),
                        label: ((l && l.innerText) || e.getAttribute('aria-label') || '').replace(/\s+/g, ' ').replace(/\*/g, '').trim()}; })""")
        for r in rows:
            if r["value"] or not r["label"]:
                continue
            if NEVER_FILL.search(r["label"]):
                if r["tag"] == "SELECT":
                    hit, _ = self.select(self.p.locator(f"[id='{r['id']}']").first, NA_OPTION)
                    self.notes.append(f"{r['label'][:40]} -> {hit}")
                continue
            label, loc = r["label"], self.p.locator(f"[id='{r['id']}']").first
            if r["tag"] == "SELECT":
                chooser = next((c for rx, c in EEO if re.search(rx, label, re.I)), None)
                if chooser is None:
                    ans = (location_answer(label, self.jd) or next((a for rx, a in self.RULES if re.search(rx, label, re.I)), None))
                    chooser = ans if callable(ans) else (lambda o, a=ans: next((x for x in o if a and
                              (x.lower() == a.lower() or x.lower().startswith(a.lower()))), None))
                hit, opts = self.select(loc, chooser)
                if not hit:
                    ans = llm.answer(label, opts, self.jd, self.company)
                    if ans:
                        hit, _ = self.select(loc, lambda o, a=ans: a if a in o else None)
                if hit:
                    self.notes.append(f"{label[:60]} -> {hit}")
                elif r["required"]:
                    self.open_q.append(label[:100])
            elif r["type"] == "checkbox":
                if re.search(r"agree|acknowledg|consent|certif|i have read|terms", label, re.I) and not NO_TEXT.search(label):
                    self.click_js(r["id"])
                    self.notes.append(f"ticked: {label[:70]}")
            elif r["required"]:
                if SALARY.search(label):
                    ans = salary_answer(label)
                else:
                    ans = work_address(label, self.jd) or \
                        next((a for rx, a in self.RULES if re.search(rx, label, re.I) and isinstance(a, str)), None) \
                        or llm.answer(label, None, self.jd, self.company)
                if ans:
                    loc.fill(llm.clean(ans))
                    self.notes.append(f"{label[:60]} -> {ans[:60]}")
                else:
                    self.open_q.append(label[:100])

    def run(self, submit=True):
        dismiss_cookies(self.p)
        if "/apply" not in self.p.url:
            self.p.locator("a:visible", has_text=re.compile(r"^\s*apply( now)?\s*$", re.I)).first.click()
            self.p.wait_for_url(re.compile(r"/apply"), timeout=30000)
            self.p.wait_for_timeout(6000)
            dismiss_cookies(self.p)
        seen = {}
        for _ in range(10):
            s = self.step()
            say(f"page: {s}")
            seen[s] = seen.get(s, 0) + 1
            if seen[s] > 2:
                return f"stuck on '{s}': {self.errors()[:3]}", None
            if re.search(r"review", s, re.I):
                review = self.p.locator("body").inner_text()[:12000]
                if self.open_q:
                    msg = "questions left for you: " + " || ".join(self.open_q)
                    self.notes.append(msg)
                    if UNATTENDED:
                        raise NeedsUser(msg)
                    return "ready for review", review
                if (doubt := second_read(self, submit)) or not submit:
                    return "ready for review", review + (f"\n{doubt}" if doubt else "")
                self.p.locator("button:visible", has_text=re.compile(r"^\s*submit", re.I)).first.click()
                for _ in range(25):
                    self.p.wait_for_timeout(1000)
                    body = self.p.locator("body").inner_text()
                    if re.search(r"thank you|application (has been |was )?(submitted|received)", body, re.I) or \
                            re.search(r"thank|success|confirmation", self.p.url, re.I):
                        return "submitted", review
                return "submit clicked - confirmation not seen", review
            if s == "personalInformation":
                self.personal()
            elif s == "workAndEducation":
                self.work_and_education()
            else:
                self.generic()
            if self.open_q and UNATTENDED:
                raise NeedsUser("questions left for you: " + " || ".join(self.open_q))
            if PRACTICE:
                return practice_stop(self)
            before = self.p.url
            self.p.locator("button#next:visible").first.click()
            for _ in range(20):
                self.p.wait_for_timeout(750)
                if self.p.url != before:
                    break
            self.p.wait_for_timeout(2500)
            if self.p.url == before:
                errs = self.errors()
                if errs:
                    say(f"validation errors: {errs[:4]}")
        return "too many pages", None


class Oracle:

    QUESTIONS = [
        (r"ex-?oracle employee", "Yes" if former_employer("Oracle") else "No"),
        (r"employed by the government|government .*contractor", GOV),
        (AUTH_RX, AUTHORIZED),
        (SPONSOR_RX, SPONSOR),
        (r"currently employed by .*(subsidiar|affiliat)|employed by one of", AFFILIATE_EMPLOYEE),
    ]
    MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September",
              "October", "November", "December"]

    def __init__(self, page, jd, company, resume_pdf):
        self.p, self.jd, self.company, self.resume = page, jd, company, resume_pdf
        self.notes, self.open_q = [], []

    def ids(self):
        return self.p.evaluate("() => [...document.querySelectorAll('input[id]')].filter(e => e.offsetParent).map(e => e.id)")

    def find(self, prefix):
        return next((i for i in self.ids() if i.startswith(prefix)), None)

    def combo(self, input_id, typed, want):
        if not input_id:
            return None
        inp = self.p.locator(f"[id='{input_id}']")
        try:
            inp.click(timeout=5000)
        except PWTimeout:
            return None
        inp.fill("")
        inp.type(typed, delay=60)
        self.p.wait_for_timeout(2500)
        ctl = inp.get_attribute("aria-controls")
        lb = self.p.locator(f"[id='{ctl}']") if ctl else None
        if lb is not None and lb.count():
            cells = lb.locator("[role=gridcell], [role=option]")
            texts = [" ".join(t.split()) for t in cells.all_inner_texts()] if lb.is_visible() else []
            if not texts:
                self.p.keyboard.press("Escape")
                inp.fill("")
                return None
            pick = lambda k: cells.nth(k)
        else:
            opts = self.p.locator("[role=listbox]:visible [role=option], ul.oj-listbox-results:visible li")
            texts = [t.strip() for t in opts.all_inner_texts()] if opts.count() else []
            pick = lambda k: opts.nth(k)
        if texts:
            hit = next((k for k, t in enumerate(texts) if re.search(want, t, re.I)), None)
            if hit is None:
                self.p.keyboard.press("Escape")
                inp.fill("")
                return None
            pick(hit).click()
            offer(self, texts[hit], texts)
        else:
            self.p.keyboard.press("ArrowDown")
            self.p.wait_for_timeout(300)
            self.p.keyboard.press("Enter")
        self.p.wait_for_timeout(800)
        self.p.keyboard.press("Tab")
        self.p.wait_for_timeout(800)
        try:
            v = inp.input_value(timeout=5000)
        except PWTimeout:
            return None
        if re.search(want, v or "", re.I):
            return v
        self.p.keyboard.press("Escape")
        return None

    def click_js(self, loc):
        loc.evaluate("e => e.click()")

    def section(self):
        m = re.search(r"/section/(\d+)", self.p.url)
        return int(m.group(1)) if m else 0

    def block(self, add_label):
        return ("(() => { const add = [...document.querySelectorAll('button')].find(b => b.innerText.trim().toUpperCase() === '"
                + add_label.upper() + "'); if (!add) return null; "
                "return add.closest('apply-flow-block, .apply-flow-block'); })()")

    def items(self, add_label):
        return self.p.evaluate("() => { const b = " + self.block(add_label) + "; if (!b) return [];"
                               " const dels = [...b.querySelectorAll('button[aria-label=Delete]')];"
                               " return dels.map((d, i) => { let it = d;"
                               "  while (it.parentElement && it.parentElement !== b &&"
                               "   it.parentElement.querySelectorAll('button[aria-label=Delete]').length === 1) it = it.parentElement;"
                               "  return [it.innerText.split('\\n').join(' ').trim(), i]; }); }")

    def delete_item(self, add_label, index):
        before = len(self.items(add_label))
        self.p.evaluate("() => { const b = " + self.block(add_label) + ";"
                        f" b.querySelectorAll('button[aria-label=Delete]')[{index}].click(); }}")
        self.confirm_dialog()
        for _ in range(20):
            if len(self.items(add_label)) < before:
                return True
            self.p.wait_for_timeout(300)
        raise RuntimeError(f"{add_label}: item {index} did not disappear after Delete")

    def confirm_dialog(self):
        self.p.wait_for_timeout(700)
        b = self.p.locator("[role=dialog] button:visible, .oj-dialog button:visible").filter(
            has_text=re.compile(r"^\s*(yes|delete|remove|ok)\s*$", re.I))
        if b.count():
            b.first.click()
            self.p.wait_for_timeout(900)

    def add_button(self, label):
        return self.p.locator("button:visible").filter(has_text=re.compile(rf"^\s*{label}\s*$", re.I))

    def save_form(self, label):
        save = self.p.get_by_role("button", name=re.compile(r"^\s*save\s*$", re.I))
        (save.last if save.count() else self.add_button(label).last).click()
        self.p.wait_for_timeout(2000)

    def confirmed(self, job_id):
        body = self.p.locator("body").inner_text()
        if CONFIRMED.search(body) or re.search(r"thank|confirm|success", self.p.url, re.I):
            return True
        today = dt.date.today().strftime("%m/%d/%Y")
        return bool(job_id) and bool(re.search(re.escape(job_id) + r"\W{0,6}Applied on " + re.escape(today), body))

    def authenticate(self):
        p = self.p
        if self.section():
            return True
        if "/apply" not in p.url:
            btn = p.get_by_role("button", name=re.compile(r"^\s*apply( now)?\s*$", re.I))
            (btn if btn.count() else p.get_by_role("link", name=re.compile(r"^\s*apply( now)?\s*$", re.I))).first.click()
            p.wait_for_timeout(5000)
        email = p.locator("input[type=email]:visible")
        if email.count():
            email.first.fill(P["identity"]["email"])
            box = p.locator("input[type=checkbox][id*=disclaimer], input[type=checkbox][id*=legal]").first
            if box.count():
                box.evaluate("e => { if (!e.checked) e.click(); }")
            since = dt.datetime.now(dt.timezone.utc) - dt.timedelta(minutes=2)
            p.get_by_role("button", name=re.compile(r"^\s*next\s*$", re.I)).first.click()
            p.wait_for_timeout(5000)
        else:
            since = dt.datetime.now(dt.timezone.utc) - dt.timedelta(minutes=1)
        if self.section():
            return True
        if re.search(r"verification code|confirm your identity|pass ?code", p.locator("body").inner_text(), re.I):
            if UNATTENDED:
                raise NeedsUser("sign-in: Oracle emails a verification code - double-click 'JobBot pending', "
                                 "paste the code (it goes on your clipboard) in the Chrome it opens; the script fills and submits")
            code = greenhouse_code(self.company, since, kind="oracle", done=lambda: bool(self.section()))
            say(f"{self.company}'s verification code {code} is on your clipboard: click the code box, Ctrl+V, VERIFY"
                if code else "waiting for you: type the verification code (sent to your email) and click VERIFY")
            for _ in range(600):
                if self.section():
                    p.wait_for_timeout(4000)
                    try:
                        clear_clipboard()
                        trash_code_emails(self.company)
                    except Exception:
                        pass
                    return True
                p.wait_for_timeout(1000)
            return False
        if self.section():
            return True
        human_check = bool(p.locator("iframe[src*='captcha'], iframe[title*='captcha' i], [class*=captcha]").count()) or \
            bool(re.search(r"captcha|verify (that )?you are (a )?human|i'?m not a robot", p.locator("body").inner_text(), re.I))
        if UNATTENDED:
            if human_check:
                raise NeedsUser("sign-in: the site shows a CAPTCHA - double-click 'JobBot pending', solve it in the Chrome "
                                 "it opens (and paste the emailed code if one follows); the script fills and submits")
            return False
        say("waiting for you: finish the check in the browser (CAPTCHA / code) - the script continues on the form")
        for _ in range(600):
            try:
                if self.section():
                    time.sleep(4)
                    return True
                if re.search(r"verification code|confirm your identity|pass ?code", p.locator("body").inner_text(timeout=3000), re.I):
                    return self.authenticate()
            except (NeedsUser, AlreadyApplied):
                raise
            except Exception:
                if p.is_closed():
                    raise NeedsUser(f"sign-in: {self.company}'s page was closed during the CAPTCHA - run JobBot pending again")
            time.sleep(1)
        return False

    def contact(self):
        idn, loc = P["identity"], P["location"]
        for prefix, val in [("lastName", idn["last_name"]), ("firstName", idn["first_name"])]:
            i = self.find(prefix)
            if i and self.p.locator(f"[id='{i}']").input_value() != val:
                self.p.locator(f"[id='{i}']").fill(val)
        i = self.find("addressLine1")
        if i and not self.p.locator(f"[id='{i}']").input_value():
            self.p.locator(f"[id='{i}']").fill(loc["street_address"])
        tel = self.p.locator("input[type=tel]:visible").first
        if tel.count() and not tel.input_value():
            tel.fill(idn["phone_digits"])
        for prefix, typed, want in [("country-codes-dropdownphoneNumber", PHONE_NAME, phone_rx(r"united states|\+1")),
                                    ("country-", HOME_NAME, home_rx(r"^united states$")),
                                    ("postalCode", loc["zip"], loc["zip"]),
                                    ("city", loc["city"], loc["city"]),
                                    ("region2", loc["state"], f"^({loc['state']}|{loc['state_code']})$"),
                                    ("region1", loc.get("county") or "", "^" + (loc.get("county") or ""))]:
            if not typed:
                continue
            i = self.find(prefix)
            if i and not self.p.locator(f"[id='{i}']").input_value():
                got = self.combo(i, typed, want)
                self.notes.append(f"{prefix} -> {got}")
                if not got:
                    self.open_q.append(f"address field {prefix} not set")
        for fid, want in [("emailPreferredFlag", True), ("phonePreferredFlag", False)]:
            box = self.p.locator(f"input[type=checkbox][id*='{fid}']")
            if box.count() and box.first.is_checked() != want:
                self.click_js(box.first)

    def profile(self):
        p = self.p
        for _ in range(12):
            if not self.items("ADD EDUCATION"):
                break
            self.delete_item("ADD EDUCATION", 0)
        before = []
        for ed in P["education_on_forms"]:
            key = ed["school"][:23].lower()
            if any(key in t and "fields to fix" not in t for t in before):
                continue
            self.click_js(self.add_button("ADD EDUCATION").first)
            p.wait_for_timeout(1800)
            level, kind = degree_level(ed["degree"]), degree_kind(ed["degree"])
            other = {"Science": "Arts", "Arts": "Science"}.get(kind, "#none#")
            deg = None
            for typed, want in ([(f"{level} of {kind}", f"{level} of {kind}")] if kind else []) + \
                    [(f"{level}", rf"^{level}'?s?( degree| or equivalent)?$|^{level}'?s? degree|^{level}ate")] + \
                    ([(f"{level[0]}.{kind[0]}", rf"^{level[0]}\.?{kind[0]}\b")] if kind else []):
                if self.find("contentItemId"):
                    deg = self.combo(self.find("contentItemId"), typed, want)
                if deg and not re.search(rf"of {other}", deg, re.I):
                    break
                deg = None
            if not deg:
                pills = p.locator("ul[role=radiogroup] button[role=radio]:visible")
                names = [t.strip() for t in pills.all_inner_texts()]
                pill = {"Master": r"^master", "Bachelor": r"bachelor", "Doctor": r"doctor|ph\.?\s?d", "Associate": r"associate",
                        "High School": r"high school|secondary|G\.?E\.?D"}.get(level, r"(?!x)x")
                k = next((i for i, t in enumerate(names) if re.search(pill, t, re.I)), None)
                if k is not None:
                    self.click_js(pills.nth(k))
                    p.wait_for_timeout(600)
                    deg = names[k] if pills.nth(k).get_attribute("aria-checked") == "true" else None
            typed = ed["school"][:23]
            sch = self.combo(self.find("educationalEstablishment"), typed, re.escape(typed.lower()))
            if not sch and ed.get("school_fallback"):
                sch = self.combo(self.find("educationalEstablishment"), ed["school_fallback"], re.escape(ed["school_fallback"]))
            major = self.find("major")
            if major:
                p.locator(f"[id='{major}']").fill(ed["field_queries"][0])
            self.save_form("ADD EDUCATION")
            self.notes.append(f"education: {sch} / {deg} / {ed['field_queries'][0]}")
            if not (deg and sch):
                self.open_q.append(f"education not confirmed: {ed['school']} (degree {deg}, school {sch})")
        edu_now = [t for t, _ in self.items("ADD EDUCATION")]
        self.notes.append("education on the form: " + " | ".join(edu_now))
        if len(edu_now) != len(P["education_on_forms"]):
            self.open_q.append(f"education on the form is not exactly the profile's degrees: {edu_now}")
        for _ in range(15):
            if not self.items("ADD EXPERIENCE"):
                break
            self.delete_item("ADD EXPERIENCE", 0)
        for job in P["experience"]:
            self.click_js(self.add_button("ADD EXPERIENCE").first)
            p.wait_for_timeout(1500)
            p.locator(f"[id='{self.find('employerName')}']").fill(job["company"])
            p.locator(f"[id='{self.find('jobTitle')}']").fill(job["title"])
            cur = p.locator("input[type=checkbox][id*=currentJobFlag]")
            if cur.count() and cur.first.is_checked() != is_current(job):
                self.click_js(cur.first)
                p.wait_for_timeout(500)
            for _ in range(10):
                if self.find("month-endDate") or not job.get("end_year"):
                    break
                if cur.count() and cur.first.is_checked():
                    self.click_js(cur.first)
                p.wait_for_timeout(500)
            for key, sfx in [("start", "startDate")] + ([] if is_current(job) else [("end", "endDate")]):
                mon = self.MONTHS[(job.get(f"{key}_month") or 1) - 1]
                got_m = self.combo(self.find(f"month-{sfx}"), mon, "^" + mon)
                got_y = self.combo(self.find(f"year-{sfx}"), str(job[f"{key}_year"]), f"^{job[key + '_year']}$")
                if not (got_m and got_y):
                    self.open_q.append(f"experience {job['title']} {job['start_year']}: {key} date not set")
            self.save_form("ADD EXPERIENCE")
        text = " ".join(t for t, _ in self.items("ADD EXPERIENCE"))
        for job in P["experience"]:
            if job["title"] not in text or str(job["start_year"]) not in text:
                self.open_q.append(f"experience not confirmed on the form: {job['title']} {job['start_year']}")
            elif job.get("end_year") and f"{job['end_month']:02d}/{job['end_year']}" not in text:
                self.open_q.append(f"experience {job['title']} {job['start_year']}: end date not on the saved row")
        self.notes.append(f"experience rebuilt from data: {len(self.items('ADD EXPERIENCE'))} roles on the form")
        rm = p.get_by_role("button", name=re.compile(r"remove resume", re.I))
        if rm.count():
            try:
                rm.first.click(timeout=5000)
            except PWTimeout:
                self.click_js(rm.first)
            self.confirm_dialog()
            p.wait_for_timeout(1500)
        idx = p.evaluate("""() => { const ins = [...document.querySelectorAll('input[type=file]')];
            return ins.findIndex(i => { const blk = i.closest('apply-flow-block, .apply-flow-block');
              const t = (blk ? blk.innerText : '').toLowerCase();
              return t.includes('supporting documents') && !/cover letter|attachment/i.test(i.id + ' ' + (i.getAttribute('aria-label') || '')); }); }""")
        if idx < 0:
            idx = p.evaluate("""() => [...document.querySelectorAll('input[type=file]')].findIndex(i =>
                i.closest('resume-upload-button') && !/import your profile/i.test((i.closest('li, section') || {}).innerText || ''))""")
        if idx < 0:
            self.open_q.append("resume: no resume upload field under Supporting Documents")
            return
        p.locator("input[type=file]").nth(idx).set_input_files(self.resume)
        stem = r"[\s_-]*".join(re.escape(w) for w in re.split(r"[\s_-]+", Path(self.resume).stem) if w)
        if not resume_shown(p, self.resume, wait_s=15, also=stem):
            self.open_q.append("resume: uploaded file not shown on the form")
        self.notes.append("resume -> " + self.resume)

    def finish(self):
        p = self.p
        today = START_DATE
        for prefix, typed, want in [("month-earliestAvailableDate", self.MONTHS[today.month - 1], "^" + self.MONTHS[today.month - 1]),
                                    ("day-earliestAvailableDate", str(today.day), f"^{today.day}$"),
                                    ("year-earliestAvailableDate", str(today.year), f"^{today.year}$")]:
            if self.find(prefix) and not self.combo(self.find(prefix), typed, want):
                self.open_q.append(f"earliest available date: {prefix} not set")
        if self.find("day-earliestAvailableDate"):
            self.notes.append(f"earliest available date -> {today:%B %d %Y}")
        qs = p.evaluate("() => [...document.querySelectorAll('button')].filter(b => b.offsetParent && b.innerText.trim() === 'Yes')"
                        ".map((b, i) => { let c = b.parentElement; while (c && c.innerText.indexOf('?') < 0) c = c.parentElement;"
                        " if (c) c.dataset.jbQ = i;"
                        " return {i, text: c ? c.innerText.split(String.fromCharCode(10))[0].slice(0, 200) : ''}; })")
        for q in qs:
            ans = next((a for rx, a in self.QUESTIONS if re.search(rx, q["text"], re.I)), None) or \
                llm.answer(q["text"], ["Yes", "No"], self.jd, self.company)
            box = p.locator(f"[data-jb-q='{q['i']}']")
            if ans in ("Yes", "No") and box.count():
                self.click_js(box.locator("button").filter(has_text=re.compile(rf"^\s*{ans}\s*$")).first)
                self.notes.append(f"{q['text'][:60]} -> {ans}")
            else:
                self.open_q.append(q["text"][:100])
        groups = p.evaluate("""() => [...document.querySelectorAll('ul[role=radiogroup]')].filter(g => g.offsetParent).map((g, i) => {
            const opts = [...g.querySelectorAll('button[role=radio]')].map(b => b.innerText.trim());
            let c = g.parentElement; while (c && c.innerText.indexOf('?') < 0 && c.innerText.length < 400) c = c.parentElement;
            return {i, opts, done: !!g.querySelector('button[aria-checked=true]'),
                    text: c ? c.innerText.split(String.fromCharCode(10))[0].slice(0, 200) : ''}; })""")
        for g in groups:
            if g["done"] or "Yes" in g["opts"] or re.search(r"pronoun|he/him|she/her|they/them", g["text"] + " ".join(g["opts"]), re.I) \
                    or any(re.search(r"bachelor|masters or equivalent", o, re.I) for o in g["opts"]):
                continue
            ans = next((a for rx, a in self.QUESTIONS if re.search(rx, g["text"], re.I)), None)
            ans = ans if ans in g["opts"] else llm.answer(g["text"], g["opts"], self.jd, self.company)
            if ans in g["opts"]:
                self.click_js(p.locator("ul[role=radiogroup]:visible").nth(g["i"]).locator("button[role=radio]").nth(g["opts"].index(ans)))
                self.notes.append(f"{g['text'][:60]} -> {ans}")
            else:
                self.open_q.append(g["text"][:100])
        race_word = (str(SI.get("race", "")).strip().split() or [""])[0]
        pills = [("I am Hispanic or Latino.", yes_no(SI.get("hispanic_latino")) == "Yes")]
        if race_word and not _declines(SI.get("race")):
            pills.append((race_word.capitalize(), True))
        for label, want in pills:
            box = p.get_by_label(label, exact=True)
            if box.count() and box.first.is_checked() != want:
                self.click_js(box.first)
        g = self.find("US-STANDARD-ORA_GENDER")
        if g:
            gv = str(SI.get("gender", "")).strip().lower()
            female, male = gv in ("female", "woman"), gv in ("male", "man")
            a, b = ("Woman", "Female") if female else ("Man", "Male")
            want_rx = "^(woman|female)$" if female else "^(man|male)$"
            got = None if _declines(SI.get("gender")) or not (female or male) else \
                (self.combo(g, a, want_rx) or self.combo(g, b, want_rx))
            if not got:
                self.open_q.append("gender not set")
            self.notes.append(f"gender -> {got}")
        e = self.find("US-DFF-ethnicity")
        if e and not p.locator(f"[id='{e}']").input_value():
            hl = None if _declines(SI.get("hispanic_latino")) else yes_no(SI.get("hispanic_latino"))
            got = self.combo(e, "Not", r"^not hispanic") if hl == "No" else \
                self.combo(e, "Hispanic", r"^hispanic") if hl == "Yes" else None
            self.notes.append(f"ethnicity -> {got}")
            if not got:
                self.open_q.append("ethnicity not set")
        r1 = self.find("US-DFF-raceOrNationalOrigin1")
        if r1 and not p.locator(f"[id='{r1}']").input_value():
            got = self.combo(r1, race_word.capitalize(), rf"^{re.escape(race_word.lower())}") if race_word and not _declines(SI.get("race")) else None
            self.notes.append(f"race -> {got}")
            if not got:
                self.open_q.append("race not set")
        labelled = p.evaluate("""() => [...document.querySelectorAll('input[role=combobox][id]')].filter(e => e.offsetParent && !e.value)
            .map(e => { const by = (e.getAttribute('aria-labelledby') || '').split(' ').map(i => document.getElementById(i)).filter(Boolean);
                        const l = (e.labels && e.labels[0]) || document.querySelector('label[for="' + e.id + '"]') || by[0];
                        return [e.id, l ? l.innerText.trim() : '']; })""")
        for fid, lab in labelled:
            if re.search(r"spouse|domestic partner", lab, re.I):
                sp = yes_no(SI.get("military_spouse"), "No")
                got = self.combo(fid, sp, rf"^{sp.lower()}\b")
            elif re.search(r"military|veteran", lab, re.I) and not fid.startswith(("US-STANDARD-ORA_VETERAN", "US-DFF-veteranStatus")):
                got = self.combo(fid, "Not", r"not a (protected )?veteran|^i am not|^no\b") if not_veteran() else None
            else:
                continue
            self.notes.append(f"{lab[:40]} -> {got}")
            if not got:
                self.open_q.append(f"{lab[:60]} not set")
        v = self.find("US-STANDARD-ORA_VETERAN") or self.find("US-DFF-veteranStatus")
        if v:
            pick = self.combo(v, "I am not", r"not a (protected )?veteran") if not_veteran() else None
            if not pick or re.search(r"identify as a veteran", pick, re.I):
                self.open_q.append(f"veteran status not set safely (got {pick!r})")
            self.notes.append(f"veteran -> {pick}")
        for box in p.locator("input[type=checkbox]:visible").all():
            lab = box.evaluate("e => (e.labels && e.labels[0] ? e.labels[0].innerText : e.closest('div').innerText)")
            if re.search(r"job opportunities|careers emails|news and events", lab, re.I) and box.is_checked():
                self.click_js(box)
        n = self.find("fullName")
        if n:
            p.locator(f"[id='{n}']").fill(f"{P['identity']['first_name']} {P['identity']['last_name']}")
            self.notes.append("e-signature -> full name")

    def run(self, submit=True):
        dismiss_cookies(self.p)
        if not self.authenticate():
            return "sign-in not completed", None
        for _ in range(8):
            s = self.section()
            say(f"page: section {s}")
            if s == 1 and self.add_button("ADD EDUCATION").count():
                say("one-page Oracle form: filling all parts on this page")
                self.contact()
                self.profile()
                self.finish()
                review = self.p.locator("body").inner_text()[:12000]
                errs = re.findall(r"The [^.\n]{2,60} field is required", review)
                if self.open_q or errs:
                    msg = "one-page Oracle form - left for you: " + " || ".join(self.open_q + errs[:3])
                    self.notes.append(msg)
                    if UNATTENDED:
                        raise NeedsUser("sign-in: " + msg)
                    say("STILL OPEN - fill these, then press Submit: " + " || ".join(self.open_q + errs[:3]))
                    return "ready for review", review
                if (doubt := second_read(self, submit)) or not submit:
                    return "ready for review", review + (f"\n{doubt}" if doubt else "")
                job_id = (re.search(r"/job/(\d+)", self.p.url) or [None, ""])[1]
                self.p.get_by_role("button", name=re.compile(r"^\s*submit\s*$", re.I)).last.click(timeout=10000)
                for _ in range(25):
                    self.p.wait_for_timeout(1000)
                    if self.confirmed(job_id):
                        return "submitted", review
                return unconfirmed(self.p, self.company), review
            if not s:
                return f"unexpected Oracle page: {self.p.url[:120]}", None
            if self.find("lastName") or self.find("firstName"):
                self.contact()
            if self.add_button("ADD EDUCATION").count() or self.add_button("ADD EXPERIENCE").count():
                self.profile()
            last = self.p.get_by_role("button", name=re.compile(r"^\s*submit\s*$", re.I)).count()
            self.finish()
            if last:
                review = self.p.locator("body").inner_text()[:12000]
                if self.open_q:
                    msg = "questions left for you: " + " || ".join(self.open_q)
                    self.notes.append(msg)
                    if UNATTENDED:
                        raise NeedsUser(msg)
                    return "ready for review", review
                if (doubt := second_read(self, submit)) or not submit:
                    return "ready for review", review + (f"\n{doubt}" if doubt else "")
                job_id = (re.search(r"/job/(\d+)", self.p.url) or [None, ""])[1]
                self.p.get_by_role("button", name=re.compile(r"^\s*submit\s*$", re.I)).last.click()
                for _ in range(25):
                    self.p.wait_for_timeout(1000)
                    if self.confirmed(job_id):
                        return "submitted", review
                return unconfirmed(self.p, self.company), review
            before = self.p.url
            self.p.get_by_role("button", name=re.compile(r"^\s*(next|continue|save and continue)\s*$", re.I)).last.click(timeout=10000)
            for _ in range(20):
                self.p.wait_for_timeout(750)
                if self.p.url != before:
                    break
            self.p.wait_for_timeout(3000)
            if self.p.url == before:
                errs = [e.strip()[:120] for e in self.p.locator("[class*=error]:visible, [role=alert]:visible").all_inner_texts() if e.strip()]
                return f"stuck on section {s}: {errs[:3]}", None
        return "too many pages", None


GOOGLE_JD_JS = """() => { let best = null; for (const e of document.querySelectorAll('div, section, main')) {
  const t = e.innerText || ''; if (t.includes('Minimum qualifications') && t.includes('Responsibilities') &&
  (!best || t.length < best.length)) best = t; } return best; }"""
GOOGLE_LIMIT = re.compile(r"reached the limit of \d+ applications", re.I)
GOOGLE_DEGREE = [(r"^B\.?A\b", "Bachelor of Arts"), (r"^B\.?Sc?\b", "Bachelor of Science"),
                 (r"^M\.?Sc?\b", "Master of Science"), (r"^M\.?A\b", "Master of Arts")]
GOOGLE_ROWS_JS = """([label, attr]) => {
  const inputs = [...document.querySelectorAll('input')].filter(i => i.checkVisibility() &&
      (i.labels?.[0]?.innerText || '').replace(/\\*/g, '').trim() === label);
  document.querySelectorAll('[' + attr + ']').forEach(e => e.removeAttribute(attr));
  inputs.forEach((inp, n) => {
    let r = inp;
    while (r.parentElement && [...r.parentElement.querySelectorAll('input')].filter(i => inputs.includes(i)).length === 1)
      r = r.parentElement;
    r.setAttribute(attr, n);
  });
  return inputs.length;
}"""
GOOGLE_GROUPS_JS = """() => {
  const seen = {}, out = [];
  document.querySelectorAll('[data-jbq]').forEach(e => e.removeAttribute('data-jbq'));
  for (const i of document.querySelectorAll('input[type=radio], input[type=checkbox]')) {
    if (!i.checkVisibility()) continue;
    const key = i.type + ':' + i.name;
    if (!(key in seen)) { seen[key] = out.length; out.push({type: i.type, name: i.name, options: [], checked: []}); }
    const g = out[seen[key]];
    const lab = (i.labels?.[0]?.innerText || i.closest('li')?.innerText || '').trim().split('\\n')[0];
    i.setAttribute('data-jbq', seen[key] + '-' + g.options.length);
    g.options.push(lab); g.checked.push(i.checked);
  }
  for (const g of out) {
    const first = document.querySelector('[data-jbq="' + out.indexOf(g) + '-0"]');
    let c = first;
    const mine = i2 => i2.type === g.type && i2.name === g.name;
    for (let k = 0; k < 12 && c.parentElement; k++) {
      if ([...c.parentElement.querySelectorAll('input[type=radio], input[type=checkbox]')]
          .some(x => !mine(x) && x.checkVisibility())) break;
      c = c.parentElement;
      const t = (c.innerText || '').trim();
      if (t.split('\\n').filter(x => x.trim()).length > g.options.length + 0) {
        let q = t; for (const o of g.options) q = q.replace(o, '');
        if (q.replace(/\\s+/g, '').length > 3) { g.question = q.replace(/\\s+/g, ' ').trim().slice(0, 400); break; }
      }
    }
  }
  return out;
}"""


class Google:

    def __init__(self, page, jd, company, resume_pdf):
        self.p, self.jd, self.company, self.resume = page, jd, company, resume_pdf
        self.notes, self.open_q = [], []

    def select(self, combo, want):
        combo.scroll_into_view_if_needed()
        root = combo.locator("xpath=ancestor::*[.//*[@role='listbox']][1]")
        combo.click()
        self.p.wait_for_timeout(500)
        opts = [o.strip() for o in root.locator("[role=option]:visible").all_inner_texts()]
        choice = want(opts) if callable(want) else (
            next((o for o in opts if o.lower() == want.lower()), None) or
            next((o for o in opts if o and want.lower() in o.lower()), None))
        if choice:
            root.locator("[role=option]:visible").filter(
                has_text=re.compile(r"^\s*" + re.escape(choice) + r"\s*$")).first.click()
            self.p.wait_for_timeout(400)
            offer(self, choice, opts)
        if combo.get_attribute("aria-expanded") == "true":
            self.p.keyboard.press("Escape")
        got = combo.inner_text()
        return choice if choice and choice in got else None

    def put(self, inp, value):
        value = str(value)
        if inp.input_value().strip() == value:
            return
        inp.scroll_into_view_if_needed()
        inp.click()
        inp.press("Control+A")
        inp.press_sequentially(value, delay=20)
        if inp.get_attribute("role") == "combobox":
            self.p.wait_for_timeout(600)
            self.p.keyboard.press("Escape")
        inp.evaluate("e => e.blur()")
        if inp.input_value().strip() != value:
            self.open_q.append(f"field shows {inp.input_value()!r}, wanted {value!r}")

    def tick(self, box, on=True):
        if box.is_checked() != on:
            box.evaluate("e => e.click()")
            self.p.wait_for_timeout(200)
        return box.is_checked() == on

    def groups(self):
        return self.p.evaluate(GOOGLE_GROUPS_JS)

    def choose(self, gi, g, option):
        k = next((n for n, o in enumerate(g["options"]) if o == option), None)
        if k is None:
            return False
        offer(self, option, g["options"])
        if not g["checked"][k]:
            self.p.locator(f"[data-jbq='{gi}-{k}']").evaluate("e => e.click()")
            self.p.wait_for_timeout(200)
        return True

    def errors(self):
        return [e.strip()[:120] for e in self.p.locator("[aria-invalid=true]:visible, [role=alert]:visible, "
                                                        "[class*=error]:visible").all_inner_texts() if e.strip()][:4]

    def step(self):
        m = re.search(r"/apply/[^/]+/([a-z]+)", self.p.url)
        return m.group(1) if m else ""

    def go_step(self, label):
        self.p.locator(f"button:visible:has-text('{label}')").first.click(timeout=10000)
        self.p.wait_for_timeout(3500)

    def next(self, label="Next"):
        before = self.p.url
        btn = self.p.locator(f"button[aria-label='{label}']:visible")
        (btn if btn.count() else self.p.locator(f"button:visible:text-is('{label}')")).last.click(timeout=10000)
        for _ in range(30):
            self.p.wait_for_timeout(500)
            if self.p.url != before:
                self.p.wait_for_timeout(3000)
                return True
        self.open_q.append(f"{self.step()}: '{label}' not accepted - " + " || ".join(self.errors()))
        return False

    def profile(self):
        p = self.p
        edit = p.locator("button[aria-label='Edit profile']:visible")
        if edit.count():
            edit.first.click()
            p.wait_for_timeout(3000)
        self.upload_resume()
        for gi, g in enumerate(self.groups()):
            q = g.get("question", "")
            want = (("Yes" if HAS_BACHELOR or HAS_MASTER else "No") if re.search(r"attended university", q, re.I) else
                    ("Yes" if any(re.search(r"google|alphabet|waymo|deepmind|verily|youtube", e.get("company", ""), re.I)
                                  for e in P.get("experience", [])) else "No") if re.search(r"alphabet company", q, re.I) else
                    ("No" if P.get("experience") else "Yes") if re.search(r"first job", q, re.I) else None)
            if want and g["type"] == "radio" and not self.choose(gi, g, want):
                self.open_q.append(f"profile: {q[:60]} - no '{want}' option")
        self.education()
        self.work()
        cl = p.get_by_label("Cover letter", exact=False).locator("visible=true")
        if cl.count():
            if cl.first.get_attribute("aria-required") == "true" or cl.first.get_attribute("required") is not None:
                if not cl.first.input_value().strip():
                    self.open_q.append("profile: a cover letter is REQUIRED - draft one (free_text.cover_letter)")
            elif cl.first.input_value().strip():
                cl.first.fill("")
                cl.first.evaluate("e => { e.dispatchEvent(new Event('input', {bubbles: true})); e.blur(); }")
                self.notes.append("optional cover letter cleared (only when required)")
        for box in p.locator("input[type=checkbox]:visible").all():
            lab = box.evaluate("e => (e.labels?.[0]?.innerText || e.closest('div')?.innerText || '')")
            if re.search(r"privacy policy|certify that.*true and accurate", lab, re.I | re.S):
                self.tick(box)
        if self.open_q:
            return False
        return self.next("Submit profile & continue")

    def upload_resume(self):
        p = self.p
        rm = p.locator("button[aria-label='Remove resume']:visible")
        if rm.count():
            rm.first.click()
            p.wait_for_timeout(1500)
        lab = p.locator("label:visible:has-text('Fill out your application with your')")
        if lab.count():
            self.tick(p.locator("#" + lab.first.get_attribute("for")), on=False)
        p.locator("button[aria-label^='Upload r']:visible").first.click()
        item = p.locator("[role=menuitem]:visible:has-text('My computer')").first
        with p.expect_file_chooser(timeout=15000) as fc:
            item.click()
        fc.value.set_files(self.resume)
        for _ in range(40):
            p.wait_for_timeout(500)
            if p.locator("button[aria-label='Remove resume']:visible").count():
                self.notes.append("resume -> " + self.resume)
                return
        self.open_q.append("resume: upload not shown on the profile")

    def education(self):
        p = self.p
        n = p.evaluate(GOOGLE_ROWS_JS, ["School name", "data-jbedu"])
        data = P["education_on_forms"]
        if n != len(data):
            self.open_q.append(f"profile: {n} degree rows, data has {len(data)} - fix by hand")
            return
        for i in range(n):
            row = p.locator(f"[data-jbedu='{i}']")
            school = row.get_by_label("School name", exact=False).first.input_value()
            d = next((d for d in data if re.search(d["degree_match"], row.inner_text(), re.I)), None)
            if not d:
                self.open_q.append(f"profile: degree row {i + 1} ({school}) matches no degree in data")
                continue
            kind = next((g for rx, g in GOOGLE_DEGREE if re.search(rx, d["degree"])), None)
            deg = row.get_by_role("combobox", name=re.compile(r"^Degree(?! Status)"))
            if kind and kind not in deg.first.inner_text() and not self.select(deg.first, kind):
                self.open_q.append(f"profile: degree {kind} not set")
            st = row.get_by_role("combobox", name=re.compile(r"^Degree Status"))
            if "Graduated" not in st.first.inner_text():
                self.select(st.first, "Graduated")
            major = row.get_by_label("Major / area of study", exact=False).first
            if major.input_value().strip() not in d["field_queries"]:
                self.put(major, d["field_queries"][0])
            key = {w for w in re.findall(r"[a-z]{4,}", d["school"].lower())
                   if w not in {"university", "college", "school", "institute", "academy"}}
            if not re.search(re.escape(d["school"]).replace(r"\-", "[- ]") + "|" + re.escape(d.get("school_fallback") or "#"),
                             school, re.I) and not (len(key) >= 2 and all(w in school.lower() for w in key)):
                self.open_q.append(f"profile: school {school!r} vs data {d['school']!r}")

    def work(self):
        import calendar
        p = self.p
        data = P["experience"]
        n = p.evaluate(GOOGLE_ROWS_JS, ["Employer name", "data-jbjob"])
        while n < len(data):
            p.locator("button:visible:has-text('ADD ANOTHER JOB')").first.click()
            p.wait_for_timeout(1200)
            m = p.evaluate(GOOGLE_ROWS_JS, ["Employer name", "data-jbjob"])
            if m == n:
                self.open_q.append("profile: 'Add another job' did nothing")
                return
            n = m
        while n > len(data):
            p.locator(f"[data-jbjob='{n - 1}'] button:visible:has-text('REMOVE THIS JOB')").first.click()
            p.wait_for_timeout(1200)
            n = p.evaluate(GOOGLE_ROWS_JS, ["Employer name", "data-jbjob"])
        for i, e in enumerate(data):
            row = p.locator(f"[data-jbjob='{i}']")
            self.put(row.get_by_label("Employer name", exact=False).first, e["company"])
            self.put(row.get_by_label("Job title", exact=False).first, e["title"])
            cur = row.locator("input[type=checkbox]").first
            self.tick(cur, on=is_current(e))
            months = row.get_by_role("combobox", name=re.compile(r"^Month"))
            years = row.locator("input[type=number]")
            spans = [(e["start_month"], e["start_year"])] + ([] if is_current(e) else [(e["end_month"], e["end_year"])])
            for k, (mo, yr) in enumerate(spans):
                name = calendar.month_name[mo]
                if name not in months.nth(k).inner_text() and not self.select(months.nth(k), name):
                    self.open_q.append(f"profile: role {i + 1} month {name} not set")
                self.put(years.nth(k), yr)
            city, state, country = split_location(e["location"])
            for label, want in [("^Country", country)] + ([("^State", state)] if state else []):
                c = row.get_by_role("combobox", name=re.compile(label)).first
                if want not in c.inner_text() and not self.select(c, want):
                    self.open_q.append(f"profile: role {i + 1} {label[1:]} not set")
            self.put(row.get_by_label("City", exact=False).first, city)
        self.notes.append(f"work history: {len(data)} roles from applicant.json")

    def role(self):
        p = self.p
        combo = p.get_by_role("combobox", name=re.compile(r"^Preferred Location"))
        if combo.count():
            city = P["location"]["city"]

            def pick(opts):
                opts = [o for o in opts if o]
                return (next((o for o in opts if city.lower() in o.lower()), None) or
                        next((o for o in opts if LOCAL.search(o)), None) or
                        next((o for o in opts if self.worth_relocating(o)), None))
            got = self.select(combo.first, pick)
            if got:
                self.notes.append(f"preferred location: {got}")
            else:
                self.open_q.append("preferred location: none in the home area / worth relocating for")
        for gi, g in enumerate(self.groups()):
            q = (g.get("question") or "").strip()
            if g["type"] == "checkbox":
                if re.search(r"additional location", q, re.I):
                    for k, o in enumerate(g["options"]):
                        if LOCAL.search(o) or self.worth_relocating(o):
                            self.tick(p.locator(f"[data-jbq='{gi}-{k}']"))
                            self.notes.append(f"also open to: {o}")
                continue
            want = self.role_answer(g["name"], q, g["options"])
            label = (g["name"] if len(g["name"]) > 20 else q)[:70]
            if want and self.choose(gi, g, want):
                self.notes.append(f"{label} -> {want}")
            elif any(g["checked"]):
                self.notes.append(f"{label} -> kept the draft's answer "
                                  f"{g['options'][g['checked'].index(True)]!r} (no rule / model answer)")
            else:
                self.open_q.append(f"role: {label}")
        if self.open_q:
            return False
        return self.next()

    def worth_relocating(self, place):
        return location_answer(f"Are you willing to relocate to {place}?", self.jd or "", where="") == "Yes"

    def role_answer(self, name, q, opts):
        if name == "WorkAuthSponsorQuestion":
            return SPONSOR
        if name == "WorkAuthEligibleQuestion":
            return AUTHORIZED
        if auth := work_auth(q):
            return auth
        text = name if len(name) > 20 else q
        if set(opts) >= {"Yes", "No"}:
            if re.search(r"ph\.?d|doctor", text, re.I):
                if HAS_DOCTORATE:
                    return "Yes"
            elif re.search(r"master'?s degree", text, re.I) and HAS_MASTER or re.search(r"bachelor", text, re.I) and HAS_BACHELOR:
                return "Yes"
            m = re.match(r"\s*(\d+) years? of experience (in|with) (software development|software engineering|"
                         r"programming|coding|(one or more )?(general purpose )?programming languages?)", text, re.I)
            if m and int(m.group(1)) <= YEARS:
                return "Yes"
        ans = llm.answer(f"Do you meet this qualification? {text}", [o for o in opts if o], self.jd, "Google")
        return ans if ans != "Not sure" else None

    def vsi(self):
        kinds = [(r"gender|\bFemale\b", "gender"), (r"\brac(e|ial)\b|ethnic|\bWhite\b", "race"), (r"veteran", "veteran"),
                 (r"disabilit", "disability")]
        for gi, g in enumerate(self.groups()):
            q = (g.get("question") or "") + " " + " ".join(g["options"])
            kind = next((kd for rx, kd in kinds if re.search(rx, q, re.I)), None)
            pick = eeo_pick(kind, g["options"]) if kind else None
            k = g["options"].index(pick) if pick in g["options"] else None
            if k is None:
                if not any(g["checked"]):
                    self.open_q.append(f"self-id: {q[:80]}")
                continue
            box = self.p.locator(f"[data-jbq='{gi}-{k}']")
            if g["type"] == "checkbox":
                for j, on in enumerate(g["checked"]):
                    if on and j != k:
                        self.tick(self.p.locator(f"[data-jbq='{gi}-{j}']"), on=False)
                self.tick(box)
            elif not g["checked"][k]:
                box.evaluate("e => e.click()")
        if self.open_q:
            return False
        return self.next()

    def run(self, submit=True):
        p = self.p
        dismiss_cookies(p)
        if "/apply/" not in p.url:
            p.locator("#apply-action-button").first.click(timeout=20000)
            p.wait_for_timeout(6000)
        body = p.locator("body").inner_text()
        if GOOGLE_LIMIT.search(body):
            return "waiting: Google 30-day limit", None
        if "/apply/" not in p.url:
            raise RuntimeError(f"Google: Apply did not open the application form ({p.url[:100]})")
        if self.step() != "form":
            self.go_step("Careers profile")
        for _ in range(6):
            s = self.step()
            say(f"page: Google {s}")
            ok = {"form": self.profile, "role": self.role, "vsi": self.vsi}.get(s)
            if ok:
                if not ok():
                    break
                continue
            for box in p.locator("input[type=checkbox]:visible").all():
                lab = box.evaluate("e => (e.labels?.[0]?.innerText || e.closest('li, div')?.innerText || '')")
                if re.search(r"privacy policy", lab, re.I) and not self.tick(box):
                    self.open_q.append("review: privacy consent box would not tick")
            if self.open_q:
                break
            review = p.locator("body").inner_text()[:12000]
            btns = [b.strip() for b in p.locator("button:visible").all_inner_texts() if b.strip()]
            sub = next((b for b in btns if re.match(r"(submit|apply)\b", b, re.I) and len(b) < 40), None)
            self.notes.append(f"review step '{s}', submit button: {sub!r}")
            if not sub:
                self.open_q.append("review: no Submit / Apply button found")
                break
            if (doubt := second_read(self, submit)) or not submit:
                return "ready for review", review + (f"\n{doubt}" if doubt else "")
            p.locator("button:visible").filter(has_text=re.compile(r"^\s*" + re.escape(sub) + r"\s*$")).first.click()
            p.wait_for_timeout(8000)
            after = p.locator("body").inner_text()
            if "/dashboard" in p.url and re.search(r"Updated now\s*\n+\s*Submitted", after):
                return "submitted", review
            if CONFIRMED.search(after) or re.search(r"application (has been |was )?(sent|submitted)|thanks for applying", after, re.I):
                return "submitted", review
            return unconfirmed(p, self.company), review
        msg = "questions left for you: " + " || ".join(self.open_q)
        self.notes.append(msg)
        if UNATTENDED:
            raise NeedsUser(msg)
        say("STILL OPEN - " + msg)
        return "ready for review", "\n".join(self.notes)


NO_POSITION = re.compile(r"\bapplication for 0 positions?\b", re.I)
JOB_SEARCH_BOX = re.compile(r"^search\b|zip code or \W*remote|^keywords?$", re.I)


class Eightfold:
    RULES = [(r"veteran", eeo("veteran")), (r"transgender", eeo("transgender")), (r"disabilit", eeo("disability")),
             (r"contractor", rf"^{CONTRACTOR_HERE.lower()}\b"), (r"worked for|employed by", r"^no\b"),
             (AUTH_RX, rf"^{AUTHORIZED.lower()}\b"), (SPONSOR_RX, rf"^{SPONSOR.lower()}\b"),
             (r"how did you hear|application source", rf"^{re.escape(SOURCE_ANSWER.lower())}\b")]

    def __init__(self, page, jd, company, resume_pdf):
        self.p, self.jd, self.company, self.resume = page, jd, company, resume_pdf
        self.notes, self.open_q = [], []

    def label(self, e):
        return e.evaluate("""e => ((e.getAttribute('aria-labelledby') || '').split(' ')
            .map(i => document.getElementById(i)?.innerText || '').join(' ').trim()
            || e.labels?.[0]?.innerText || e.getAttribute('aria-label') || '').trim()""")

    def text(self, e, value):
        if e.input_value().strip() != value:
            e.click()
            e.press("Control+A")
            e.press_sequentially(value, delay=15)
            if e.get_attribute("aria-autocomplete") is None and "city" not in (self.label(e) or "").lower():
                e.evaluate("e => e.blur()")

    def combo(self, e, want, typed=None):
        e.scroll_into_view_if_needed()
        e.click()
        if typed:
            e.evaluate("""e => { Object.getOwnPropertyDescriptor(HTMLInputElement.prototype, 'value').set.call(e, '');
                e.dispatchEvent(new Event('input', {bubbles: true})); }""")
            e.press_sequentially(typed, delay=30)
        self.p.wait_for_timeout(800)
        opts = [o.strip() for o in self.p.locator("[role=option]:visible").all_inner_texts()]
        choice = want(opts) if callable(want) else min((o for o in opts if re.search(want, o, re.I)), key=len, default=None)
        if choice in opts:
            self.p.locator("[role=option]:visible").nth(opts.index(choice)).click()
            self.p.wait_for_timeout(400)
            offer(self, choice, opts)
        else:
            self.p.keyboard.press("Escape")
        return choice

    def signin(self):
        p = self.p
        form = lambda: p.locator("input[type=file]").count() > 0
        for _ in range(10):
            if form():
                return True
            if p.get_by_text(re.compile(r"sign in using google", re.I)).count():
                break
            p.wait_for_timeout(1000)
        else:
            return form()
        me, ctx = P["identity"]["email"], p.context
        target = p.url
        before = set(ctx.pages)
        try:
            p.get_by_text(re.compile(r"^\s*sign in using google\s*$", re.I)).first.click(timeout=8000)
        except Exception:
            pass
        stop = None
        for _ in range(45):
            p.wait_for_timeout(1000)
            if not p.is_closed() and form():
                self.notes.append("signed in with Google")
                return True
            if not p.is_closed() and "accounts.google.com" not in p.url and "/careers/apply" not in p.url and \
                    re.search(r"\bHi \w+|sign out|my profile", p.locator("body").inner_text(), re.I):
                p.goto(target, wait_until="domcontentloaded")
                p.wait_for_timeout(4000)
                continue
            g = next((q for q in [p, *(set(ctx.pages) - before)] if not q.is_closed() and "accounts.google.com" in q.url), None)
            if not g:
                continue
            try:
                if g.locator("input[type=password]:visible").count():
                    stop = "Google asks for the password"
                    break
                tile = g.locator(f"[data-identifier='{me}']:visible")
                if tile.count():
                    tile.first.click()
                    continue
                body = g.locator("body").inner_text()
                if re.search(r"will share|wants (additional )?access|\bAllow\b|create (an |your )?account", body, re.I):
                    stop = "Google asks for first-time consent"
                    break
                if re.search(r"signing back in", body, re.I):
                    g.get_by_role("button", name=re.compile(r"^continue$", re.I)).first.click()
            except Exception:
                continue
        msg = f"sign-in: {self.company}'s careers site needs a sign-in ({stop or 'no Google sign-in'}) - double-click " \
              f"'JobBot pending' and sign in (prefer 'Sign in using Google'); the script fills and submits"
        if UNATTENDED:
            raise NeedsUser(msg)
        say("waiting for you: " + msg)
        for _ in range(600):
            if not p.is_closed() and form():
                return True
            time.sleep(1)
        return False

    def answer_combo(self, e, lab):
        if re.search(r"^(select )?country( code)?$", lab, re.I) and (HOME != "US" or PHONE_REGION != "US"):
            code = re.search(r"code", lab, re.I)
            name = PHONE_NAME if code else HOME_NAME
            if countries.pick_country([e.input_value()], PHONE_REGION if code else HOME):
                return
            got = self.combo(e, (phone_pick if code else home_pick)(None), typed=name)
        elif re.search(r"^(select )?country( code)?$", lab, re.I):
            if re.search(r"united states", e.input_value(), re.I):
                return
            got = self.combo(e, r"united states", typed="United States")
        elif re.search(r"\bdate\b", lab, re.I) and e.input_value().strip():
            return
        else:
            rule = next((want for rx, want in self.RULES if re.search(rx, lab, re.I)), None)
            got = self.combo(e, rule) if rule else None
            if not got:
                got = self.combo(e, lambda opts: llm.answer(lab, [o for o in opts if o], self.jd, self.company))
        if got:
            self.notes.append(f"{lab[:60]} -> {got}")
        elif e.get_attribute("aria-required") == "true":
            self.open_q.append(f"{lab[:80]}")

    def run(self, submit=True):
        p, me = self.p, P["identity"]
        dismiss_cookies(p)
        m = re.search(r"/careers/job/(\d+)", p.url) or \
            (re.search(r"[?&]pid=(\d+)", p.url) if "/careers/apply" not in p.url else None)
        if m:
            u = urlparse(p.url)
            dom = re.search(r"\b(?:domain|microsite)=([^&]+)", p.url)
            dom = dom.group(1) if dom else u.netloc.split(".", 1)[-1]
            p.goto(f"{u.scheme}://{u.netloc}/careers/apply?domain={dom}&microsite={dom}&pid={m.group(1)}",
                   wait_until="domcontentloaded")
            p.wait_for_timeout(5000)
        if not self.signin():
            return "sign-in not completed", None
        if "/careers/apply" not in p.url or NO_POSITION.search(p.title() + " " + p.locator("body").inner_text(timeout=5000)[:3000]):
            raise RuntimeError(f"{self.company}'s apply page opened without the job: {p.url[:120]}")
        p.locator("input[type=file]").first.set_input_files(self.resume)
        self.notes.append("resume -> " + self.resume)
        if done := privacy_dialog(p):
            self.notes.append(done)
        p.wait_for_timeout(6000)
        if not resume_shown(p, self.resume):
            self.open_q.append("resume: uploaded file not shown on the form")
        done = set()
        for _ in range(4):
            todo = [(e, self.label(e)) for e in p.locator("input[role=combobox]:visible, input[placeholder='Select']:visible, "
                                                          "input[placeholder='select']:visible").all()]
            todo = [(e, lab) for e, lab in todo if lab and lab not in done and not JOB_SEARCH_BOX.search(lab)]
            if not todo:
                break
            e, lab = todo[0]
            done.add(lab)
            self.answer_combo(e, lab)
            for e, lab in todo[1:]:
                if self.label(e) == lab:
                    done.add(lab)
                    self.answer_combo(e, lab)

        loc = P["location"]
        fixed = {"email": me["email"], "first name": me["first_name"], "last name": me["last_name"],
                 "phone number": me["phone_digits"], "phone": me["phone_digits"], "city": loc["city"],
                 "address 1": loc.get("street_address"), "address line 1": loc.get("street_address"),
                 "street address": loc.get("street_address"), "zip/post code": loc.get("zip"),
                 "zip/postal code": loc.get("zip"), "zip code": loc.get("zip"), "postal code": loc.get("zip"), "zip": loc.get("zip")}
        fixed = {k: v for k, v in fixed.items() if v}
        for e in p.locator("input:not([type]):visible, input[type=text]:visible, input[type=email]:visible, "
                           "input[type=tel]:visible").all():
            if e.get_attribute("role") == "combobox":
                continue
            lab = (self.label(e) or e.get_attribute("placeholder") or "").lower().strip(" *")
            if lab in fixed:
                self.text(e, fixed[lab])
            elif re.search(r"signature", e.get_attribute("id") or "", re.I) or re.fullmatch(r"i accept|(electronic |e-)?"
                                                                                            r"signature|full (legal )?name", lab):
                if not e.input_value().strip():
                    self.text(e, f"{me['first_name']} {me['last_name']}")
                    self.notes.append("e-signature -> full name")
            elif re.search(r"other source|source not listed|(specify|enter) (the |your )?source", lab) and \
                    not e.input_value().strip():
                self.text(e, SOURCE_ANSWER)
                self.notes.append(f"{lab[:50]} -> {SOURCE_ANSWER}")
                if lab == "city":
                    p.wait_for_timeout(1500)
                    hit = p.locator("[role=option]:visible").filter(has_text=re.compile(re.escape(P["location"]["city"]), re.I))
                    if hit.count():
                        hit.first.click()
                        p.wait_for_timeout(400)
                    if not e.input_value().strip():
                        self.open_q.append(f"City: the {P['location']['city']} suggestion did not stick")
            elif re.search(r"linkedin", lab):
                self.text(e, me["linkedin"])
        orient = p.locator("input[type=checkbox][name*=exualOrientation]:visible")
        groups = [("gender", "ender"), ("race", "ace")] + ([("orientation", "exualOrientation")] if orient.count() and
                                                          orient.first.get_attribute("aria-required") == "true" else [])
        wants = []
        for kind, name in groups:
            labs = [(self.label(b) or "").strip() for b in p.locator(f"input[type=checkbox][name*={name}]:visible").all()]
            pick = eeo_pick(kind, labs)
            if pick:
                wants.append("^" + re.escape(pick) + "$")
            elif labs:
                self.open_q.append(f"self-ID {kind}: no option matches applicant.json")
        for want in wants:
            box = [b for b in p.locator("input[type=checkbox]:visible").all() if re.search(want, self.label(b) or "")]
            if not box:
                self.open_q.append(f"self-ID: no '{want.strip('^$')}' option")
                continue
            if not box[0].is_checked():
                try:
                    box[0].check(timeout=5000)
                except Exception:
                    box[0].evaluate("e => (e.labels?.[0] || e).click()")
            if not box[0].is_checked():
                self.open_q.append(f"self-ID: '{want.strip('^$')}' would not tick")
        review = p.locator("body").inner_text()[:12000]
        if self.open_q:
            msg = "questions left for you: " + " || ".join(self.open_q)
            self.notes.append(msg)
            if UNATTENDED:
                raise NeedsUser(msg)
            say("STILL OPEN - " + msg)
            return "ready for review", review
        if (doubt := second_read(self, submit)) or not submit:
            return "ready for review", review + (f"\n{doubt}" if doubt else "")
        p.get_by_role("button", name=re.compile(r"^\s*submit application\s*$", re.I)).first.click()
        p.wait_for_timeout(8000)
        after = p.locator("body").inner_text()
        if CONFIRMED.search(after) or re.search(r"thank you", after, re.I):
            return "submitted", review
        errs = [x.strip()[:100] for x in p.locator("[role=alert]:visible, [class*=error]:visible").all_inner_texts() if x.strip()]
        if errs:
            self.notes.append("form errors: " + " || ".join(errs[:4]))
        return unconfirmed(p, self.company), review


class Lever:

    def __init__(self, page, jd, company, resume_pdf):
        self.p, self.jd, self.company, self.resume = page, jd, company, resume_pdf
        self.notes, self.open_q = [], []

    def text(self, loc, value):
        if loc.count() and loc.first.input_value().strip() != value:
            loc.first.fill(value)

    def question(self, inp):
        return inp.evaluate("""e => { const c = e.closest('.application-question') || e.closest('li');
            const l = c && c.querySelector('.application-label, .text');
            return ((l ? l.innerText : '') || (c ? c.innerText : '')).replace(/\\u2731|\\*/g, '').replace(/\\s+/g, ' ').trim(); }""")

    def cards(self):
        p, done = self.p, set()
        for inp in p.locator("[name^='cards[']").all():
            name = inp.get_attribute("name")
            if name in done or not (inp.is_visible() or inp.get_attribute("type") in ("radio", "checkbox")):
                continue
            done.add(name)
            q = self.question(inp)
            kind = inp.evaluate("e => e.tagName === 'SELECT' ? 'select' : (e.type || 'text')")
            if kind in ("radio", "checkbox"):
                group = p.locator(f"[name='{name}']")
                opts = [g.evaluate("e => (e.closest('label')?.innerText || e.value || '').trim()") for g in group.all()]
                if any(g.is_checked() for g in group.all()):
                    continue
                want = work_auth(q) or llm.answer(q, [o for o in opts if o], self.jd, self.company)
                k = next((i for i, o in enumerate(opts) if want and o.strip().lower() == want.strip().lower()), None)
                if k is None:
                    self.open_q.append(q[:90])
                    continue
                group.nth(k).check(force=True)
                self.notes.append(f"{q[:60]} -> {opts[k]}")
            elif kind == "select":
                opts = [o.strip() for o in inp.evaluate("e => [...e.options].map(o => o.text)") if o.strip()]
                want = llm.answer(q, opts, self.jd, self.company)
                if want:
                    inp.select_option(label=want)
                    self.notes.append(f"{q[:60]} -> {want}")
                elif inp.get_attribute("required") is not None:
                    self.open_q.append(q[:90])
            else:
                if inp.input_value().strip():
                    continue
                if SALARY.search(q):
                    ans = salary_answer(q)
                else:
                    loc_ans = location_answer(q, self.jd)
                    ans = str(loc_ans) if loc_ans else llm.answer(q, None, self.jd, self.company)
                if ans:
                    inp.fill(ans)
                    self.notes.append(f"{q[:60]} -> {ans[:60]}")
                elif inp.get_attribute("required") is not None:
                    self.open_q.append(q[:90])

    def eeo(self):
        for sel in self.p.locator("select[name^='eeo[']").all():
            if not sel.is_visible():
                continue
            name = sel.get_attribute("name")
            opts = [o.strip() for o in sel.evaluate("e => [...e.options].map(o => o.text)") if o.strip()]
            pick = next((fn(opts) for rx, fn in EEO if re.search(rx, name, re.I)), None)
            if pick:
                sel.select_option(label=pick)
                self.notes.append(f"{name} -> {pick}")

    def location(self):
        p, loc = self.p, self.p.locator("input[name=location]")
        if not loc.count() or loc.first.input_value().strip():
            return
        city = place_text(f"{P['location']['city']}, {P['location']['state_code']}")
        loc.first.click()
        loc.first.press_sequentially(city, delay=40)
        p.wait_for_timeout(2500)
        sel = ".dropdown-location .dropdown-results div, .location-dropdown li, [class*=dropdown] [class*=result]"
        if HOME == "US":
            sug = p.locator(sel).filter(has_text=re.compile(P["location"]["city"], re.I))
        else:
            texts = [t.strip() for t in p.locator(sel).all_inner_texts()]
            got = place_pick(texts)
            sug = p.locator(sel).nth(texts.index(got)) if got in texts else p.locator(sel).filter(has_text=re.compile("(?!x)x"))
        if sug.count():
            sug.first.click()
            p.wait_for_timeout(500)
        if not loc.first.input_value().strip():
            self.open_q.append("Current location: no suggestion taken")

    def captcha_open(self):
        return any(f.is_visible() for f in self.p.locator("iframe[src*='hcaptcha'][src*='challenge'], iframe[title*='hCaptcha challenge' i]").all())

    def run(self, submit=True):
        p, me = self.p, P["identity"]
        dismiss_cookies(p)
        if not re.search(r"/apply\b", p.url):
            p.goto(p.url.split("?")[0].rstrip("/") + "/apply", wait_until="domcontentloaded")
            p.wait_for_timeout(3000)
        p.locator("input[type=file][name=resume]").set_input_files(self.resume)
        self.notes.append("resume -> " + self.resume)
        if not resume_shown(p, self.resume, wait_s=20, also=r"success|uploaded"):
            self.open_q.append("resume: uploaded file not shown on the form")
        self.text(p.locator("input[name=name]"), f"{me['first_name']} {me['last_name']}")
        self.text(p.locator("input[name=email]"), me["email"])
        self.text(p.locator("input[name=phone]"), me["phone"])
        self.location()
        org = p.locator("input[name=org]")
        if org.count() and org.first.input_value().strip() != current_company():
            org.first.fill(current_company())
        self.text(p.locator("input[name='urls[LinkedIn]']"), me["linkedin"])
        self.cards()
        self.eeo()
        for box in p.locator("input[type=checkbox]:visible").all():
            lab = box.evaluate("e => e.closest('label, li, div')?.innerText || ''")
            if re.search(r"privacy|consent|agree", lab, re.I) and not re.search(r"sms|text message|whatsapp", lab, re.I):
                box.check(force=True)
        review = p.locator("body").inner_text()[:12000]
        if self.open_q:
            msg = "questions left for you: " + " || ".join(self.open_q)
            self.notes.append(msg)
            if UNATTENDED:
                raise NeedsUser(msg)
            say("STILL OPEN - " + msg)
            return "ready for review", review
        if (doubt := second_read(self, submit)) or not submit:
            return "ready for review", review + (f"\n{doubt}" if doubt else "")
        p.locator("#btn-submit, button:has-text('Submit application')").first.click()
        for i in range(600 if not UNATTENDED else 30):
            p.wait_for_timeout(1000)
            body = p.locator("body").inner_text()
            if CONFIRMED.search(body) or re.search(r"application submitted|thanks for applying", body, re.I) or "/thanks" in p.url:
                return "submitted", review
            if self.captcha_open() or i >= 20:
                if UNATTENDED:
                    raise NeedsUser("Lever's bot check held Submit - double-click 'JobBot pending' and press SUBMIT "
                                     "APPLICATION yourself (solve the CAPTCHA if one shows); the form is filled")
                if i == 20 or i % 60 == 0:
                    say("waiting for you: press SUBMIT APPLICATION in the browser (and solve a CAPTCHA if shown)")
        errs = [e.strip()[:100] for e in p.locator(".error:visible, [class*=error]:visible").all_inner_texts() if e.strip()]
        if errs:
            self.notes.append("form errors: " + " || ".join(errs[:4]))
        return unconfirmed(p, self.company), review


ADAPTERS = {"workday": Workday, "greenhouse": Greenhouse, "ashby": Ashby, "phenom": Phenom, "oracle": Oracle, "rippling": Rippling, "gem": Gem, "jobvite": Jobvite, "icims": ICIMS, "google": Google, "eightfold": Eightfold, "lever": Lever}


PLUGIN_DIR = HERE / "adapters"
PLUGINS, PLUGIN_ERRORS = {}, []
_API_NAMES = ("P", "ELIG", "STANDING", "SI", "START_DATE", "EARLIEST_START", "AUTHORIZED", "SPONSOR", "OVER_18", "RELOCATE",
              "TRAVEL", "CLEARANCE", "EMPLOYED", "YEARS", "GOV", "TIME_ZONE", "UNATTENDED", "REFERRAL", "eeo_pick", "eeo",
              "eeo_list", "location_answer", "travel_answer", "salary_answer", "years_option", "current_company",
              "is_current", "former_employer", "split_location", "degree_level", "degree_kind", "when_required", "yes_no",
              "Workday", "Greenhouse", "SOURCE_Q", "resume_shown", "unconfirmed", "CONFIRMED", "trim_history",
              "dismiss_cookies", "check_closed", "say", "NeedsUser", "AlreadyApplied", "JobClosed", "llm")


RISKY_PLUGIN = re.compile(r"\b(?:import|from)\s+(?:subprocess|socket|ctypes|urllib|requests|httpx|http|smtplib|ftplib|winreg|"
                          r"shutil|vault|config|pickle|marshal)\b|\bos\.(?:system|popen|remove|unlink|rmdir|startfile|exec)|"
                          r"\b(?:eval|exec|compile|__import__)\s*\(|importlib|getattr\(\s*__builtins__|rmtree")


def _plugin_modules():
    import importlib.util
    import zipfile
    import zipimport
    out = []
    for f in sorted(PLUGIN_DIR.glob("*")) if PLUGIN_DIR.is_dir() else []:
        if f.name.startswith(("_", ".")) or f.suffix.lower() not in (".py", ".zip"):
            continue
        try:
            src = f.read_text(encoding="utf-8", errors="replace") if f.suffix.lower() == ".py" else \
                "\n".join(zipfile.ZipFile(f).read(n).decode("utf-8", "replace") for n in zipfile.ZipFile(f).namelist() if n.endswith(".py"))
            bad = RISKY_PLUGIN.search(src)
            if bad:
                raise PermissionError(f"uses {bad.group(0).strip()!r} - an adapter only fills web forms; not loaded "
                                      f"(ask Claude Code to review it, and install adapters only from whoever gave you the kit)")
            if f.suffix.lower() == ".py":
                spec = importlib.util.spec_from_file_location(f"jobbot_plugin_{f.stem}", f)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                out.append((f.name, mod))
            else:
                zi = zipimport.zipimporter(str(f))
                with zipfile.ZipFile(f) as z:
                    names = [n[:-3] for n in z.namelist() if n.endswith(".py") and "/" not in n and not n.startswith("_")]
                for n in names:
                    spec = zi.find_spec(n)
                    mod = importlib.util.module_from_spec(spec)
                    spec.loader.exec_module(mod)
                    out.append((f"{f.name}:{n}.py", mod))
        except Exception as e:
            PLUGIN_ERRORS.append(f"{f.name}: {type(e).__name__}: {str(e)[:160]}")
    return out


def load_plugins():
    import jobbot_api
    global ATS_HREF
    jobbot_api.__dict__.update({k: globals()[k] for k in _API_NAMES if k in globals()})
    jobbot_api.NeedsUser = NeedsUser
    for label, mod in _plugin_modules():
        try:
            name, hosts = str(getattr(mod, "NAME", "")).strip().lower(), getattr(mod, "HOSTS", "")
            if getattr(mod, "API", None) != jobbot_api.API_VERSION:
                raise ValueError(f"API {getattr(mod, 'API', None)!r} - this JobBot runs plugin API {jobbot_api.API_VERSION}")
            if not re.fullmatch(r"[a-z][a-z0-9_-]{1,30}", name):
                raise ValueError(f"NAME {name!r} must be a short lowercase word")
            host_rx = re.compile(hosts, re.I)
            slug_rx = re.compile(mod.BOARD_SLUG, re.I) if getattr(mod, "BOARD_SLUG", None) else None
            cls = getattr(mod, "Adapter", None)
            if not (isinstance(cls, type) and callable(getattr(cls, "run", None))):
                raise ValueError("no class Adapter with a run(submit) method")
            ver = int(getattr(mod, "VERSION", 1))
            if name in PLUGINS and PLUGINS[name]["version"] >= ver:
                PLUGIN_ERRORS.append(f"{label}: {name} v{ver} ignored - {PLUGINS[name]['file']} has v{PLUGINS[name]['version']}")
                continue
            PLUGINS[name] = {"version": ver, "file": label, "hosts": host_rx, "slug": slug_rx, "builtin": name in ADAPTERS}
            ADAPTERS[name] = cls
        except Exception as e:
            PLUGIN_ERRORS.append(f"{label}: {type(e).__name__}: {str(e)[:160]}")
    if PLUGINS:
        ATS_HREF = re.compile(ATS_HREF.pattern + "|" + "|".join(f"(?:{p['hosts'].pattern})" for p in PLUGINS.values()), re.I)


def plugin_host(url):
    return next((n for n, p in PLUGINS.items() if p["hosts"].search(url or "")), None)


load_plugins()


def pending_signins():
    cutoff = dt.datetime.now() - dt.timedelta(hours=PENDING_HOURS)

    def fresh(r):
        try:
            return dt.datetime.fromisoformat(r.get("ts") or "") >= cutoff
        except ValueError:
            return (r.get("date") or "") >= cutoff.date().isoformat()
    latest = {}
    if LOG.exists():
        with LOG.open(encoding="utf-8") as f:
            for r in csv.DictReader(f):
                latest[r.get("url")] = r
    import sites
    own = lambda n: bool(sites.USERS_OWN.search(n or "")) and "your call" not in (n or "")
    return [r for r in latest.values() if r.get("url") and fresh(r) and (
            ((r.get("status") or "").startswith("needs you") and own(r.get("notes")))
            or (not config.AUTO_SUBMIT and (r.get("status") or "").startswith("ready for review")))]


def linkedin_signin():
    import socket
    import jobapply
    from playwright.sync_api import sync_playwright
    lock = socket.socket()
    try:
        lock.bind(("127.0.0.1", config.PORT_LOCK))
    except OSError:
        say("another JobBot run is using the browser - LinkedIn check skipped")
        return
    try:
        if not jobapply.port_open():
            jobapply.launch()
        with sync_playwright() as pw:
            ctx = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{jobapply.PORT}").contexts[0]
            has = lambda: any(c["name"] == "li_at" for c in ctx.cookies("https://www.linkedin.com"))
            flag = HERE / "runs" / "linkedin-signin-needed"
            if has():
                flag.unlink(missing_ok=True)
                say("LinkedIn: signed in")
                return
            p = ctx.new_page()
            p.goto("https://www.linkedin.com/login", wait_until="domcontentloaded")
            p.bring_to_front()
            if jobapply.linkedin_google_signin(ctx, p):
                flag.unlink(missing_ok=True)
                say("LinkedIn: was signed out, signed back in with Google")
                return
            if "/login" not in p.url:
                p.goto("https://www.linkedin.com/login", wait_until="domcontentloaded")
            say("LinkedIn is SIGNED OUT - sign in in the Chrome window that opened (let Chrome save the password); "
                "waiting up to 15 minutes")
            for _ in range(900):
                if has() and "/login" not in p.url and "checkpoint" not in p.url:
                    flag.unlink(missing_ok=True)
                    say("LinkedIn: signed in - the next daily run catches up")
                    break
                time.sleep(1)
            else:
                say("LinkedIn: still signed out after 15 minutes - run JobBot pending again")
    finally:
        jobapply.close_chrome()
        lock.close()


def run_pending(only=None):
    import subprocess
    linkedin_signin()
    jobs = pending_signins()
    if only:
        latest = {}
        if LOG.exists():
            with LOG.open(encoding="utf-8") as f:
                for r in csv.DictReader(f):
                    latest[r.get("url")] = r
        jobs = [latest[only]] if only in latest else []
    say(f"{len(jobs)} job(s) waiting on you (sign-in / code / CAPTCHA{'' if config.AUTO_SUBMIT else ' / review and submit'})")
    for i, r in enumerate(jobs, 1):
        if (r.get("status") or "").startswith("ready for review"):
            say(f"[{i}/{len(jobs)}] {r.get('company')} - {r.get('title')}: JobBot refills the form and stops before Submit - "
                f"check it in the Chrome window, press Submit yourself; JobBot records it when the confirmation shows")
        else:
            say(f"[{i}/{len(jobs)}] {r.get('company')} - {r.get('title')}: sign in or create the account in "
                f"the Chrome window that opens (prefer 'Sign in with Google'); the script does the rest")
        subprocess.run([sys.executable, __file__, r["url"], "--no-count-check"])
    say("all pending jobs done" if jobs else "nothing pending")


def main():
    args = sys.argv[1:]
    if args[:1] == ["--pending"]:
        return run_pending(args[args.index("--only") + 1] if "--only" in args else None)
    if not args:
        sys.exit("usage: apply.py <job-url> [--resume CATEGORY] [--no-submit] [--no-count-check] [--force] "
                 "[--unattended] [--recruiter] | --pending [--only URL]")
    url = args[0]
    resume_cat = args[args.index("--resume") + 1] if "--resume" in args else None
    submit = "--no-submit" not in args and ("--submit" in args or not (REFERRAL and not UNATTENDED))
    if not config.AUTO_SUBMIT and "--submit" not in args:
        submit = False
    if PRACTICE:
        submit = False
    RUNS.mkdir(exist_ok=True)
    import socket
    lock = socket.socket()
    for waited in range(2400):
        try:
            lock.bind(("127.0.0.1", config.PORT_LOCK))
            break
        except OSError:
            if waited % 60 == 0:
                say("another JobBot run is using the browser - waiting for it to finish")
            time.sleep(1)
    else:
        sys.exit("another JobBot run held the browser for 40 minutes - giving up")
    if not jobapply.port_open():
        say(jobapply.launch())
    state = {}
    try:
        with sync_playwright() as pw:
            browser = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{jobapply.PORT}")
            ctx = browser.contexts[0]
            watch_outage(ctx)
            for old_pg in list(ctx.pages):
                if re.search(r"myworkdayjobs|myworkdaysite|linkedin\.com/jobs/view|greenhouse|lever\.co|ashbyhq", old_pg.url):
                    old_pg.close()
            page = ctx.new_page()
            page.goto(url, wait_until="domcontentloaded", timeout=60000)
            info = {"company": "", "title": "", "jd": ""}
            global JOB_WHERE
            JOB_WHERE = locations().get(url.split("?")[0], "")
            if "linkedin.com/jobs" in url:
                check_closed(page, wait=2500)
                page, info = linkedin_hop(ctx, page)
                a = info.get("applicants")
                say(f"LinkedIn: {info.get('company')} | {info.get('title')} | applicants={a}")
                state.update(company=info.get("company", ""), title=info.get("title", ""), applicants=a)
                why = excluded(info.get("company"), info.get("title"))
                if why and "--force" in args and why.startswith(FORCEABLE):
                    say(f"--force: overriding '{why}'")
                    why = None
                if why:
                    log_row(date=dt.date.today(), company=info["company"], title=info["title"], url=url,
                            applicants=a, status="skipped", notes=why)
                    return say("SKIP: " + why)
                prev = relisting_of(info.get("company"), info.get("title"), info.get("jd"))
                if prev:
                    log_row(date=dt.date.today(), company=info["company"], title=info["title"], url=url, applicants=a,
                            status="skipped", notes=f"re-listing of a job already applied to on {prev['date']} "
                                                    f"({prev['title'][:60]}; same description) - not applied again")
                    return say(f"SKIP: re-listing of a job already applied to on {prev['date']}")
                nofte = fte_check(info["company"], info["title"], info.get("jd"), info.get("head"))
                if nofte:
                    log_row(date=dt.date.today(), company=info["company"], title=info["title"], url=url,
                            applicants=a, status="skipped", notes=nofte)
                    return say("SKIP: " + nofte)
                low, ask = pay_check(info["company"], info["title"], info.get("jd"))
                if low:
                    log_row(date=dt.date.today(), company=info["company"], title=info["title"], url=url,
                            applicants=a, status="skipped", notes=low)
                    return say("SKIP: " + low)
                if ask:
                    state["action_url"] = url
                    raise NeedsUser(ask)
                if a is not None and a > MAX_APPLICANTS and "--no-count-check" not in args:
                    log_row(date=dt.date.today(), company=info["company"], title=info["title"], url=url,
                            applicants=a, status="skipped", notes=f"{a} applicants > {MAX_APPLICANTS}")
                    return say(f"SKIP: {a} applicants")
                if "--no-company-limit" not in args:
                    import jobseek
                    with LOG.open(encoding="utf-8") as fh:
                        left = jobseek.company_slots_left(info["company"], jobseek.active_by_company(None, list(csv.DictReader(fh))))
                    if left <= 0:
                        log_row(date=dt.date.today(), company=info["company"], title=info["title"], url=url,
                                applicants=a, status="waiting: company limit",
                                notes=f"{jobseek.max_active(info['company'])} active applications at {info['company']} in {jobseek.WINDOW_DAYS} days (or the employer's own cap)")
                        return say(f"WAIT: {info['company']} is at its limit ({jobseek.max_active(info['company'])} active applications or the employer's own cap)")
                if page is None:
                    state["action_url"] = url
                    raise NeedsUser(f"{info.get('skip', 'no Apply button')} - apply by hand on LinkedIn")
            if not info["jd"]:
                page.wait_for_timeout(2500)
                if detect_ats(page.url) == "google":
                    info["jd"] = page.evaluate(GOOGLE_JD_JS) or ""
                info["jd"] = info["jd"] or page.locator("body").inner_text()[:15000]
                for _ in range(5):
                    if JD_MARKERS.search(info["jd"]):
                        break
                    page.wait_for_timeout(1500)
                    info["jd"] = page.locator("body").inner_text()[:15000]
                info["title"] = re.sub(r"^(submit )?application for |\s+[—|-]\s+Google Careers$", "", page.title(), flags=re.I)
            dismiss_cookies(page)
            page = resolve_ats(ctx, page) or page
            check_closed(page, wait=1500)
            dismiss_cookies(page)
            ats = detect_ats(page.url)
            company = info["company"] or ("Google" if ats == "google" else "Netflix" if "netflix" in page.url else
                                          url_company(page.url))
            try:
                here = page.locator("body").inner_text(timeout=5000)[:20000]
            except Exception:
                here = ""
            pay = pay_facts((info["jd"] or "") + "\n" + here)
            note_pay(url, (info["jd"] or "") + "\n" + here)
            state.update(company=company, title=info["title"], ats=detect_ats(page.url) or "",
                     summary=(f"PAY: {pay}\n" if pay else "") + short_jd(info["jd"]), action_url=page.url)
            low = pay_below_floor(here)
            if low:
                note_low_pay(company, info["title"], low)
                log_row(date=dt.date.today(), company=company, title=info["title"], url=url, ats=state["ats"],
                        applicants=state.get("applicants", ""), status="skipped", notes=low, summary=state["summary"])
                return say("SKIP: " + low)
            if not info["jd"]:
                page.wait_for_timeout(2500)
                info["jd"] = page.locator("body").inner_text()[:15000]
                info["title"] = page.title()
            if ats == "google":
                import referrals
                used = referrals.google_applications()
                if len(used) >= referrals.GOOGLE_MAX:
                    nxt = used[0] + dt.timedelta(days=referrals.GOOGLE_DAYS)
                    log_row(date=dt.date.today(), company=company, title=info["title"], url=url, ats=ats,
                            applicants=state.get("applicants", ""), status="waiting: Google 30-day limit",
                            notes=f"Google allows {referrals.GOOGLE_MAX} applications per {referrals.GOOGLE_DAYS} days; next slot {nxt}",
                            action_url=page.url)
                    return say(f"WAIT: Google 30-day window full - next slot {nxt}")
            if ats and ats not in ADAPTERS:
                raise NoAdapter(f"{ats} - no adapter yet")
            if ats not in ADAPTERS:
                state["ats"] = urlparse(page.url).netloc
                if down := site_down(page):
                    raise SiteDown(down)
                raise NoAdapter(f"{urlparse(page.url).netloc} - unsupported site")
            if (bad := sites.is_broken(page.url)) and "--force" not in args:
                raise SiteBroken(f"{sites.host(page.url)} ({bad.get('reason', '')[:120]})")
            if PRACTICE and ats in PRACTICE_SIGNIN:
                log_row(date=dt.date.today(), company=company, title=info.get("title", ""), url=url, ats=ats,
                        status="skipped", notes=f"practice: {ats} asks for an account or an emailed code before its form")
                return say(f"PRACTICE: stopped - {ats} needs a sign-in first")
            if resume_cat:
                cat, why = resume_cat, "given on command line"
            else:
                cat, why = llm.pick_category(info["jd"])
            pdf = str(config.path(P["resumes"][cat]))
            say(f"{company} via {ats} | resume: {cat} ({why[:120]})")
            why = excluded(company, info.get("title", ""))
            page_why, check = excluded_page(page, company)
            why = why or page_why
            if why and "--force" in args and why.startswith(FORCEABLE):
                why = None
            elif why and RECRUITER and why.startswith(FORCEABLE):
                raise NeedsUser(f"recruiter link - {why} - apply by hand")
            elif check:
                raise NeedsUser(check + " - apply by hand if it is not that company")
            if why:
                log_row(date=dt.date.today(), company=company, title=info.get("title", ""), url=url, ats=ats,
                        status="skipped", notes=why)
                return say("SKIP: " + why)
            if RECRUITER:
                title = re.split(r"\s+\|\s+|\s+in\s+[A-Z][\w .,-]+,\s", info.get("title", ""))[0].strip()
                nofte = fte_check(company, title, info["jd"])
                verdict, reason = ("skip", nofte) if nofte else llm.fit(title, company, info["jd"])
                if verdict == "skip" and not nofte and not JD_MARKERS.search(info["jd"]):
                    verdict, reason = "stretch", "no job description could be read on the page"
                if verdict == "skip":
                    log_row(date=dt.date.today(), company=company, title=title, url=url, ats=ats, status="skipped",
                            notes=f"recruiter link - not a fit: {reason}"[:900], summary=state.get("summary", ""))
                    return say("SKIP (recruiter link, not a fit): " + reason[:150])
                if verdict != "strong":
                    pol = str(config.setting("recruiter_unclear", "apply")).lower()
                    if pol == "skip":
                        log_row(date=dt.date.today(), company=company, title=title, url=url, ats=ats, status="skipped",
                                notes=f"recruiter link - partial fit, skipped (settings): {reason}"[:900])
                        return say("SKIP (recruiter link, partial fit - settings say skip): " + reason[:150])
                    if "no job description" in reason:
                        raise NeedsUser("recruiter link - no job description could be read on the page, so the fit "
                                         "could not be judged")
                    if pol == "ask":
                        raise NeedsUser(f"recruiter link - fit unclear ({reason[:150]}) - your call")
                    say(f"recruiter link - partial fit, applying (settings: recruiter_unclear = apply): {reason[:150]}")
                info["title"] = state["title"] = title
                say(f"recruiter link - fit: {reason[:150]}")
            personalize_for(company)
            if PRACTICE:
                page = practice_page(browser, page, state)
            wd = ADAPTERS[ats](page, info["jd"], company, pdf)
            state["action_url"] = page.url
            try:
                status, review = wd.run(submit=submit)
            except (NeedsUser, AlreadyApplied, JobClosed, SiteDown):
                practice_after(wd.p, state, wd.notes)
                raise
            except Exception:
                practice_after(wd.p, state, wd.notes)
                check_already_applied(ctx)
                raise
            practice_after(wd.p, state, wd.notes)
            if status != "submitted":
                check_already_applied(ctx)
            if status.startswith(("stuck on", "too many pages")):
                if down := site_down(wd.p):
                    raise SiteDown(down)
                raise NeedsUser(f"the form got {status[:200]} - finish it by hand")
            if status.startswith("submit clicked"):
                import jobseek
                cap = jobseek.EMPLOYER_CAP.search(" ".join(wd.notes))
                if cap:
                    status = "waiting: employer limit"
                    wd.notes.insert(0, f"employer limit - the site says: {cap.group(0)}")
            if status == "sign-in not completed":
                raise NeedsUser(f"sign-in not completed at {ats} - double-click 'JobBot pending' when you have a minute")
            stamp = f"{dt.datetime.now():%Y-%m-%d_%H%M}_{re.sub(r'[^A-Za-z0-9]+', '-', company)[:30]}"
            if review:
                (RUNS / f"{stamp}.txt").write_text(
                    f"URL: {url}\nResume: {cat}\nStatus: {status}\n\nNOTES:\n" + "\n".join(wd.notes) +
                    "\n\nREVIEW PAGE:\n" + review, encoding="utf-8")
            log_row(date=dt.date.today(), company=company, title=info["title"], url=url, ats=ats,
                    category=cat, applicants=info.get("applicants", ""), status=status,
                    notes=" | ".join(wd.notes)[:900], summary=state.get("summary", ""),
                    action_url=wd.p.url if status != "submitted" else "")
            say(f"RESULT: {status}" + (f"  (review saved: runs/{stamp}.txt)" if review else ""))
            if status in ("ready for review", "submit clicked - confirmation not seen") and not UNATTENDED:
                state["keep_open"] = True
                say("browser left open for you to check - close it when done")
                if status == "ready for review" and not config.AUTO_SUBMIT:
                    say("CALIBRATION: review the form and press Submit yourself - waiting up to 20 minutes")
                    for _ in range(240):
                        time.sleep(5)
                        try:
                            hit = any(not t.is_closed() and (CONFIRMED.search(t.locator("body").inner_text(timeout=3000))
                                      or re.search(r"thank|confirm|success|/dashboard", t.url, re.I)) for t in ctx.pages)
                        except Exception:
                            hit = False
                        if hit:
                            log_row(date=dt.date.today(), company=company, title=info["title"], url=url, ats=ats,
                                    category=cat, applicants=info.get("applicants", ""), status="submitted",
                                    notes=f"Submitted by you on the form {config.APP_NAME} filled.",
                                    summary=state.get("summary", ""))
                            say("RESULT: submitted (by you) - recorded")
                            state["keep_open"] = False
                            break
    except AlreadyApplied as e:
        log_row(date=dt.date.today(), company=state.get("company", ""), title=state.get("title", ""),
                url=url, ats=state.get("ats", ""), status="applied (already on file at the employer)",
                notes=str(e)[:300], summary=state.get("summary", ""))
        say(f"ALREADY APPLIED: {e}")
    except JobClosed as e:
        log_row(date=dt.date.today(), company=state.get("company", ""), title=state.get("title", ""),
                url=url, ats=state.get("ats", ""), applicants=state.get("applicants", ""),
                status="skipped", notes=str(e)[:300])
        say(f"SKIP: {e}")
    except SiteDown as e:
        site_down_row(url, state, str(e))
    except SiteBroken as e:
        site_broken_row(url, state, str(e))
    except NoAdapter as e:
        note, _down = employer_tab(state, "unsupported")
        site_broken_row(url, state, str(e) + note, status="waiting: site not supported")
    except NeedsUser as e:
        note, down = employer_tab(state, "needs-you") if state.get("ats") else ("", None)
        if down:
            site_down_row(url, state, down)
            return
        if waits_for_fix(state, str(e)):
            broken_check(state, str(e), url)
            site_broken_row(url, state, f"{sites.host(state['action_url'])} ({str(e)[:400]})" + note)
            return
        if note:
            say("page kept" + note)
        log_row(date=dt.date.today(), company=state.get("company", ""), title=state.get("title", ""),
                url=url, ats=state.get("ats", ""), applicants=state.get("applicants", ""),
                status="needs you", notes=str(e)[:300], summary=state.get("summary", ""),
                action_url=state.get("action_url", url))
        say(f"NEEDS YOU (logged, moving on): {e}")
        broken_check(state, str(e), url)
    except Exception as e:
        msg = f"{type(e).__name__}: {str(e).splitlines()[0] if str(e) else ''}"[:300]
        import traceback
        here = [f for f in traceback.extract_tb(e.__traceback__) if f.filename.endswith("apply.py")]
        if here:
            msg = f"{msg[:200]} @ line {here[-1].lineno}: {(here[-1].line or '')[:80]}"
        note, down = employer_tab(state, "error")
        if down:
            site_down_row(url, state, down)
            return
        msg += note
        log_row(date=dt.date.today(), company=state.get("company", ""), title=state.get("title", ""),
                url=url, ats=state.get("ats", ""), applicants=state.get("applicants", ""),
                status="error", notes=msg, summary=state.get("summary", ""),
                action_url=state.get("action_url", url))
        say(f"ERROR (logged, skipping this job): {msg}")
        broken_check(state, f"exception: {msg}", url)
        if not UNATTENDED:
            state["keep_open"] = True
            say("browser left open on the form - finish it by hand if you like, then close it")
    finally:
        if UNATTENDED or not state.get("keep_open"):
            say("browser: " + jobapply.close_chrome())


def employer_tab(state, kind):
    if PRACTICE and state.get("fresh"):
        return state.get("evidence") or "", None
    note, down = "", site_down(None) if OUTAGE else None
    try:
        shot = RUNS / f"{dt.datetime.now():%Y-%m-%d_%H%M}_{re.sub(r'[^A-Za-z0-9]+', '-', state.get('company', 'job'))[:30]}_{kind}.png"
        with sync_playwright() as pw2:
            tabs = pw2.chromium.connect_over_cdp(f"http://127.0.0.1:{jobapply.PORT}").contexts[0].pages
            pg = ([t for t in tabs if "linkedin.com" not in t.url and t.url.startswith("http")] or tabs)[-1]
            down = site_down(pg)
            pg.screenshot(path=str(shot), full_page=True)
            note = f"; page {pg.url[:100]}; screenshot runs/{shot.name}"
            try:
                form_map(pg, shot.with_name(shot.stem + "-form.json"))
            except Exception:
                pass
    except Exception:
        pass
    return note, down


def form_map(pg, out):
    frames = []
    for fr in pg.frames:
        try:
            fields = fr.evaluate(jobapply.FIELDS_JS)
            extra = fr.evaluate("""() => ({
              buttons: [...document.querySelectorAll('button, [role=button], input[type=submit]')].filter(b => b.getBoundingClientRect().width > 0)
                .map(b => (b.innerText || b.value || b.getAttribute('aria-label') || '').trim().replace(/\\s+/g, ' ').slice(0, 50)).filter(Boolean).slice(0, 40),
              headings: [...document.querySelectorAll('h1, h2, h3, legend')].map(h => h.innerText.trim().replace(/\\s+/g, ' ').slice(0, 80)).filter(Boolean).slice(0, 30),
              errors: [...document.querySelectorAll('[role=alert], [aria-invalid=true], .error, [class*=error]')].filter(e => e.getBoundingClientRect().width > 0)
                .map(e => (e.innerText || e.getAttribute('aria-label') || e.name || '').trim().replace(/\\s+/g, ' ').slice(0, 100)).filter(Boolean).slice(0, 20)})""")
        except Exception:
            continue
        if not fields and fr != pg.main_frame:
            continue
        frames.append({"url": fr.url.split("?")[0][:200], **extra, "fields": [
            {"label": f.get("label"), "type": f.get("type"), "required": f.get("req"), "filled": bool(f.get("value")),
             **({"options": f["options"]} if f.get("options") else {}), "selector": f.get("sel")} for f in fields]})
    out.write_text(json.dumps({"url": pg.url.split("?")[0][:200], "title": pg.title()[:120], "frames": frames}, indent=1),
                   encoding="utf-8")


PRACTICE_GUARD = r"""(() => {
  const SUBMITS = /^\s*(submit|send|finish|complete|confirm)\b|\b(submit|send|complete|finish)\s+(my\s+|your\s+|the\s+)?application\b/i;
  const note = what => { window.__practiceBlocked = (window.__practiceBlocked || []).concat([what]); };
  const label = el => String(el.innerText || el.value || el.getAttribute('aria-label') || el.title || '').trim().slice(0, 80);
  window.addEventListener('click', e => {
    const el = e.target && e.target.closest ? e.target.closest('button, a, input, [role=button]') : null;
    if (el && SUBMITS.test(label(el))) { e.preventDefault(); e.stopImmediatePropagation(); note('click ' + label(el)); }
  }, true);
  const typed = f => [...((f && f.elements) || [])].some(e => e.tagName === 'TEXTAREA' ? e.value.trim() :
    e.tagName === 'INPUT' && (e.type === 'file' ? e.files && e.files.length :
      /^(text|email|tel|url|number|date)$/i.test(e.type) && String(e.value || '').trim()));
  const tag = f => typed(f) ? '' : ' (nothing filled)';
  window.addEventListener('submit', e => { e.preventDefault(); e.stopImmediatePropagation(); note('form submit' + tag(e.target)); }, true);
  HTMLFormElement.prototype.submit = function () { note('form.submit()' + tag(this)); };
  HTMLFormElement.prototype.requestSubmit = function () { note('form.requestSubmit()' + tag(this)); };
})();"""
PRACTICE_WRITES = re.compile(r"submit|draft|autosave|\bsave|upload|attachment|/resume|/applications?(/|\?|$)|/apply/?(\?|$)",
                             re.I)
PRACTICE_BLOCKED = []


def practice_route(route):
    r = route.request
    body = ""
    try:
        body = (r.post_data or "")[:4000]
    except Exception:
        pass
    mutation = re.search(r'"query"\s*:\s*"\s*mutation\b|^\s*mutation\b|"operationName"\s*:\s*"[^"]*(submit|apply|save|draft|upload)',
                         body, re.I)
    if r.method not in ("GET", "HEAD", "OPTIONS") and (PRACTICE_WRITES.search(r.url) or mutation):
        PRACTICE_BLOCKED.append(f"{r.method} {r.url.split('?')[0][:90]}")
        return route.abort()
    return route.continue_()


def practice_page(browser, page, state):
    fresh = browser.new_context()
    fresh.add_init_script(PRACTICE_GUARD)
    fresh.route("**/*", practice_route)
    pg = fresh.new_page()
    pg.goto(page.url, wait_until="domcontentloaded", timeout=60000)
    pg.wait_for_timeout(4000)
    dismiss_cookies(pg)
    try:
        page.close()
    except Exception:
        pass
    state["fresh"] = True
    say("practice: the form opened in an empty browser of its own - stand-in details, nothing uploaded or submitted")
    return pg


def practice_after(pg, state, notes):
    if not PRACTICE or state.get("evidence") is not None:
        return
    state["evidence"] = ""
    try:
        clicks = pg.evaluate("() => window.__practiceBlocked || []") or []
    except Exception:
        clicks = []
    pressed = [c for c in clicks if re.search(r"submit|send|finish|complete|confirm", c, re.I)
               and "(nothing filled)" not in c]
    tried = pressed + ([c for c in PRACTICE_BLOCKED if re.search(r"submit", c, re.I)] if pressed else [])
    guard = ("PRACTICE GUARD - SUBMIT ATTEMPT BLOCKED: " + "; ".join(tried[:5]) if tried else
             f"practice guard: {len(clicks) + len(PRACTICE_BLOCKED)} write(s) refused ({'; '.join((clicks + PRACTICE_BLOCKED)[:3])})"
             if clicks or PRACTICE_BLOCKED else "")
    if guard:
        notes.append(guard)
        state["evidence"] = f"; {guard}"
    try:
        shot = RUNS / f"{dt.datetime.now():%Y-%m-%d_%H%M}_{re.sub(r'[^A-Za-z0-9]+', '-', state.get('company', 'job'))[:30]}_practice.png"
        pg.screenshot(path=str(shot), full_page=True)
        form_map(pg, shot.with_name(shot.stem + "-form.json"))
        state["evidence"] += f"; page {pg.url[:100]}; screenshot runs/{shot.name}"
    except Exception:
        pass


def practice_stop(form):
    doubt = second_read(form, submit=False)
    return "ready for review", "\n".join(form.notes) + (f"\n{doubt}" if doubt else "")


def waits_for_fix(state, reason):
    return bool(state.get("action_url")) and not sites.USERS_OWN.search(reason or "")


def broken_check(state, reason, url):
    try:
        if state.get("action_url") and sites.note_failure(state["action_url"], state.get("ats", ""), reason, url):
            say(f"SITE MARKED BROKEN: {sites.host(state['action_url'])} - its jobs wait for an update (problem reported)")
    except Exception as e:
        say(f"(broken-site check failed: {e})")


def site_broken_row(url, state, why, status=None):
    status = status or sites.STATUS
    rows = []
    if LOG.exists():
        with LOG.open(encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
    days = sites.waited_days(rows, url, status)
    kw = dict(date=dt.date.today(), company=state.get("company", ""), title=state.get("title", ""), url=url,
              ats=state.get("ats", ""), applicants=state.get("applicants", ""), summary=state.get("summary", ""),
              action_url=state.get("action_url") or url)
    if days >= sites.WAIT_DAYS:
        log_row(**kw, status="needs you", notes=f"{why} - the service request is still open after {days} days - apply "
                                                "yourself if you still want it")
        say(f"NEEDS YOU (service request still open after {days} days): {why}")
    elif PRACTICE:
        log_row(**kw, status=status, notes=f"{why} - a service request was filed; practice waits for the update")
    else:
        log_row(**kw, status=status, notes=f"{why} - a service request was filed; tried again on the next runs")
        say(f"SERVICE REQUEST ({status}): {why}")


def site_down_row(url, state, why):
    n = 1
    if LOG.exists():
        with LOG.open(encoding="utf-8") as f:
            n += sum(1 for r in csv.DictReader(f) if r.get("url") == url and (r.get("status") or "").startswith("waiting: site down"))
    kw = dict(date=dt.date.today(), company=state.get("company", ""), title=state.get("title", ""), url=url,
              ats=state.get("ats", ""), applicants=state.get("applicants", ""), summary=state.get("summary", ""),
              action_url=url)
    if n >= SITE_DOWN_TRIES:
        log_row(**kw, status="needs you", notes=f"the employer's site was down on {n} tries ({why}) - apply by hand")
        say(f"NEEDS YOU (the site was down on {n} tries): {why}")
    else:
        log_row(**kw, status="waiting: site down", notes=f"{why} - tried again on the next run ({n} of {SITE_DOWN_TRIES})")
        say(f"SITE DOWN - waiting, tried again on the next run ({n} of {SITE_DOWN_TRIES}): {why}")


if __name__ == "__main__":
    main()
