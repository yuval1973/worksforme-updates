import ctypes
import ctypes.wintypes as wt
import getpass
import os
import subprocess
import sys
import time
from pathlib import Path

NAMES = ("ANTHROPIC_API_KEY", "EMAIL_PASS")
try:
    from config import VAULT_PREFIX as PREFIX, APP_NAME
except Exception:
    PREFIX, APP_NAME = "JobBot/", "JobBot"
CRED_TYPE_GENERIC, CRED_PERSIST_LOCAL_MACHINE = 1, 2


class CREDENTIAL(ctypes.Structure):
    _fields_ = [("Flags", wt.DWORD), ("Type", wt.DWORD), ("TargetName", wt.LPWSTR), ("Comment", wt.LPWSTR),
                ("LastWritten", wt.FILETIME), ("CredentialBlobSize", wt.DWORD),
                ("CredentialBlob", ctypes.POINTER(ctypes.c_char)), ("Persist", wt.DWORD),
                ("AttributeCount", wt.DWORD), ("Attributes", ctypes.c_void_p), ("TargetAlias", wt.LPWSTR),
                ("UserName", wt.LPWSTR)]


_adv = ctypes.WinDLL("advapi32", use_last_error=True) if os.name == "nt" else None


def _cm_read(name):
    if not _adv:
        return None
    p = ctypes.POINTER(CREDENTIAL)()
    if not _adv.CredReadW(PREFIX + name, CRED_TYPE_GENERIC, 0, ctypes.byref(p)):
        return None
    try:
        blob = ctypes.string_at(p.contents.CredentialBlob, p.contents.CredentialBlobSize)
        return blob.decode("utf-16-le")
    finally:
        _adv.CredFree(p)


def _cm_write(name, value):
    data = value.encode("utf-16-le")
    buf = ctypes.create_string_buffer(data, len(data))
    c = CREDENTIAL(Type=CRED_TYPE_GENERIC, TargetName=PREFIX + name, CredentialBlobSize=len(data),
                   CredentialBlob=ctypes.cast(buf, ctypes.POINTER(ctypes.c_char)), Persist=CRED_PERSIST_LOCAL_MACHINE,
                   UserName=os.environ.get("USERNAME", "jobbot"))
    if not _adv.CredWriteW(ctypes.byref(c), 0):
        raise OSError(ctypes.get_last_error(), "CredWrite failed")


def forget_all():
    if not _adv or not PREFIX.endswith(".app/"):
        return 0
    n, pp = wt.DWORD(), ctypes.POINTER(ctypes.POINTER(CREDENTIAL))()
    if not _adv.CredEnumerateW(PREFIX + "*", 0, ctypes.byref(n), ctypes.byref(pp)):
        return 0
    try:
        names = [pp[i].contents.TargetName for i in range(n.value)]
    finally:
        _adv.CredFree(pp)
    gone = 0
    for t in names:
        if t and t.startswith(PREFIX) and _adv.CredDeleteW(t, CRED_TYPE_GENERIC, 0):
            gone += 1
    return gone


def _legacy(name):
    try:
        from config import setting
        store = setting("legacy_secret_store")
        if not store:
            return None
        p = os.path.expandvars(store)
        sys.path.insert(0, p)
        try:
            from secrets_store import get_secret_any
            return get_secret_any(name)
        finally:
            sys.path.remove(p)
    except Exception:
        return None


def get(name):
    v = os.environ.get(name) or _cm_read(name) or _legacy(name)
    if not v:
        raise RuntimeError(f"secret {name} is not set - run:  python vault.py ask {name}")
    return v


def _to_front():
    k, u = ctypes.windll.kernel32, ctypes.windll.user32
    h = k.GetConsoleWindow()
    if not h:
        return
    u.ShowWindow(h, 9)
    for z in (-1, -2):
        u.SetWindowPos(h, z, 0, 0, 0, 0, 0x0001 | 0x0002 | 0x0040)
    ft, me = u.GetWindowThreadProcessId(u.GetForegroundWindow(), None), k.GetCurrentThreadId()
    if ft and ft != me:
        u.AttachThreadInput(me, ft, True)
    u.BringWindowToTop(h)
    u.SetForegroundWindow(h)
    if ft and ft != me:
        u.AttachThreadInput(me, ft, False)
    if u.GetForegroundWindow() != h:
        u.keybd_event(0x12, 0, 0, 0)
        u.keybd_event(0x12, 0, 2, 0)
        u.SetForegroundWindow(h)


def _needs_settings():
    if not (Path(__file__).parent / "settings.json").exists():
        sys.exit("settings.json is missing - create it first (SETUP.md step 3), then store the secret")


def main():
    a = sys.argv[1:]
    if a[:1] == ["set"] and len(a) == 2:
        if _adv:
            ctypes.windll.kernel32.SetConsoleTitleW(f"{APP_NAME} - {a[1]}")
            try:
                _to_front()
            except Exception:
                pass
        _needs_settings()
        print(f"Paste your {a[1]} below (Ctrl+V or right-click), then press Enter. Nothing shows while you paste - "
              f"that is normal.\n")
        v = getpass.getpass(f"{a[1]} (input hidden): ").strip()
        if not v:
            print("nothing entered - unchanged")
            time.sleep(4)
            sys.exit(1)
        _cm_write(a[1], v)
        print(f"{a[1]} stored in Windows Credential Manager ({PREFIX}{a[1]}). This window closes now.")
        time.sleep(2)
    elif a[:1] == ["ask"] and len(a) == 2:
        _needs_settings()
        before = _cm_read(a[1])
        print(f"A window titled '{APP_NAME} - {a[1]}' is open: the user pastes the secret there and presses Enter "
              f"(waiting up to 9 minutes) ...", flush=True)
        exe = Path(sys.executable)
        if exe.name.lower() == "pythonw.exe" and exe.with_name("python.exe").exists():
            exe = exe.with_name("python.exe")
        pr = subprocess.Popen([str(exe), str(Path(__file__).resolve()), "set", a[1]], cwd=Path(__file__).parent,
                              creationflags=getattr(subprocess, "CREATE_NEW_CONSOLE", 0))
        try:
            pr.wait(timeout=540)
        except subprocess.TimeoutExpired:
            pr.kill()
            sys.exit(f"{a[1]}: no answer in 9 minutes - window closed; run it again when the user is ready")
        now = _cm_read(a[1])
        if now and now != before:
            print(f"{a[1]} stored ({PREFIX}{a[1]})")
        elif now:
            sys.exit(f"{a[1]}: unchanged (an earlier value is still stored)")
        else:
            sys.exit(f"{a[1]}: NOT stored - the window was closed without a value; run it again")
    elif a[:1] == ["check"]:
        for n in NAMES:
            src = "environment" if os.environ.get(n) else "Credential Manager" if _cm_read(n) else \
                "legacy store" if _legacy(n) else None
            print(f"{n:18} {'present (' + src + ')' if src else 'MISSING - python vault.py ask ' + n}")
    else:
        sys.exit("usage: vault.py check | ask NAME | set NAME")


if __name__ == "__main__":
    main()
