import datetime as dt
import socket
import subprocess
import sys
import time
from pathlib import Path

HERE = Path(__file__).parent
sys.path.insert(0, str(HERE))
import config
RUN_AT = dt.time(*map(int, config.RUN_AT.split(":")))
IDLE_MIN = config.IDLE_MIN
MARK = HERE / "runs" / "last_daily_run.txt"
RETRY = HERE / "runs" / "retry_daily_run.txt"
LOG = HERE / "runs" / "agent.log"
PY = str(Path(sys.executable).with_name("python.exe"))


def log(msg):
    LOG.parent.mkdir(exist_ok=True)
    with LOG.open("a", encoding="utf-8") as f:
        f.write(f"[{dt.datetime.now():%Y-%m-%d %H:%M:%S}] {msg}\n")


def online():
    try:
        socket.create_connection(("imap.gmail.com", 993), timeout=5).close()
        return True
    except OSError:
        return False


def idle_minutes():
    import ctypes

    class LASTINPUTINFO(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]
    li = LASTINPUTINFO(ctypes.sizeof(LASTINPUTINFO), 0)
    if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(li)):
        return 10 ** 6
    return ((ctypes.windll.kernel32.GetTickCount() - li.dwTime) & 0xFFFFFFFF) / 60000


def due(now, last, retry):
    if last != now.date().isoformat():
        return now.time() >= RUN_AT
    try:
        at = dt.datetime.fromisoformat(retry.strip()) if retry else None
    except ValueError:
        return False
    return bool(at) and at.date() == now.date() and now >= at


def main():
    lock = socket.socket()
    try:
        lock.bind(("127.0.0.1", config.PORT_AGENT))
    except OSError:
        return
    log(f"agent started (pid-less, {sys.executable}); daily run at {RUN_AT:%H:%M}")
    while True:
        now = dt.datetime.now()
        last = MARK.read_text().strip() if MARK.exists() else ""
        retry = RETRY.read_text().strip() if RETRY.exists() else ""
        if due(now, last, retry) and idle_minutes() >= IDLE_MIN:
            if not online():
                if int(time.time() // 60) % 30 == 0:
                    log("offline - the daily run waits for a connection")
                time.sleep(60)
                continue
            MARK.write_text(now.date().isoformat())
            RETRY.unlink(missing_ok=True)
            log(f"starting run_daily.py (idle {idle_minutes():.0f} min{', the retry after a postponed run' if last == now.date().isoformat() else ''})")
            day_log = HERE / "runs" / f"daily-{now.date()}.log"
            try:
                with day_log.open("a", encoding="utf-8") as out:
                    r = subprocess.run([PY, str(HERE / "run_daily.py")], cwd=HERE, stdout=out,
                                       stderr=subprocess.STDOUT, timeout=3 * 3600,
                                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                log(f"run_daily.py finished, exit {r.returncode}")
            except Exception as e:
                log(f"run_daily.py failed to run: {e!r}")
        time.sleep(60)


if __name__ == "__main__":
    main()
