import os
import subprocess
import sys
import tempfile
import time
from pathlib import Path

HERE = Path(__file__).parent
CANDIDATES = [str(HERE.parent / "libreoffice" / "program" / "soffice.exe"),
              r"C:\Program Files\LibreOffice\program\soffice.exe", r"C:\Program Files (x86)\LibreOffice\program\soffice.exe"]
NW = getattr(subprocess, "CREATE_NO_WINDOW", 0)
WORD_PS = r"""param([string]$Src, [string]$Out)
$ErrorActionPreference = "Stop"
$w = New-Object -ComObject Word.Application
try {
    $w.Visible = $false; $w.DisplayAlerts = 0
    $d = $w.Documents.Open($Src, $false, $true, $false)
    $d.ExportAsFixedFormat($Out, 17)
    $d.Close(0)
} finally { $w.Quit() }
"""


def word():
    if os.environ.get("WFM_PDF_MAKER") == "libreoffice":
        return False
    try:
        import winreg
        winreg.CloseKey(winreg.OpenKey(winreg.HKEY_CLASSES_ROOT, r"Word.Application\CLSID"))
        return True
    except OSError:
        return False


def libreoffice():
    return next((c for c in CANDIDATES if Path(c).exists()), None)


def available():
    return "word" if word() else libreoffice()


def soffice():
    exe = libreoffice()
    if not exe:
        raise RuntimeError("no PDF maker on this PC - Microsoft Word did not save it and LibreOffice is not installed")
    return exe


def _word(docx, pdf, timeout=90):
    script = Path(tempfile.gettempdir()) / "jobbot_word_pdf.ps1"
    script.write_text(WORD_PS, encoding="utf-8")
    t0 = time.time()
    pr = subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File",
                           str(script), "-Src", str(docx), "-Out", str(pdf)],
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, creationflags=NW)
    try:
        pr.wait(timeout=timeout)
    except subprocess.TimeoutExpired:
        subprocess.run(["taskkill", "/T", "/F", "/PID", str(pr.pid)], capture_output=True, creationflags=NW)
        since = time.strftime("%Y%m%d%H%M%S", time.localtime(t0 - 2))
        subprocess.run(["powershell", "-NoProfile", "-Command",
                        "Get-CimInstance Win32_Process -Filter \"Name='WINWORD.EXE'\" | Where-Object { $_.CommandLine -match "
                        f"'/Automation' -and $_.CreationDate.ToString('yyyyMMddHHmmss') -ge '{since}' }} | "
                        "ForEach-Object { Stop-Process -Id $_.ProcessId -Force }"], capture_output=True, creationflags=NW)
        return False
    return pdf.exists() and pdf.stat().st_size > 0 and pdf.stat().st_mtime >= t0 - 1


def convert(docx):
    docx = Path(docx).resolve()
    pdf = docx.with_suffix(".pdf")
    if word() and _word(docx, pdf):
        print(f"PDF (Word): {pdf}")
        return pdf
    profile = Path(tempfile.gettempdir()) / f"jobbot_lo_profile_{os.getpid()}"
    env = dict(os.environ, SAL_DISABLE_PRINTERLIST="1", SAL_DISABLE_DEFAULTPRINTER="1", SAL_USE_VCLPLUGIN="svp")
    cmd = [soffice(), f"-env:UserInstallation={profile.as_uri()}", "--headless", "--norestore", "--nologo",
           "--convert-to", "pdf", "--outdir", str(docx.parent), str(docx)]
    pr = subprocess.Popen(cmd, env=env, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        pr.wait(timeout=120)
    except subprocess.TimeoutExpired:
        subprocess.run(["taskkill", "/T", "/F", "/PID", str(pr.pid)], capture_output=True, creationflags=NW)
        raise RuntimeError(f"LibreOffice did not finish in 2 minutes converting {docx.name} - close any LibreOffice window and retry")
    if not pdf.exists() or pdf.stat().st_mtime < docx.stat().st_mtime - 1:
        raise RuntimeError(f"no PDF produced for {docx.name}")
    print(f"PDF: {pdf}")
    return pdf


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit("usage: make_pdf.py <file.docx> [<file2.docx> ...]")
    for f in sys.argv[1:]:
        try:
            convert(f)
        except RuntimeError as e:
            sys.exit(str(e))
