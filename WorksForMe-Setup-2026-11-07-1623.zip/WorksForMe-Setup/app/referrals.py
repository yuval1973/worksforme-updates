import csv
import email
import html
import re
import subprocess
import sys
from email.header import decode_header, make_header
from pathlib import Path
from urllib.parse import urlparse

HERE = Path(__file__).parent
HOLD_STATUS = "waiting: applications on hold"
sys.path.insert(0, str(HERE))
import gmail

import config
QUERY = ("newer_than:30d -in:trash (in:inbox OR label:misc-job-seek) -from:linkedin.com -subject:JobBot "
         f"-subject:{config.APP_NAME} "
         + (f"-to:{config.setting('support_to')} " if config.setting("support_to") else "")
         + "subject:(refer OR referred OR referral OR referring)")
GOOGLE_MAX, GOOGLE_DAYS = 3, 30
JOB_HOST = re.compile(r"myworkdayjobs\.com|myworkdaysite\.com|greenhouse\.io|lever\.co|ashbyhq\.com|"
                      r"ats\.rippling\.com|jobs\.gem\.com|jobs\.jobvite\.com|\.icims\.com/jobs|oraclecloud\.com|amazon\.jobs|google\.com/about/careers|"
                      r"careers\.google\.com|/jobs?/|/careers?/.*\d", re.I)
SOCIAL = re.compile(r"facebook|twitter|instagram|youtube|flickr|mailchimp|blogs?\.|linkedin\.com/company|"
                    r"unsubscribe|privacy|\.(png|jpe?g|gif)\b", re.I)
FINAL = ("submitted", "applied", "submit clicked", "ready", "needs you", "skipped")
MAX_TRIES = 3


def _dec(v):
    return " ".join(str(make_header(decode_header(v or ""))).split())


def key(url):
    u = urlparse(url)
    return (u.netloc + u.path).lower().rstrip("/")


def plugin_job(link):
    try:
        from apply import plugin_host
        return bool(plugin_host(link))
    except Exception:
        return False


def job_links(msg):
    text = ""
    for p in msg.walk():
        if p.get_content_type() in ("text/plain", "text/html"):
            text += p.get_payload(decode=True).decode(p.get_content_charset() or "utf-8", "replace")
    out = []
    for l in re.findall(r"https?://[^\s\"'<>]+", text):
        l = html.unescape(l).rstrip(").,;")
        if (JOB_HOST.search(l) or plugin_job(l)) and not SOCIAL.search(l) and key(l) not in {key(x) for x in out}:
            out.append(l)
    return [l for l in out if not any(x != l and key(x).startswith(key(l)) for x in out)]


ATS_SENDER = re.compile(r"@([\w-]+\.)*(myworkday|greenhouse|lever|ashbyhq|icims|jobvite|smartrecruiters|eightfold|"
                        r"phenompeople|oraclecloud|successfactors|taleo|rippling|workablemail)\.(com|io|co|ai|net)>?$", re.I)
FREE_MAIL = {"gmail", "googlemail", "outlook", "hotmail", "live", "msn", "yahoo", "icloud", "me", "mac", "aol", "proton",
             "protonmail", "pm", "gmx", "mail", "yandex", "zoho", "fastmail", "hey", "comcast", "verizon", "att"}
SUFFIX = {"com", "co", "org", "net", "ac", "gov", "edu", "io", "ai", "biz", "info", "ltd", "plc"}


def org_name(domain):
    labels = [x for x in domain.lower().split(".") if x]
    while labels and (labels[-1] in SUFFIX or len(labels[-1]) == 2):
        labels.pop()
    return labels[-1] if labels else ""


def trusted(sender, links):
    import config
    addr = (re.search(r"<([^>]+)>", sender or "") or re.search(r"(\S+@\S+)", sender or "") or [None, ""])[1].lower()
    if not addr:
        return False
    if addr == str(config.EMAIL).lower() or ATS_SENDER.search(addr) or \
            any(re.search(s, addr, re.I) for s in config.setting("referral_senders", []) or []):
        return True
    name = org_name(addr.split("@")[-1])
    if not name or name in FREE_MAIL or len(name) < 3:
        return False
    from apply import url_company
    return all(name in urlparse(l).netloc.lower().split(".") or url_company(l).lower() == name for l in links)


def find(m, log=print):
    m.select(f'"{gmail.special(m, chr(92) + "All")}"', readonly=True)
    found = []
    for uid in m.uid("SEARCH", "X-GM-RAW", f'"{QUERY}"')[1][0].split():
        msg = email.message_from_bytes(m.uid("FETCH", uid, "(BODY.PEEK[])")[1][0][1])
        links = job_links(msg)
        if links and trusted(_dec(msg["From"]), links):
            found.append((uid.decode(), _dec(msg["Subject"]), _dec(msg["From"]), links))
        elif links:
            log(f"   not a trusted referral sender - ignored: {_dec(msg['From'])[:60]} | {_dec(msg['Subject'])[:60]}")
    return found


def ledger_state():
    st, errs = {}, {}
    with (HERE / "applications.csv").open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            for u in (r.get("url"), r.get("action_url")):
                if u:
                    k = key(u)
                    st[k] = r.get("status") or ""
                    if st[k].startswith("error"):
                        errs[k] = errs.get(k, 0) + 1
    return {k: (v, errs.get(k, 0)) for k, v in st.items()}


def is_final(state):
    status, errors = state
    return status.startswith(FINAL) or (status.startswith("error") and errors >= MAX_TRIES)


def google_applications():
    import datetime as dt
    import jobseek
    since = dt.date.today() - dt.timedelta(days=GOOGLE_DAYS)
    from collections import Counter
    mails = Counter(dt.datetime.fromisoformat(c["date"]).date() for c in jobseek._load().values()
                    if c.get("kind") == "confirmation" and "google" in (c.get("company") or "").lower() and c.get("date"))
    latest = {}
    with (HERE / "applications.csv").open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if "google" in (r.get("company") or "").lower():
                latest[r.get("url")] = r
    rows = Counter(dt.date.fromisoformat(r["date"]) for r in latest.values()
                   if (r.get("status") or "").startswith(("submitted", "applied")))
    days = [d for d in set(mails) | set(rows) for _ in range(max(mails[d], rows[d]))]
    return sorted(d for d in days if d >= since)


def google_link(link, free, log):
    import datetime as dt
    from apply import log_row
    state = ledger_state().get(key(link))
    if free > 0:
        log_row(date=dt.date.today(), company="Google", title="(referred role - see link)", url=link, ats="google",
                status="needs you", action_url=link,
                notes="REFERRAL | Google window open - apply by hand (or ask Claude Code why JobBot did not apply)")
        log(f"      Google slot open -> needs you: {link[:100]}")
        return True
    if not (state and state[0].startswith("waiting")):
        nxt = google_applications()[0] + dt.timedelta(days=GOOGLE_DAYS)
        log_row(date=dt.date.today(), company="Google", title="(referred role - see link)", url=link, ats="google",
                status="waiting: Google 30-day limit", action_url=link,
                notes=f"REFERRAL | Google allows {GOOGLE_MAX} applications per {GOOGLE_DAYS} days; next slot {nxt}")
        log(f"      Google window full - waiting (next slot {nxt}): {link[:90]}")
    return False


def backlog(tag="REFERRAL"):
    latest, errs = {}, {}
    with (HERE / "applications.csv").open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if not r.get("url"):
                continue
            k = key(r["url"])
            latest[k] = r
            if (r.get("status") or "").startswith("error"):
                errs[k] = errs.get(k, 0) + 1
    return [r["url"] for k, r in latest.items() if tag in (r.get("notes") or "")
            and ((r.get("status") or "").startswith("waiting")
                 or ((r.get("status") or "").startswith("error") and errs.get(k, 0) < MAX_TRIES))]


def handle(link, log, dry, py, logfile, recruiter=False):
    state = ledger_state().get(key(link))
    if state and is_final(state):
        log(f"      already handled ({state[0][:30]}): {link[:90]}")
        return False
    if recruiter:
        return recruiter_apply(link, log, dry, py, logfile)
    if (HERE / "HOLD").exists():
        if dry:
            log(f"      HOLD - would keep waiting: {link[:90]}")
        elif not (state and state[0].startswith(HOLD_STATUS)):
            import datetime as dt
            from apply import log_row
            log_row(date=dt.date.today(), company="", title="(referred role - see link)", url=link, status=HOLD_STATUS,
                    action_url=link, notes="REFERRAL | applying on hold (Apply/HOLD) - applied when the hold ends")
            log(f"      on hold - kept waiting: {link[:90]}")
        return False
    from apply import ADAPTERS
    free = GOOGLE_MAX - len(google_applications())
    if re.search(r"google\.com|careers\.google", link, re.I) and not ("google" in ADAPTERS and free > 0):
        if dry:
            log(f"      Google referral - {max(free, 0)} slot(s) free now: {link[:90]}")
            return False
        return google_link(link, free, log)
    if dry:
        log(f"      WOULD APPLY (referral): {link[:110]}")
        return False
    args = [py or sys.executable, str(HERE / "apply.py"), link, "--unattended", "--referral", "--no-company-limit"]
    args.append("--force")
    log(f"      applying (referral): {link[:110]}")
    return _run_apply(args, logfile)


def _run_apply(args, logfile):
    out = open(logfile, "a", encoding="utf-8") if logfile else None
    try:
        subprocess.run(args, cwd=HERE, timeout=1500, stdout=out, stderr=subprocess.STDOUT if out else None,
                       creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
    finally:
        if out:
            out.close()
    return True


INMAIL_QUERY = "newer_than:30d -in:trash from:inmail-hit-reply@linkedin.com"
INMAIL_SEEN = HERE / "runs" / "inmail_seen.json"


def inmail_links(msg):
    out = []
    for l in job_links(msg):
        if "linkedin.com" in urlparse(l).netloc:
            jid = re.search(r"/jobs/view/(\d+)", l)
            if not jid:
                continue
            l = f"https://www.linkedin.com/jobs/view/{jid.group(1)}/"
        if l not in out:
            out.append(l)
    return out


THREAD = re.compile(r"https://www\.linkedin\.com/messaging/thread/[^\s\"'<>?]+")


def find_inmails(m):
    import jobseek
    from email.utils import parsedate_to_datetime
    m.select(f'"{gmail.special(m, chr(92) + "All")}"', readonly=True)
    found = []
    for uid in m.uid("SEARCH", "X-GM-RAW", f'"{INMAIL_QUERY}"')[1][0].split():
        msg = email.message_from_bytes(m.uid("FETCH", uid, "(BODY.PEEK[])")[1][0][1])
        body = jobseek._body(msg)
        thread = THREAD.search(body)
        try:
            when = parsedate_to_datetime(msg["Date"]).date().isoformat()
        except (TypeError, ValueError):
            when = ""
        found.append({"mid": (msg["Message-ID"] or uid.decode()).strip(), "subject": _dec(msg["Subject"]),
                      "sender": re.sub(r"\s*<.*", "", _dec(msg["From"])).strip('" ') or "a recruiter",
                      "links": inmail_links(msg), "date": when, "thread": thread.group(0) if thread else "",
                      "body": re.sub(r"https?://\S+|[͏​-‏­﻿]", "",
                                     re.split(r"-{10,}|This email was intended for", body.split("Reply ", 1)[-1])[0]).strip()[:3000]})
    best = {}
    for x in found:
        if x["mid"] not in best or (x["thread"] and not best[x["mid"]]["thread"]):
            best[x["mid"]] = x
    return list(best.values())


REPLY_DAYS = 3


def _clean_title(t):
    return re.split(r"\s+\|\s+|\s+in\s+[A-Z][\w .,-]+,\s", t or "")[0].strip()


def wanted_kinds():
    from apply import EMPLOYMENT_TYPES
    return set(EMPLOYMENT_TYPES) or {"full-time"}


def kind_ok(kind, kinds):
    return kind in ("", "unknown") or kind in kinds or (kind == "contract-to-hire" and "contract" in kinds)


def recruiter_mismatch(info, kinds):
    if not info:
        return ""
    kind = info.get("kind") or "unknown"
    if not kind_ok(kind, kinds):
        return f"{kind} work"
    if info.get("sender_is") == "staffing" and not info.get("specific_role"):
        return "a staffing firm's general outreach"
    return ""


def recruiter_unclear(info, kinds):
    if info and info.get("sender_is") == "staffing" and (info.get("kind") or "unknown") == "unknown" \
            and not kinds & {"contract", "contract-to-hire", "temporary"}:
        return "a staffing firm, and the kind of work is not stated"
    return ""


def kinds_text(kinds):
    import llm
    order = [k for k in llm.KINDS if k in kinds] or ["full-time"]
    return order[0] if len(order) == 1 else ", ".join(order[:-1]) + " or " + order[-1]


def decline_text(mail, kinds, me):
    return "\n".join([f"Hi {mail['sender'].split()[0]},", "",
                      f"Thanks for reaching out. I'm looking for {kinds_text(kinds)} roles, so I'll pass on this one.", "",
                      "Best,", me])


def reply_plan(mail):
    import config
    import llm
    from apply import P
    me = P.get("identity", {}).get("preferred_name") or P.get("identity", {}).get("first_name") or ""
    kinds, info = wanted_kinds(), mail.get("read") or {}
    bad = recruiter_mismatch(info, kinds)
    if bad:
        if config.setting("recruiter_decline", False):
            return ("decline", decline_text(mail, kinds, me), "")
        return ("ignore", "not a fit: " + bad)
    rows = {}
    with (HERE / "applications.csv").open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if r.get("url"):
                rows[key(r["url"])] = r
    line, cat = "", ""
    if mail["links"]:
        got = [rows.get(key(l)) for l in mail["links"]]
        done = [r for r in got if r and (r.get("status") or "").startswith(("submitted", "applied"))]
        if not done:
            if got and all(r and (r.get("status") or "").startswith("skipped") for r in got):
                return ("ignore", "not a fit: " + re.sub(r"^RECRUITER \| ", "", got[0].get("notes") or "")[:150])
            return ("wait", "the application is not done yet: " + ", ".join((r or {}).get("status", "not processed")[:40] for r in got))
        r = done[0]
        title = _clean_title(r.get("title")) or "the"
        what = "applied to" if r["status"].startswith("submitted") else "already applied to"
        line = f"I've {what} the {title} role." if title != "the" else f"I've {what} the role."
        cat = r.get("category") or ""
    else:
        verdict, why = llm.fit(mail["subject"], "", mail["body"])
        from apply import JD_MARKERS
        if verdict == "skip" and JD_MARKERS.search(mail["body"]):
            return ("ignore", "not a fit: " + why[:150])
        if verdict == "skip":
            return ("ask", ("fit unclear from the message: " if info.get("specific_role")
                            else "the message names no specific job: ") + why[:120])
        if verdict != "strong":
            return ("ask", "fit unclear from the message: " + why[:150])
        if recruiter_unclear(info, kinds):
            return ("ask", recruiter_unclear(info, kinds))
    resumes = {k: v for k, v in P.get("resumes", {}).items() if not k.startswith("_")}
    if cat not in resumes:
        cat, _ = llm.pick_category(mail["body"])
    if cat not in resumes:
        cat = next(iter(resumes))
    avail = (config.setting("recruiter_reply_availability") or "").strip()
    text = "\n".join([f"Hi {mail['sender'].split()[0]},", "",
                      " ".join(x for x in ("Thanks for reaching out, I'm interested.", line, "My resume is attached.") if x), "",
                      f"I'd be glad to set up a call. I'm available {avail}. Let me know what works for you." if avail
                      else "I'd be glad to set up a call. Let me know what times work for you.", "", "Best,", me])
    return ("send", text, cat)


def _norm(t):
    return " ".join((t or "").replace(" ", " ").split())


def thread_state(page, thread, me):
    page.goto(thread, wait_until="domcontentloaded", timeout=60000)
    try:
        page.locator("div.msg-form__contenteditable[contenteditable=true]").first.wait_for(state="visible", timeout=20000)
    except Exception:
        return "failed: the conversation did not open (archived or deleted?)"
    page.wait_for_timeout(2500)
    if "/messaging/thread/" not in page.url:
        return "failed: LinkedIn did not open the conversation (signed out?)"
    senders = page.locator(".msg-s-message-group__name").all_inner_texts()
    if not senders or not me:
        return "failed: could not read the conversation"
    return "already answered" if any(me in s.lower() for s in senders) else "open"


def send_reply(thread, text, pdf, log):
    import socket
    import time
    import config
    import jobapply
    from apply import P
    from playwright.sync_api import sync_playwright
    me = " ".join(x for x in (P.get("identity", {}).get("first_name"), P.get("identity", {}).get("last_name")) if x).lower()
    lock = socket.socket()
    for _ in range(1200):
        try:
            lock.bind(("127.0.0.1", config.PORT_LOCK))
            break
        except OSError:
            time.sleep(1)
    else:
        return "failed: the browser stayed busy"
    try:
        if not jobapply.port_open():
            log("      " + jobapply.launch())
        with sync_playwright() as pw:
            ctx = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{jobapply.PORT}").contexts[0]
            page = ctx.new_page()
            try:
                state = thread_state(page, thread, me)
                if state != "open":
                    return state
                box = page.locator("div.msg-form__contenteditable[contenteditable=true]").first
                if _norm(box.inner_text()):
                    return "failed: the reply box already holds a draft"
                box.click()
                for i, ln in enumerate(text.split("\n")):
                    if i:
                        page.keyboard.press("Shift+Enter")
                    if ln:
                        page.keyboard.insert_text(ln)
                if pdf:
                    page.locator("input.msg-form__attachment-upload-input[accept*='.pdf']").first.set_input_files(pdf)
                    form = page.locator("form.msg-form, .msg-form").first
                    for _ in range(30):
                        if Path(pdf).stem.lower() in form.inner_text().lower():
                            break
                        page.wait_for_timeout(1000)
                    else:
                        return "failed: the resume did not attach"
                if _norm(box.inner_text()) != _norm(text):
                    return "failed: the typed reply did not read back as written"
                send = page.locator("button.msg-form__send-button").first
                for _ in range(30):
                    if send.is_enabled():
                        break
                    page.wait_for_timeout(1000)
                else:
                    return "failed: Send stayed disabled"
                before = page.locator(".msg-s-event-listitem").count()
                send.click()
                for _ in range(20):
                    page.wait_for_timeout(1000)
                    if page.locator(".msg-s-event-listitem").count() > before and not _norm(box.inner_text()):
                        return "sent"
                return "failed: sending was not confirmed - check the conversation"
            finally:
                page.close()
    except Exception as e:
        return f"failed: {type(e).__name__}: {str(e).splitlines()[0][:120] if str(e) else ''}"
    finally:
        lock.close()


def recruiter_apply(link, log, dry, py, logfile):
    if dry:
        log(f"      WOULD APPLY (recruiter link - fit checked first, hold bypassed): {link[:110]}")
        return False
    args = [py or sys.executable, str(HERE / "apply.py"), link, "--unattended", "--recruiter", "--no-company-limit"]
    log(f"      applying (recruiter link, hold bypassed): {link[:110]}")
    return _run_apply(args, logfile)


def recruiters(log=print, dry=False, py=None, logfile=None):
    import datetime as dt
    import json
    m = gmail.connect()
    try:
        mails = find_inmails(m)
    finally:
        m.logout()
    try:
        seen = json.loads(INMAIL_SEEN.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        seen = {}
    log(f"{len(mails)} recruiter InMail(s) in 30 days, {sum(1 for x in mails if x['mid'] not in seen)} new")
    applied, done = 0, set()
    for x in mails:
        if x["mid"] not in seen:
            log(f"   InMail: {x['sender'][:30]} | {x['subject'][:70]} - {len(x['links']) or 'no'} job link(s)")
            if not dry:
                seen[x["mid"]] = {"first_seen": dt.date.today().isoformat(), "sender": x["sender"],
                                  "subject": x["subject"], "links": x["links"], "thread": x["thread"]}
        for link in x["links"]:
            done.add(key(link))
            applied += handle(link, log, dry, py, logfile, recruiter=True)
    for link in [u for u in backlog("RECRUITER") if key(u) not in done]:
        applied += handle(link, log, dry, py, logfile, recruiter=True)
    auto_replies(mails, seen, log, dry, send=config_reply())
    if not dry:
        INMAIL_SEEN.parent.mkdir(exist_ok=True)
        INMAIL_SEEN.write_text(json.dumps(seen, indent=1, ensure_ascii=False), encoding="utf-8")
    return applied


def ledger_reply(x, cat):
    import datetime as dt
    from apply import log_row
    company = title = ""
    rows = {}
    with (HERE / "applications.csv").open(encoding="utf-8") as f:
        for r in csv.DictReader(f):
            if r.get("url"):
                rows[key(r["url"])] = r
    job = next((rows[key(l)] for l in x["links"] if key(l) in rows), None)
    if job:
        company, title = job.get("company", ""), _clean_title(job.get("title"))
    else:
        try:
            import jobseek
            company = jobseek.classify(x["sender"], x["subject"], x["body"]).get("company", "")
        except Exception:
            pass
        title = x["subject"]
    log_row(date=dt.date.today(), company=company, title=title, url=x["thread"], ats="linkedin",
            status="recruiter contact: replied on LinkedIn",
            notes=f"RECRUITER | auto-reply sent to {x['sender']} with the {cat} resume" +
                  (f" | job: {x['links'][0]}" if x["links"] else ""))


def config_reply():
    import config
    return bool(config.setting("recruiter_auto_reply", False))


def read_message(x, rec, dry):
    if rec.get("read") is not None:
        return rec["read"]
    import llm
    info = llm.recruiter_read(x["sender"], x["subject"], x["body"]) or {}
    if not dry and info:
        rec["read"] = info
    return info


def auto_replies(mails, seen, log, dry, send=True):
    import datetime as dt
    from apply import P
    recent = (dt.date.today() - dt.timedelta(days=REPLY_DAYS)).isoformat()
    for x in mails:
        rec = seen.get(x["mid"]) or {}
        if rec.get("reply") or (x["date"] or "") < recent:
            continue
        x = dict(x, read=read_message(x, rec, dry))
        if not x["thread"]:
            plan = ("ask", "no conversation link in the email")
        else:
            plan = reply_plan(x)
        who = f"{x['sender'][:30]} | {x['subject'][:50]}"
        if plan[0] == "wait":
            log(f"   auto-reply later ({plan[1][:80]}): {who}")
            continue
        if plan[0] == "decline" or (plan[0] == "send" and send):
            if dry:
                log(f"   WOULD {'DECLINE' if plan[0] == 'decline' else 'REPLY'} to {who}:\n"
                    + "\n".join("      | " + l for l in plan[1].split("\n")))
                continue
            pdf = str(Path(P["resumes"][plan[2]])) if plan[0] == "send" else None
            status = send_reply(x["thread"], plan[1], pdf, log)
            log(f"   {'decline' if plan[0] == 'decline' else 'auto-reply'} {status}: {who}")
            if plan[0] == "decline":
                status = "declined" if status == "sent" else "ignore"
            extra = {"text": plan[1], "resume": plan[2]}
            if status == "sent":
                ledger_reply(x, plan[2])
        else:
            status = "fit" if plan[0] == "send" else plan[0]
            log(f"   no auto-reply ({status}: {(plan[1] if plan[0] != 'send' else 'replying is off')[:80]}): {who}")
            extra = {"why": plan[1] if plan[0] != "send" else ""}
        if not dry:
            rec["reply"] = {"date": dt.date.today().isoformat(), "status": status, **extra}
            seen[x["mid"]] = rec


def run(log=print, dry=False, py=None, logfile=None):
    m = gmail.connect()
    try:
        mails = find(m, log)
    finally:
        m.logout()
    log(f"{len(mails)} referral email(s) with job links")
    applied, seen, done_uids = 0, set(), []
    for uid, subj, frm, links in mails:
        log(f"   referral: {subj[:70]}  ({frm[:40]}) - {len(links)} link(s)")
        for link in links:
            seen.add(key(link))
            applied += handle(link, log, dry, py, logfile)
        if not dry and all(key(l) in ledger_state() for l in links):
            done_uids.append(uid)
    todo = [u for u in backlog() if key(u) not in seen]
    if todo:
        log(f"   referral backlog in the ledger: {len(todo)} link(s)")
    for link in todo:
        applied += handle(link, log, dry, py, logfile)
    if done_uids and not dry:
        m = gmail.connect()
        try:
            n = gmail.trash(m, done_uids)
        finally:
            m.logout()
        log(f"moved {n} referral email(s) to Gmail Trash - their links are in the ledger")
    return applied, len(done_uids)


if __name__ == "__main__":
    sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    run(dry="--dry-run" in sys.argv)
    recruiters(dry="--dry-run" in sys.argv)
