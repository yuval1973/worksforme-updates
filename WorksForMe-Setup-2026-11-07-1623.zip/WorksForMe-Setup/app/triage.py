import csv
import datetime as dt
import re
import sys
from pathlib import Path
from urllib.parse import urlparse

from playwright.sync_api import sync_playwright

import jobapply
import llm
from apply import detect_ats, excluded, log_row, MAX_APPLICANTS, LOG, pay_below_floor, note_low_pay, fte_check

HERE = Path(__file__).parent
SEARCH = "https://mail.google.com/mail/u/0/#search/from%3Ajobalerts-noreply%40linkedin.com"

sys.stdout.reconfigure(encoding="utf-8", errors="replace")


def seen_urls():
    ids = set()
    for f in [LOG, *sorted((HERE / "runs").glob("triage-*.csv"))]:
        if f.exists():
            with f.open(encoding="utf-8") as fh:
                for r in csv.DictReader(fh):
                    m = re.search(r"jobs/view/(\d+)", r.get("url") or "")
                    if m and r.get("verdict", "") != "error" and r.get("status", "") != "error":
                        ids.add(m.group(1))
    return ids


def alert_job_ids(page, n_emails):
    page.goto(SEARCH, wait_until="domcontentloaded")
    page.wait_for_selector("tr.zA", timeout=30000)
    ids = {}
    for i in range(n_emails):
        rows = page.locator("tr.zA")
        if i >= rows.count():
            break
        rows.nth(i).click()
        page.wait_for_timeout(2500)
        found = page.evaluate("""() => {
            const out = {};
            for (const a of document.querySelectorAll('div[role=main] a[href*="linkedin.com"]')) {
              const m = a.href.match(/jobs\\/view\\/(\\d+)/); if (!m || out[m[1]]) continue;
              const card = a.closest('table') || a.parentElement;
              out[m[1]] = (card.innerText || a.innerText).replace(/\\s+/g, ' ').trim().slice(0, 140);
            }
            return out; }""")
        ids.update(found)
        page.go_back()
        page.wait_for_selector("tr.zA", timeout=30000)
    return ids


class NotSignedIn(RuntimeError):
    pass


def check_job(ctx, page, job_id):
    url = f"https://www.linkedin.com/jobs/view/{job_id}/"
    for attempt in range(3):
        try:
            page.goto(url, wait_until="domcontentloaded", timeout=45000)
            break
        except Exception:
            if attempt == 2:
                raise
            page.wait_for_timeout(3000)
    page.wait_for_timeout(2500)
    if re.search(r"authwall|/login|/signup|/uas/", page.url) or re.search(r"join linkedin|sign up", page.title(), re.I)             or not any(c["name"] == "li_at" for c in ctx.cookies("https://www.linkedin.com")):
        raise NotSignedIn("LinkedIn is not signed in in the job-apply Chrome - sign in once, then rerun")
    main = page.locator("main").inner_text(timeout=15000)
    lines = [l.strip() for l in main.splitlines() if l.strip()]
    r = {"url": url, "company": lines[0] if lines else "", "title": lines[1] if len(lines) > 1 else ""}
    from apply import linkedin_location, note_location
    note_location(url, linkedin_location(main))
    head = " ".join(lines[:6])
    r["_head12"] = " ".join(lines[:12])
    m = re.search(r"·\s*((?:Reposted )?\d+ \w+ ago)", head)
    r["posted"] = m.group(1) if m else ""
    m = re.search(r"Candidates who clicked apply\s+([\d,]+)", main) or \
        re.search(r"([\d,]+) (?:people clicked apply|applicants)", head)
    r["applicants"] = int(m.group(1).replace(",", "")) if m else (101 if "Over 100" in head else None)
    over = re.search(r"\bover\s+([\d,]+)\s+(?:applicants|people clicked apply)", head, re.I)
    if over and not re.search(r"Candidates who clicked apply\s+[\d,]+", main):
        r["applicants"] = int(over.group(1).replace(",", "")) + 1
    jd = re.split(r"Set alert for similar jobs|See how you compare", main.split("About the job", 1)[-1])[0]
    from apply import note_pay
    note_pay(url, jd)
    if excluded(r["company"], r["title"]):
        r["ats"] = "-"
    elif re.search(r"\bEasy Apply\b", head):
        r["ats"] = "easy-apply"
    elif r["applicants"] is not None and r["applicants"] > MAX_APPLICANTS:
        r["ats"] = "?"
    else:
        r["ats"] = "?"
        link = page.get_by_role("link", name=re.compile("Apply on company website", re.I))
        if link.count():
            try:
                with ctx.expect_page(timeout=15000) as newp:
                    link.first.click()
                emp = newp.value
                emp.wait_for_load_state("domcontentloaded")
                from apply import resolve_ats
                hop = resolve_ats(ctx, emp)
                r["ats"] = (detect_ats(hop.url) if hop else None) or urlparse(emp.url).netloc
                for pg in {emp, hop} - {None, page}:
                    pg.close()
            except Exception as e:
                r["ats"] = f"? ({type(e).__name__})"
    crowded = r["applicants"] is not None and r["applicants"] > MAX_APPLICANTS
    why = excluded(r["company"], r["title"])
    if why:
        r["verdict"], r["reason"] = "skip", why
    elif crowded:
        r["verdict"], r["reason"] = "skip", f"crowded: {r['applicants']} applicants"
    elif nofte := fte_check(r["company"], r["title"], jd, r.get("_head12")):
        r["verdict"], r["reason"] = "skip", nofte
    elif low := pay_below_floor(jd):
        r["verdict"], r["reason"] = "skip", low
        note_low_pay(r["company"], r["title"], r["reason"])
    else:
        r["verdict"], r["reason"] = fit_or_error(r["title"], r["company"], jd)
    keep_jd(r.get("url"), jd)
    return r


def keep_jd(url, jd):
    m = re.search(r"jobs/view/(\d+)", url or "")
    if m and jd:
        p = HERE / "runs" / "jd" / f"{m.group(1)}.txt"
        if not p.exists():
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(jd[:15000], encoding="utf-8")


def fit_or_error(title, company, jd):
    v, why = llm.fit(title, company, jd)
    return ("error", why) if why.startswith("fit check failed") else (v, why)


def score(ids):
    done = seen_urls()
    todo = [j for j in ids if j not in done]
    print(f"{len(ids)} jobs; {len(ids) - len(todo)} already handled; {len(todo)} to score")
    rows = []
    if todo:
        if not jobapply.port_open():
            print(jobapply.launch())
        with sync_playwright() as pw:
            ctx = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{jobapply.PORT}").contexts[0]
            page = ctx.new_page()
            for j in todo:
                try:
                    r = check_job(ctx, page, j)
                except NotSignedIn as e:
                    print("STOP:", e)
                    break
                except Exception as e:
                    r = {"url": f"https://www.linkedin.com/jobs/view/{j}/", "company": (ids.get(j) or "")[:40],
                         "verdict": "error", "reason": str(e).splitlines()[0][:200] if str(e) else type(e).__name__}
                    log_row(date=dt.date.today(), company=r["company"], url=r["url"], status="error",
                            notes="triage: " + r["reason"])
                rows.append(r)
                print(f"{r.get('verdict','?'):8} {str(r.get('applicants','?')):>4} appl | {r.get('ats','?'):12} | "
                      f"{r.get('company','')[:22]:22} | {r.get('title','')[:48]:48} | {r.get('reason','')[:110]}")
            page.close()
    out = HERE / "runs" / f"triage-{dt.datetime.now():%Y-%m-%d_%H%M}.csv"
    out.parent.mkdir(exist_ok=True)
    with out.open("w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["verdict", "applicants", "posted", "ats", "company", "title", "url", "reason"])
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in w.fieldnames})
    print("saved", out.name)
    return rows


def run():
    a = sys.argv[1:]
    n = int(a[a.index("--emails") + 1]) if "--emails" in a else 1
    if not jobapply.port_open():
        print(jobapply.launch())
    with sync_playwright() as pw:
        ctx = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{jobapply.PORT}").contexts[0]
        page = ctx.new_page()
        ids = alert_job_ids(page, n)
        page.close()
    score(ids)


def main():
    try:
        run()
    finally:
        print("browser:", jobapply.close_chrome())


if __name__ == "__main__":
    main()
