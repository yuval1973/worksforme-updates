import csv
import re
import datetime as dt
import html
import smtplib
import sys
from email.mime.image import MIMEImage
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

HERE = Path(__file__).parent
LOG = HERE / "applications.csv"
import config

ME = config.EMAIL
TO = config.REPORT_TO
LOGO = HERE / "product" / "icon-64.png"

sys.stdout.reconfigure(encoding="utf-8", errors="replace")

INK, MUTED, LINE, BG, ACCENT, AMBER = "#171c24", "#5c6878", "#e2e7ee", "#f4f6fa", "#12808c", "#f4a53a"
TONE = {"good": ("#157a47", "#e3f4ea"), "warn": ("#9a5800", "#fff3dc"), "bad": ("#b42318", "#fdecea"),
        "info": ("#12808c", "#e2f2f3")}


def app_password():
    import vault
    return vault.get("EMAIL_PASS")


def collect(day, asks=None):
    rows, overall, first_wait = [], {}, {}
    FIX = ("waiting: site not supported", "waiting: site broken")
    if LOG.exists():
        with LOG.open(encoding="utf-8") as f:
            latest = {}
            for r in csv.DictReader(f):
                if r.get("date") == day:
                    latest[r.get("url") or id(r)] = r
                overall[r.get("url") or id(r)] = r
                if (r.get("status") or "").startswith(FIX):
                    first_wait.setdefault(r.get("url"), r.get("date"))
            rows = list(latest.values())
    st = lambda r: (r.get("status") or "").lower()
    review = [] if config.AUTO_SUBMIT else [r for r in rows if st(r).startswith("ready")]
    applied = [r for r in rows if st(r).startswith(("submitted", "applied", "ready")) and r not in review]
    on_file = [r for r in applied if "already on file" in st(r)]
    applied = [r for r in applied if r not in on_file]
    product = config.setting("edition") == "product"
    items = [needs_item(r, product) for r in rows if st(r).startswith("needs you")]
    unconfirmed = [r for r in rows if st(r).startswith("submit clicked")]
    errors = [r for r in rows if st(r).startswith("error")]
    handled = [handled_item(r) for r in rows if st(r).startswith(FIX) and first_wait.get(r.get("url")) == day] + \
        [n for n in items if n["kind"] == "handled"]
    return dict(day=day, applied=[applied_item(r) for r in applied], on_file=on_file, review=review,
                needs=[n for n in items if n["kind"] == "you"] + [review_item(r) for r in review], errors=errors,
                responses=responses(), inmails=recruiter_inmails(day, overall), asks=list(asks or []), product=product,
                fixes=handled,
                unconfirmed=unconfirmed,
                still=sum(1 for r in overall.values() if st(r).startswith("needs you")
                          and (dt.date.fromisoformat(day) - dt.timedelta(days=14)).isoformat() <= (r.get("date") or "") < day))


def applied_item(r):
    s, notes = (r.get("status") or "").lower(), r.get("notes") or ""
    tags = ([] if s.startswith("submitted") else ["by you"] if s.startswith("applied") else ["filled - waiting on the Review page"])
    if "referral" in s + notes.lower():
        tags.append("referral")
    if notes.startswith("RECRUITER"):
        tags.append("recruiter")
    return dict(row=r, tags=tags)


KIND_LABEL = {"you": "Only you can do this", "handled": "Service request filed"}


def review_item(r):
    import email_actions
    return dict(row=r, kind="you", label="Waiting for your Submit", why="",
                todo="Check it and press Submit. It isn't sent until you do.",
                act=("Finish in browser", email_actions.link(email_actions.new("finish", r))))


REVIEW_FULL, NUDGE_AFTER = 10, 5
BY_YOU = re.compile(r"^submitted by (you|the user)\b", re.I)


def last_user_report():
    try:
        import json
        import support
        sent = json.loads(support.SENT.read_text(encoding="utf-8"))
    except (ImportError, OSError, ValueError):
        return ""
    return max((v.get("date") or "" for v in sent.values() if " from the user - " in (v.get("subject") or "")), default="")


def review_nudge(rows, settings):
    since = max(last_user_report(), str(settings.get("review_nudge_at") or ""))
    if settings.get("auto_submit"):
        return 0, since
    n = sum(1 for r in rows if (r.get("status") or "").startswith("submitted") and BY_YOU.search(r.get("notes") or "")
            and (r.get("date") or "") > since)
    return (n if n >= NUDGE_AFTER else 0), since


def nudge_ask(n):
    return (f"Let {config.APP_NAME} submit by itself?",
            f"You've submitted {n} applications {config.APP_NAME} filled. When you're ready, turn on \"Submit by itself\" "
            f"on the dashboard.")


def apply_yourself(r):
    return ("Apply yourself", r.get("url") or r.get("action_url"))


NOTICES = f"{{app}} notices the employer's confirmation email."


def reported():
    return bool(config.setting("support_reports", False) and config.setting("support_to"))


def handled_item(r, days=None, retried=True, tries=None):
    app = config.APP_NAME
    if reported():
        first = (f"A service request was filed {days} days ago and is still open." if days else
                 "A service request was filed.")
        rest = ("Still interested? Apply yourself." if days else
                f"{app} tries again by itself once it is resolved. You can also apply yourself." if retried else
                "You can apply yourself.")
        label = KIND_LABEL["handled"]
    else:
        first = f"The employer's site did not work on {tries} tries." if tries else ""
        rest = (f"{app} tries again on its next runs. You can also apply yourself." if retried else
                "You can apply yourself.")
        label = "Apply yourself"
    return dict(row=r, kind="handled", label=label, todo=f"{first} {rest}".strip(), act=apply_yourself(r))


def needs_item(r, product):
    notes = r.get("notes") or ""
    s = (r.get("status") or "").lower()
    import email_actions
    if re.search(r"security code|verification code|captcha|bot check|sign-?in|create (an |the )?account"
                 r"|ready for review", notes + " " + s, re.I):
        return dict(row=r, kind="you", label=KIND_LABEL["you"], why=notes,
                    todo="Sign in or enter a code to finish this application.",
                    act=("Finish in browser", email_actions.link(email_actions.new("finish", r))))
    if "your call" in notes:
        return dict(row=r, kind="you", label=KIND_LABEL["you"], why=notes,
                    todo="A partial fit from a recruiter. Apply yourself if you're interested.", act=apply_yourself(r))
    days = re.search(r"in (\d+) days|after (\d+) days", notes)
    n = next((g for g in days.groups() if g), None) if days else None
    tries = re.search(r"on (\d+) tries", notes)
    return dict(handled_item(r, int(n) if n else None, retried=False, tries=int(tries.group(1)) if tries else None),
                why=notes)


def responses():
    import jobseek
    cache = jobseek._load()
    cut = dt.datetime.now(dt.timezone.utc) - dt.timedelta(hours=26)
    fresh = [c for c in jobseek.responses(cache, days=2) if dt.datetime.fromisoformat(c["date"]) >= cut]
    lines = {}
    for c, n in jobseek.grouped(fresh):
        co = jobseek.norm(c["company"])
        if c.get("role"):
            lines[(co, c["role"])] = [c, n + lines.pop((co, None), [None, 0])[1]]
        elif any(k[0] == co and k[1] for k in lines):
            k = next(k for k in lines if k[0] == co and k[1])
            lines[k][1] += n
        else:
            lines.setdefault((co, None), [c, 0])[1] += n
    return [c for c, _n in lines.values()]


def recruiter_inmails(day, overall):
    import json
    try:
        seen = json.loads((HERE / "runs" / "inmail_seen.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    try:
        import jobseek
        known = jobseek._load()
    except Exception:
        known = {}
    by_url = {(r.get("url") or "").split("?")[0].rstrip("/").lower(): r for r in overall.values()}
    out = []
    for mid, m in seen.items():
        rep = m.get("reply") or {}
        if m.get("first_seen") != day and rep.get("date") != day:
            continue
        s = rep.get("status", "") if rep.get("date") == day else ""
        if rep.get("status") in ("ignore", "declined"):
            continue
        who = f"From {(m.get('sender') or 'a recruiter').rstrip('. ')}."
        ask = f"{who} Reply if it interests you."
        reply = (("Answered", "good", f"{who} Replied on LinkedIn with your {rep.get('resume')} resume:", rep.get("text") or "")
                 if s == "sent" else
                 ("You replied", "info", who, "") if s == "already answered" else
                 ("Not sent", "bad", f"{who} Reply on LinkedIn.", "") if s.startswith("failed") else
                 ("A fit", "good", ask, "") if s == "fit" else
                 ("Your call", "info", ask, "") if s == "ask" else
                 ("", "info", who if m.get("links") else ask, ""))
        c = dict(m.get("read") or {}, **{k: v for k, v in (known.get(mid) or {}).items() if v})
        links = []
        for link in m.get("links") or []:
            r = by_url.get(link.split("?")[0].rstrip("/").lower())
            ls = (r.get("status") or "").lower() if r else ""
            notes = re.sub(r"^RECRUITER \| ", "", (r or {}).get("notes") or "")
            links.append((link, "Applied - tell the recruiter you applied" if ls.startswith("submitted") else
                          "Already applied (on file at the employer) - tell the recruiter" if ls.startswith("applied") else
                          f"Not a fit, not applied: {notes[:120]}" if ls.startswith("skipped") else
                          "Needs you - see above" if ls.startswith(("needs you", "submit clicked")) else
                          f"Error, retried next run: {notes[:100]}" if ls.startswith("error") else
                          ls or "Not processed yet"))
        out.append(dict(sender=m.get("sender") or "", subject=m.get("subject") or "", reply=reply, links=links,
                        thread=m.get("thread") or "", company=c.get("company") or "",
                        role=c.get("role") or m.get("subject") or "A role"))
    return out


def subject_of(d, hold=None, shadow=None):
    day = dt.date.fromisoformat(d["day"])
    n = len(d["needs"]) + len(d["asks"])
    parts = ([f"{len(d['applied'])} applied"] if d["applied"] else []) + \
        ([f"{len(d['fixes'])} pending"] if d["fixes"] else []) + \
        ([f"{len(d['inmails'])} from recruiters"] if d["inmails"] else []) + \
        ([f"{n} need{'s' if n == 1 else ''} you"] if n else [])
    return (("[shadow] " if shadow is not None else "") + f"{config.APP_NAME} update, {day:%a %b} {day.day}: " +
            (", ".join(parts) or "nothing new"))


def worth_sending(d, shadow=None):
    return bool(d["applied"] or d["needs"] or d["asks"] or d["fixes"] or d["inmails"] or shadow is not None)


def job(r):
    return f"{r.get('company') or '?'} - {r.get('title') or '?'}"


def text(d, hold=None, shadow=None):
    out = []
    if shadow is not None:
        out += [f"SHADOW MODE - nothing was applied, moved or sent. Would have applied ({len(shadow)}):"] + \
            [f"- {x}" for x in shadow] + [""]
    def item(n):
        return [f"- {job(n['row'])}   [{n['label']}]", f"  {n['todo']}"] + \
            ([f"  What it asks: {short(n['why'], 300)}"] if n["kind"] == "you" and n.get("why") else []) + \
            ([f"  {n['act'][0]}: {n['act'][1]}"] if n.get("act") else []) + [""]
    if d["applied"]:
        out.append(f"APPLIED ({len(d['applied'])})")
        out += [f"- {job(a['row'])}" + "".join(f"   [{t}]" for t in a["tags"]) for a in d["applied"]] + [""]
    if d["fixes"]:
        out.append(f"PENDING ({len(d['fixes'])}) - a service request was filed for each")
        for n in d["fixes"]:
            out += item(n)
    if d["inmails"]:
        out.append(f"RECRUITER MESSAGES ({len(d['inmails'])})")
        for m in d["inmails"]:
            tag, _tone, line, body = m["reply"]
            out.append(f"- {short(m['role'], 90)}" + (f" | {m['company']}" if m["company"] else "") + (f"   [{tag}]" if tag else ""))
            out.append(f"  {line}")
            out += ["    | " + l for l in body.split("\n") if body]
            out += [f"  {link}\n    -> {what}" for link, what in m["links"]]
            if m["thread"]:
                out.append(f"  Open the message: {m['thread']}")
        out.append("")
    if d["needs"] or d["asks"]:
        out.append(f"NEEDS YOU ({len(d['needs']) + len(d['asks'])})")
        first, last = asks_split(d["asks"])
        for title, todo in first:
            out += [f"- {title}", f"  {todo}", ""]
        for n in d["needs"]:
            out += item(n)
        for title, todo in last:
            out += [f"- {title}", f"  {todo}", ""]
    return "\n".join(out)


def asks_split(asks):
    later = nudge_ask(0)[0]
    return [a for a in asks if a[0] != later], [a for a in asks if a[0] == later]


def short(s, n):
    s = " ".join(str(s or "").split())
    return s if len(s) <= n else s[:n - 1].rstrip() + "…"


def html_page(d, hold=None, shadow=None, logo=True):
    e = lambda s: html.escape(str(s or ""), quote=True)
    font = "font-family:'Segoe UI',system-ui,-apple-system,Helvetica,Arial,sans-serif;"
    a = lambda url, label, style="": f'<a href="{e(url)}" style="color:{ACCENT};text-decoration:none;{style}">{e(label)}</a>'

    def chip(n, label, tone):
        fg, bg = TONE[tone]
        return (f'<td style="padding:4px 12px;border-radius:999px;background:{bg};color:{fg};font-size:13px;font-weight:600;'
                f'white-space:nowrap">{e(n)} {e(label)}</td><td style="width:8px;font-size:1px">&nbsp;</td>')

    def section(title, tone, body):
        fg = TONE[tone][0]
        return (f'<tr><td style="padding:22px 28px 4px"><div style="font-size:12px;font-weight:700;letter-spacing:.06em;'
                f'text-transform:uppercase;color:{fg}">{e(title)}</div></td></tr>'
                f'<tr><td style="padding:6px 28px 0">{body}</td></tr>')

    def card(tone, inner):
        return (f'<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="margin:0 0 10px;'
                f'border:1px solid {LINE};border-left:4px solid {TONE[tone][0]};border-radius:8px">'
                f'<tr><td style="padding:12px 14px">{inner}</td></tr></table>')

    def tags_row(tags, tone="good"):
        fg, bg = TONE[tone]
        cells = "".join(f'<td style="padding:1px 8px;border-radius:999px;background:{bg};color:{fg};font-size:11px;'
                        f'font-weight:600;white-space:nowrap">{e(t)}</td><td style="width:6px;font-size:1px">&nbsp;</td>'
                        for t in tags)
        return (f'<table role="presentation" cellpadding="0" cellspacing="0" style="margin-top:8px"><tr>{cells}</tr></table>'
                if tags else "")

    def title_of(r, tab, tags=(), tone="good"):
        posting = r.get("url") or ""
        head = (a(posting, r.get("title") or "?", f"color:{INK};font-weight:600") if posting.startswith("http")
                else f'<span style="font-weight:600">{e(r.get("title"))}</span>')
        return (f'<div style="font-size:15px;line-height:1.35">{head}</div>'
                f'<div style="color:{INK};font-size:14px;margin-top:2px">{e(r.get("company"))}</div>{tags_row(tags, tone)}')

    def button(label, url, tone="info", outline=False):
        look = (f"background:#ffffff;color:{TONE[tone][0]};border:1px solid {TONE[tone][0]}" if outline else
                f"background:{TONE[tone][0]};color:#ffffff;border:1px solid {TONE[tone][0]}")
        return (f'<a href="{e(url)}" style="display:inline-block;margin-top:10px;padding:7px 14px;border-radius:7px;'
                f'{look};font-size:13px;font-weight:600;text-decoration:none">{e(label)}</a>')

    parts = []
    if shadow is not None:
        parts.append(section(f"Shadow mode - would have applied ({len(shadow)})", "info",
                             "".join(card("info", e(x)) for x in shadow) or "nothing"))
    kind_tone = {"you": "warn", "handled": "info"}

    def need(n):
        act = n.get("act") if n.get("act") and str(n["act"][1] or "").startswith("http") else None
        return card(kind_tone[n["kind"]],
            title_of(n["row"], "needs", [n["label"]], kind_tone[n["kind"]])
            + f'<div style="font-size:13px;margin-top:8px;color:{INK}">{e(n["todo"])}</div>'
            + (f'<div style="font-size:12px;margin-top:6px;color:{MUTED}">What it asks: {e(short(n["why"], 300))}</div>'
               if n["kind"] == "you" and n.get("why") else "")
            + (button(act[0], act[1], "info", outline=n["kind"] != "you") if act else ""))
    if d["applied"]:
        parts.append(section(f"Applied ({len(d['applied'])})", "good", "".join(
            card("good", title_of(x["row"], "applied", x["tags"])) for x in d["applied"])))
    if d["fixes"]:
        parts.append(section(f"Pending ({len(d['fixes'])})", "info", "".join(need(n) for n in d["fixes"])))
    if d["inmails"]:
        def mail(m):
            tag, tone, line, body = m["reply"]
            thread = m["thread"] if m["thread"].startswith("http") else ""
            head = (a(thread, short(m["role"], 120), f"color:{INK};font-weight:600") if thread
                    else f'<span style="font-weight:600">{e(short(m["role"], 120))}</span>')
            inner = (f'<div style="font-size:15px;line-height:1.35">{head}</div>'
                     + (f'<div style="color:{INK};font-size:14px;margin-top:2px">{e(m["company"])}</div>' if m["company"] else "")
                     + (tags_row([tag], tone) if tag else "")
                     + f'<div style="font-size:13px;margin-top:8px;color:{INK}">{e(line)}</div>')
            if body:
                inner += (f'<div style="font-size:13px;margin-top:6px;padding:8px 10px;background:{BG};border-radius:6px;'
                          f'white-space:pre-wrap;color:{INK}">{e(body)}</div>')
            for link, what in m["links"]:
                inner += f'<div style="font-size:13px;margin-top:6px">{a(link, short(link, 70))}<br>{e(what)}</div>'
            return card("info", inner + (button("Open the message", thread, "info", outline=True) if thread else ""))
        parts.append(section(f"Recruiter messages ({len(d['inmails'])})", "info", "".join(mail(m) for m in d["inmails"])))
    n_you = len(d["needs"]) + len(d["asks"])
    if n_you:
        first, last = asks_split(d["asks"])
        ask = lambda title, todo: card("warn", f'<div style="font-size:15px;font-weight:600">{e(title)}</div>'
                                               f'<div style="font-size:13px;margin-top:8px;color:{INK}">{e(todo)}</div>')
        parts.append(section(f"Needs you ({n_you})", "warn", "".join(ask(*a) for a in first)
                             + "".join(need(n) for n in d["needs"]) + "".join(ask(*a) for a in last)))
    day = dt.date.fromisoformat(d["day"])
    chips = ((chip(len(d["applied"]), "applied", "good") if d["applied"] else "")
             + (chip(len(d["fixes"]), "pending", "info") if d["fixes"] else "")
             + (chip(len(d["inmails"]), "from recruiters", "info") if d["inmails"] else "")
             + (chip(n_you, "need you" if n_you != 1 else "needs you", "warn") if n_you else ""))
    icon = (f'<img src="cid:logo" width="28" height="28" alt="" style="vertical-align:middle;border:0;margin-right:9px">'
            if logo else "")
    return f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width">
<meta name="color-scheme" content="light"><title>{e(config.APP_NAME)}</title></head>
<body style="margin:0;padding:0;background:{BG}">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:{BG};{font}color:{INK}"><tr>
<td align="center" style="padding:24px 12px">
<table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="max-width:600px;background:#ffffff;
border:1px solid {LINE};border-top:4px solid {ACCENT};border-radius:12px">
<tr><td style="padding:22px 28px 0"><table role="presentation" width="100%" cellpadding="0" cellspacing="0"><tr>
<td style="font-size:18px;font-weight:700;letter-spacing:-.01em">{icon}{e(config.APP_NAME)}</td>
<td align="right" style="font-size:13px;color:{MUTED}">{day:%A, %B} {day.day}</td></tr></table></td></tr>
<tr><td style="padding:14px 28px 0"><table role="presentation" cellpadding="0" cellspacing="0"><tr>{chips}</tr></table></td></tr>
{"".join(parts)}
<tr><td style="height:24px;font-size:0;line-height:0">&nbsp;</td></tr>
</table></td></tr></table></body></html>"""


def compose(day, asks=None, hold=None, shadow=None):
    d = collect(day, asks)
    return dict(subject=subject_of(d, hold, shadow), text=text(d, hold, shadow).replace("JobBot", config.APP_NAME),
                html=html_page(d, hold, shadow, logo=LOGO.exists()), anything=worth_sending(d, shadow), data=d)


def build(day, asks=None):
    r = compose(day, asks)
    return r["subject"], r["text"], r["anything"]


def send(subject, body, html_body=None):
    if html_body is None:
        msg = MIMEText(body, "plain", "utf-8")
    else:
        msg = MIMEMultipart("related")
        alt = MIMEMultipart("alternative")
        alt.attach(MIMEText(body, "plain", "utf-8"))
        alt.attach(MIMEText(html_body, "html", "utf-8"))
        msg.attach(alt)
        if "cid:logo" in html_body and LOGO.exists():
            img = MIMEImage(LOGO.read_bytes(), "png")
            img.add_header("Content-ID", "<logo>")
            img.add_header("Content-Disposition", "inline", filename="logo.png")
            msg.attach(img)
    me, to = config.EMAIL, config.REPORT_TO or config.EMAIL
    msg["Subject"], msg["From"], msg["To"] = subject, me, to
    if config.setting("mail_source") == "forward":
        import fwdmail
        fwdmail.send_message(msg, "self")
        return
    with smtplib.SMTP("smtp.gmail.com", 587, timeout=30) as s:
        s.starttls()
        s.login(me, app_password())
        s.sendmail(me, [to], msg.as_string())


def main():
    a = sys.argv[1:]
    day = a[a.index("--date") + 1] if "--date" in a else dt.date.today().isoformat()
    r = compose(day)
    if "--html" in a:
        Path(a[a.index("--html") + 1]).write_text(r["html"].replace("cid:logo", LOGO.as_uri()), encoding="utf-8")
    if "--dry-run" in a or "--html" in a:
        print("SUBJECT:", r["subject"], "\n")
        print(r["text"])
        print("\n(would send)" if r["anything"] else "\n(quiet day - nothing would be sent)")
        return
    if not r["anything"]:
        print("nothing applied and nothing needs you - no email sent")
        return
    send(r["subject"], r["text"], r["html"])
    print("sent:", r["subject"])


if __name__ == "__main__":
    main()
