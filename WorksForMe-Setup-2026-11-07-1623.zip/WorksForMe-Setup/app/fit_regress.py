import csv, glob, os, re, sys
os.chdir(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.getcwd())
sys.argv = sys.argv[:1]
sys.stdout.reconfigure(encoding="utf-8")
from playwright.sync_api import sync_playwright
import jobapply, llm, apply

import json
WANT = json.loads(open("fit_cases.json", encoding="utf-8-sig").read())["cases"]
rows = {}
for f in sorted(glob.glob("runs/triage-*.csv")):
    for r in csv.DictReader(open(f, encoding="utf-8")):
        hay = (r["company"] + " " + r["title"]).lower()
        k = next((k for k in WANT if all(w in hay for w in k.lower().split())), None)
        if k and k not in rows:
            rows[k] = r
missing = [k for k in WANT if k not in rows]
if missing:
    print("not found in triage history:", missing)
jobapply.launch()
bad = 0
try:
    with sync_playwright() as pw:
        ctx = pw.chromium.connect_over_cdp(f"http://127.0.0.1:{jobapply.PORT}").contexts[0]
        p = ctx.new_page()
        for k, r in rows.items():
            p.goto(r["url"], wait_until="domcontentloaded"); p.wait_for_timeout(3000)
            main = p.locator("main").inner_text(timeout=15000)
            jd = re.split(r"Set alert for similar jobs|See how you compare", main.split("About the job", 1)[-1])[0]
            why = apply.excluded(r["company"], r["title"], declined=False)
            runs = [("skip", why)] * 2 if why else [llm.fit(r["title"], r["company"], jd) for _ in range(2)]
            got = [v == "strong" for v, _ in runs]
            ok = all(g == WANT[k] for g in got)
            bad += not ok
            print(f"{'OK' if ok else 'XX'} {k[:34]:34} want={'apply' if WANT[k] else 'skip':5} "
                  f"got={[v for v, _ in runs]}  {runs[0][1][:110]}")
finally:
    print("browser:", jobapply.close_chrome())
print(f"{len(rows) - bad}/{len(rows)} correct and stable")
if not rows:
    print("NOTHING TESTED - no fit case matched a job in runs/triage-*.csv (run the daily dry run first, then use\n"
          "fragments of real 'company title' strings from those files in fit_cases.json)")
sys.exit(1 if bad or not rows else 0)
