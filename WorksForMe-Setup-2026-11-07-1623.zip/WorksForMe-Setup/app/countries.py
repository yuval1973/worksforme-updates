import re
import unicodedata

import i18naddress
import phonenumbers

_DATA = i18naddress.load_validation_data("all")

US_STATES = [("AL", "Alabama"), ("AK", "Alaska"), ("AZ", "Arizona"), ("AR", "Arkansas"), ("CA", "California"),
             ("CO", "Colorado"), ("CT", "Connecticut"), ("DE", "Delaware"), ("DC", "District of Columbia"), ("FL", "Florida"),
             ("GA", "Georgia"), ("HI", "Hawaii"), ("ID", "Idaho"), ("IL", "Illinois"), ("IN", "Indiana"), ("IA", "Iowa"),
             ("KS", "Kansas"), ("KY", "Kentucky"), ("LA", "Louisiana"), ("ME", "Maine"), ("MD", "Maryland"),
             ("MA", "Massachusetts"), ("MI", "Michigan"), ("MN", "Minnesota"), ("MS", "Mississippi"), ("MO", "Missouri"),
             ("MT", "Montana"), ("NE", "Nebraska"), ("NV", "Nevada"), ("NH", "New Hampshire"), ("NJ", "New Jersey"),
             ("NM", "New Mexico"), ("NY", "New York"), ("NC", "North Carolina"), ("ND", "North Dakota"), ("OH", "Ohio"),
             ("OK", "Oklahoma"), ("OR", "Oregon"), ("PA", "Pennsylvania"), ("RI", "Rhode Island"), ("SC", "South Carolina"),
             ("SD", "South Dakota"), ("TN", "Tennessee"), ("TX", "Texas"), ("UT", "Utah"), ("VT", "Vermont"),
             ("VA", "Virginia"), ("WA", "Washington"), ("WV", "West Virginia"), ("WI", "Wisconsin"), ("WY", "Wyoming")]

_NAMES = {
    "AX": "Aland Islands", "BG": "Bulgaria", "BN": "Brunei", "BL": "Saint Barthelemy", "CC": "Cocos (Keeling) Islands",
    "CD": "Democratic Republic of the Congo", "CG": "Republic of the Congo", "CI": "Cote d'Ivoire",
    "CW": "Curacao", "CZ": "Czech Republic", "DO": "Dominican Republic", "FK": "Falkland Islands", "FM": "Micronesia",
    "GD": "Grenada", "GG": "Guernsey", "GS": "South Georgia and the South Sandwich Islands", "GW": "Guinea-Bissau",
    "HM": "Heard Island and McDonald Islands", "HU": "Hungary", "JE": "Jersey", "LA": "Laos", "MD": "Moldova",
    "MK": "North Macedonia", "MO": "Macau", "NR": "Nauru", "PA": "Panama", "PM": "Saint Pierre and Miquelon",
    "PS": "Palestine", "RE": "Reunion", "RS": "Serbia", "RU": "Russia", "SG": "Singapore",
    "SJ": "Svalbard and Jan Mayen", "ST": "Sao Tome and Principe", "SZ": "Eswatini", "TL": "Timor-Leste",
    "TZ": "Tanzania", "VA": "Vatican City", "VC": "Saint Vincent and the Grenadines", "VG": "British Virgin Islands",
    "VI": "U.S. Virgin Islands", "VN": "Vietnam", "WF": "Wallis and Futuna",
}
ALIASES = {
    "US": ["United States of America", "USA", "U.S.A.", "U.S.", "US", "America"],
    "GB": ["United Kingdom of Great Britain and Northern Ireland", "UK", "U.K.", "Great Britain", "Britain", "England"],
    "KR": ["Korea, Republic of", "Republic of Korea", "Korea", "Korea (South)"],
    "KP": ["Korea, Democratic People's Republic of", "Korea (North)"],
    "RU": ["Russian Federation"], "VN": ["Viet Nam"], "IR": ["Iran, Islamic Republic of"], "SY": ["Syrian Arab Republic"],
    "TW": ["Taiwan, Province of China", "Taiwan (ROC)"], "CZ": ["Czechia"], "NL": ["The Netherlands", "Netherlands, The",
    "Holland"], "AE": ["UAE", "U.A.E."], "TR": ["Turkiye", "Republic of Turkiye"], "MK": ["Macedonia"],
    "SZ": ["Swaziland"], "CV": ["Cabo Verde"], "LA": ["Lao People's Democratic Republic"], "MD": ["Moldova, Republic of"],
    "TZ": ["Tanzania, United Republic of"], "BO": ["Bolivia, Plurinational State of"],
    "VE": ["Venezuela, Bolivarian Republic of"], "CD": ["Congo, The Democratic Republic of the", "Congo (DRC)", "DR Congo"],
    "CG": ["Congo"], "PS": ["Palestine, State of", "Palestinian Territories"], "MO": ["Macao"], "HK": ["Hong Kong SAR"],
    "CI": ["Ivory Coast"], "BN": ["Brunei Darussalam"], "VA": ["Holy See", "Vatican"], "FM": ["Micronesia, Federated States of"],
    "IL": ["State of Israel"], "IE": ["Republic of Ireland"], "CN": ["China, People's Republic of", "People's Republic of China"],
}
_SMALL = {"and", "of", "the", "da", "de", "du", "la", "des", "et"}


def _title(n):
    return " ".join(w.lower() if i and w.lower() in _SMALL else w.capitalize() if w.isupper() or w.islower() else w
                    for i, w in enumerate(n.split()))


NAMES = {c: _NAMES.get(c) or _title(d["name"]) for c, d in _DATA.items()
         if len(c) == 2 and c.isalpha() and d.get("name") and c not in ("AC", "TA")}
COUNTRIES = sorted(NAMES.items(), key=lambda x: x[1])


def norm(s):
    s = unicodedata.normalize("NFKD", str(s or "")).encode("ascii", "ignore").decode()
    return " ".join(re.sub(r"[^a-z0-9+]+", " ", s.lower()).split())


def name(cc):
    return NAMES.get((cc or "").upper(), cc or "")


def code_of(text):
    t = norm(text)
    if not t:
        return None
    if len(t) == 2 and t.upper() in NAMES:
        return t.upper()
    for c, n in NAMES.items():
        if t == norm(n) or t in (norm(a) for a in ALIASES.get(c, [])):
            return c
    return None


_CODE_PART = re.compile(r"\(?\+\s?\d[\d\s-]*\)?")


def pick_country(options, cc):
    names = {norm(n) for n in [name(cc)] + ALIASES.get((cc or "").upper(), [])}
    plain = lambda o: norm(_CODE_PART.sub(" ", o))
    hits = [o for o in options if plain(o) in names]
    return min(hits, key=len) if hits else None


def pick_phone_code(options, region, calling_code):
    hit = pick_country(options, region)
    if hit:
        return hit
    exact = [o for o in options if norm(o) == f"+{calling_code}"]
    return exact[0] if len(exact) == 1 else None


_LATIN = re.compile(r"[A-Za-z]")
_AREA_LABEL = {"state": "State", "province": "Province", "prefecture": "Prefecture", "do_si": "Province",
               "county": "County", "island": "Island", "emirate": "Emirate", "department": "Department",
               "parish": "Parish", "oblast": "Region", "area": "Area", "district": "District"}


def _areas(choices):
    out, done = [], set()
    for k, v in choices:
        if not k or k in done:
            continue
        names = [v for kk, v in choices if kk == k and v and _LATIN.search(v)]
        code = _LATIN.search(k) and (len(k) <= 5 or "." in k)
        shown = (names[0] if names else None) if code or not _LATIN.search(k) else k
        if shown:
            done.add(k)
            out.append((k, shown))
    return out


def address_rules(cc):
    cc = (cc or "US").upper()
    r = i18naddress.get_validation_rules({"country_code": cc})
    if cc == "US":
        uniq = list(US_STATES)
    else:
        uniq = _areas(r.country_area_choices)
    kind = {"zip": "ZIP code", "pin": "PIN code", "eircode": "Eircode"}.get(r.postal_code_type, "Postal code")
    return {"country": cc, "name": name(cc), "areas": uniq,
            "area_label": _AREA_LABEL.get(r.country_area_type, "Region"),
            "area_required": "country_area" in r.required_fields and bool(uniq),
            "postal_label": kind, "postal_required": "postal_code" in r.required_fields,
            "postal_example": (r.postal_code_examples or [""])[0], "has_postal": bool(r.postal_code_matchers),
            "county": cc == "US"}


def check_postal(cc, v):
    rules = i18naddress.get_validation_rules({"country_code": (cc or "US").upper()})
    v = " ".join(str(v or "").upper().split())
    if not v:
        return v, None
    if (cc or "").upper() in ("GB", "CA", "IE") and " " not in v and 5 <= len(v) <= 7:
        v = f"{v[:-3]} {v[-3:]}"
    if not rules.postal_code_matchers or all(m.match(v) for m in rules.postal_code_matchers):
        return v, None
    ex = (rules.postal_code_examples or [""])[0]
    return v, f"a postal code like {ex}" if ex else "a postal code of this country"


def check_address(cc, street="", city="", region="", postal=""):
    cc = (cc or "US").upper()
    try:
        i18naddress.normalize_address({"country_code": cc, "street_address": street or "", "city": city or "",
                                       "country_area": region or "", "postal_code": postal or ""})
        return {}
    except i18naddress.InvalidAddressError as e:
        errs = e.errors
    except Exception:
        return {}
    r, out = address_rules(cc), {}
    where = name(cc) if not region else (dict(r["areas"]).get(region) or region)
    r = {**r, "postal_label": r["postal_label"] if r["postal_label"][:3] in ("ZIP", "PIN") else r["postal_label"].lower()}
    for f, why in errs.items():
        key = {"postal_code": "location.zip", "country_area": "location.state_code", "city": "location.city",
               "street_address": "location.street_address"}.get(f)
        if not key:
            continue
        if why == "required":
            out[key] = f"needed for an address in {name(cc)}"
        elif f == "postal_code":
            alone = not check_postal(cc, postal)[1]
            out[key] = (f"{postal} is not a {r['postal_label']} in {where}" if alone and region
                        else f"a {r['postal_label']} like {r['postal_example']}")
        elif f == "country_area":
            out[key] = f"a {r['area_label'].lower()} of {name(cc)}"
        else:
            out[key] = f"not a {f.replace('_', ' ')} in {where}"
    return out


def area(cc, v):
    t = norm(v)
    for k, n in address_rules(cc)["areas"]:
        if t in (norm(k), norm(n)):
            return k, n
    return None


def phone(text, cc="US"):
    t = str(text or "").strip()
    if t.startswith("00"):
        t = "+" + t[2:]
    try:
        p = phonenumbers.parse(t, (cc or "US").upper())
    except phonenumbers.NumberParseException:
        raise ValueError("a phone number with its area code") from None
    if not phonenumbers.is_valid_number(p):
        ex = phonenumbers.example_number_for_type((cc or "US").upper(), phonenumbers.PhoneNumberType.MOBILE)
        sample = phonenumbers.format_number(ex, phonenumbers.PhoneNumberFormat.NATIONAL) if ex else ""
        raise ValueError(f"not a valid {name(phonenumbers.region_code_for_number(p) or cc)} number"
                         + (f" - e.g. {sample}" if sample else ""))
    region = phonenumbers.region_code_for_number(p) or (cc or "US").upper()
    nat = phonenumbers.national_significant_number(p)
    if p.country_code == 1 and region == "US":
        display = f"+1-{nat[:3]}-{nat[3:6]}-{nat[6:]}"
    else:
        display = phonenumbers.format_number(p, phonenumbers.PhoneNumberFormat.INTERNATIONAL)
    return {"display": display, "e164": phonenumbers.format_number(p, phonenumbers.PhoneNumberFormat.E164),
            "calling_code": str(p.country_code), "national": nat, "region": region}
