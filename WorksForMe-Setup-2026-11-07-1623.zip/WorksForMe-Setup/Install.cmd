@echo off
if exist "%~dp0setup.ps1" if exist "%~dp0app\product\app.py" goto setup
if exist "%~dp0runtime\python.exe" goto install
echo Extract the zip first, then double-click Install.cmd
echo (right-click the zip - Extract All - then open the extracted folder)
pause
exit /b 1
:setup
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0setup.ps1"
exit /b 0
:install
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0install.ps1"
if errorlevel 1 pause
