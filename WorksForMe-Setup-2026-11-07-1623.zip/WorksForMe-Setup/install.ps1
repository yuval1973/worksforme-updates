param(
    [string]$Dest = "",
    [switch]$NoShortcuts,
    [switch]$NoStart,
    [switch]$Quiet
)
$ErrorActionPreference = "Stop"
$Here = Split-Path -Parent $MyInvocation.MyCommand.Path
$Name = (Get-Content (Join-Path $Here "NAME.txt") -Raw).Trim()
if (-not $Dest) { $Dest = Join-Path $env:LOCALAPPDATA "Programs\$Name" }
$Dest = [IO.Path]::GetFullPath($Dest).TrimEnd('\')
$Here = [IO.Path]::GetFullPath($Here).TrimEnd('\')
function Say($m) { Write-Host "[$Name] $m" }
function Folder($n) { [Environment]::GetFolderPath($n, 'Create') }
if ($Here -eq $Dest) { throw "run the installer from the unpacked package, not from the install folder $Dest" }

function Stop-Procs($procs) {
    $ids = @($procs | Where-Object { $_ } | ForEach-Object { $_.ProcessId })
    foreach ($id in $ids) { Stop-Process -Id $id -Force -ErrorAction SilentlyContinue }
    if ($ids) { try { Wait-Process -Id $ids -Timeout 20 -ErrorAction SilentlyContinue } catch { } }
}

function Get-EngineBrowser {
    $f = Join-Path $Dest "app\settings.json"
    if (-not (Test-Path $f)) { return }
    try { $bh = (Get-Content $f -Raw -Encoding UTF8 | ConvertFrom-Json).browser_home } catch { return }
    if (-not $bh) { return }
    $bh = [Environment]::ExpandEnvironmentVariables([string]$bh)
    if (-not [IO.Path]::IsPathRooted($bh)) { $bh = Join-Path (Join-Path $Dest "app") $bh }
    $rx = [Regex]::Escape([IO.Path]::GetFullPath($bh).TrimEnd('\')) + '(["\\\s]|$)'
    Get-CimInstance Win32_Process | Where-Object { $_.Name -in @("chrome.exe", "msedge.exe") -and $_.CommandLine -and $_.CommandLine -match $rx }
}

$inDest = "*" + [Management.Automation.WildcardPattern]::Escape("$Dest\") + "*"
Stop-Procs (Get-CimInstance Win32_Process | Where-Object { $_.ProcessId -ne $PID -and -not ($_.CommandLine -and $_.CommandLine -like "*updater.py*") -and (
                                                           ($_.Name -in @("python.exe", "pythonw.exe", "llama-server.exe", "soffice.exe", "soffice.bin") -and
                                                            $_.CommandLine -and $_.CommandLine -like $inDest) -or
                                                           ($_.ExecutablePath -and $_.ExecutablePath -like $inDest)) })
Stop-Procs (Get-EngineBrowser)

New-Item -ItemType Directory -Force $Dest | Out-Null
$data = @("settings.json", "applicant.json", "targets.json", "fit_cases.json", "applications.csv", "locations.json",
          "low_pay_companies.json", "parked_companies.json", "google_signin.json", "pay.json", "job_notes.json")
foreach ($part in @("runtime", "engine", "libreoffice", "app")) {
    $src = Join-Path $Here $part
    if (-not (Test-Path $src)) { continue }
    $dst = Join-Path $Dest $part
    $how = if ($part -eq "app") { "/E" } else { "/MIR" }
    $xf = if ($part -eq "app") { $data } else { @() }
    $xd = if ($part -eq "app") { @("runs") } else { @() }
    $rc = @($src, $dst, $how, "/NFL", "/NDL", "/NJH", "/NJS", "/NP", "/R:2", "/W:2")
    if ($xf) { $rc += "/XF"; $rc += $xf }
    if ($xd) { $rc += "/XD"; $rc += $xd }
    & robocopy @rc | Out-Null
    if ($LASTEXITCODE -ge 8) { throw "copy failed for $part (robocopy $LASTEXITCODE)" }
}
& robocopy (Join-Path $Here "app\templates") (Join-Path $Dest "app\templates") /E /NFL /NDL /NJH /NJS /NP /R:2 /W:2 | Out-Null
if ($LASTEXITCODE -ge 8) { throw "copy failed for the templates (robocopy $LASTEXITCODE)" }
Copy-Item (Join-Path $Here "NAME.txt") $Dest -Force
Copy-Item (Join-Path $Here "uninstall.ps1") $Dest -Force
if (Test-Path (Join-Path $Here "components.json")) { Copy-Item (Join-Path $Here "components.json") $Dest -Force }
Copy-Item (Join-Path $Here "install.ps1") $Dest -Force
Say "program files in $Dest"
if (Get-Item -LiteralPath (Join-Path $Here "install.ps1") -Stream Zone.Identifier -ErrorAction SilentlyContinue) {
    $items = @(@("runtime", "engine") | ForEach-Object { Join-Path $Dest $_ } | Where-Object { Test-Path $_ })
    $items += @(Get-ChildItem -LiteralPath (Join-Path $Dest "app") -Force | Where-Object { $_.Name -ne "runs" } | ForEach-Object { $_.FullName })
    $items += @(Get-ChildItem -LiteralPath $Dest -File -Force | ForEach-Object { $_.FullName })
    Get-ChildItem -LiteralPath $items -Recurse -File -Force -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
    Say "program files unblocked (they came from a downloaded zip)"
}

$py = Join-Path $Dest "runtime\python.exe"
$pyw = Join-Path $Dest "runtime\pythonw.exe"
& $py -E -s (Join-Path $Dest "app\product\first_run.py") $Dest $Name

if (-not $NoShortcuts) {
    $ws = New-Object -ComObject WScript.Shell
    $tray = Join-Path $Dest "app\product\tray.pyw"
    $icon = Join-Path $Dest "app\product\icon.ico"
    $menuPath = Join-Path (Folder "Programs") "$Name.lnk"
    $bootPath = Join-Path (Folder "Startup") "$Name tray.lnk"
    if (-not $Quiet -or (Test-Path $menuPath)) {
        $menu = $ws.CreateShortcut($menuPath)
        $menu.TargetPath = $pyw; $menu.Arguments = "-E -s `"$tray`" --open"; $menu.WorkingDirectory = (Join-Path $Dest "app")
        $menu.IconLocation = $icon; $menu.Description = "$Name - your job search assistant"; $menu.Save()
    }
    if (-not $Quiet -or (Test-Path $bootPath)) {
        $boot = $ws.CreateShortcut($bootPath)
        $boot.TargetPath = $pyw; $boot.Arguments = "-E -s `"$tray`""; $boot.WorkingDirectory = (Join-Path $Dest "app")
        $boot.IconLocation = $icon; $boot.Save()
    }
    $key = Join-Path "HKCU:\Software\Microsoft\Windows\CurrentVersion\Uninstall" (& { param($d) "$Name-" + ([BitConverter]::ToString(
        [Security.Cryptography.SHA1]::Create().ComputeHash([Text.Encoding]::UTF8.GetBytes($d.ToLower()))) -replace "-", "").Substring(0, 8) } $Dest)
    if (-not $Quiet -or (Test-Path $key)) {
        New-Item -Path $key -Force | Out-Null
        $ver = (Get-Content (Join-Path $Dest "app\VERSION.txt") -Raw).Trim() -replace "^\S+\s+", ""
        $kb = [int]((Get-ChildItem $Dest -Recurse -File -Force -ErrorAction SilentlyContinue | Measure-Object Length -Sum).Sum / 1KB)
        $props = [ordered]@{ DisplayName = $Name; DisplayVersion = $ver; Publisher = $Name; InstallLocation = $Dest; DisplayIcon = $icon
                             UninstallString = "powershell.exe -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $Dest 'uninstall.ps1')`" -FromApps" }
        foreach ($k in $props.Keys) { New-ItemProperty -Path $key -Name $k -Value $props[$k] -PropertyType String -Force | Out-Null }
        foreach ($k in @{ NoModify = 1; NoRepair = 1; EstimatedSize = $kb }.GetEnumerator()) {
            New-ItemProperty -Path $key -Name $k.Key -Value $k.Value -PropertyType DWord -Force | Out-Null
        }
    }
    Say "Start-menu shortcut + tray at logon + Settings > Apps entry"
}

if (-not $NoStart) {
    $open = if ($Quiet) { "" } else { " --open" }
    Start-Process -FilePath $pyw -ArgumentList "-E -s `"$(Join-Path $Dest 'app\product\tray.pyw')`"$open" -WorkingDirectory (Join-Path $Dest "app")
    $agent = Join-Path (Folder "Startup") "$Name daily run.lnk"
    if (Test-Path $agent) { Start-Process $agent }
    Say "started - the icon is in the notification area"
}
